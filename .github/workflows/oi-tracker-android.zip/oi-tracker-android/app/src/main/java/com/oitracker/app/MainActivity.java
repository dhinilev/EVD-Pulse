package com.oitracker.app;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    static final String CH_ALERTS = "alerts";
    static final String CH_TRACKING = "tracking";

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final AtomicInteger notifId = new AtomicInteger(100);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannels(this);
        // NSE/BSE need session cookies: keep them across requests (in memory).
        if (!(CookieHandler.getDefault() instanceof CookieManager)) {
            CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
        }

        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#0E1116"));
        w.setNavigationBarColor(Color.parseColor("#161B22"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0E1116"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    // Keep running when the user presses Back, so tracking continues in the background.
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        // The tracking runs inside this screen's WebView, so stop the background service with it.
        if (isFinishing()) stopService(new Intent(this, TrackService.class));
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        pool.shutdownNow();
        super.onDestroy();
    }

    static void createChannels(Context ctx) {
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        NotificationChannel a = new NotificationChannel(CH_ALERTS, "OI alerts", NotificationManager.IMPORTANCE_HIGH);
        a.setDescription("PCR, OI spike and support/resistance alerts");
        a.enableVibration(true);
        nm.createNotificationChannel(a);
        NotificationChannel t = new NotificationChannel(CH_TRACKING, "Background tracking", NotificationManager.IMPORTANCE_LOW);
        t.setDescription("Shown while the app tracks the option chain in the background");
        nm.createNotificationChannel(t);
    }

    private PendingIntent openAppIntent() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static String jsString(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    /** Methods callable from JavaScript as window.Android.* */
    class Bridge {

        /** HTTP request done natively (no browser CORS limits). Result goes to window.__httpCb(id, status, base64Body). */
        @JavascriptInterface
        public void http(final String id, final String method, final String url, final String headersJson, final String body) {
            pool.execute(() -> {
                int status = 0;
                String b64;
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method);
                    c.setInstanceFollowRedirects(true);
                    c.setUseCaches(false);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(20000);
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> keys = h.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                    if (body != null && !body.isEmpty() && !"GET".equals(method)) {
                        c.setDoOutput(true);
                        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                        c.setFixedLengthStreamingMode(bytes.length);
                        try (OutputStream os = c.getOutputStream()) {
                            os.write(bytes);
                        }
                    }
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    byte[] data = in == null ? new byte[0] : readAll(in);
                    b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                } catch (Exception e) {
                    status = 0;
                    String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
                    b64 = Base64.encodeToString(msg.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.__httpCb && window.__httpCb(" + jsString(id) + "," + status + "," + jsString(b64) + ")";
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript(js, null);
                });
            });
        }

        /** SHA-256 hex of a UTF-8 string (Flattrade token exchange). */
        @JavascriptInterface
        public String sha256(String s) {
            try {
                byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b));
                return sb.toString();
            } catch (Exception e) {
                return "";
            }
        }

        /**
         * Opens the broker login page in a full-screen dialog. When the page redirects to
         * redirectPrefix, the "code" and "client" query values are handed to window.__ftCode(code, client).
         */
        @JavascriptInterface
        public void ftLogin(final String url, final String redirectPrefix) {
            runOnUiThread(() -> {
                final Dialog d = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                final WebView w = new WebView(MainActivity.this);
                final boolean[] done = {false};
                WebSettings ws = w.getSettings();
                ws.setJavaScriptEnabled(true);
                ws.setDomStorageEnabled(true);
                w.setWebViewClient(new WebViewClient() {
                    private boolean handle(String u) {
                        if (u == null || !u.startsWith(redirectPrefix)) return false;
                        if (!done[0]) {
                            done[0] = true;
                            Uri uri = Uri.parse(u);
                            final String js = "window.__ftCode && window.__ftCode(" + jsString(uri.getQueryParameter("code"))
                                    + "," + jsString(uri.getQueryParameter("client")) + ")";
                            if (web != null) web.evaluateJavascript(js, null);
                            d.dismiss();
                        }
                        return true;
                    }
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                        return handle(req.getUrl().toString());
                    }
                    @Override
                    public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                        if (handle(u)) v.stopLoading();
                    }
                });
                d.setContentView(w);
                d.setOnDismissListener(x -> {
                    if (!done[0] && web != null) web.evaluateJavascript("window.__ftCode && window.__ftCode('', '')", null);
                    w.destroy();
                });
                d.show();
                w.loadUrl(url);
            });
        }

        @JavascriptInterface
        public void notify(String title, String text) {
            Notification n = new Notification.Builder(MainActivity.this, CH_ALERTS)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true)
                    .setContentIntent(openAppIntent())
                    .build();
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            nm.notify(notifId.incrementAndGet(), n);
        }

        @JavascriptInterface
        public void setBackground(boolean on) {
            Intent i = new Intent(MainActivity.this, TrackService.class);
            if (on) {
                startForegroundService(i);
            } else {
                stopService(i);
            }
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void openBatterySettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception ignored) { }
                }
            });
        }
    }

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }
}
