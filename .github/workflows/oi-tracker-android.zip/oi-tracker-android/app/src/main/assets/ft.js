/* EVD Pulse — Flattrade live data (Pi API, Noren-style). Login once a day, then a websocket streams ticks. */
(function (root) {
  'use strict';

  const AUTH = 'https://auth.flattrade.in/?app_key=';
  const TOKEN_URL = 'https://authapi.flattrade.in/trade/apitoken';
  const REST = 'https://piconnect.flattrade.in/PiConnectAPI';
  const WS_URL = 'wss://piconnect.flattrade.in/PiConnectWSAPI/';
  const REDIRECT = 'https://127.0.0.1/evdplan';
  const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const CFG = {
    NIFTY: { exch: 'NFO', spot: 'NSE|26000', step: 50 },
    SENSEX: { exch: 'BFO', spot: 'BSE|1', step: 100 },
  };

  function createFT(deps) {
    const { http, store, Core, sha256, openLogin } = deps;
    const C = Core;
    const ft = {
      REDIRECT,
      cfg: Object.assign({ uid: '', key: '', secret: '' }, store.get('oi.ft.cfg', {})),
      sess: store.get('oi.ft.sess', null),      // {token, uid, at}
      live: {},                                  // "EXCH|token" -> {lp, c, oi, poi, v, ts}
      subs: {},                                  // index -> {iso, center, exch, tokens:[{k, strike, optt}]}
      fut: null,                                 // {k, tsym, iso}
      ws: null, wsState: 'off', wsWanted: new Set(), lastTick: 0,
      diag: [], err: null,
    };

    function log(what, detail) {
      ft.diag.unshift({ at: Date.now(), what, detail: String(detail || '').slice(0, 500) });
      ft.diag.length = Math.min(ft.diag.length, 12);
    }

    // ---- session ----------------------------------------------------------
    // Tokens expire daily at 5:00 AM IST.
    function lastReset(now) {
      const p = C.istParts(now);
      const todayReset = Date.UTC(p.y, p.mo - 1, p.d, 5, 0) - 5.5 * 3600e3;
      return now >= todayReset ? todayReset : todayReset - 86400e3;
    }
    ft.configured = () => !!(ft.cfg.uid && ft.cfg.key && ft.cfg.secret);
    ft.ready = () => !!(ft.sess && ft.sess.token && ft.sess.at >= lastReset(Date.now()));
    ft.saveCfg = (cfg) => { ft.cfg = Object.assign({}, ft.cfg, cfg); store.set('oi.ft.cfg', ft.cfg); };
    ft.logout = () => { ft.sess = null; store.set('oi.ft.sess', null); closeWs(); };

    ft.login = function () {
      return new Promise((resolve, reject) => {
        if (!ft.configured()) { reject({ msg: 'Enter your Flattrade client ID, API key and secret first.' }); return; }
        root.__ftCode = async (code, client) => {
          root.__ftCode = null;
          if (!code) { reject({ msg: 'Login cancelled.' }); return; }
          try {
            const hash = sha256(ft.cfg.key + code + ft.cfg.secret);
            const r = await http('POST', TOKEN_URL, { 'Content-Type': 'application/json', 'Accept': 'application/json' },
              JSON.stringify({ api_key: ft.cfg.key, request_code: code, api_secret: hash }));
            log('apitoken HTTP ' + r.status, r.text);
            let j = null; try { j = JSON.parse(r.text); } catch (e) { }
            if (!j || !j.token) { reject({ msg: 'Flattrade login failed: ' + ((j && (j.emsg || j.message)) || ('HTTP ' + r.status)) }); return; }
            ft.sess = { token: j.token, uid: (j.client || client || ft.cfg.uid).toUpperCase(), at: Date.now() };
            store.set('oi.ft.sess', ft.sess);
            ft.subs = {}; ft.fut = null; ft.err = null;
            resolve(ft.sess);
          } catch (e) { reject({ msg: 'Flattrade login error: ' + e }); }
        };
        openLogin(AUTH + encodeURIComponent(ft.cfg.key), REDIRECT);
      });
    };

    // ---- REST (jData + jKey form body) -----------------------------------
    async function rest(path, values) {
      if (!ft.ready()) throw { msg: 'Flattrade: log in for today first (Settings).', login: true };
      const body = 'jData=' + JSON.stringify(Object.assign({ uid: ft.sess.uid }, values)) + '&jKey=' + ft.sess.token;
      const r = await http('POST', REST + path, { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }, body);
      let j = null; try { j = JSON.parse(r.text); } catch (e) { }
      log(path + ' HTTP ' + r.status, r.text);
      if (j && /session expired|invalid session|not logged/i.test(String(j.emsg || ''))) {
        ft.logout(); throw { msg: 'Flattrade session expired: log in again in Settings.', login: true };
      }
      if (!j) throw { msg: `Flattrade ${path}: no response (HTTP ${r.status}).` };
      return j;
    }
    const okList = j => (Array.isArray(j) ? j : (j && j.stat === 'Ok' && Array.isArray(j.values) ? j.values : []));

    // ---- websocket ---------------------------------------------------------
    function closeWs() { try { if (ft.ws) ft.ws.close(); } catch (e) { } ft.ws = null; ft.wsState = 'off'; }
    function openWs() {
      if (!ft.ready() || (ft.ws && (ft.wsState === 'open' || ft.wsState === 'connecting'))) return;
      ft.wsState = 'connecting';
      let ws;
      try { ws = new WebSocket(WS_URL); } catch (e) { ft.wsState = 'error'; log('ws error', e); return; }
      ft.ws = ws;
      ws.onopen = () => ws.send(JSON.stringify({ t: 'c', uid: ft.sess.uid, actid: ft.sess.uid, susertoken: ft.sess.token, source: 'API' }));
      ws.onmessage = ev => {
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === 'ck') {
          log('ws connect', ev.data);
          if (String(m.s).toUpperCase() === 'OK') { ft.wsState = 'open'; sendSub([...ft.wsWanted]); }
          else { ft.wsState = 'error'; }
          return;
        }
        if (m.t === 'tk' || m.t === 'tf' || m.t === 'dk' || m.t === 'df') {
          const k = (m.e || '') + '|' + m.tk;
          const x = ft.live[k] || (ft.live[k] = {});
          for (const f of ['lp', 'c', 'oi', 'poi', 'v', 'pc']) if (m[f] !== undefined && m[f] !== '') x[f] = parseFloat(m[f]);
          x.ts = Date.now(); ft.lastTick = x.ts;
        }
      };
      ws.onerror = () => { ft.wsState = 'error'; log('ws error', 'connection error'); };
      ws.onclose = () => { if (ft.ws === ws) { ft.ws = null; ft.wsState = 'off'; setTimeout(openWs, 3000); } };
    }
    function sendSub(keys) {
      if (!keys.length || !ft.ws || ft.wsState !== 'open') return;
      for (let i = 0; i < keys.length; i += 40) ft.ws.send(JSON.stringify({ t: 't', k: keys.slice(i, i + 40).join('#') }));
    }
    function want(keys) {
      const fresh = keys.filter(k => !ft.wsWanted.has(k));
      fresh.forEach(k => ft.wsWanted.add(k));
      openWs(); sendSub(fresh);
    }

    // ---- option chain for one expiry ---------------------------------------
    function tsym(index, iso, strike, opt) {   // e.g. NIFTY06OCT26C25000
      const [y, m, d] = iso.split('-');
      return `${index}${d}${MON[+m - 1]}${y.slice(2)}${opt}${Math.round(strike)}`;
    }
    ft.prepare = async function (index, iso, spotHint) {
      const cfg = CFG[index];
      const spot = ft.spot(index) || spotHint;
      if (!spot) return false;
      const center = Math.round(spot / cfg.step) * cfg.step;
      const cur = ft.subs[index];
      if (cur && cur.iso === iso && Math.abs(cur.center - center) <= cfg.step * 6) return true;
      let vals = okList(await rest('/GetOptionChain', { exch: cfg.exch, tsym: tsym(index, iso, center, 'C'), strprc: String(center), cnt: '15' }));
      if (!vals.length) {   // symbol format differs: find one real contract of this expiry by search
        const [y, m, d] = iso.split('-');
        const found = okList(await rest('/SearchScrip', { exch: cfg.exch, stext: `${index} ${d}${MON[+m - 1]} ${center}` }));
        const pick = found.find(v => /C/i.test(String(v.optt || '')) || /C\d+$|CE$/.test(String(v.tsym || ''))) || found[0];
        if (pick) vals = okList(await rest('/GetOptionChain', { exch: cfg.exch, tsym: pick.tsym, strprc: String(center), cnt: '15' }));
      }
      if (!vals.length) throw { msg: `Flattrade: couldn't load the ${index} ${iso} option chain.` };
      const tokens = vals.map(v => ({ k: (v.exch || cfg.exch) + '|' + v.token, strike: parseFloat(v.strprc), optt: /^P/i.test(String(v.optt)) ? 'PE' : 'CE' }))
        .filter(t => isFinite(t.strike));
      ft.subs[index] = { iso, center, exch: cfg.exch, tokens };
      want([cfg.spot, ...tokens.map(t => t.k)]);
      return true;
    };
    ft.spot = index => { const x = ft.live[CFG[index].spot]; return x && x.lp > 0 ? x.lp : 0; };
    ft.hasChain = (index, iso) => { const s = ft.subs[index]; return !!(s && s.iso === iso && s.tokens.some(t => ft.live[t.k] && ft.live[t.k].ts)); };
    /** {spot, rows} in the same shape as the NSE/BSE parsers produce. */
    ft.chain = function (index, iso, spotHint) {
      const s = ft.subs[index];
      if (!s || s.iso !== iso) return { spot: 0, rows: [] };
      const by = new Map();
      for (const t of s.tokens) {
        const x = ft.live[t.k]; if (!x || !x.ts) continue;
        const row = by.get(t.strike) || { strike: t.strike, ce: blank(), pe: blank() };
        const oi = x.oi || 0, poi = isFinite(x.poi) ? x.poi : oi, lp = x.lp || 0;
        row[t.optt === 'PE' ? 'pe' : 'ce'] = { oi, poi, ltp: lp, pc: isFinite(x.c) ? x.c : lp, iv: 0, vol: x.v || 0 };
        by.set(t.strike, row);
      }
      const rows = [...by.values()].filter(r => r.ce.oi > 0 || r.pe.oi > 0 || r.ce.ltp > 0 || r.pe.ltp > 0).sort((a, b) => a.strike - b.strike);
      return { spot: ft.spot(index) || spotHint || 0, rows };
    };
    const blank = () => ({ oi: 0, poi: 0, ltp: 0, pc: 0, iv: 0, vol: 0 });

    // ---- NIFTY futures (current month) -------------------------------------
    ft.prepareFut = async function () {
      const today = C.istDate(Date.now());
      if (ft.fut && ft.fut.iso >= today) { want([ft.fut.k]); return true; }
      const vals = okList(await rest('/SearchScrip', { exch: 'NFO', stext: 'NIFTY FUT' }));
      const futs = vals.map(v => {
        const m = /^NIFTY(\d{2})([A-Z]{3})(\d{2})F$/.exec(String(v.tsym || ''));
        if (!m || MON.indexOf(m[2]) < 0) return null;
        return { k: 'NFO|' + v.token, tsym: v.tsym, iso: `20${m[3]}-${String(MON.indexOf(m[2]) + 1).padStart(2, '0')}-${m[1]}` };
      }).filter(Boolean).filter(f => f.iso >= today).sort((a, b) => a.iso < b.iso ? -1 : 1);
      if (!futs.length) throw { msg: 'Flattrade: NIFTY futures contract not found.' };
      ft.fut = futs[0];
      want([ft.fut.k, CFG.NIFTY.spot]);
      return true;
    };
    ft.futQuote = function () {
      if (!ft.fut) return null;
      const x = ft.live[ft.fut.k];
      if (!x || !(x.lp > 0)) return null;
      return { iso: ft.fut.iso, ltp: x.lp, prevClose: isFinite(x.c) ? x.c : NaN, oi: isFinite(x.oi) ? x.oi : NaN,
               oiChg: isFinite(x.oi) && isFinite(x.poi) ? x.oi - x.poi : NaN, underlying: ft.spot('NIFTY') };
    };

    ft.status = function () {
      if (!ft.configured()) return 'Not set up';
      if (!ft.ready()) return 'Not logged in today';
      if (ft.wsState === 'open') return ft.lastTick ? `Live · last tick ${C.istTime(ft.lastTick, true)}` : 'Connected · waiting for ticks';
      return ft.wsState === 'error' ? 'Live feed error · retrying' : 'Connecting…';
    };
    if (ft.ready()) openWs();
    return ft;
  }

  root.createFT = createFT;
})(typeof window !== 'undefined' ? window : globalThis);
