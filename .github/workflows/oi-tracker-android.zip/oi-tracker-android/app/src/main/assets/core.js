/* OI Tracker — core logic (no UI). Works in the Android WebView and in Node for tests. */
(function (root) {
  'use strict';

  const INDICES = {
    NIFTY:  { id: 13, seg: 'IDX_I', step: 50, src: 'NSE' },
    SENSEX: { id: 51, seg: 'IDX_I', step: 100, src: 'BSE' },
  };

  // ---------- time (always IST, whatever the phone's timezone) ----------
  function istParts(ms) {
    const d = new Date(ms + 5.5 * 3600 * 1000);
    return { y: d.getUTCFullYear(), mo: d.getUTCMonth() + 1, d: d.getUTCDate(),
             h: d.getUTCHours(), mi: d.getUTCMinutes(), s: d.getUTCSeconds(), wd: d.getUTCDay() };
  }
  const pad = n => String(n).padStart(2, '0');
  function istDate(ms) { const p = istParts(ms); return `${p.y}-${pad(p.mo)}-${pad(p.d)}`; }
  function istTime(ms, secs) { const p = istParts(ms); return `${pad(p.h)}:${pad(p.mi)}` + (secs ? `:${pad(p.s)}` : ''); }
  function marketOpen(ms) {
    const p = istParts(ms);
    if (p.wd === 0 || p.wd === 6) return false;
    const m = p.h * 60 + p.mi;
    return m >= 9 * 60 + 14 && m <= 15 * 60 + 32;
  }

  // ---------- parsing & analytics ----------
  function side(o) {
    o = o || {};
    return { oi: +o.oi || 0, poi: +o.previous_oi || 0, ltp: +o.last_price || 0,
             pc: +o.previous_close_price || 0, iv: +o.implied_volatility || 0, vol: +o.volume || 0 };
  }

  function parseChain(resp) {
    const data = (resp && resp.data) || {};
    const spot = +data.last_price || 0;
    const rows = [];
    for (const [k, v] of Object.entries(data.oc || {})) {
      const ce = side(v.ce), pe = side(v.pe);
      if (ce.oi > 0 || pe.oi > 0) rows.push({ strike: parseFloat(k), ce, pe });
    }
    rows.sort((a, b) => a.strike - b.strike);
    return { spot, rows };
  }

  function sum(rows, f) { let s = 0; for (const r of rows) s += f(r); return s; }

  function pcr(rows) { const c = sum(rows, r => r.ce.oi); return c ? sum(rows, r => r.pe.oi) / c : NaN; }

  function maxPain(rows) {
    let best = NaN, bestPain = Infinity;
    for (const k of rows) {
      let pain = 0;
      for (const r of rows) {
        if (k.strike > r.strike) pain += r.ce.oi * (k.strike - r.strike);
        if (k.strike < r.strike) pain += r.pe.oi * (r.strike - k.strike);
      }
      if (pain < bestPain) { bestPain = pain; best = k.strike; }
    }
    return best;
  }

  function argmax(rows, f) {
    let best = null, bv = -Infinity;
    for (const r of rows) { const v = f(r); if (v > bv) { bv = v; best = r; } }
    return best ? best.strike : NaN;
  }

  const NEAR = 5;   // ATM ± 5 strikes for the hero-zero totals
  function nearTotals(rows, spot) {
    const w = windowRows(rows, spot, NEAR);
    let ce = 0, pe = 0;
    for (const r of w) { ce += r.ce.oi - r.ce.poi; pe += r.pe.oi - r.pe.poi; }
    return { ce, pe };
  }

  function makeSnap(ts, spot, rows) {
    const nt = rows.length ? nearTotals(rows, spot) : { ce: 0, pe: 0 };
    return {
      ts, spot, rows, nearCe: nt.ce, nearPe: nt.pe,
      pcr: pcr(rows), mp: maxPain(rows),
      sup: argmax(rows, r => r.pe.oi), res: argmax(rows, r => r.ce.oi),
      tce: sum(rows, r => r.ce.oi), tpe: sum(rows, r => r.pe.oi),
    };
  }

  function summary(s) {
    return { ts: s.ts, spot: s.spot, pcr: s.pcr, mp: s.mp, sup: s.sup, res: s.res, tce: s.tce, tpe: s.tpe, nce: s.nearCe, npe: s.nearPe };
  }

  function buildup(dp, doi) {
    if (Math.abs(doi) < 1 || Math.abs(dp) < 0.01) return '';
    if (dp > 0 && doi > 0) return 'Long buildup';
    if (dp < 0 && doi > 0) return 'Short buildup';
    if (dp > 0 && doi < 0) return 'Short covering';
    return 'Long unwinding';
  }

  /** Current chain with change fields. base = null means vs previous day's close. */
  function compare(cur, base) {
    const bmap = new Map();
    if (base) for (const r of base.rows) bmap.set(r.strike, r);
    return cur.rows.map(r => {
      const b = bmap.get(r.strike);
      const out = { strike: r.strike };
      for (const sd of ['ce', 'pe']) {
        const x = r[sd];
        const bOi = base ? (b ? b[sd].oi : x.oi) : x.poi;
        const bLtp = base ? (b ? b[sd].ltp : x.ltp) : x.pc;
        const doi = x.oi - bOi, dltp = x.ltp - bLtp;
        out[sd] = Object.assign({}, x, {
          doi, dltp, doiPct: bOi ? (doi / bOi) * 100 : 0, bu: buildup(dltp, doi),
        });
      }
      return out;
    });
  }

  function atmIndex(rows, spot) {
    let bi = 0, bd = Infinity;
    rows.forEach((r, i) => { const d = Math.abs(r.strike - spot); if (d < bd) { bd = d; bi = i; } });
    return bi;
  }

  function windowRows(rows, spot, n) {
    if (!rows.length) return rows;
    const i = atmIndex(rows, spot);
    return rows.slice(Math.max(0, i - n), i + n + 1);
  }

  /** hist: full snapshots (oldest first). first: first snapshot of the day (may be older than hist[0]). */
  function baseline(hist, first, win) {
    if (win === 'prev' || !hist.length) return null;
    if (win === 'open') return first || hist[0];
    const cutoff = hist[hist.length - 1].ts - (+win) * 60000;
    let pick = null;
    for (const s of hist) if (s.ts <= cutoff + 5000) pick = s;
    return pick || hist[0];
  }

  // ---------- alerts ----------
  const DEFAULT_SETTINGS = {
    strikes: 10,
    pcrAlerts: true, pcrHigh: 1.3, pcrLow: 0.7,
    levelAlerts: true,
    spikeAlerts: true, spikePct: 20, spikeWin: 5, spikeShare: 3,
    cooldown: 15,
    notify: true,
    heroMin: 5, heroMax: 30, heroDrop: 80, heroStart: 13 * 60 + 30,
    source: 'exchange',
  };

  function fmtL(x) { return (x / 1e5).toLocaleString('en-IN', { maximumFractionDigits: 1, minimumFractionDigits: 1 }) + ' L'; }
  function fmtStrike(x) { return Math.round(x).toLocaleString('en-IN'); }

  /**
   * Returns new alerts for the latest snapshot. `cool` is a {key: lastMs} map that is updated in place.
   */
  function checkAlerts(index, expiry, hist, S, cool) {
    const out = [];
    if (hist.length < 2) return out;
    const cur = hist[hist.length - 1], prev = hist[hist.length - 2];
    const now = cur.ts;
    const cd = S.cooldown * 60000;
    const raise = (kind, key, msg) => {
      const k = `${index}|${expiry}|${key}`;
      if (cool[k] && now - cool[k] < cd) return;
      cool[k] = now;
      out.push({ ts: now, index, expiry, kind, msg });
    };

    if (S.pcrAlerts && isFinite(cur.pcr) && isFinite(prev.pcr)) {
      if (prev.pcr < S.pcrHigh && cur.pcr >= S.pcrHigh)
        raise('PCR', 'pcrHigh', `PCR rose above ${S.pcrHigh.toFixed(2)} (now ${cur.pcr.toFixed(2)}): put writers getting stronger`);
      if (prev.pcr > S.pcrLow && cur.pcr <= S.pcrLow)
        raise('PCR', 'pcrLow', `PCR fell below ${S.pcrLow.toFixed(2)} (now ${cur.pcr.toFixed(2)}): call writers getting stronger`);
    }

    if (S.levelAlerts) {
      if (cur.sup !== prev.sup)
        raise('Support', 'sup' + cur.sup, `Support shifted ${fmtStrike(prev.sup)} → ${fmtStrike(cur.sup)} (highest Put OI)`);
      if (cur.res !== prev.res)
        raise('Resistance', 'res' + cur.res, `Resistance shifted ${fmtStrike(prev.res)} → ${fmtStrike(cur.res)} (highest Call OI)`);
      if (cur.mp !== prev.mp)
        raise('Max pain', 'mp' + cur.mp, `Max pain moved ${fmtStrike(prev.mp)} → ${fmtStrike(cur.mp)}`);
    }

    const p = istParts(now);
    if (S.spikeAlerts && (p.h > 9 || (p.h === 9 && p.mi >= 20))) {
      const base = baseline(hist, null, String(S.spikeWin));
      if (base && base !== cur && cur.ts - base.ts >= (S.spikeWin - 1) * 60000) {
        const rows = windowRows(compare(cur, base), cur.spot, S.strikes);
        let top = 1;
        for (const r of cur.rows) top = Math.max(top, r.ce.oi, r.pe.oi);
        let hits = [];
        for (const r of rows) for (const sd of ['ce', 'pe']) {
          const x = r[sd];
          if (Math.abs(x.doiPct) >= S.spikePct && Math.abs(x.doi) / top * 100 >= S.spikeShare)
            hits.push({ strike: r.strike, sd, x });
        }
        hits.sort((a, b) => Math.abs(b.x.doi) - Math.abs(a.x.doi));
        hits = hits.filter(h => {
          const k = `${index}|${expiry}|spike${h.sd}${h.strike}`;
          return !(cool[k] && now - cool[k] < cd);
        });
        if (hits.length) {
          hits.forEach(h => { cool[`${index}|${expiry}|spike${h.sd}${h.strike}`] = now; });
          const parts = hits.slice(0, 3).map(h =>
            `${fmtStrike(h.strike)} ${h.sd.toUpperCase()} ${h.x.doi > 0 ? '+' : '−'}${fmtQ(Math.abs(h.x.doi))} (${h.x.doiPct > 0 ? '+' : ''}${h.x.doiPct.toFixed(0)}%)${h.x.bu ? ' ' + h.x.bu : ''}`);
          out.push({ ts: now, index, expiry, kind: 'OI spike',
                     msg: `Sharp OI change in ${S.spikeWin} min: ${parts.join(' · ')}${hits.length > 3 ? ` +${hits.length - 3} more` : ''}` });
        }
      }
    }
    return out;
  }

  // ---------- demo data (for trying the app without a token) ----------
  function makeDemo(seed) {
    let s = seed || 7;
    const rnd = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    const gauss = () => { let u = 0, v = 0; while (!u) u = rnd(); while (!v) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
    const spot = { NIFTY: 25150, SENSEX: 82300 };
    const books = {};
    const N = x => 0.5 * (1 + erf(x / Math.SQRT2));
    function erf(x) { const t = 1 / (1 + 0.3275911 * Math.abs(x)); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; }
    function bs(S0, K, t, v, call) {
      if (t <= 0) return Math.max(0, call ? S0 - K : K - S0);
      const d1 = (Math.log(S0 / K) + 0.5 * v * v * t) / (v * Math.sqrt(t)), d2 = d1 - v * Math.sqrt(t);
      return Math.max(0.05, call ? S0 * N(d1) - K * N(d2) : K * N(-d2) - S0 * N(-d1));
    }
    return {
      expiryList(index, nowMs) {
        const wd = istParts(nowMs).wd, target = index === 'NIFTY' ? 2 : 4; // Tue / Thu
        const days = (target - wd + 7) % 7;
        const out = [];
        for (let i = 0; i < 4; i++) out.push(istDate(nowMs + (days + 7 * i) * 86400000));
        return out;
      },
      optionChain(index, expiry, nowMs) {
        const step = INDICES[index].step;
        spot[index] *= 1 + gauss() * 0.0012;
        const S0 = spot[index], key = index + expiry;
        const atm = Math.round(S0 / step) * step;
        if (!books[key]) {
          const b = {};
          for (let k = -40; k <= 40; k++) {
            const K = atm + k * step, round = K % (step * 10) === 0 ? 1.6 : 1;
            const ce = 6e6 * Math.exp(-((k - 4) ** 2) / 120) * round, pe = 6e6 * Math.exp(-((k + 4) ** 2) / 120) * round;
            b[K] = { ce: ce * (0.7 + 0.6 * rnd()), pe: pe * (0.7 + 0.6 * rnd()), cep: ce * (0.6 + 0.5 * rnd()), pep: pe * (0.6 + 0.5 * rnd()), cpc: null, ppc: null };
          }
          books[key] = b;
        }
        const dte = Math.max(0, (Date.parse(expiry + 'T10:00:00Z') - nowMs) / 86400000) + 0.3;
        const t = dte / 365, vol = index === 'NIFTY' ? 0.12 : 0.13;
        const oc = {};
        for (const [K, d] of Object.entries(books[key])) {
          for (const sd of ['ce', 'pe']) {
            let drift = 0.003 + gauss() * 0.012;
            if (rnd() < 0.0015) drift += rnd() < 0.6 ? 0.3 : -0.2;
            d[sd] = Math.max(0, d[sd] * (1 + drift));
          }
          const cpx = bs(S0, +K, t, vol, true), ppx = bs(S0, +K, t, vol, false);
          if (d.cpc === null) { d.cpc = cpx * (0.8 + 0.4 * rnd()); d.ppc = ppx * (0.8 + 0.4 * rnd()); }
          oc[(+K).toFixed(6)] = {
            ce: { oi: Math.round(d.ce), previous_oi: Math.round(d.cep), last_price: +cpx.toFixed(2), previous_close_price: +d.cpc.toFixed(2), implied_volatility: vol * 100, volume: Math.round(d.ce * 8) },
            pe: { oi: Math.round(d.pe), previous_oi: Math.round(d.pep), last_price: +ppx.toFixed(2), previous_close_price: +d.ppc.toFixed(2), implied_volatility: vol * 100 + 1.5, volume: Math.round(d.pe * 8) },
          };
        }
        return { data: { last_price: +S0.toFixed(2), oc }, status: 'success' };
      },
    };
  }

  // ---------- quantity formatting (NSE/BSE report OI in contracts) ----------
  function fmtQ(x) {
    if (!isFinite(x)) return '–';
    const a = Math.abs(x), s = x < 0 ? '−' : '';
    if (a >= 1e7) return s + (a / 1e7).toFixed(2) + 'Cr';
    if (a >= 1e5) return s + (a / 1e5).toFixed(2) + 'L';
    if (a >= 1e3) return s + (a / 1e3).toFixed(1) + 'K';
    return s + Math.round(a);
  }

  // ---------- expiry date formats ----------
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  /** "07-Oct-2026" / "07 Oct 2026" / "2026-10-07" -> "2026-10-07" (or null) */
  function toIso(raw) {
    raw = String(raw || '').trim();
    let m = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return `${m[1]}-${m[2]}-${m[3]}`;
    m = raw.match(/^(\d{1,2})[-\s]([A-Za-z]{3})[A-Za-z]*[-\s,]+(\d{4})/);
    if (m && MON[m[2].toLowerCase()]) return `${m[3]}-${pad(MON[m[2].toLowerCase()])}-${pad(+m[1])}`;
    return null;
  }

  const num = v => { if (v === null || v === undefined || v === '' || v === '-') return 0; const n = parseFloat(String(v).replace(/,/g, '')); return isFinite(n) ? n : 0; };

  // ---------- NSE option-chain-v3 ----------
  function nseSide(o) {
    o = o || {};
    const oi = num(o.openInterest), chg = num(o.changeinOpenInterest), ltp = num(o.lastPrice), ch = num(o.change);
    return { oi, poi: oi - chg, ltp, pc: ltp - ch, iv: num(o.impliedVolatility), vol: num(o.totalTradedVolume) };
  }
  /** NSE JSON -> {spot, rows, ts}. Optionally filter by raw expiry (for the old all-expiry endpoint). */
  function parseNSE(json, rawExpiry) {
    const rec = (json && (json.records || json.filtered)) || {};
    let data = rec.data || (json && json.filtered && json.filtered.data) || [];
    if (rawExpiry) {
      const iso = toIso(rawExpiry);
      const f = data.filter(d => { const e = d.expiryDates || d.expiryDate || (d.CE && d.CE.expiryDate) || (d.PE && d.PE.expiryDate); return !e || toIso(e) === iso; });
      if (f.length) data = f;
    }
    let spot = num(rec.underlyingValue);
    const rows = [];
    for (const d of data) {
      const strike = num(d.strikePrice);
      if (!strike) continue;
      if (!spot) spot = num((d.CE && d.CE.underlyingValue) || (d.PE && d.PE.underlyingValue));
      const ce = nseSide(d.CE), pe = nseSide(d.PE);
      if (ce.oi > 0 || pe.oi > 0 || ce.ltp > 0 || pe.ltp > 0) rows.push({ strike, ce, pe });
    }
    rows.sort((a, b) => a.strike - b.strike);
    return { spot, rows, ts: rec.timestamp || '' };
  }
  function nseExpiries(json) {
    const list = (json && (json.expiryDates || (json.records && json.records.expiryDates))) || [];
    return list.map(r => ({ raw: r, iso: toIso(r) })).filter(x => x.iso);
  }

  // ---------- BSE DerivOptionChain (field names matched loosely) ----------
  function findRowsArray(json) {
    let best = null;
    (function walk(v, depth) {
      if (best || depth > 4 || !v || typeof v !== 'object') return;
      if (Array.isArray(v)) {
        if (v.length && typeof v[0] === 'object' && Object.keys(v[0]).some(k => /strike/i.test(k))) { best = v; return; }
        v.forEach(x => walk(x, depth + 1));
      } else Object.values(v).forEach(x => walk(x, depth + 1));
    })(json, 0);
    return best || [];
  }
  function bseFieldMap(arr) {
    const sample = arr[0];
    const keys = Object.keys(sample);
    const dataLike = k => /open|int|(^|_)oi|ltp|last|price|chng|change|vol|iv/i.test(k);
    const isCe = k => /^c_|^ce_|^call/i.test(k), isPe = k => /^p_|^pe_|^put/i.test(k);
    // Only treat "p_" as the put prefix if p_ columns actually hold data (BSE has a stray p_Series_Code)
    const hasPrefixPe = keys.some(k => isPe(k) && dataLike(k));
    const ceKeys = keys.filter(isCe);
    const peKeys = keys.filter(k => hasPrefixPe ? isPe(k) : (!isCe(k) && !isPe(k) && !/strike/i.test(k)));
    const filled = k => arr.reduce((n, r) => n + (num(r[k]) !== 0 ? 1 : 0), 0);
    const chgRe = /chng|change|chg/i, pctRe = /per|pct|%/i;
    // among matching columns, prefer the one that actually has values
    const pick = (ks, test) => { const m = ks.filter(test); if (m.length < 2) return m[0]; return m.sort((a, b) => filled(b) - filled(a))[0]; };
    const fields = ks => ({
      oi: pick(ks, k => /open_?int|(^|_)oi$/i.test(k) && !chgRe.test(k)),
      chg: pick(ks, k => /(open_?int|(^|_)oi)/i.test(k) && chgRe.test(k) && !pctRe.test(k)),
      ltp: pick(ks, k => /last|ltp/i.test(k) && !chgRe.test(k)),
      netch: pick(ks, k => /net_?ch|(^|_)chng$|price_?chng/i.test(k) && !/oi|open/i.test(k) && !pctRe.test(k)),
      iv: pick(ks, k => /(^|_)iv$|implied|vola/i.test(k)),
      vol: pick(ks, k => /vol|traded_?q|trd_?qty/i.test(k) && !/vola|value|iv/i.test(k)),
    });
    return {
      strike: keys.find(k => /strike/i.test(k) && !isPe(k)) || keys.find(k => /strike/i.test(k)),
      ce: fields(ceKeys), pe: fields(peKeys),
      spot: keys.find(k => /ula|underly|spot|index_?val/i.test(k) && !/code|_id$|name/i.test(k)),
    };
  }
  function parseBSE(json) {
    const arr = findRowsArray(json);
    if (!arr.length) return { spot: 0, rows: [], map: null };
    const map = bseFieldMap(arr);
    const sideOf = (r, f) => {
      const oi = num(r[f.oi]), chg = num(r[f.chg]), ltp = num(r[f.ltp]), ch = num(r[f.netch]);
      return { oi, poi: oi - chg, ltp, pc: ltp - ch, iv: num(r[f.iv]), vol: num(r[f.vol]) };
    };
    let spot = 0;
    const rows = [];
    for (const r of arr) {
      const strike = num(r[map.strike]);
      if (!strike) continue;
      if (!spot && map.spot) spot = num(r[map.spot]);
      const ce = sideOf(r, map.ce), pe = sideOf(r, map.pe);
      if (ce.oi > 0 || pe.oi > 0 || ce.ltp > 0 || pe.ltp > 0) rows.push({ strike, ce, pe });
    }
    if (!spot) {   // spot sometimes sits outside the rows
      const m = JSON.stringify(json).match(/"(?:UlaValue|Ula_Value|UnderlyingValue|underlyingValue|IndexValue|Index_Value|UlaPrice|Ula_Price)"\s*:\s*"?([\d.,]+)/);
      if (m) spot = num(m[1]);
    }
    rows.sort((a, b) => a.strike - b.strike);
    if (!spot && rows.length) {  // last resort: strike where call and put prices cross
      let best = rows[0], bd = Infinity;
      for (const r of rows) { const d = Math.abs(r.ce.ltp - r.pe.ltp); if (r.ce.ltp && r.pe.ltp && d < bd) { bd = d; best = r; } }
      spot = best.strike + best.ce.ltp - best.pe.ltp;
    }
    return { spot, rows, map };
  }
  function bseExpiries(json) {
    const seen = new Set(), out = [];
    const re = /\b(\d{1,2}[\s-][A-Za-z]{3}[A-Za-z]*[\s-]\d{4})\b/g;
    let m; const s = JSON.stringify(json || {});
    while ((m = re.exec(s))) { const iso = toIso(m[1]); if (iso && !seen.has(iso)) { seen.add(iso); out.push({ raw: m[1], iso }); } }
    return out.sort((a, b) => a.iso < b.iso ? -1 : 1);
  }

  // ---------- hero-zero ----------
  /**
   * series: today's summaries for the NEAREST expiry (oldest first), each with nce/npe (ATM±5 total OI change).
   * Returns state + per-side drop from today's peak + OTM picks in the premium band.
   */
  function heroZero(series, cur, compareRows, expiryIso, S, nowMs) {
    const p = istParts(nowMs), today = istDate(nowMs), mins = p.h * 60 + p.mi;
    const out = { expiryDay: expiryIso === today, active: false, state: 'idle', ce: null, pe: null, picks: [], since: series.length ? series[0].ts : null };
    const sideStat = key => {
      let peak = -Infinity, peakTs = null;
      for (const x of series) if (isFinite(x[key]) && x[key] > peak) { peak = x[key]; peakTs = x.ts; }
      const now = series.length ? series[series.length - 1][key] : NaN;
      const drop = peak > 0 && isFinite(now) ? Math.max(0, (peak - now) / peak * 100) : 0;
      return { peak: peak > -Infinity ? peak : NaN, peakTs, now, drop, hit: peak > 0 && drop >= S.heroDrop };
    };
    out.ce = sideStat('nce'); out.pe = sideStat('npe');
    if (!out.expiryDay) { out.state = 'not-expiry'; return out; }
    if (mins < S.heroStart) { out.state = 'before'; return out; }
    if (mins > 15 * 60 + 30) out.closed = true;
    out.active = true;
    out.state = out.ce.hit && out.pe.hit ? 'both' : out.ce.hit ? 'CE' : out.pe.hit ? 'PE' : 'none';
    const pickSide = out.state === 'CE' || out.state === 'PE' ? out.state.toLowerCase() : null;
    if (pickSide && cur) {
      const otm = compareRows.filter(r => pickSide === 'ce' ? r.strike > cur.spot : r.strike < cur.spot)
        .filter(r => r[pickSide].ltp >= S.heroMin && r[pickSide].ltp <= S.heroMax)
        .sort((a, b) => Math.abs(a.strike - cur.spot) - Math.abs(b.strike - cur.spot));
      out.picks = otm.slice(0, 3).map(r => ({ strike: r.strike, ltp: r[pickSide].ltp, oi: r[pickSide].oi, doi: r[pickSide].doi, side: pickSide.toUpperCase() }));
    }
    return out;
  }

  // ---------- index futures ----------
  /** Finds futures contracts in NSE liveEquity-derivatives or quote-derivative JSON. */
  function parseNseFutures(json) {
    const out = [];
    (function walk(v, depth) {
      if (!v || typeof v !== 'object' || depth > 6) return;
      if (Array.isArray(v)) { v.forEach(x => walk(x, depth + 1)); return; }
      const meta = v.metadata && typeof v.metadata === 'object' ? v.metadata : v;
      const type = String(meta.instrumentType || meta.instrument || v.instrumentType || v.instrument || '');
      const exp = meta.expiryDate || v.expiryDate;
      const isFut = /fut/i.test(type) || (exp && !meta.optionType && !v.optionType && !meta.strikePrice && /fut/i.test(String(v.identifier || '')));
      if (isFut && exp && (meta.lastPrice !== undefined || v.lastPrice !== undefined)) {
        const ti = (v.marketDeptOrderBook && v.marketDeptOrderBook.tradeInfo) || v.tradeInfo || {};
        const pick = (...ks) => { for (const k of ks) for (const o of [meta, v, ti]) if (o[k] !== undefined && o[k] !== null && o[k] !== '' && o[k] !== '-') return num(o[k]); return NaN; };
        const ltp = pick('lastPrice'), ch = pick('change');
        const iso = toIso(exp);
        if (iso && ltp > 0) out.push({
          iso, raw: exp, ltp, change: isFinite(ch) ? ch : NaN,
          prevClose: isFinite(pick('prevClose')) ? pick('prevClose') : (isFinite(ch) ? ltp - ch : NaN),
          oi: pick('openInterest'), oiChg: pick('changeinOpenInterest', 'changeInOpenInterest'),
          vol: pick('numberOfContractsTraded', 'volume', 'totalTradedVolume'), underlying: pick('underlyingValue'),
        });
        return;
      }
      Object.values(v).forEach(x => walk(x, depth + 1));
    })(json, 0);
    const seen = new Set();
    return out.filter(f => !seen.has(f.iso) && seen.add(f.iso)).sort((a, b) => a.iso < b.iso ? -1 : 1);
  }

  const BIAS = { 'Long buildup': 'Bullish', 'Short covering': 'Bullish', 'Short buildup': 'Bearish', 'Long unwinding': 'Bearish' };
  /**
   * Futures buildup between two readings. Ignores tiny moves so the label doesn't flicker:
   * price must move >= 0.03% and OI >= 0.2%.
   */
  function futBuildup(cur, base) {
    if (!cur || !base) return { label: '', bias: '', dp: NaN, doi: NaN };
    const dp = cur.ltp - base.ltp, doi = cur.oi - base.oi;
    const okP = Math.abs(dp) >= cur.ltp * 0.0003, okO = isFinite(doi) && Math.abs(doi) >= Math.max(1, (base.oi || 0) * 0.002);
    const label = okP && okO ? buildup(dp, doi) : '';
    return { label, bias: BIAS[label] || '', dp, doi };
  }
  /** Does the futures bias agree with a hero-zero side? */
  function futConfirm(side, bias) {
    if (!bias || (side !== 'CE' && side !== 'PE')) return '';
    return (side === 'CE' && bias === 'Bullish') || (side === 'PE' && bias === 'Bearish') ? 'agree' : 'disagree';
  }

  // ---------- hero-zero plan helpers ----------
  /**
   * Estimated price of an option (side 'ce'|'pe', strike K) if spot moves from S to T,
   * using today's chain ("same distance from spot = similar price"): price now of the strike K - (T - S).
   */
  function estPrice(rows, side, K, S, T) {
    const K2 = K - (T - S);
    const pts = rows.filter(r => r[side].ltp > 0).map(r => [r.strike, r[side].ltp]).sort((a, b) => a[0] - b[0]);
    if (!pts.length) return NaN;
    const intrinsic = Math.max(0, side === 'ce' ? T - K : K - T);
    if (K2 <= pts[0][0]) return side === 'ce' ? Math.max(intrinsic, pts[0][1] + (pts[0][0] - K2)) : Math.max(intrinsic, pts[0][1]);
    if (K2 >= pts[pts.length - 1][0]) return side === 'pe' ? Math.max(intrinsic, pts[pts.length - 1][1] + (K2 - pts[pts.length - 1][0])) : Math.max(intrinsic, pts[pts.length - 1][1]);
    for (let i = 1; i < pts.length; i++) {
      if (K2 <= pts[i][0]) {
        const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
        return Math.max(intrinsic, y0 + (y1 - y0) * (K2 - x0) / (x1 - x0));
      }
    }
    return NaN;
  }

  /**
   * Plan from zero-OI zones. rows = compare(cur, prevClose); isZero(row, i) i=0 CE, 1 PE.
   * Returns {side, zone:[from,to], wall, buy:{strike,ltp}, targets:[{level, est, x}]} or {side:null, why}.
   */
  function heroPlan(rows, spot, isZero, S) {
    const up = rows.filter(r => r.strike > spot).sort((a, b) => a.strike - b.strike);
    const dn = rows.filter(r => r.strike < spot).sort((a, b) => b.strike - a.strike);
    const ceUp = up.filter(r => isZero(r, 0)).length, peDn = dn.filter(r => isZero(r, 1)).length;
    if (!ceUp && !peDn) return { side: null, why: 'No zero-OI zone yet: writers are holding both sides.' };
    if (ceUp === peDn) return { side: null, why: `Zero OI is balanced (${ceUp} CE above, ${peDn} PE below): no clear side.` };
    const side = ceUp > peDn ? 'ce' : 'pe', i = side === 'ce' ? 0 : 1, path = side === 'ce' ? up : dn;
    // open road = strikes from spot outward until the first strike where writers are still adding heavily
    const adds = path.map(r => r[side].doi).filter(v => v > 0);
    const big = adds.length ? Math.max(...adds) * 0.35 : Infinity;
    let wall = null, last = null;
    for (const r of path) {
      if (isZero(r, i)) { last = r; continue; }
      if (r[side].doi >= big) { wall = r; break; }
      if (last) last = r;     // small, non-zero additions don't stop the road
    }
    const zoneEnd = wall ? wall.strike : last ? last.strike : null;
    if (!zoneEnd) return { side: null, why: 'Zero OI strikes are scattered: no clean open road from spot.' };
    const inZone = path.filter(r => side === 'ce' ? r.strike <= zoneEnd : r.strike >= zoneEnd);
    const buyable = inZone.filter(r => r[side].ltp >= S.heroMin && r[side].ltp <= S.heroMax);
    const buy = buyable[0] || inZone.filter(r => r[side].ltp > 0 && r[side].ltp < S.heroMin).slice(-1)[0] || null;
    const levels = [];
    for (const r of inZone) levels.push(r.strike);
    const pickLv = [...new Set([levels[Math.floor((levels.length - 1) / 2)], zoneEnd])].filter(v => v !== undefined);
    const targets = buy ? pickLv.map(level => { const est = estPrice(rows, side, buy.strike, spot, level); return { level, est, x: est / buy[side].ltp }; }) : [];
    return { side: side.toUpperCase(), zone: [spot, zoneEnd], wall: wall ? wall.strike : null, count: side === 'ce' ? ceUp : peDn,
             buy: buy ? { strike: buy.strike, ltp: buy[side].ltp } : null, targets };
  }

  // ---------- support / resistance tracking ----------
  /**
   * For one side ('ce' = resistance, 'pe' = support): the level (max OI strike), its OI change today and
   * over the recent window (cur vs past snapshot b), the strongest challenger, and a shift forecast.
   */
  function srSide(cur, b, side) {
    const rows = cur.rows.filter(r => r[side].oi > 0);
    if (!rows.length) return null;
    const bmap = new Map(); if (b) for (const r of b.rows) bmap.set(r.strike, r);
    const delta = r => { if (!b) return NaN; const o = bmap.get(r.strike); return o ? r[side].oi - o[side].oi : NaN; };
    const ranked = rows.slice().sort((x, y) => y[side].oi - x[side].oi);
    const L = ranked[0], second = ranked[1] || null;
    const lvlOi = L[side].oi, lvlToday = L[side].oi - L[side].poi, lvlRecent = delta(L);
    const recentOk = isFinite(lvlRecent);
    const move = r => recentOk ? delta(r) : (r[side].oi - r[side].poi);   // recent change, or today's if no history yet
    // challenger: a big strike (>= 50% of level OI) building fastest
    let ch = null;
    for (const r of rows) {
      if (r === L || r[side].oi < lvlOi * 0.5) continue;
      const m = move(r);
      if (m > 0 && (!ch || m > move(ch))) ch = r;
    }
    const lvlMove = move(L);
    let state = 'Holding', dir = '', target = null, conf = '';
    const unwinding = lvlMove < 0 && Math.abs(lvlMove) > lvlOi * (recentOk ? 0.02 : 0.05);
    if (ch && move(ch) > Math.max(lvlMove, 0) * 1.5 && ch[side].oi >= lvlOi * 0.75) {
      dir = ch.strike > L.strike ? 'up' : 'down'; target = ch.strike; state = 'Shift'; conf = unwinding ? 'Likely' : 'Possible';
    } else if (unwinding) {
      state = 'Weakening'; dir = side === 'ce' ? 'up' : 'down';
      const beyond = rows.filter(r => side === 'ce' ? r.strike > L.strike : r.strike < L.strike).sort((x, y) => y[side].oi - x[side].oi)[0];
      target = beyond ? beyond.strike : null; conf = 'Possible';
    } else if (lvlMove <= 0) state = 'Flat';
    return {
      side, level: L.strike, oi: lvlOi, today: lvlToday, recent: lvlRecent, recentOk,
      next: second ? { strike: second.strike, oi: second[side].oi, recent: delta(second), today: second[side].oi - second[side].poi } : null,
      ch: ch ? { strike: ch.strike, oi: ch[side].oi, move: move(ch), share: ch[side].oi / lvlOi } : null,
      state, dir, target, conf,
    };
  }
  /** Times today when support/resistance changed, from minute summaries. */
  function srHistory(series, key) {
    const out = [];
    for (let i = 1; i < series.length; i++) if (series[i][key] !== series[i - 1][key] && isFinite(series[i][key]) && isFinite(series[i - 1][key]))
      out.push({ ts: series[i].ts, from: series[i - 1][key], to: series[i][key] });
    return out;
  }

  // ---------- daily prediction ----------
  /**
   * Combine signals into a direction bias. inp: {pcr, spot, mp, step, R, S, zeroAbove, zeroBelow,
   * futDay, fut15, giftGap, giftPct, news}. Returns {score, max, label, tone, conf, factors:[{name, val, w, txt}]}.
   */
  function predict(inp) {
    const F = [];
    const add = (name, val, w, txt) => { if (val !== null && val !== undefined && isFinite(val)) F.push({ name, val: Math.max(-1, Math.min(1, val)), w, txt }); };
    if (isFinite(inp.pcr)) add('PCR', inp.pcr > 1.15 ? 1 : inp.pcr < 0.85 ? -1 : 0, 1,
      `PCR ${inp.pcr.toFixed(2)}: ` + (inp.pcr > 1.15 ? 'put writers dominate (supportive)' : inp.pcr < 0.85 ? 'call writers dominate (capping)' : 'balanced'));
    if (inp.S) {
      const v = inp.S.state === 'Shift' ? (inp.S.dir === 'up' ? 1 : -1) : inp.S.state === 'Weakening' ? -1 : inp.S.state === 'Holding' ? 0.3 : 0;
      add('Support', v, 1, `Support ${fmtStrike(inp.S.level)}: ` + (inp.S.state === 'Shift' ? `may shift ${inp.S.dir} to ${fmtStrike(inp.S.target)}` : inp.S.state === 'Weakening' ? 'put writers exiting' : inp.S.state === 'Holding' ? 'holding, put writers adding' : 'no fresh writing'));
    }
    if (inp.R) {
      const v = inp.R.state === 'Shift' ? (inp.R.dir === 'up' ? 1 : -1) : inp.R.state === 'Weakening' ? 1 : inp.R.state === 'Holding' ? -0.3 : 0;
      add('Resistance', v, 1, `Resistance ${fmtStrike(inp.R.level)}: ` + (inp.R.state === 'Shift' ? `may shift ${inp.R.dir} to ${fmtStrike(inp.R.target)}` : inp.R.state === 'Weakening' ? 'call writers exiting' : inp.R.state === 'Holding' ? 'holding, call writers adding' : 'no fresh writing'));
    }
    if (isFinite(inp.zeroAbove) && isFinite(inp.zeroBelow) && (inp.zeroAbove || inp.zeroBelow))
      add('Zero OI', inp.zeroAbove > inp.zeroBelow ? 1 : inp.zeroBelow > inp.zeroAbove ? -1 : 0, 0.7,
        `Zero OI change: ${inp.zeroAbove} above vs ${inp.zeroBelow} below spot` + (inp.zeroAbove > inp.zeroBelow ? ' (upside open)' : inp.zeroBelow > inp.zeroAbove ? ' (downside open)' : ''));
    if (isFinite(inp.mp) && isFinite(inp.spot) && inp.step) {
      const d = inp.mp - inp.spot;
      add('Max pain', Math.abs(d) <= inp.step ? 0 : d > 0 ? 1 : -1, 0.3, `Max pain ${fmtStrike(inp.mp)} is ${Math.abs(d) <= inp.step ? 'near spot' : (d > 0 ? 'above' : 'below') + ' spot (pull ' + (d > 0 ? 'up' : 'down') + ')'}`);
    }
    if (inp.futDay) add('Futures (day)', inp.futDay.bias === 'Bullish' ? 1 : inp.futDay.bias === 'Bearish' ? -1 : 0, 1, `NIFTY futures today: ${inp.futDay.label || 'no clear buildup'}`);
    if (inp.fut15 && inp.fut15.label) add('Futures (15 min)', inp.fut15.bias === 'Bullish' ? 1 : -1, 0.5, `NIFTY futures last 15 min: ${inp.fut15.label}`);
    if (isFinite(inp.giftGap)) add('GIFT Nifty', inp.giftPct > 0.3 ? 1 : inp.giftPct < -0.3 ? -1 : inp.giftPct / 0.3, 1,
      `GIFT Nifty ${inp.giftGap >= 0 ? '+' : '−'}${Math.abs(Math.round(inp.giftGap))} pts (${inp.giftPct >= 0 ? '+' : ''}${inp.giftPct.toFixed(2)}%) vs NIFTY futures: ` + (inp.giftPct > 0.3 ? 'gap-up cue' : inp.giftPct < -0.3 ? 'gap-down cue' : 'flat cue'));
    if (inp.news && inp.news.n) add('News', Math.max(-1, Math.min(1, inp.news.score * 2)), 0.7,
      `News (24 h): ${inp.news.pos} positive, ${inp.news.neg} negative of ${inp.news.n} headlines`);
    const score = F.reduce((a, f) => a + f.val * f.w, 0), max = F.reduce((a, f) => a + f.w, 0) || 1;
    const r = score / max;
    const label = r >= 0.45 ? 'Bullish' : r >= 0.15 ? 'Mildly bullish' : r > -0.15 ? 'Sideways' : r > -0.45 ? 'Mildly bearish' : 'Bearish';
    const tone = r >= 0.15 ? 'up' : r <= -0.15 ? 'dn' : '';
    const sideSign = Math.sign(r);
    const agree = sideSign ? F.filter(f => Math.sign(f.val) === sideSign).length : F.filter(f => f.val === 0).length;
    const conf = F.length ? (agree / F.length >= 0.7 ? 'High' : agree / F.length >= 0.5 ? 'Medium' : 'Low') : 'Low';
    return { score, max, r, label, tone, conf, factors: F };
  }

  const Core = { INDICES, DEFAULT_SETTINGS, istParts, istDate, istTime, marketOpen, parseChain, pcr, maxPain,
                 makeSnap, summary, compare, buildup, atmIndex, windowRows, baseline, checkAlerts, makeDemo,
                 fmtL, fmtStrike, fmtQ, toIso, parseNSE, nseExpiries, parseBSE, bseExpiries, heroZero, nearTotals, parseNseFutures, futBuildup, futConfirm, BIAS, estPrice, heroPlan, srSide, srHistory, predict };
  if (typeof module !== 'undefined' && module.exports) module.exports = Core; else root.Core = Core;
})(typeof window !== 'undefined' ? window : globalThis);
