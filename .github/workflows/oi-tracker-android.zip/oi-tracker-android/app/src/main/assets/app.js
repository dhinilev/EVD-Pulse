/* OI Tracker — app shell: NSE/BSE polling, storage, rendering. */
(function () {
  'use strict';
  const C = window.Core;
  const Bridge = window.Android || null;
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const NSE = 'https://www.nseindia.com';
  const BSE_API = 'https://api.bseindia.com/BseIndiaAPI/api';
  const UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36';
  const WINDOWS = [['prev', 'Prev close'], ['open', '9:15'], ['5', '5 min'], ['15', '15 min'], ['30', '30 min'], ['60', '1 hr']];
  const MEM_SNAPS = 150;

  // ------------------------------------------------------------------ storage
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } },
  };

  const st = {
    settings: Object.assign({}, C.DEFAULT_SETTINGS, store.get('oi.settings', {})),
    ui: Object.assign({ index: 'NIFTY', win: 'prev', view: 'home', oiMode: 'oi', bg: false }, store.get('oi.ui', {})),
    expiries: {}, expRaw: {}, expFetchedAt: {}, sel: {},
    snaps: {}, first: {}, series: {},
    alerts: [], cool: {}, heroLast: {}, unseen: 0, peaks: {},
    fut: { series: [], meta: null, lastLabel: '', err: null },
    live: {}, srcUsed: {}, ftErr: null,
    lastOk: null, errors: {}, diag: {}, busy: false,
    nseWarmAt: 0, bseWarmAt: 0,
    openRow: null, scrolledFor: null, day: C.istDate(Date.now()), timer: null,
  };

  const F = ['oi', 'poi', 'ltp', 'pc', 'iv', 'vol'];
  function pack(s) { return { ts: s.ts, spot: s.spot, r: s.rows.map(r => [r.strike, ...F.map(f => r.ce[f]), ...F.map(f => r.pe[f])]) }; }
  function unpack(p) {
    const rows = p.r.map(a => { const ce = {}, pe = {}; F.forEach((f, i) => { ce[f] = a[1 + i]; pe[f] = a[7 + i]; }); return { strike: a[0], ce, pe }; });
    return C.makeSnap(p.ts, p.spot, rows);
  }
  function saveDay() {
    const last = {}, first = {};
    for (const k in st.snaps) { const h = st.snaps[k]; if (h.length) last[k] = pack(h[h.length - 1]); }
    for (const k in st.first) first[k] = pack(st.first[k]);
    store.set('oi.day.' + st.day, { series: st.series, first, last, alerts: st.alerts.slice(-200), cool: st.cool, heroLast: st.heroLast, peaks: st.peaks, fut: { series: st.fut.series, meta: st.fut.meta, lastLabel: st.fut.lastLabel } });
  }
  function loadDay() {
    try { for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.startsWith('oi.day.') && k !== 'oi.day.' + st.day) localStorage.removeItem(k); } } catch (e) { }
    const d = store.get('oi.day.' + st.day, null);
    if (!d) return;
    st.series = d.series || {}; st.alerts = d.alerts || []; st.cool = d.cool || {}; st.heroLast = d.heroLast || {}; st.peaks = d.peaks || {};
    if (d.fut) { st.fut.series = d.fut.series || []; st.fut.meta = d.fut.meta || null; st.fut.lastLabel = d.fut.lastLabel || ''; }
    for (const k in d.first || {}) st.first[k] = unpack(d.first[k]);
    for (const k in d.last || {}) st.snaps[k] = [unpack(d.last[k])];
    for (const k in st.snaps) { const [i, e] = k.split('|'); (st.expiries[i] = st.expiries[i] || []).includes(e) || st.expiries[i].push(e); }
    for (const i in st.expiries) st.expiries[i].sort();
  }

  // ------------------------------------------------------------------- network
  let reqId = 0; const pending = {};
  window.__httpCb = function (id, status, b64) {
    const p = pending[id]; if (!p) return; delete pending[id];
    let text = '';
    try { text = decodeURIComponent(escape(atob(b64 || ''))); } catch (e) { try { text = atob(b64 || ''); } catch (e2) { } }
    p({ status: status, text: text });
  };
  function http(method, url, headers, body) {
    if (Bridge && Bridge.http) {
      return new Promise(res => {
        const id = 'r' + (++reqId); pending[id] = res;
        Bridge.http(id, method, url, JSON.stringify(headers || {}), body || '');
        setTimeout(() => { if (pending[id]) { delete pending[id]; res({ status: 0, text: 'timeout' }); } }, 30000);
      });
    }
    // In a normal browser some headers are not allowed; send only the safe ones.
    const h = {}; for (const k in headers || {}) if (/^(accept|content-type)$/i.test(k)) h[k] = headers[k];
    return fetch(url, { method, headers: h, body: body || undefined, credentials: 'include' })
      .then(r => r.text().then(t => ({ status: r.status, text: t })))
      .catch(e => ({ status: 0, text: String(e) }));
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const FT = window.createFT({
    http, store, Core: C,
    sha256: x => (Bridge && Bridge.sha256 ? Bridge.sha256(x) : ''),
    openLogin: (u, r) => { if (Bridge && Bridge.ftLogin) Bridge.ftLogin(u, r); else { toast('Flattrade login works in the Android app'); window.__ftCode && window.__ftCode('', ''); } },
  });
  const NEWS = window.NewsKit.createNews(http);
  const wantFT = () => st.settings.source === 'ft';
  const useFT = () => wantFT() && FT.ready();
  function lastSpot(index) {
    const e = st.sel[index] || (st.expiries[index] || [])[0], h = e ? st.snaps[index + '|' + e] : null;
    return h && h.length ? h[h.length - 1].spot : 0;
  }
  function parseJson(t) { try { const j = JSON.parse(t); return j && typeof j === 'object' && Object.keys(j).length ? j : null; } catch (e) { return null; } }
  function note(src, url, r, ok) {
    st.diag[src] = { at: Date.now(), url, status: r.status, ok, snippet: (r.text || '').slice(0, 600) };
  }

  // NSE needs its cookies first: open the option-chain page once, then call the API.
  async function nseWarm() {
    await http('GET', NSE + '/option-chain', { 'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'en-US,en;q=0.9' });
    st.nseWarmAt = Date.now();
    await sleep(300);
  }
  async function nseGet(path) {
    const url = NSE + path;
    const hdr = { 'User-Agent': UA, 'Accept': 'application/json, text/plain, */*', 'Accept-Language': 'en-US,en;q=0.9', 'Referer': NSE + '/option-chain', 'X-Requested-With': 'XMLHttpRequest' };
    if (!st.nseWarmAt || Date.now() - st.nseWarmAt > 4 * 60000) await nseWarm();
    let r = await http('GET', url, hdr), j = parseJson(r.text);
    if (!j) { await nseWarm(); r = await http('GET', url, hdr); j = parseJson(r.text); }
    note('NSE', url, r, !!j);
    if (!j) throw { msg: r.status === 0 ? 'No internet, or NSE not reachable.' : `NSE didn't return data (HTTP ${r.status}). It may be blocking requests; retrying every minute.` };
    return j;
  }
  async function bseGet(url) {
    const hdr = { 'User-Agent': UA, 'Accept': 'application/json, text/plain, */*', 'Accept-Language': 'en-US,en;q=0.9', 'Referer': 'https://www.bseindia.com/', 'Origin': 'https://www.bseindia.com' };
    if (!st.bseWarmAt || Date.now() - st.bseWarmAt > 10 * 60000) {
      await http('GET', 'https://www.bseindia.com/', { 'User-Agent': UA, 'Accept': 'text/html,*/*' });
      st.bseWarmAt = Date.now();
    }
    let r = await http('GET', url, hdr), j = parseJson(r.text);
    if (!j) { await sleep(800); r = await http('GET', url, hdr); j = parseJson(r.text); }
    note('BSE', url, r, !!j);
    if (!j) throw { msg: r.status === 0 ? 'No internet, or BSE not reachable.' : `BSE didn't return data (HTTP ${r.status}); retrying every minute.` };
    return j;
  }

  async function getExpiries(index) {
    const now = Date.now();
    if (st.expFetchedAt[index] && now - st.expFetchedAt[index] < 30 * 60000 && (st.expiries[index] || []).length) return st.expiries[index];
    let list = [];
    if (index === 'NIFTY') {
      try { list = C.nseExpiries(await nseGet('/api/option-chain-contract-info?symbol=NIFTY')); } catch (e) { }
      if (!list.length) list = C.nseExpiries(await nseGet('/api/option-chain-indices?symbol=NIFTY'));
    } else {
      list = C.bseExpiries(await bseGet(`${BSE_API}/ddlExpiry_IV/w?ProductType=IO&scrip_cd=1`));
    }
    const today = C.istDate(now);
    list = list.filter(x => x.iso >= today);
    if (!list.length) throw { msg: `${index}: couldn't read expiry dates from ${C.INDICES[index].src}.` };
    st.expRaw[index] = {}; list.forEach(x => { st.expRaw[index][x.iso] = x.raw; });
    st.expiries[index] = list.map(x => x.iso);
    st.expFetchedAt[index] = now;
    return st.expiries[index];
  }
  async function getChain(index, iso) {
    if (useFT()) {
      try {
        await FT.prepare(index, iso, lastSpot(index));
        if (FT.hasChain(index, iso)) { const p = FT.chain(index, iso, lastSpot(index)); if (p.rows.length && p.spot) { p.src = 'Flattrade'; st.ftErr = null; return p; } }
      } catch (e) { st.ftErr = (e && e.msg) || String(e); }
    }
    const p = await getChainExchange(index, iso);
    p.src = C.INDICES[index].src;
    return p;
  }
  async function getChainExchange(index, iso) {
    const raw = (st.expRaw[index] || {})[iso] || iso;
    if (index === 'NIFTY') {
      let p = { rows: [] };
      try { p = C.parseNSE(await nseGet(`/api/option-chain-v3?type=Indices&symbol=NIFTY&expiry=${encodeURIComponent(raw)}`)); } catch (e) { }
      if (!p.rows.length) p = C.parseNSE(await nseGet('/api/option-chain-indices?symbol=NIFTY'), raw);
      return p;
    }
    return C.parseBSE(await bseGet(`${BSE_API}/DerivOptionChain_IV/w?Expiry=${encodeURIComponent(raw)}&scrip_cd=1&strprice=0`));
  }

  // --------------------------------------------------------------- poll cycle
  async function cycle(manual) {
    if (st.busy) return;
    clearTimeout(st.timer);
    st.busy = true; setSpin(true);
    try {
      const today = C.istDate(Date.now());
      if (today !== st.day) { st.day = today; st.snaps = {}; st.first = {}; st.series = {}; st.alerts = []; st.cool = {}; st.heroLast = {}; st.peaks = {}; st.fut = { series: [], meta: null, lastLabel: '', err: null }; st.expFetchedAt = {}; }
      const open = C.marketOpen(Date.now());
      try { await fetchFutures(open, manual); st.fut.err = null; } catch (e) { st.fut.err = (e && e.msg) || String(e); }
      NEWS.refresh(false).then(() => { if (st.ui.view === 'daily') render(); }).catch(() => { });
      for (const index of Object.keys(C.INDICES)) {
        try {
          const exps = await getExpiries(index);
          if (st.sel[index] && !exps.includes(st.sel[index])) st.sel[index] = null;
          if (!st.sel[index]) st.sel[index] = exps[0];
          const tracked = [exps[0]];
          if (st.sel[index] !== exps[0]) tracked.push(st.sel[index]);
          for (const expiry of tracked) {
            const key = index + '|' + expiry;
            if (!open && (st.snaps[key] || []).length && !manual) continue;
            const parsed = await getChain(index, expiry);
            st.srcUsed[index] = parsed.src;
            if (!parsed.rows.length) throw { msg: `${index}: option chain came back empty.` };
            const snap = C.makeSnap(Date.now(), parsed.spot, parsed.rows);
            const h = st.snaps[key] = st.snaps[key] || [];
            h.push(snap); if (h.length > MEM_SNAPS) h.shift();
            if (!st.first[key]) st.first[key] = snap;
            updatePeaks(key, snap);
            (st.series[key] = st.series[key] || []).push(C.summary(snap));
            if (st.series[key].length > 800) st.series[key].shift();
            if (open) {
              for (const a of C.checkAlerts(index, expiry, h, st.settings, st.cool)) pushAlert(a);
              if (expiry === exps[0]) heroAlert(index, expiry);
            }
            await sleep(400);
          }
          delete st.errors[index];
        } catch (e) {
          st.errors[index] = (e && e.msg) || String(e);
        }
      }
      if (Object.keys(st.errors).length < Object.keys(C.INDICES).length) st.lastOk = Date.now();
    } finally {
      st.busy = false; setSpin(false);
      saveDay(); render();
      st.timer = setTimeout(() => cycle(false), C.marketOpen(Date.now()) ? 60000 : 5 * 60000);
    }
  }

  // today's highest OI change per strike (for the "going to zero" highlight)
  function updatePeaks(key, snap) {
    const pk = st.peaks[key] = st.peaks[key] || {};
    for (const r of snap.rows) {
      const p = pk[r.strike] || (pk[r.strike] = [-Infinity, -Infinity]);
      p[0] = Math.max(p[0], r.ce.oi - r.ce.poi);
      p[1] = Math.max(p[1], r.pe.oi - r.pe.poi);
    }
  }

  // ------- NIFTY futures (current month) — used as the direction read for both tabs
  async function fetchFutures(open, manual) {
    if (!open && st.fut.series.length && !manual) return;
    let list = [];
    if (useFT()) {
      try { await FT.prepareFut(); const q = FT.futQuote(); if (q) { list = [q]; st.fut.src = 'Flattrade'; } } catch (e) { st.ftErr = (e && e.msg) || String(e); }
    }
    if (!list.length) st.fut.src = 'NSE';
    if (!list.length) try { list = C.parseNseFutures(await nseGet('/api/liveEquity-derivatives?index=nse50_fut')); } catch (e) { }
    if (st.fut.src !== 'Flattrade' && (!list.length || !isFinite(list[0].oi))) {
      const b = C.parseNseFutures(await nseGet('/api/quote-derivative?symbol=NIFTY'));
      if (b.length) list = b;
    }
    const today = C.istDate(Date.now());
    const f = list.find(x => x.iso >= today) || list[0];
    if (!f) throw { msg: 'NIFTY futures: no data from NSE.' };
    if (st.fut.meta && st.fut.meta.iso !== f.iso) { st.fut.series = []; st.fut.lastLabel = ''; }  // monthly rollover
    const spot = isFinite(f.underlying) && f.underlying > 0 ? f.underlying : niftySpot();
    st.fut.meta = { iso: f.iso, prevClose: f.prevClose, prevOi: isFinite(f.oiChg) && isFinite(f.oi) ? f.oi - f.oiChg : NaN, vol: f.vol };
    st.fut.series.push({ ts: Date.now(), ltp: f.ltp, oi: isFinite(f.oi) ? f.oi : NaN, spot });
    if (st.fut.series.length > 800) st.fut.series.shift();
    if (open) futAlert();
  }
  function niftySpot() {
    const e = (st.expiries.NIFTY || [])[0], h = e ? st.snaps['NIFTY|' + e] : null;
    return h && h.length ? h[h.length - 1].spot : NaN;
  }
  function futBase(win) {
    const s = st.fut.series, m = st.fut.meta;
    if (!s.length) return null;
    if (win === 'prev') {
      if (m && isFinite(m.prevClose) && isFinite(m.prevOi)) return { ltp: m.prevClose, oi: m.prevOi, ts: null, label: 'vs prev close' };
      return Object.assign({ label: 'since ' + C.istTime(s[0].ts) }, s[0]);
    }
    if (win === 'open') return Object.assign({ label: 'since ' + C.istTime(s[0].ts) }, s[0]);
    const cut = s[s.length - 1].ts - (+win) * 60000 + 5000;
    let b = s[0]; for (const x of s) if (x.ts <= cut) b = x;
    return Object.assign({ label: b === s[0] && s[0].ts > cut ? 'since ' + C.istTime(s[0].ts) : 'last ' + win + ' min' }, b);
  }
  function fut15() {
    const s = st.fut.series; if (s.length < 2) return { label: '', bias: '' };
    const b = futBase('15');
    if (!b || s[s.length - 1].ts - b.ts < 5 * 60000) return { label: '', bias: '' };
    return C.futBuildup(s[s.length - 1], b);
  }
  function futAlert() {
    const r = fut15();
    if (!r.label || r.label === st.fut.lastLabel) return;
    const prev = st.fut.lastLabel;
    st.fut.lastLabel = r.label;
    if (!prev) return;   // first reading of the day: just remember it
    const k = 'FUT|' + r.label, now = Date.now();
    if (st.cool[k] && now - st.cool[k] < st.settings.cooldown * 60000) return;
    st.cool[k] = now;
    const cur = st.fut.series[st.fut.series.length - 1];
    pushAlert({ ts: now, index: 'NIFTY', expiry: st.fut.meta.iso, kind: 'Futures',
      msg: `NIFTY futures turned ${prev} → ${r.label} (${r.bias}) in the last 15 min. Price ${sgn(r.dp, f1)}, OI ${sQ(r.doi)}. Fut ${f2(cur.ltp)}.` });
  }

  function pushAlert(a) {
    st.alerts.push(a); st.unseen++;
    if (st.settings.notify) notify(`${a.index} ${fmtExp(a.expiry)} · ${a.kind}`, a.msg);
  }
  function heroFor(index) {
    const exps = st.expiries[index] || [];
    if (!exps.length) return null;
    const key = index + '|' + exps[0], h = st.snaps[key] || [];
    const cur = h.length ? h[h.length - 1] : null;
    return C.heroZero(st.series[key] || [], cur, cur ? C.compare(cur, null) : [], exps[0], st.settings, Date.now());
  }
  function heroAlert(index, expiry) {
    const hz = heroFor(index);
    if (!hz || !hz.active || hz.closed) return;
    const prev = st.heroLast[index];
    if (hz.state === prev) return;
    st.heroLast[index] = hz.state;
    if (hz.state === 'none') return;
    const picks = hz.picks.map(p => `${fmtK(p.strike)} ${p.side} ₹${f2(p.ltp)}`).join(', ');
    const msg = hz.state === 'both' ? 'OI change falling on both sides. Wait for one side to stand out.'
      : `${hz.state} side: ${hz.state === 'CE' ? 'call' : 'put'} writers exiting. Near-ATM ${hz.state} OI change down ${Math.round(hz[hz.state.toLowerCase()].drop)}% from today's peak.` + (picks ? ` Strikes: ${picks}` : '');
    const r15 = fut15(), conf = C.futConfirm(hz.state, r15.bias);
    const fmsg = conf === 'agree' ? ` Futures agree (${r15.label}).` : conf === 'disagree' ? ` Careful: futures show ${r15.label} (${r15.bias}).` : '';
    pushAlert({ ts: Date.now(), index, expiry, kind: 'Hero-zero', msg: (fmsg ? msg.replace(/\.?$/, '.') : msg) + fmsg });
  }

  function notify(title, text) {
    if (Bridge && Bridge.notify) Bridge.notify(title, text);
    else toast(title + ': ' + text);
  }

  // ------------------------------------------------------------------ helpers
  const Q = C.fmtQ;
  const sQ = x => (x > 0 ? '+' : '') + Q(x);
  const f1 = x => (isFinite(x) ? x.toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '–');
  const f2 = x => (isFinite(x) ? x.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '–');
  const sgn = (x, f) => (x > 0 ? '+' : x < 0 ? '−' : '') + f(Math.abs(x));
  const cls = x => (x > 0 ? 'up' : x < 0 ? 'dn' : '');
  const fmtK = x => (isFinite(x) ? Math.round(x).toLocaleString('en-IN') : '–');
  const MONS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function fmtExp(e) { const [y, m, d] = e.split('-').map(Number); return `${d} ${MONS[m - 1]}`; }
  function fmtExpLong(e) { const [y, m, d] = e.split('-').map(Number); const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(Date.UTC(y, m - 1, d)).getUTCDay()]; return `${fmtExp(e)} ${String(y).slice(2)} · ${wd}`; }
  function ago(ms) { const s = Math.round((Date.now() - ms) / 1000); return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)}m ago` : C.istTime(ms); }
  const hhmm = m => `${Math.floor(m / 60) % 12 || 12}:${String(m % 60).padStart(2, '0')} ${m >= 720 ? 'PM' : 'AM'}`;
  let toastT; function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
  function setSpin(on) { $('refresh').classList.toggle('spin', on); }
  const curKey = () => st.ui.index + '|' + st.sel[st.ui.index];

  function current() {
    const key = curKey(), h = st.snaps[key] || [];
    if (!h.length) return null;
    const lv = st.live[key];
    const cur = lv && lv.ts > h[h.length - 1].ts ? lv : h[h.length - 1];
    const base = C.baseline(h, st.first[key], st.ui.win);
    return { key, h, cur, base, rows: C.compare(cur, base), series: st.series[key] || [] };
  }

  // ------------------------------------------------------------------- render
  function render() {
    renderTop();
    const d = current();
    const dataView = ['home', 'chain', 'oi', 'trends'].includes(st.ui.view);
    $('dataHead').style.display = dataView ? '' : 'none';
    $('pickers').style.display = (st.ui.view === 'settings' || st.ui.view === 'daily') ? 'none' : '';
    renderBanner(d);
    if (dataView) renderMetrics(d);
    if (st.ui.view === 'home') { renderFut(); renderSR(d); renderHero(); renderZero(d); renderAtm(d); }
    if (st.ui.view === 'chain') renderChain(d);
    if (st.ui.view === 'oi') renderOI(d);
    if (st.ui.view === 'trends') renderTrends(d);
    if (st.ui.view === 'alerts') renderAlerts();
    if (st.ui.view === 'daily') renderDaily();
    if (st.ui.view === 'settings') renderSettings();
    const b = $('badge'); b.hidden = !st.unseen; b.textContent = st.unseen > 99 ? '99+' : st.unseen;
    document.documentElement.style.setProperty('--top-h', $('top').offsetHeight + 'px');
  }

  function renderTop() {
    const pill = $('pill'), txt = $('pillText');
    pill.className = 'pill';
    if (st.errors[st.ui.index] && !current()) { pill.classList.add('err'); txt.textContent = 'ERROR'; }
    else if (C.marketOpen(Date.now())) { pill.classList.add(st.errors[st.ui.index] ? 'err' : 'live'); txt.textContent = st.errors[st.ui.index] ? 'RETRYING' : 'LIVE'; }
    else txt.textContent = 'CLOSED';
    for (const b of $('idxSeg').children) b.classList.toggle('on', b.dataset.i === st.ui.index);
    const sel = $('expSel'), exps = st.expiries[st.ui.index] || [];
    const want = exps.map(e => `<option value="${e}">${fmtExpLong(e)}</option>`).join('') || '<option>Loading…</option>';
    if (sel.dataset.h !== want) { sel.innerHTML = want; sel.dataset.h = want; }
    if (st.sel[st.ui.index]) sel.value = st.sel[st.ui.index];
    for (const c of $('winChips').querySelectorAll('.chip')) c.classList.toggle('on', c.dataset.w === st.ui.win);
  }

  function renderBanner(d) {
    let h = '';
    const err = st.errors[st.ui.index];
    if (wantFT() && !FT.ready() && st.ui.view !== 'settings')
      h = `<div class="banner">Flattrade live data is on, but you're not logged in today. Showing ${C.INDICES[st.ui.index].src} data. <button data-ftlogin="1">Log in</button></div>`;
    else if (useFT() && st.ftErr && st.srcUsed[st.ui.index] !== 'Flattrade')
      h = `<div class="banner">${esc(st.ftErr)} Showing ${C.INDICES[st.ui.index].src} data for now. <button data-go="settings">Check</button></div>`;
    else if (err) h = `<div class="banner err">${esc(err)}${d ? ` Showing data from ${C.istTime(d.cur.ts)}.` : ''} <button data-go="settings">Data check</button></div>`;
    else if (d && st.ui.win !== 'prev' && st.ui.win !== 'open' && d.base && d.cur.ts - d.base.ts < (+st.ui.win - 1) * 60000)
      h = `<div class="banner">Only ${Math.max(1, Math.round((d.cur.ts - d.base.ts) / 60000))} min of history so far, so changes are vs ${C.istTime(d.base.ts)}.</div>`;
    $('banner').innerHTML = h;
  }

  function renderMetrics(d) {
    if (!d) { $('metrics').innerHTML = ''; return; }
    const { cur, base, series } = d;
    const firstSpot = series.length ? series[0].spot : cur.spot;
    const pcrBase = base ? base.pcr : (series.length ? series[0].pcr : cur.pcr);
    const sp = cur.spot - firstSpot;
    $('metrics').innerHTML = [
      `<div class="m"><div class="k">Spot · ${st.srcUsed[st.ui.index] === 'Flattrade' ? 'live' : C.INDICES[st.ui.index].src}</div><div class="v num">${f2(cur.spot)}</div><div class="d num ${cls(sp)}">${sgn(sp, f1)} today</div></div>`,
      `<div class="m"><div class="k">PCR</div><div class="v num">${isFinite(cur.pcr) ? cur.pcr.toFixed(2) : '–'}</div><div class="d num ${cls(cur.pcr - pcrBase)}">${sgn(cur.pcr - pcrBase, x => x.toFixed(2))}</div></div>`,
      `<div class="m mp"><div class="k">Max pain</div><div class="v num">${fmtK(cur.mp)}</div><div class="d num">${sgn(cur.mp - cur.spot, fmtK)} vs spot</div></div>`,
    ].join('');
  }

  // ------- futures card
  function renderFut() {
    const el = $('futCard'), s = st.fut.series;
    if (!s.length) { el.innerHTML = st.fut.err ? `<div class="card fut"><div class="fhead"><h3>NIFTY futures</h3></div><div class="hzmsg dn">${esc(st.fut.err)}</div></div>` : ''; return; }
    const cur = (useFT() && st.fut.liveCur) || s[s.length - 1], base = futBase(st.ui.win), r = C.futBuildup(cur, base), r15 = fut15();
    const prem = cur.ltp - cur.spot;
    const tag = x => x.label ? `<span class="fb ${x.bias === 'Bullish' ? 'bull' : 'bear'}">${x.label} · ${x.bias}</span>` : '<span class="fb">No clear buildup</span>';
    const exp = st.fut.meta ? fmtExp(st.fut.meta.iso) : '';
    el.innerHTML = `<div class="card fut">
      <div class="fhead"><h3>NIFTY futures <span class="dim">· ${exp}</span></h3>${tag(r)}</div>
      <div class="fgrid num">
        <div><div class="k">Price</div><div class="v">${f2(cur.ltp)}</div><div class="d ${cls(r.dp)}">${isFinite(r.dp) ? sgn(r.dp, f1) : '–'}</div></div>
        <div><div class="k">Premium</div><div class="v ${cls(prem)}">${isFinite(prem) ? sgn(prem, f1) : '–'}</div><div class="d">vs spot</div></div>
        <div><div class="k">OI</div><div class="v">${Q(cur.oi)}</div><div class="d ${cls(r.doi)}">${isFinite(r.doi) ? sQ(r.doi) : '–'}</div></div>
      </div>
      <div class="fnote">Change ${base ? base.label : ''} · last 15 min: ${tag(r15)}${st.ui.index === 'SENSEX' ? '<br>Used for SENSEX too: SENSEX futures trade too thinly to read.' : ''}</div>
    </div>`;
  }

  // ------- hero-zero box
  function heroBar(label, side, s, S) {
    const pct = Math.min(100, s.drop || 0);
    const hit = s.hit;
    return `<div class="hzrow"><div class="hzl ${side}">${label}</div>
      <div class="hzbar"><div class="hzfill ${side} ${hit ? 'hit' : ''}" style="width:${pct.toFixed(0)}%"></div><div class="hzmark" style="left:${S.heroDrop}%"></div></div>
      <div class="hzv num">${isFinite(s.peak) && s.peak > 0 ? `${sQ(s.now)} <span>/ ${sQ(s.peak)}</span>` : (isFinite(s.now) ? sQ(s.now) : '–')}</div></div>`;
  }
  function renderHero() {
    const el = $('hero'), S = st.settings, index = st.ui.index;
    const hz = heroFor(index);
    if (!hz) { el.innerHTML = ''; return; }
    const exp = (st.expiries[index] || [])[0];
    let head = '', body = '';
    const bars = `${heroBar('CE', 'ce', hz.ce, S)}${heroBar('PE', 'pe', hz.pe, S)}
      <div class="hzcap">Total OI change of ATM ±5 strikes · bar = fall from today's peak · line = ${S.heroDrop}% trigger${hz.since ? ` · watching since ${C.istTime(hz.since)}` : ''}</div>`;
    if (hz.state === 'not-expiry') {
      head = `<span class="hzst idle">Not expiry day</span>`;
      body = `<div class="hzmsg">Activates on ${index} expiry day (${fmtExpLong(exp)}) after ${hhmm(S.heroStart)}.</div>`;
    } else if (hz.state === 'before') {
      head = `<span class="hzst idle">Expiry day · starts ${hhmm(S.heroStart)}</span>`;
      body = `<div class="hzmsg">Tracking OI change peaks from now. Signal shows after ${hhmm(S.heroStart)}.</div>${bars}`;
    } else {
      const sideTxt = { CE: 'CE side', PE: 'PE side', both: 'Both falling: wait', none: 'No signal yet' }[hz.state];
      head = `<span class="hzst ${hz.state === 'CE' ? 'ce' : hz.state === 'PE' ? 'pe' : 'idle'}">${sideTxt}</span>`;
      let msg = '';
      if (hz.state === 'CE') msg = `Call writers exiting: near-ATM CE OI change is down <b>${Math.round(hz.ce.drop)}%</b> from today's peak.`;
      else if (hz.state === 'PE') msg = `Put writers exiting: near-ATM PE OI change is down <b>${Math.round(hz.pe.drop)}%</b> from today's peak.`;
      else if (hz.state === 'both') msg = 'OI change is falling on both sides. Wait for one side to stand out.';
      else msg = `Waiting for CE or PE OI change to fall ${S.heroDrop}% from its peak.`;
      if (hz.closed) msg += ' (Market closed.)';
      if (hz.state === 'CE' || hz.state === 'PE') {
        const r15 = fut15(), conf = C.futConfirm(hz.state, r15.bias);
        msg += conf === 'agree' ? `<div class="hzconf ok">✅ Futures agree · last 15 min: ${r15.label} (${r15.bias})</div>`
          : conf === 'disagree' ? `<div class="hzconf bad">⚠️ Futures disagree · last 15 min: ${r15.label} (${r15.bias})</div>`
          : `<div class="hzconf">Futures: no clear buildup in the last 15 min</div>`;
      }
      const picks = hz.picks.length ? `<div class="hzpicks">${hz.picks.map(p => `<div class="hzp ${p.side.toLowerCase()}"><b>${fmtK(p.strike)} ${p.side}</b><span>₹${f2(p.ltp)}</span></div>`).join('')}</div>`
        : (hz.state === 'CE' || hz.state === 'PE') ? `<div class="hzmsg">No ${hz.state} strike priced ₹${S.heroMin}–₹${S.heroMax} right now.</div>` : '';
      body = `<div class="hzmsg">${msg}</div>${picks}${bars}`;
    }
    el.innerHTML = `<div class="card hz"><div class="hzhead"><h3>Hero-zero</h3>${head}</div>${body}
      <div class="hzfoot">Guide only. Most hero-zero trades expire worthless.</div></div>`;
  }

  // ------- chain table: OI | OI chg | LTP | Strike | LTP | OI chg | OI
  /**
   * "Zero OI change" test for a strike side (i: 0 = CE, 1 = PE): OI change exactly 0, or (vs prev close)
   * fallen >= heroDrop% from that strike's peak today. Same rule as the amber cells.
   */
  function zeroTester(key, view) {
    const pk = st.peaks[key] || {}, drop = st.settings.heroDrop;
    const top = [0, 0];
    for (const r of view) { const p = pk[r.strike]; if (p) { top[0] = Math.max(top[0], p[0]); top[1] = Math.max(top[1], p[1]); } }
    const hasChg = [view.some(r => r.ce.doi !== 0), view.some(r => r.pe.doi !== 0)];
    const t = (r, i) => {
      if (!hasChg[i]) return false;   // no OI-change data on this side (e.g. after hours)
      const x = i ? r.pe : r.ce;
      if (x.oi > 0 && Math.round(x.doi) === 0) return true;
      if (st.ui.win !== 'prev') return false;
      const peak = pk[r.strike] ? pk[r.strike][i] : 0;
      return peak > 0 && peak >= top[i] * 0.05 && (peak - x.doi) / peak * 100 >= drop;
    };
    t.hasData = hasChg[0] || hasChg[1];
    return t;
  }

  // ------- Home: zero OI change above vs below spot
  function renderZero(d) {
    const el = $('zeroCard');
    if (!d) { el.innerHTML = ''; return; }
    const { cur, rows, key } = d;
    const view = C.windowRows(rows, cur.spot, st.settings.strikes);
    const z = zeroTester(key, view);
    const up = view.filter(r => r.strike > cur.spot), dn = view.filter(r => r.strike < cur.spot);
    const cnt = (list, i) => list.filter(r => z(r, i)).length;
    const a = { ce: cnt(up, 0), pe: cnt(up, 1) }, b = { ce: cnt(dn, 0), pe: cnt(dn, 1) };
    const ta = a.ce + a.pe, tb = b.ce + b.pe;
    const strikesOf = (list, i) => list.filter(r => z(r, i)).map(r => fmtK(r.strike));
    const tip = (list, i) => { const k = strikesOf(list, i); return k.length ? k.slice(0, 6).join(', ') + (k.length > 6 ? ' …' : '') : '—'; };
    let verdict, vcls = '';
    if (!z.hasData) verdict = 'No OI-change data right now (market closed or data not published yet).';
    else if (ta === 0 && tb === 0) verdict = 'No strike has zero OI change: writers are active on both sides.';
    else if (ta > tb) { verdict = `More zero OI change <b>above spot</b> (${ta} vs ${tb}). Writers are inactive or exiting above the price.` + (a.ce >= a.pe ? ' Call writers above are fading: resistance is weakening.' : ''); vcls = 'up'; }
    else if (tb > ta) { verdict = `More zero OI change <b>below spot</b> (${tb} vs ${ta}). Writers are inactive or exiting below the price.` + (b.pe >= b.ce ? ' Put writers below are fading: support is weakening.' : ''); vcls = 'dn'; }
    else verdict = `Equal on both sides (${ta} each): no clear lean.`;
    const total = Math.max(1, ta + tb);
    el.innerHTML = `<div class="card zc">
      <div class="fhead"><h3>Zero OI change</h3><span class="dim" style="font-size:11px">±${st.settings.strikes} strikes · vs ${winLabel()}</span></div>
      <div class="zgrid num">
        <div class="zcol"><div class="zt">▲ Above spot</div><div class="zbig">${ta}</div>
          <div class="zrow"><span class="ce">CE</span><b>${a.ce}</b></div><div class="zst">${tip(up, 0)}</div>
          <div class="zrow"><span class="pe">PE</span><b>${a.pe}</b></div><div class="zst">${tip(up, 1)}</div></div>
        <div class="zcol"><div class="zt">▼ Below spot</div><div class="zbig">${tb}</div>
          <div class="zrow"><span class="ce">CE</span><b>${b.ce}</b></div><div class="zst">${tip(dn, 0)}</div>
          <div class="zrow"><span class="pe">PE</span><b>${b.pe}</b></div><div class="zst">${tip(dn, 1)}</div></div>
      </div>
      <div class="zsplit"><div style="width:${(ta / total * 100).toFixed(0)}%" class="za"></div><div style="width:${(tb / total * 100).toFixed(0)}%" class="zb"></div></div>
      <div class="zlab"><span>Above ${ta}</span><span>Below ${tb}</span></div>
      <div class="zverdict ${vcls}">${verdict}</div>
      ${planHtml(view, cur.spot, z)}
      <div class="hzcap">Zero = OI change is 0, or has fallen ${st.settings.heroDrop}%+ from that strike's peak today (the amber cells in Chain).</div>
    </div>`;
  }

  function planHtml(view, spot, z) {
    if (!z.hasData) return '';
    const pl = C.heroPlan(view, spot, z, st.settings);
    if (!pl.side) return `<div class="plan"><div class="ph"><b>Hero-zero plan</b></div><div class="pmsg">${pl.why}</div></div>`;
    const sc = pl.side === 'CE' ? 'ce' : 'pe', dir = pl.side === 'CE' ? 'up' : 'down';
    const buy = pl.buy ? `<div class="pbuy ${sc}"><div><div class="pk">Strike to watch</div><div class="pv">${fmtK(pl.buy.strike)} ${pl.side}</div></div><div><div class="pk">Now</div><div class="pv">₹${f2(pl.buy.ltp)}</div></div></div>`
      : `<div class="pmsg">No ${pl.side} strike in the open road is priced ₹${st.settings.heroMin}–₹${st.settings.heroMax} right now.</div>`;
    const tg = pl.targets.length ? `<div class="ptab num"><div class="pth">If ${st.ui.index} reaches</div><div class="pth">Est. price</div><div class="pth">Return</div>` +
      pl.targets.map(t => `<div>${fmtK(t.level)}${t.level === pl.wall ? ' <span class="dim">(wall)</span>' : ''}</div><div><b>₹${isFinite(t.est) ? f1(t.est) : '–'}</b></div><div class="${t.x >= 1 ? 'up' : 'dn'}">${isFinite(t.x) ? t.x.toFixed(1) + 'x' : '–'}</div>`).join('') + '</div>' : '';
    return `<div class="plan">
      <div class="ph"><b>Hero-zero plan</b><span class="hzst ${sc}">${pl.side} side</span></div>
      <div class="pmsg">Open road <b>${dir}</b>: ${pl.count} ${pl.side} strikes have zero OI change. Spike zone <b>${fmtK(pl.zone[0])} → ${fmtK(pl.zone[1])}</b>${pl.wall ? `, where writers are still adding at <b>${fmtK(pl.wall)}</b> (expect the move to slow there)` : ''}.</div>
      ${buy}${tg}
      <div class="pnote">Estimates use today's chain prices: they show what the option could be worth <i>if</i> spot gets there. If the move doesn't come, a hero-zero option can expire at ₹0. Guide only, not advice.</div>
    </div>`;
  }

  // ------- Daily Trade
  function dataFor(index) {
    const exps = st.expiries[index] || [], iso = st.sel[index] || exps[0];
    if (!iso) return null;
    const key = index + '|' + iso, h = st.snaps[key] || [];
    if (!h.length) return null;
    const lv = st.live[key], cur = lv && lv.ts > h[h.length - 1].ts ? lv : h[h.length - 1];
    let b = C.baseline(h, st.first[key], '15'); if (b && (b === cur || cur.ts - b.ts < 4 * 60000)) b = null;
    return { index, iso, key, h, cur, b, series: st.series[key] || [] };
  }
  function giftGet() { const g = store.get('oi.gift', null); return g && C.istDate(g.ts) === C.istDate(Date.now()) ? g : null; }
  function futLast() { const s = st.fut.series; return (useFT() && st.fut.liveCur) || (s.length ? s[s.length - 1] : null); }
  function predictionFor(index) {
    const d = dataFor(index); if (!d) return null;
    const { cur, key, b } = d;
    const prevRows = C.compare(cur, null);
    const view = C.windowRows(prevRows, cur.spot, st.settings.strikes);
    const z = zeroTester(key, view);
    const zeroAbove = view.filter(r => r.strike > cur.spot && (z(r, 0) || z(r, 1))).length;
    const zeroBelow = view.filter(r => r.strike < cur.spot && (z(r, 0) || z(r, 1))).length;
    const R = C.srSide(cur, b, 'ce'), S = C.srSide(cur, b, 'pe');
    const fl = futLast(), fb = futBase('prev');
    const futDay = fl && fb ? C.futBuildup(fl, fb) : null;
    const g = giftGet();
    const giftGap = g && fl ? g.v - fl.ltp : NaN;
    const giftPct = g && fl ? giftGap / fl.ltp * 100 : NaN;
    const p = C.predict({ pcr: cur.pcr, spot: cur.spot, mp: cur.mp, step: C.INDICES[index].step, R, S,
      zeroAbove: z.hasData ? zeroAbove : NaN, zeroBelow: z.hasData ? zeroBelow : NaN,
      futDay, fut15: fut15(), giftGap, giftPct, news: NEWS.mood() });
    return Object.assign(p, { d, R, S, zeroAbove, zeroBelow, futDay, g, giftGap, giftPct });
  }
  function predCard(index) {
    const p = predictionFor(index);
    if (!p) return `<div class="card"><h3>${index}</h3><div class="hzmsg">${loadingMsg() || 'No data yet.'}</div></div>`;
    const { cur } = p.d, pct = Math.max(-1, Math.min(1, p.r));
    const lo = Math.min(p.S.level, cur.spot), hi = Math.max(p.R.level, cur.spot);
    const watch = p.tone === 'up' ? `A move above <b>${fmtK(p.R.level)}</b> (resistance) can extend toward ${p.R.target ? fmtK(p.R.target) : 'the next strike'}.`
      : p.tone === 'dn' ? `A break below <b>${fmtK(p.S.level)}</b> (support) can extend toward ${p.S.target ? fmtK(p.S.target) : 'the next strike'}.`
      : `Expect trading between <b>${fmtK(p.S.level)}</b> and <b>${fmtK(p.R.level)}</b> until one side breaks.`;
    const ic = v => v > 0.15 ? '<span class="fi up">▲</span>' : v < -0.15 ? '<span class="fi dn">▼</span>' : '<span class="fi">●</span>';
    return `<div class="card pred">
      <div class="fhead"><h3>${index} <span class="dim">· ${f2(cur.spot)}</span></h3><span class="pl ${p.tone === 'up' ? 'bull' : p.tone === 'dn' ? 'bear' : ''}">${p.label}</span></div>
      <div class="pmeter"><div class="pmid"></div><div class="pdot ${p.tone}" style="left:${(50 + pct * 50).toFixed(1)}%"></div></div>
      <div class="plab"><span>Bearish</span><span>Sideways</span><span>Bullish</span></div>
      <div class="pgrid num">
        <div><div class="k">Expected range</div><div class="v">${fmtK(lo)} – ${fmtK(hi)}</div></div>
        <div><div class="k">Confidence</div><div class="v">${p.conf}</div></div>
        <div><div class="k">Score</div><div class="v ${p.tone}">${p.score >= 0 ? '+' : ''}${p.score.toFixed(1)} / ${p.max.toFixed(1)}</div></div>
      </div>
      <div class="zverdict ${p.tone}">${watch}</div>
      <div class="flist">${p.factors.map(f => `<div class="fr">${ic(f.val)}<span>${f.txt}</span></div>`).join('')}</div>
    </div>`;
  }
  function renderDaily() {
    const el = $('daily');
    const g = giftGet(), fl = futLast();
    const gap = g && fl ? g.v - fl.ltp : NaN;
    const now = Date.now(), p = C.istParts(now);
    const giftCard = `<div class="card">
      <div class="fhead"><h3>GIFT Nifty</h3><span class="dim" style="font-size:11px">${g ? 'entered ' + C.istTime(g.ts) : 'enter today\'s value'}</span></div>
      <div class="gift"><input id="giftIn" type="number" inputmode="decimal" placeholder="e.g. 25120" value="${g ? g.v : ''}"><button class="btn" id="giftSave" style="margin:0;width:auto;padding:10px 16px">Save</button></div>
      <div class="hzmsg" style="margin-top:8px">${g && fl ? `vs NIFTY futures ${f2(fl.ltp)}: <b class="${cls(gap)}">${sgn(gap, fmtK)} pts (${sgn(gap / fl.ltp * 100, x => x.toFixed(2))}%)</b>, ` +
        (gap / fl.ltp * 100 > 0.3 ? 'gap-up cue for the open.' : gap / fl.ltp * 100 < -0.3 ? 'gap-down cue for the open.' : 'flat open likely.') : 'GIFT Nifty trades almost round the clock and hints at how NIFTY may open. Type the value from any app (Moneycontrol, NSE IX, etc.) before 9:15.'}</div>
    </div>`;
    const tab = st.ui.newsTab || 'All';
    const items = NEWS.items.filter(x => tab === 'All' || x.scope === tab);
    const mood = NEWS.mood();
    const imp = x => x.impact > 0 ? '<span class="nb up">Positive for market</span>' : x.impact < 0 ? '<span class="nb dn">Negative for market</span>' : '<span class="nb">Neutral</span>';
    const newsCard = `<div class="card">
      <div class="fhead"><h3>Market-moving news</h3><button class="chip" id="newsRefresh">Refresh</button></div>
      <div class="toggle" id="newsTabs">${['All', 'India', 'World'].map(t => `<button class="chip ${t === tab ? 'on' : ''}" data-nt="${t}">${t}</button>`).join('')}</div>
      ${mood.n ? `<div class="hzmsg">Last 24 h: <b class="up">${mood.pos} positive</b> · <b class="dn">${mood.neg} negative</b> · ${mood.n - mood.pos - mood.neg} neutral</div>` : ''}
      ${NEWS.err && !items.length ? `<div class="hzmsg dn">${esc(NEWS.err)}</div>` : ''}
      ${!items.length && !NEWS.err ? '<div class="hzmsg">Loading headlines…</div>' : ''}
      <div class="nlist">${items.slice(0, 20).map((x, i) => `<div class="ni" data-ni="${NEWS.items.indexOf(x)}">
        <div class="nt">${imp(x)}<span class="ntop">${esc(x.topic)} · ${x.scope}</span></div>
        <div class="nh">${esc(x.title)}</div>
        ${x.society ? `<div class="ns">👥 ${esc(x.society)}</div>` : ''}
        <div class="nm">${esc(x.src)}${x.ts ? ' · ' + ago(x.ts) : ''}</div></div>`).join('')}</div>
      <div class="hzcap">Headlines from Google News. Market impact and impact on society are read from the headline by a built-in rulebook (e.g. rate cut → EMIs may fall). Tap a headline to read the full story.</div>
    </div>`;
    el.innerHTML = `<div class="dhead"><div class="dt">Daily Trade Plan</div><div class="dd">${p.d} ${MONS[p.mo - 1]} ${p.y} · ${C.istTime(now)} IST · ${C.marketOpen(now) ? 'market open' : 'market closed'}</div></div>
      ${predCard('NIFTY')}${predCard('SENSEX')}${giftCard}${newsCard}
      <div class="help" style="padding:0 16px 16px">The prediction combines option chain (PCR, support/resistance shifts, zero OI, max pain), NIFTY futures buildup, GIFT Nifty and news mood. It is a probability-based guide, not a certainty or investment advice.</div>`;
  }

  // ------- Home: support & resistance tracker
  function renderSR(d) {
    const el = $('srCard');
    if (!d) { el.innerHTML = ''; return; }
    const { cur, h, key, series } = d;
    let b = C.baseline(h, st.first[key], '15');
    if (b && (b === cur || cur.ts - b.ts < 4 * 60000)) b = null;
    const mins = b ? Math.round((cur.ts - b.ts) / 60000) : 0;
    const R = C.srSide(cur, b, 'ce'), S = C.srSide(cur, b, 'pe');
    if (!R || !S) { el.innerHTML = ''; return; }
    const winTxt = b ? `last ${mins} min` : 'today';
    const badge = x => {
      if (x.state === 'Shift') return `<span class="sb ${x.dir}">${x.conf === 'Likely' ? 'Likely' : 'May'} shift ${x.dir === 'up' ? '↑' : '↓'} ${fmtK(x.target)}</span>`;
      if (x.state === 'Weakening') return `<span class="sb weak">Weakening ${x.dir === 'up' ? '↑' : '↓'}</span>`;
      if (x.state === 'Flat') return `<span class="sb">No fresh writing</span>`;
      return `<span class="sb hold">Holding</span>`;
    };
    const why = (x) => {
      const who = x.side === 'ce' ? 'Call' : 'Put', name = x.side === 'ce' ? 'Resistance' : 'Support';
      const rc = x.recentOk ? x.recent : x.today;
      if (x.state === 'Shift') return `${who} writers are adding faster at <b>${fmtK(x.target)}</b> (${sQ(x.ch.move)} ${winTxt}, OI now ${Math.round(x.ch.share * 100)}% of ${fmtK(x.level)})` +
        (rc < 0 ? ` while ${fmtK(x.level)} is unwinding (${sQ(rc)}).` : ` than at ${fmtK(x.level)} (${sQ(rc)}).`) +
        ` ${name} may shift <b>${x.dir}</b> to ${fmtK(x.target)}.`;
      if (x.state === 'Weakening') return `${who} writers are exiting ${fmtK(x.level)} (${sQ(rc)} ${winTxt}). ${name} may shift <b>${x.dir}</b>` + (x.target ? ` toward ${fmtK(x.target)}.` : '.');
      if (x.state === 'Flat') return `No new ${who.toLowerCase()} writing at ${fmtK(x.level)} ${winTxt}. Watch for a shift.`;
      return `${who} writers still adding at ${fmtK(x.level)} (${sQ(rc)} ${winTxt}). ${name} is holding.`;
    };
    const lvl = (x, title) => `<div class="srb ${x.side}">
        <div class="srh"><div><div class="srt">${title}</div><div class="srv">${fmtK(x.level)}</div></div>${badge(x)}</div>
        <div class="srg num">
          <div><div class="k">${x.side === 'ce' ? 'Call' : 'Put'} OI</div><div class="v">${Q(x.oi)}</div></div>
          <div><div class="k">OI chg today</div><div class="v ${cls(x.today)}">${sQ(x.today)}</div></div>
          <div><div class="k">Last ${b ? mins + ' min' : '15 min'}</div><div class="v ${x.recentOk ? cls(x.recent) : ''}">${x.recentOk ? sQ(x.recent) : '—'}</div></div>
        </div>
        <div class="srw">${why(x)}</div>
        ${x.next ? `<div class="srn">2nd strongest ${x.side === 'ce' ? 'resistance' : 'support'}: <b>${fmtK(x.next.strike)}</b> · OI ${Q(x.next.oi)}${isFinite(x.next.recent) ? ` · ${sQ(x.next.recent)} ${winTxt}` : ` · ${sQ(x.next.today)} today`}</div>` : ''}
      </div>`;
    // range bar
    const lo = Math.min(S.level, cur.spot), hi = Math.max(R.level, cur.spot), span = Math.max(1, hi - lo);
    const pos = v => ((v - lo) / span * 100).toFixed(1);
    const range = `<div class="srr"><div class="srline"></div>
        <div class="srm pe" style="left:${pos(S.level)}%"><span>S ${fmtK(S.level)}</span></div>
        <div class="srm sp" style="left:${pos(cur.spot)}%"><span>${f1(cur.spot)}</span></div>
        <div class="srm ce" style="left:${pos(R.level)}%"><span>R ${fmtK(R.level)}</span></div></div>
      <div class="srd num"><span class="pe">${fmtK(cur.spot - S.level)} pts above support</span><span class="ce">${fmtK(R.level - cur.spot)} pts to resistance</span></div>`;
    const hr = C.srHistory(series, 'res').slice(-2).map(x => `${C.istTime(x.ts)} R ${fmtK(x.from)}→${fmtK(x.to)}`)
      .concat(C.srHistory(series, 'sup').slice(-2).map(x => `${C.istTime(x.ts)} S ${fmtK(x.from)}→${fmtK(x.to)}`)).sort();
    el.innerHTML = `<div class="card src">
      <div class="fhead"><h3>Support &amp; Resistance</h3><span class="dim" style="font-size:11px">from option OI · ${winTxt}</span></div>
      ${lvl(R, 'Resistance (max Call OI)')}
      ${range}
      ${lvl(S, 'Support (max Put OI)')}
      ${hr.length ? `<div class="srhist">Moves today: ${hr.join(' · ')}</div>` : '<div class="srhist">No support/resistance shift yet today.</div>'}
      <div class="hzcap">Shift forecast: a strike with ≥75% of the level's OI and building faster can take over; writers exiting the level weaken it. Guide only.</div>
    </div>`;
  }

  // ------- Home: ATM CE vs PE OI-change comparison
  function renderAtm(d) {
    const el = $('atmCard');
    if (!d) { el.innerHTML = ''; return; }
    const { cur, h, key } = d;
    const prev = C.compare(cur, null);                 // OI change vs previous close
    const atm = prev[C.atmIndex(prev, cur.spot)];
    if (!atm) { el.innerHTML = ''; return; }
    const at = (mins) => {                              // OI change at this strike N minutes ago
      const b = C.baseline(h, st.first[key], String(mins));
      if (!b || b === cur || cur.ts - b.ts < (mins - 1) * 60000) return null;
      const r = b.rows.find(x => x.strike === atm.strike);
      return r ? { ce: r.ce.oi - r.ce.poi, pe: r.pe.oi - r.pe.poi } : null;
    };
    const m5 = at(5), m15 = at(15);
    const ce = atm.ce.doi, pe = atm.pe.doi;
    const mv = (b, side) => b ? (side === 'ce' ? ce - b.ce : pe - b.pe) : NaN;
    const cell = v => isFinite(v) ? `<b class="${cls(v)}">${sQ(v)}</b>` : '<span class="dim">—</span>';
    const mx = Math.max(1, Math.abs(ce), Math.abs(pe));
    const bar = (v, c) => `<div class="abar"><div class="${c} ${v < 0 ? 'neg' : ''}" style="width:${(Math.abs(v) / mx * 100).toFixed(0)}%"></div></div>`;
    const d5 = [mv(m5, 'ce'), mv(m5, 'pe')], d15 = [mv(m15, 'ce'), mv(m15, 'pe')];
    const pick = isFinite(d5[0]) ? d5 : isFinite(d15[0]) ? d15 : null, plab = isFinite(d5[0]) ? '5 min' : '15 min';
    let verdict = '', vcls = '';
    if (pick) {
      const [c5, p5] = pick;
      if (p5 > 0 && p5 > c5) { verdict = `Put writing at ATM is growing faster (last ${plab}): support building, bullish tilt.`; vcls = 'up'; }
      else if (c5 > 0 && c5 > p5) { verdict = `Call writing at ATM is growing faster (last ${plab}): resistance building, bearish tilt.`; vcls = 'dn'; }
      else if (c5 < 0 && p5 >= c5) { verdict = `Call writers at ATM are exiting (last ${plab}): upside can open up.`; vcls = 'up'; }
      else if (p5 < 0 && c5 >= p5) { verdict = `Put writers at ATM are exiting (last ${plab}): downside can open up.`; vcls = 'dn'; }
      else verdict = `Little change at ATM in the last ${plab}.`;
    } else {
      verdict = pe > ce ? 'Today so far: more put writing than call writing at ATM.' : ce > pe ? 'Today so far: more call writing than put writing at ATM.' : 'ATM OI change is balanced.';
      verdict += ' (5/15-min moves appear once the app has tracked a few minutes.)';
    }
    el.innerHTML = `<div class="card atc">
      <div class="fhead"><h3>ATM ${fmtK(atm.strike)} · CE vs PE</h3><span class="dim" style="font-size:11px">spot ${f2(cur.spot)}</span></div>
      <div class="atgrid num">
        <div></div><div class="ah ce">CE</div><div class="ah pe">PE</div>
        <div class="al">OI</div><div>${Q(atm.ce.oi)}</div><div>${Q(atm.pe.oi)}</div>
        <div class="al">OI chg today</div><div>${cell(ce)}</div><div>${cell(pe)}</div>
        <div class="al">OI chg %</div><div>${cell2(atm.ce.doiPct)}</div><div>${cell2(atm.pe.doiPct)}</div>
        <div class="al">Last 5 min</div><div>${cell(d5[0])}</div><div>${cell(d5[1])}</div>
        <div class="al">Last 15 min</div><div>${cell(d15[0])}</div><div>${cell(d15[1])}</div>
        <div class="al">LTP</div><div>${f2(atm.ce.ltp)}</div><div>${f2(atm.pe.ltp)}</div>
      </div>
      <div class="acmp"><span class="ce">CE</span>${bar(ce, 'ce')}<span class="num">${sQ(ce)}</span></div>
      <div class="acmp"><span class="pe">PE</span>${bar(pe, 'pe')}<span class="num">${sQ(pe)}</span></div>
      <div class="zverdict ${vcls}">${verdict}</div>
    </div>`;
  }
  const cell2 = v => isFinite(v) ? `<b class="${cls(v)}">${sgn(v, x => x.toFixed(1))}%</b>` : '<span class="dim">—</span>';

  function renderChain(d) {
    const tbl = $('chainTbl');
    if (!d) { tbl.innerHTML = ''; $('chainSub').innerHTML = loadingMsg(); return; }
    const { cur, rows, key } = d;
    const view = C.windowRows(rows, cur.spot, st.settings.strikes);
    let maxOi = 1; for (const r of view) maxOi = Math.max(maxOi, r.ce.oi, r.pe.oi);
    const atm = view[C.atmIndex(view, cur.spot)];
    const zeroish = zeroTester(key, view);
    const head = `<colgroup><col style="width:14.5%"><col style="width:14%"><col style="width:13.5%"><col style="width:16%"><col style="width:13.5%"><col style="width:14%"><col style="width:14.5%"></colgroup>
      <thead><tr><th class="ceh"><span class="side">CALLS</span>OI</th><th class="ceh">OI chg</th><th class="ceh">LTP</th><th class="s">Strike</th><th class="pe peh"><span class="side">PUTS</span>LTP</th><th class="pe peh">OI chg</th><th class="pe peh">OI</th></tr></thead>`;
    let body = '', spotDone = false;
    for (const r of view) {
      if (!spotDone && r.strike > cur.spot) { body += spotRow(cur.spot); spotDone = true; }
      const isAtm = r === atm, open = st.openRow === r.strike;
      const wc = (r.ce.oi / maxOi * 100).toFixed(1), wp = (r.pe.oi / maxOi * 100).toFixed(1);
      body += `<tr data-k="${r.strike}" class="${isAtm ? 'atm ' : ''}${r.strike < cur.spot ? 'itm-ce' : 'itm-pe'}">
        <td class="oice ${r.strike === cur.res ? 'maxoi' : ''}" style="--w:${wc}%">${Q(r.ce.oi)}</td>
        <td class="chg ${zeroish(r, 0) ? 'zero' : cls(r.ce.doi)}">${sQ(r.ce.doi)}</td>
        <td>${f2(r.ce.ltp)}</td>
        <td class="s">${fmtK(r.strike)}</td>
        <td class="pe">${f2(r.pe.ltp)}</td>
        <td class="pe chg ${zeroish(r, 1) ? 'zero' : cls(r.pe.doi)}">${sQ(r.pe.doi)}</td>
        <td class="pe oipe ${r.strike === cur.sup ? 'maxoi' : ''}" style="--w:${wp}%">${Q(r.pe.oi)}</td></tr>`;
      if (open) body += detailRow(r);
    }
    if (!spotDone) body += spotRow(cur.spot);
    tbl.innerHTML = head + '<tbody>' + body + '</tbody>';
    $('chainSub').innerHTML = subLine(d);
    if (st.scrolledFor !== key) {
      st.scrolledFor = key;
      const a = tbl.querySelector('tr.atm');
      if (a) setTimeout(() => { const y = a.getBoundingClientRect().top + window.scrollY - window.innerHeight / 2; window.scrollTo(0, Math.max(0, y)); }, 30);
    }
  }
  const subLine = d => `${srcLabel()} · updated ${C.istTime(d.cur.ts, true)} (${ago(d.cur.ts)}) · OI chg vs <b>${winLabel()}</b>`;
  function srcLabel() { const s = st.srcUsed[st.ui.index] || C.INDICES[st.ui.index].src; return s === 'Flattrade' ? '<b class="up">⚡ Flattrade live</b>' : s; }
  function spotRow(spot) { return `<tr class="spot"><td colspan="7"><div class="sl"><span>Spot ${f2(spot)}</span></div></td></tr>`; }
  function buTag(b) { if (!b) return '<span class="bu" style="color:var(--muted);background:var(--panel2)">No clear buildup</span>'; return `<span class="bu ${/Long buildup|Short covering/.test(b) ? 'g' : 'r'}">${b}</span>`; }
  function detailRow(r) {
    const side = (sd, name) => {
      const x = r[sd];
      return `<div><h4 class="${sd}h">${name} ${fmtK(r.strike)}</h4>${buTag(x.bu)}
        <div class="kv"><span>OI</span><b>${Q(x.oi)}</b></div>
        <div class="kv"><span>OI chg</span><b class="${cls(x.doi)}">${sQ(x.doi)} (${sgn(x.doiPct, v => v.toFixed(1))}%)</b></div>
        <div class="kv"><span>LTP</span><b>${f2(x.ltp)}</b></div>
        <div class="kv"><span>LTP chg</span><b class="${cls(x.dltp)}">${sgn(x.dltp, f2)}</b></div>
        <div class="kv"><span>IV</span><b>${x.iv ? x.iv.toFixed(1) : '–'}</b></div></div>`;
    };
    return `<tr class="detail"><td colspan="7"><div class="dgrid">${side('ce', 'CALL')}${side('pe', 'PUT')}</div></td></tr>`;
  }
  const winLabel = () => (WINDOWS.find(w => w[0] === st.ui.win) || [])[1].replace(/^9:15$/, 'since 9:15').toLowerCase();
  function loadingMsg() {
    if (st.errors[st.ui.index]) return '';
    return st.busy || !st.lastOk ? `Fetching option chain from ${C.INDICES[st.ui.index].src}…` : 'No data for this expiry yet.';
  }

  function renderOI(d) {
    for (const b of $('oiToggle').children) b.classList.toggle('on', b.dataset.m === st.ui.oiMode);
    if (!d) { $('bf').innerHTML = `<div class="sub" style="grid-column:1/-1">${loadingMsg()}</div>`; $('lean').innerHTML = ''; $('leanNote').textContent = ''; return; }
    const { cur, rows } = d, m = st.ui.oiMode;
    const view = C.windowRows(rows, cur.spot, st.settings.strikes);
    const val = (r, sd) => (m === 'oi' ? r[sd].oi : r[sd].doi);
    let mx = 1; for (const r of view) mx = Math.max(mx, Math.abs(val(r, 'ce')), Math.abs(val(r, 'pe')));
    const atm = view[C.atmIndex(view, cur.spot)];
    let h = '';
    for (const r of view) {
      const c = val(r, 'ce'), p = val(r, 'pe');
      const kc = r === atm ? 'atm' : (r.strike === cur.mp ? 'mp' : '');
      h += `<div class="vl">${m === 'oi' ? Q(c) : sQ(c)}</div>
            <div class="l"><div class="bar ${c < 0 ? 'neg' : ''}" style="width:${(Math.abs(c) / mx * 100).toFixed(1)}%"></div></div>
            <div class="k ${kc}">${fmtK(r.strike)}</div>
            <div class="r"><div class="bar ${p < 0 ? 'neg' : ''}" style="width:${(Math.abs(p) / mx * 100).toFixed(1)}%"></div></div>
            <div class="vr">${m === 'oi' ? Q(p) : sQ(p)}</div>`;
    }
    $('bf').innerHTML = h;
    let dce = 0, dpe = 0; for (const r of view) { dce += r.ce.doi; dpe += r.pe.doi; }
    $('lean').innerHTML = `<div><div class="k">Call OI chg near ATM</div><div class="v num" style="color:var(--ce)">${sQ(dce)}</div></div>
                           <div><div class="k">Put OI chg near ATM</div><div class="v num" style="color:var(--pe)">${sQ(dpe)}</div></div>`;
    $('leanNote').innerHTML = (dce === 0 && dpe === 0) ? '' :
      (dpe > dce ? 'Put writers more active than call writers: supportive / bullish tilt.' : 'Call writers more active than put writers: capping / bearish tilt.')
      + ` Change vs ${winLabel()}. ${m === 'doi' ? 'Hollow bars = OI reduced.' : 'Blue = ATM, amber outline = max pain.'}`;
  }

  // ------- trend charts (hand-drawn SVG)
  function lineChart(series, opt) {
    const W = 360, H = opt.h || 170, pl = 46, pr = 8, pt = 10, pb = 20;
    const xs = series[0].pts.map(p => p.t);
    if (xs.length < 2) return '';
    const t0 = xs[0], t1 = xs[xs.length - 1] || t0 + 1;
    let lo = Infinity, hi = -Infinity;
    for (const s of series) for (const p of s.pts) if (isFinite(p.v)) { lo = Math.min(lo, p.v); hi = Math.max(hi, p.v); }
    (opt.bands || []).forEach(b => { lo = Math.min(lo, b.v); hi = Math.max(hi, b.v); });
    if (!isFinite(lo)) return '';
    if (hi - lo < 1e-9) { hi += 1; lo -= 1; }
    const padv = (hi - lo) * 0.08; lo -= padv; hi += padv;
    const X = t => pl + (t - t0) / (t1 - t0 || 1) * (W - pl - pr);
    const Y = v => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
    let g = '';
    for (let i = 0; i <= 3; i++) {
      const v = lo + (hi - lo) * i / 3, y = Y(v).toFixed(1);
      g += `<line x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}" stroke="#262D37" stroke-width="1"/><text x="${pl - 6}" y="${+y + 3}" text-anchor="end">${opt.fmt(v)}</text>`;
    }
    for (const b of (opt.bands || [])) g += `<line x1="${pl}" x2="${W - pr}" y1="${Y(b.v).toFixed(1)}" y2="${Y(b.v).toFixed(1)}" stroke="${b.c}" stroke-dasharray="4 4" stroke-width="1.2"/>`;
    const tl = [t0, (t0 + t1) / 2, t1];
    tl.forEach((t, i) => { g += `<text x="${X(t).toFixed(1)}" y="${H - 5}" text-anchor="${['start', 'middle', 'end'][i]}">${C.istTime(t)}</text>`; });
    for (const s of series) {
      const d = s.pts.filter(p => isFinite(p.v)).map((p, i) => `${i ? 'L' : 'M'}${X(p.t).toFixed(1)},${Y(p.v).toFixed(1)}`).join('');
      g += `<path d="${d}" fill="none" stroke="${s.c}" stroke-width="${s.w || 2}" ${s.dash ? 'stroke-dasharray="5 4"' : ''} stroke-linejoin="round" stroke-linecap="round"/>`;
    }
    const keys = series.map(s => `<span><i style="background:${s.c}"></i>${s.n}</span>`).join('');
    return `<svg class="chart" viewBox="0 0 ${W} ${H}">${g}</svg><div class="keys">${keys}</div>`;
  }
  function renderTrends(d) {
    const el = $('trends');
    if (!d || d.series.length < 2) { el.innerHTML = `<div class="empty">Trends appear after a few updates.<br>History builds up through the day.</div>`; return; }
    const s = d.series, pts = f => s.map(x => ({ t: x.ts, v: f(x) }));
    const S = st.settings;
    el.innerHTML =
      `<div class="card"><h3>Near-ATM OI change</h3><div class="cap">ATM ±5 strikes total, the hero-zero input. A side falling toward zero = writers exiting.</div>${lineChart(
        [{ n: 'CE OI chg', c: '#F2555A', pts: pts(x => x.nce) }, { n: 'PE OI chg', c: '#2FB37A', pts: pts(x => x.npe) }],
        { fmt: Q, bands: [{ v: 0, c: '#5D6674' }] })}</div>` +
      `<div class="card"><h3>PCR</h3><div class="cap">Put OI ÷ Call OI · dashed lines = your alert levels</div>${lineChart(
        [{ n: 'PCR', c: '#4C7DFF', pts: pts(x => x.pcr) }],
        { fmt: v => v.toFixed(2), bands: [{ v: S.pcrHigh, c: '#2FB37A' }, { v: S.pcrLow, c: '#F2555A' }] })}</div>` +
      `<div class="card"><h3>Spot vs key levels</h3><div class="cap">Where OI says the floor and ceiling are</div>${lineChart(
        [{ n: 'Spot', c: '#E6EAF0', pts: pts(x => x.spot), w: 2.2 },
         { n: 'Resistance', c: '#F2555A', pts: pts(x => x.res), w: 1.6 },
         { n: 'Support', c: '#2FB37A', pts: pts(x => x.sup), w: 1.6 },
         { n: 'Max pain', c: '#F5A524', pts: pts(x => x.mp), w: 1.6, dash: 1 }],
        { fmt: v => Math.round(v).toLocaleString('en-IN'), h: 200 })}</div>` + futTrends();
  }
  function futTrends() {
    const s = st.fut.series;
    if (s.length < 2) return '';
    const pts = f => s.map(x => ({ t: x.ts, v: f(x) }));
    return `<div class="card"><h3>NIFTY futures vs spot</h3><div class="cap">Futures above spot and widening = buyers in control</div>${lineChart(
        [{ n: 'Futures', c: '#4C7DFF', pts: pts(x => x.ltp), w: 2.2 }, { n: 'Spot', c: '#E6EAF0', pts: pts(x => x.spot), w: 1.6 }],
        { fmt: v => Math.round(v).toLocaleString('en-IN') })}</div>` +
      `<div class="card"><h3>NIFTY futures OI</h3><div class="cap">Rising OI + rising price = long buildup; rising OI + falling price = short buildup</div>${lineChart(
        [{ n: 'Futures OI', c: '#F5A524', pts: pts(x => x.oi) }], { fmt: Q })}</div>`;
  }

  function renderAlerts() {
    st.unseen = 0;
    const icon = { 'PCR': '⚖️', 'OI spike': '⚡', 'Support': '🟩', 'Resistance': '🟥', 'Max pain': '🎯', 'Hero-zero': '🚀', 'Futures': '📊' };
    const list = st.alerts.slice().reverse();
    $('alertList').innerHTML = list.length ? list.map(a => `<div class="alert"><div class="ic">${icon[a.kind] || '🔔'}</div><div>
        <div class="t"><b>${C.istTime(a.ts)}</b> · ${a.index} ${fmtExp(a.expiry)} · ${a.kind}</div><div class="msg">${esc(a.msg)}</div></div></div>`).join('')
      : `<div class="empty">No alerts yet today.<br>Alerts run during market hours. You can change thresholds in Settings.</div>`;
  }

  let settingsFilled = false;
  function renderSettings() {
    const line = (src, idx) => {
      const dg = st.diag[src], err = st.errors[idx];
      const state = err ? `<span class="dn">✗ ${esc(err)}</span>` : dg ? (dg.ok ? '<span class="up">✓ Working</span>' : '<span class="dn">✗ No data</span>') : 'Not checked yet';
      return `<div><b>${src}</b> (${idx}) · ${state}${dg ? `<br><span class="dim">Last call ${C.istTime(dg.at, true)} · HTTP ${dg.status}</span>` : ''}</div>`;
    };
    $('connStatus').innerHTML = line('NSE', 'NIFTY') + '<div style="height:6px"></div>' + line('BSE', 'SENSEX');
    const diagEl = $('diagOut');
    if (diagEl.dataset.open === '1') {
      diagEl.innerHTML = ['NSE', 'BSE'].map(src => { const dg = st.diag[src]; return dg ? `<b>${src}</b> ${esc(dg.url)}<br>HTTP ${dg.status}<pre>${esc(dg.snippet || '(empty)')}</pre>` : `<b>${src}</b>: no call yet`; }).join('<hr>');
    }
    $('ftStatus').innerHTML = `<b>${FT.status()}</b>` + (st.ftErr ? `<br><span class="dn">${esc(st.ftErr)}</span>` : '');
    $('srcFt').classList.toggle('on', wantFT()); $('srcEx').classList.toggle('on', !wantFT());
    $('ftLoginBtn').textContent = FT.ready() ? 'Logged in for today ✓ (log in again)' : 'Log in to Flattrade (today)';
    const fd = $('ftDiagOut');
    if (fd.dataset.open === '1') fd.innerHTML = FT.diag.length ? FT.diag.map(x => `<b>${C.istTime(x.at, true)} ${esc(x.what)}</b><pre>${esc(x.detail)}</pre>`).join('') : 'No Flattrade calls yet.';
    if (settingsFilled) return;
    settingsFilled = true;
    $('ftUid').value = FT.cfg.uid; $('ftKey').value = FT.cfg.key;
    $('ftSecret').value = ''; $('ftSecret').placeholder = FT.cfg.secret ? 'Saved ✓ (paste to replace)' : 'API secret';
    $('ftRedirect').textContent = FT.REDIRECT;
    const S = st.settings;
    $('strikes').value = S.strikes; $('strikesVal').textContent = S.strikes;
    $('sNotify').checked = S.notify; $('sPcr').checked = S.pcrAlerts; $('sLevel').checked = S.levelAlerts; $('sSpike').checked = S.spikeAlerts;
    $('sPcrHigh').value = S.pcrHigh; $('sPcrLow').value = S.pcrLow; $('sSpikePct').value = S.spikePct;
    $('sSpikeWin').value = String(S.spikeWin); $('sSpikeShare').value = S.spikeShare; $('sCool').value = S.cooldown;
    $('hMin').value = S.heroMin; $('hMax').value = S.heroMax; $('hDrop').value = S.heroDrop;
    $('hStart').value = `${String(Math.floor(S.heroStart / 60)).padStart(2, '0')}:${String(S.heroStart % 60).padStart(2, '0')}`;
    $('bgOn').checked = !!st.ui.bg;
  }

  // ------------------------------------------------------------------- events
  function saveUi() { store.set('oi.ui', st.ui); }
  function go(view) {
    st.ui.view = view; saveUi();
    for (const b of $('nav').children) b.classList.toggle('on', b.dataset.v === view);
    for (const v of document.querySelectorAll('.view')) v.classList.toggle('on', v.id === 'v-' + view);
    if (view === 'settings') settingsFilled = false;
    if (view === 'daily') NEWS.refresh(false).then(render).catch(() => { });
    window.scrollTo(0, 0); st.scrolledFor = null;
    render();
  }

  function bind() {
    $('winChips').insertAdjacentHTML('beforeend', WINDOWS.map(w => `<button class="chip" data-w="${w[0]}">${w[1]}</button>`).join(''));
    $('winChips').addEventListener('click', e => { const b = e.target.closest('.chip'); if (!b) return; st.ui.win = b.dataset.w; saveUi(); render(); });
    $('idxSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; st.ui.index = b.dataset.i; st.openRow = null; st.scrolledFor = null; saveUi(); render(); });
    $('expSel').addEventListener('change', e => {
      st.sel[st.ui.index] = e.target.value; st.scrolledFor = null; st.openRow = null; render();
      if (!(st.snaps[curKey()] || []).length) cycle(true);
    });
    $('refresh').addEventListener('click', () => cycle(true));
    document.querySelector('.brand').addEventListener('click', () => go('settings'));
    $('nav').addEventListener('click', e => { const b = e.target.closest('button'); if (b) go(b.dataset.v); });
    document.body.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) go(b.dataset.go); });
    $('chainTbl').addEventListener('click', e => {
      const tr = e.target.closest('tr[data-k]'); if (!tr) return;
      const k = +tr.dataset.k; st.openRow = st.openRow === k ? null : k; render();
    });
    $('oiToggle').addEventListener('click', e => { const b = e.target.closest('.chip'); if (!b) return; st.ui.oiMode = b.dataset.m; saveUi(); render(); });
    $('clearAlerts').addEventListener('click', () => { st.alerts = []; saveDay(); render(); });
    $('diagBtn').addEventListener('click', () => { const el = $('diagOut'); el.dataset.open = el.dataset.open === '1' ? '0' : '1'; if (el.dataset.open !== '1') el.innerHTML = ''; renderSettings(); });
    const ftLogin = () => {
      FT.login().then(() => { toast('Flattrade connected ✓'); st.settings.source = 'ft'; saveSettings(); settingsFilled = false; cycle(true); })
        .catch(e => { toast((e && e.msg) || 'Login failed'); render(); });
    };
    document.body.addEventListener('click', e => { if (e.target.closest('[data-ftlogin]')) ftLogin(); });
    $('ftSave').addEventListener('click', () => {
      const uid = $('ftUid').value.trim().toUpperCase(), key = $('ftKey').value.trim(), sec = $('ftSecret').value.trim() || FT.cfg.secret;
      if (!uid || !key || !sec) { toast('Enter client ID, API key and API secret'); return; }
      FT.saveCfg({ uid, key, secret: sec }); settingsFilled = false; toast('Saved. Now tap "Log in to Flattrade".'); render();
    });
    $('ftLoginBtn').addEventListener('click', ftLogin);
    $('srcFt').addEventListener('click', () => { st.settings.source = 'ft'; saveSettings(); render(); if (FT.ready()) cycle(true); else toast('Save your Flattrade details and log in'); });
    $('srcEx').addEventListener('click', () => { st.settings.source = 'exchange'; saveSettings(); st.live = {}; st.fut.liveCur = null; render(); cycle(true); });
    $('ftCopy').addEventListener('click', () => { try { navigator.clipboard.writeText(FT.REDIRECT); toast('Redirect URL copied'); } catch (e) { toast(FT.REDIRECT); } });
    $('ftDiagBtn').addEventListener('click', () => { const el = $('ftDiagOut'); el.dataset.open = el.dataset.open === '1' ? '0' : '1'; if (el.dataset.open !== '1') el.innerHTML = ''; renderSettings(); });
    $('daily').addEventListener('click', e => {
      if (e.target.closest('#giftSave')) {
        const v = parseFloat($('giftIn').value);
        if (!(v > 1000)) { toast('Enter the GIFT Nifty value, e.g. 25120'); return; }
        store.set('oi.gift', { v, ts: Date.now() }); toast('GIFT Nifty saved'); render(); return;
      }
      const t = e.target.closest('[data-nt]'); if (t) { st.ui.newsTab = t.dataset.nt; saveUi(); render(); return; }
      if (e.target.closest('#newsRefresh')) { toast('Loading news…'); NEWS.refresh(true).then(render); return; }
      const ni = e.target.closest('[data-ni]');
      if (ni) { const x = NEWS.items[+ni.dataset.ni]; if (x && x.link) { if (Bridge && Bridge.openUrl) Bridge.openUrl(x.link); else window.open(x.link, '_blank'); } }
    });
    $('retryNow').addEventListener('click', () => { st.nseWarmAt = 0; st.bseWarmAt = 0; st.expFetchedAt = {}; toast('Fetching from NSE & BSE…'); cycle(true); });

    $('strikes').addEventListener('input', e => { st.settings.strikes = +e.target.value; $('strikesVal').textContent = e.target.value; saveSettings(); });
    const bindCk = (id, k) => $(id).addEventListener('change', e => { st.settings[k] = e.target.checked; saveSettings(); });
    bindCk('sNotify', 'notify'); bindCk('sPcr', 'pcrAlerts'); bindCk('sLevel', 'levelAlerts'); bindCk('sSpike', 'spikeAlerts');
    const bindNum = (id, k, lo, hi) => $(id).addEventListener('change', e => {
      let v = parseFloat(e.target.value); if (!isFinite(v)) v = C.DEFAULT_SETTINGS[k];
      v = Math.min(hi, Math.max(lo, v)); e.target.value = v; st.settings[k] = v; saveSettings();
    });
    bindNum('sPcrHigh', 'pcrHigh', 0.3, 5); bindNum('sPcrLow', 'pcrLow', 0.05, 3); bindNum('sSpikePct', 'spikePct', 2, 500);
    bindNum('sSpikeShare', 'spikeShare', 0, 100); bindNum('sCool', 'cooldown', 1, 240); bindNum('sSpikeWin', 'spikeWin', 1, 60);
    bindNum('hMin', 'heroMin', 0.05, 500); bindNum('hMax', 'heroMax', 0.1, 1000); bindNum('hDrop', 'heroDrop', 10, 100);
    $('hStart').addEventListener('change', e => {
      const m = /^(\d{1,2}):(\d{2})$/.exec(e.target.value);
      if (m) { st.settings.heroStart = +m[1] * 60 + +m[2]; saveSettings(); }
    });
    $('testNotif').addEventListener('click', () => { notify("EVD Pulse", 'Test alert ✓ Notifications are working.'); toast('Test notification sent'); });
    $('bgOn').addEventListener('change', e => {
      st.ui.bg = e.target.checked; saveUi();
      if (Bridge && Bridge.setBackground) Bridge.setBackground(st.ui.bg);
      toast(st.ui.bg ? 'Background tracking on' : 'Background tracking off');
    });
    $('battery').addEventListener('click', () => { if (Bridge && Bridge.openBatterySettings) Bridge.openBatterySettings(); else toast('Available in the Android app'); });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        render();
        if (!st.busy && (!st.lastOk || Date.now() - st.lastOk > 70000)) cycle(false);
      }
    });
    setInterval(() => { if (document.visibilityState === 'visible' && !st.busy) { renderTop(); if (st.ui.view === 'chain') { const d = current(); if (d) $('chainSub').innerHTML = subLine(d); } } }, 10000);
  }
  function saveSettings() { store.set('oi.settings', st.settings); }

  // live refresh: every 2 s rebuild the visible chain + futures from Flattrade ticks
  setInterval(() => {
    if (!useFT() || st.busy || document.visibilityState !== 'visible') return;
    const index = st.ui.index, iso = st.sel[index];
    if (!iso || !FT.hasChain(index, iso)) return;
    const p = FT.chain(index, iso, lastSpot(index));
    if (p.rows.length && p.spot) { st.live[index + '|' + iso] = C.makeSnap(Date.now(), p.spot, p.rows); st.srcUsed[index] = 'Flattrade'; }
    const q = FT.futQuote();
    if (q) st.fut.liveCur = { ltp: q.ltp, oi: q.oi, spot: q.underlying || lastSpot('NIFTY'), ts: Date.now() };
    if (['home', 'chain', 'oi'].includes(st.ui.view)) render();
  }, 2000);

  // -------------------------------------------------------------------- start
  loadDay();
  bind();
  go(st.ui.view);
  if (Bridge && Bridge.setBackground && st.ui.bg) Bridge.setBackground(true);
  setTimeout(() => { const sp = $('splash'); if (sp) { sp.classList.add('hide'); setTimeout(() => sp.remove(), 500); } }, 1300);
  cycle(true);
})();
