# OI Tracker: Android app for NIFTY & SENSEX option chains (Dhan)

A phone app that pulls the option chain straight from Dhan every minute during market hours and shows:

- **Chain**: Call/Put OI with bars, change in OI, LTP, ATM and spot marker. Tap a strike for buildup (long buildup / short buildup / short covering / long unwinding), ΔOI %, ΔLTP, IV and volume.
- **Change vs**: previous close, 9:15, or the last 5 min, 15 min, 30 min or 1 hr.
- **PCR, max pain, support** (highest Put OI), **resistance** (highest Call OI), and net ΔOI.
- **OI view**: butterfly chart of OI or change in OI by strike, plus whether call or put writers are more active near ATM.
- **Trends**: PCR, spot vs support/resistance/max pain, and total OI through the day.
- **Alerts as phone notifications**: PCR crossing your levels, sudden OI change at near-ATM strikes, and support/resistance/max pain shifts.

Your Dhan token is stored only on your phone. The app only reads market data and never places orders. Without a token, it runs on demo data.

---

## Step 1: Build the APK (one time, free, about 10 minutes)

The APK is built on GitHub's free build servers. You don't need to install anything on your computer.

1. Sign in at **github.com** (create a free account if needed).
2. Create a **New repository** named `oi-tracker` and set it to **Private**.
3. Upload the project:
   - **On a laptop:** unzip `oi-tracker-android.zip`. On the new repo page, click **uploading an existing file**, then drag in everything *inside* the `oi-tracker-android` folder, including the `.github` folder. Then click **Commit changes**.
     - On a Mac, hidden folders like `.github` don't show in Finder. Press **Cmd + Shift + .** to show them.
   - **Or let Claude do it:** tell Claude the repository name, and Claude can upload it for you if your GitHub is connected.
4. Open the repo's **Actions** tab. A run called **Build APK** starts by itself and takes about 4 minutes. A green tick means it's done.
5. Open the repo's main page and find **Releases** on the right. Open the latest one and download **OI-Tracker.apk**. Do this on your phone, signed in to GitHub in the browser.

## Step 2: Install on your phone

1. Tap the downloaded **OI-Tracker.apk**.
2. If Android asks, allow **Install unknown apps** for your browser or Files app. This is normal for apps not from the Play Store.
3. If Play Protect warns that the app is unrecognised, tap **More details → Install anyway**. The warning appears because the app is your personal build, not a Play Store listing.
4. Open **OI Tracker** and allow notifications.

## Step 3: Connect Dhan

1. Make sure **Data APIs** are active on your Dhan account. Dhan may charge for this; check their current terms.
2. On **web.dhan.co**, go to **Profile → Access DhanHQ APIs** and note your **Client ID**. Then tap **Generate token**.
3. In the app, go to **Settings**, enter your Client ID, paste the token, and tap **Save & connect**.

The token is valid for **24 hours**. The app renews it automatically while it's active. If the app shows **TOKEN** in the top corner, generate a new token and paste it again.

## Step 4: Keep alerts running with the screen off

In **Settings**, turn on **Keep tracking in background** and tap **Allow unrestricted battery use**. Set Battery to **Unrestricted / No restrictions**.

On Xiaomi/Redmi/POCO, also turn on **Autostart** for the app. On Realme, Oppo and Vivo, allow **background activity**.

Pressing **Back** keeps the app running in the background. Swiping it away from Recent apps stops tracking.

---

## Alert settings (in the app → Settings)

| Setting | Default | Meaning |
|---|---|---|
| PCR above / below | 1.30 / 0.70 | Alert when PCR crosses these levels |
| OI change % | 20% within 5 min | A near-ATM strike's OI jumps or drops this much |
| Ignore strikes below | 3% of top OI | Skips tiny far-OTM strikes |
| Don't repeat for | 15 min | Same alert won't repeat within this time |

Spike alerts skip 9:15–9:20 because OI is noisy at the open.

## Updating the app later

Any change pushed to the repo builds a new APK under Releases. Install it over the old one; your settings and token stay.

## Technical notes

- Dhan API v2: `POST /v2/optionchain` and `/v2/optionchain/expirylist`, one request every 3 s per index/expiry. The app makes 4 chain calls a minute.
- NIFTY = security ID 13 and SENSEX = 51, segment `IDX_I`. To change them, edit `INDICES` in `app/src/main/assets/core.js`.
- The UI is HTML/JS in `app/src/main/assets/` running in a WebView. The native Java side only does HTTP, notifications and the background service.
- The signing key `app/oitracker.jks` is included so every build can update the installed app. Keep the repo private.
- This is an analysis tool, not trading advice.
