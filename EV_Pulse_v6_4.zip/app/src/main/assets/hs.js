/* EV Pulse — HDFC Sky live data (Open API). Login once a day, then a websocket streams ticks (protobuf frames). */
(function (root) {
  'use strict';

  const HOST = 'https://developer.hdfcsky.com';
  const WS_URL = 'wss://developer.hdfcsky.com/wsapi/v1/session';
  const MASTER = 'https://hdfcsky.com/api/v1/contract/Compact?info=download';
  const DEF_REDIRECT = 'https://127.0.0.1/evpulse-hdfc';
  const UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36';
  const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const CFG = { NIFTY: { exch: 'NFO', step: 50 }, SENSEX: { exch: 'BFO', step: 100 } };
  const N_SIDE = 15;                     // strikes each side of ATM to stream

  // ---------------------------------------------------------------- protobuf (just what the feed needs)
  function b64bytes(b64) { const s = atob(b64 || ''); const a = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
  function pbFields(buf, start, end) {    // -> [{f, w, v}] ; v = number (varint), [s,e] (bytes), or double
    const out = []; let i = start;
    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    function varint() { let r = 0, mul = 1, b; do { if (i >= end) throw 0; b = buf[i++]; r += (b & 0x7f) * mul; mul *= 128; } while (b & 0x80); return r; }
    while (i < end) {
      const key = varint(), f = Math.floor(key / 8), w = key & 7;
      if (w === 0) out.push({ f, w, v: varint() });
      else if (w === 1) { if (i + 8 > end) throw 0; out.push({ f, w, v: dv.getFloat64(i, true) }); i += 8; }
      else if (w === 2) { const n = varint(); if (i + n > end) throw 0; out.push({ f, w, v: [i, i + n] }); i += n; }
      else if (w === 5) { if (i + 4 > end) throw 0; out.push({ f, w, v: dv.getFloat32(i, true) }); i += 4; }
      else throw 0;
    }
    return out;
  }
  function decodeDTO(buf, s, e) {
    const t = { id: 0, type: -1 };
    for (const x of pbFields(buf, s, e)) {
      if (x.f === 1 && x.w === 0) t.id = x.v;
      else if (x.f === 9 && x.w === 0) t.type = x.v;
      else if (x.f === 8 && x.w === 0) t.ts = x.v;
      else if (x.f === 2 && x.w === 2) {                    // MBPData
        const m = {};
        for (const y of pbFields(buf, x.v[0], x.v[1])) {
          if (y.w === 1) { if (y.f === 1) m.lp = y.v; else if (y.f === 7) m.c = y.v; else if (y.f === 11) m.ap = y.v; }
          else if (y.w === 0) { if (y.f === 9) m.v = y.v; else if (y.f === 17) m.oi = y.v; }
          else if (y.f === 12 && y.w === 2) {             // depth list
            for (const z of pbFields(buf, y.v[0], y.v[1])) if (z.f === 1 && z.w === 2) {
              let px = 0, buy = false;
              for (const q of pbFields(buf, z.v[0], z.v[1])) { if (q.f === 2 && q.w === 1) px = q.v; else if (q.f === 4 && q.w === 0) buy = !!q.v; }
              if (px > 0) { if (buy && !(m.bp1 > 0)) m.bp1 = px; if (!buy && !(m.sp1 > 0)) m.sp1 = px; }
            }
          }
        }
        t.mbp = m;
      } else if (x.f === 3 && x.w === 2) {                  // IndexData
        const m = {};
        for (const y of pbFields(buf, x.v[0], x.v[1])) if (y.w === 1) { if (y.f === 2) m.lp = y.v; else if (y.f === 6) m.c = y.v; }
        t.idx = m;
      }
    }
    return t;
  }
  /** One binary frame -> list of ticks. Frames are GenericDTOList (field 1 = repeated DTO) or a bare GenericDTO. */
  function decodeFrame(buf) {
    try {
      const top = pbFields(buf, 0, buf.length);
      if (top.length && top.every(x => x.f === 1 && x.w === 2)) return top.map(x => decodeDTO(buf, x.v[0], x.v[1]));
      return [decodeDTO(buf, 0, buf.length)];
    } catch (e) { return []; }
  }

  // ---------------------------------------------------------------- CSV (contract list)
  function csvRow(line) {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) { if (ch === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
      else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = ''; } else cur += ch;
    }
    out.push(cur); return out.map(s => s.trim());
  }
  function expIso(s) {                    // "25-Aug-2026" -> 2026-08-25
    const m = /^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/.exec(String(s || '').trim()); if (!m || +m[3] < 1900) return '';
    const mo = MON.indexOf(m[2].toUpperCase()); return mo < 0 ? '' : `${m[3]}-${String(mo + 1).padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  }
  /** Parse the filtered contract CSV into the compact list the app keeps. */
  function parseMaster(text, today) {
    const lines = String(text || '').split(/\r?\n/).filter(Boolean); if (lines.length < 2) return null;
    const head = csvRow(lines[0]).map(h => h.toLowerCase()), col = n => head.indexOf(n);
    const I = { tok: col('exchange_token'), sym: col('trading_symbol'), name: col('company_name'), exp: col('expiry'), k: col('strike'), lot: col('lot_size'),
      inst: col('instrument_name'), opt: col('option_type'), seg: col('segment'), ex: col('exchange') };
    if (I.tok < 0 || I.sym < 0 || I.ex < 0) return null;
    const M = { day: today, NIFTY: { opts: [], futs: [] }, SENSEX: { opts: [], futs: [] }, idx: {} };
    for (let n = 1; n < lines.length; n++) {
      const r = csvRow(lines[n]), ex = (r[I.ex] || '').toUpperCase(), sym = r[I.sym] || '', name = (r[I.name] || '').toUpperCase(), seg = (r[I.seg] || '').toUpperCase(), tok = r[I.tok];
      if (!tok) continue;
      if ((ex === 'NSE' && seg === 'INDICES') || (ex === 'BSE' && seg === 'IDX')) {
        const sN = sym.toUpperCase().replace(/\s+/g, ''), nN = name.replace(/\s+/g, '');
        if (ex === 'NSE' && (sN === 'NIFTY50' || sN === 'NIFTY' || nN === 'NIFTY50') && !M.idx.NIFTY) M.idx.NIFTY = 'NSE_INDEX_' + tok;
        else if (ex === 'NSE' && (/INDIAVIX/.test(sN) || /INDIAVIX/.test(nN))) M.idx.VIX = 'NSE_INDEX_' + tok;
        else if (ex === 'BSE' && (sN === 'SENSEX' || nN === 'SENSEX' || nN === 'S&PBSESENSEX' || nN === 'BSESENSEX') && !M.idx.SENSEX) M.idx.SENSEX = 'BSE_INDEX_' + tok;
        continue;
      }
      const index = ex === 'NFO' ? 'NIFTY' : ex === 'BFO' ? 'SENSEX' : null; if (!index) continue;
      const iso = expIso(r[I.exp]); if (!iso || iso < today) continue;
      const und = name || '';
      const usym = sym.toUpperCase();
      // the underlying must be exactly NIFTY / SENSEX (not BANKNIFTY, NIFTYNXT50, SENSEX50)
      const okU = und ? (und === index) : new RegExp('^' + index + '\\d').test(usym) && !/^SENSEX50/.test(usym);
      if (!okU) continue;
      const opt = (r[I.opt] || '').toUpperCase(), lot = parseInt(r[I.lot]) || 0;
      if (opt === 'CE' || opt === 'PE') {
        const k = parseFloat(r[I.k]); if (!(k > 0)) continue;
        M[index].opts.push([iso, k, opt, tok, sym, lot]);
      } else if (/FUT$/.test(usym)) M[index].futs.push([iso, tok, sym, lot]);
    }
    for (const i of ['NIFTY', 'SENSEX']) {
      const ex = [...new Set(M[i].opts.map(o => o[0]))].sort().slice(0, 4);    // keep the next 4 expiries only
      M[i].opts = M[i].opts.filter(o => ex.includes(o[0]));
      M[i].futs.sort((a, b) => a[0] < b[0] ? -1 : 1);
    }
    return M.NIFTY.opts.length || M.SENSEX.opts.length ? M : null;
  }

  function createHS(deps) {
    const { http, store, Core, openLogin, zipCsv } = deps;
    const C = Core;
    const hs = {
      name: 'HDFC Sky', DEF_REDIRECT,
      cfg: Object.assign({ key: '', secret: '', redirect: DEF_REDIRECT }, store.get('oi.hs.cfg', {})),
      sess: store.get('oi.hs.sess', null),        // {token, cid, at}
      live: {},                                    // scripId -> {lp, c, oi, poi, v, bp1, sp1, ts}
      subs: {}, fut: null, master: null,
      ws: null, wsState: 'off', wsWanted: new Set(), lastTick: 0,
      diag: [], err: null, prevOi: {}, oiQuotes: {},
    };
    function log(what, detail) { hs.diag.unshift({ at: Date.now(), what, detail: String(detail || '').slice(0, 500) }); hs.diag.length = Math.min(hs.diag.length, 14); }

    // ---- session: tokens roll over around 3 AM IST
    function lastReset(now) {
      const p = C.istParts(now), r = Date.UTC(p.y, p.mo - 1, p.d, 3, 0) - 5.5 * 3600e3;
      return now >= r ? r : r - 86400e3;
    }
    hs.configured = () => !!(hs.cfg.key && hs.cfg.secret);
    hs.ready = () => !!(hs.sess && hs.sess.token && hs.sess.at >= lastReset(Date.now()));
    hs.saveCfg = cfg => { hs.cfg = Object.assign({}, hs.cfg, cfg); if (!hs.cfg.redirect) hs.cfg.redirect = DEF_REDIRECT; store.set('oi.hs.cfg', hs.cfg); };
    hs.logout = () => { hs.sess = null; store.set('oi.hs.sess', null); closeWs(); };
    function jwtSub(t) {
      try { const p = String(t).split('.')[1]; if (!p) return ''; const j = JSON.parse(atob(p.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((p.length + 3) % 4)));
        return String(j.sub || j.client_id || j.clientId || ''); } catch (e) { return ''; }
    }
    function qparam(url, names) {
      const q = String(url || '').split('?')[1] || ''; const h = String(url || '').split('#')[1] || '';
      for (const part of (q.split('#')[0] + '&' + h).split('&')) { const [k, v] = part.split('='); if (names.includes(k)) return decodeURIComponent(v || ''); }
      return '';
    }
    hs.login = function () {
      return new Promise((resolve, reject) => {
        if (!hs.configured()) { reject({ msg: 'Enter your HDFC Sky API key and secret first.' }); return; }
        root.__hsUrl = async url => {
          root.__hsUrl = null;
          const rt = qparam(url, ['request_token', 'requestToken', 'token', 'code']);
          log('login redirect', String(url).replace(/(request_token|requestToken|token|code)=[^&]+/g, '$1=…'));
          if (!rt) { reject({ msg: url ? 'HDFC Sky login: no request token came back.' : 'Login cancelled.' }); return; }
          try {
            const u = `${HOST}/oapi/v1/access-token?api_key=${encodeURIComponent(hs.cfg.key)}&request_token=${encodeURIComponent(rt)}`;
            const r = await http('POST', u, { 'Content-Type': 'application/json', 'Accept': 'application/json', 'User-Agent': UA }, JSON.stringify({ apiSecret: hs.cfg.secret }));
            log('access-token HTTP ' + r.status, r.text);
            let j = null; try { j = JSON.parse(r.text); } catch (e) { }
            const tok = j && (j.accessToken || j.access_token || (j.data && (j.data.accessToken || j.data.access_token)));
            if (!tok) { reject({ msg: 'HDFC Sky login failed: ' + ((j && (j.message || j.error)) || ('HTTP ' + r.status)) }); return; }
            hs.sess = { token: tok, cid: jwtSub(tok), at: Date.now() };
            store.set('oi.hs.sess', hs.sess);
            hs.subs = {}; hs.fut = null; hs.err = null;
            hs.wsReset();
            resolve(hs.sess);
          } catch (e) { reject({ msg: 'HDFC Sky login error: ' + e }); }
        };
        openLogin(`${HOST}/oapi/v1/login?api_key=${encodeURIComponent(hs.cfg.key)}`, hs.cfg.redirect || DEF_REDIRECT, '__hsUrl');
      });
    };

    // ---- REST
    async function rest(method, path, params, body) {
      if (!hs.ready()) throw { msg: 'HDFC Sky: log in for today first (Settings).', login: true };
      const q = Object.assign({ api_key: hs.cfg.key }, params || {});
      const url = HOST + path + '?' + Object.keys(q).map(k => k + '=' + encodeURIComponent(q[k])).join('&');
      const h = { 'Authorization': hs.sess.token, 'User-Agent': UA, 'Accept': 'application/json' };
      if (body) h['Content-Type'] = 'application/json';
      const r = await http(method, url, h, body ? JSON.stringify(body) : '');
      log(method + ' ' + path + ' HTTP ' + r.status, r.text);
      let j = null; try { j = JSON.parse(r.text); } catch (e) { }
      if (r.status === 401 || /token.*(expired|invalid)|unauthori[sz]ed|session expired/i.test(String((j && (j.message || j.error)) || ''))) {
        hs.logout(); throw { msg: 'HDFC Sky session expired: log in again in Settings.', login: true };
      }
      if (!j) throw { msg: `HDFC Sky ${path}: no response (HTTP ${r.status}).` };
      return j;
    }
    const cidParam = () => (hs.sess && hs.sess.cid ? { client_id: hs.sess.cid } : {});

    // ---- contract list (once a day; cached on the phone)
    hs.master = store.get('oi.hs.master', null);
    let masterBusy = null;
    hs.loadMaster = function (force) {
      const today = C.istDate(Date.now());
      if (!force && hs.master && hs.master.day === today) return Promise.resolve(hs.master);
      if (masterBusy) return masterBusy;
      masterBusy = (async () => {
        const r = await zipCsv(MASTER, { 'User-Agent': UA, 'Accept': '*/*' }, '^[^,]*,"?(NIFTY|SENSEX)\\d|,"?(INDICES|IDX)"?,');
        log('contract list HTTP ' + r.status, (r.text || '').slice(0, 300));
        const M = r.status === 200 ? parseMaster(r.text, today) : null;
        if (!M) throw { msg: `HDFC Sky: couldn't load the contract list (HTTP ${r.status}).` };
        hs.master = M; try { store.set('oi.hs.master', M); } catch (e) { }
        log('contracts', `NIFTY ${M.NIFTY.opts.length} options, SENSEX ${M.SENSEX.opts.length}; index ids ${JSON.stringify(M.idx)}`);
        return M;
      })().finally(() => { masterBusy = null; });
      return masterBusy;
    };
    hs.expiries = index => hs.master && hs.master[index] ? [...new Set(hs.master[index].opts.map(o => o[0]))].sort() : [];
    const spotId = index => hs.master && hs.master.idx ? hs.master.idx[index] : null;

    // ---- websocket (protobuf frames)
    let wsSeq = 0; const wsMap = {};
    const prevEvt = root.__wsEvt;
    root.__wsEvt = (id, type, data) => {
      if (!String(id).startsWith('hs')) { const p = root.__wsEvtFt || prevEvt; return p && p(id, type, data); }
      const w = wsMap[id]; if (!w) return;
      if (type === 'open') w.onopen && w.onopen();
      else if (type === 'bin') w.onbin && w.onbin(b64bytes(data));
      else if (type === 'message') w.ontext && w.ontext(data);
      else { delete wsMap[id]; if (type === 'error') { w.why = data; w.onerror && w.onerror(data); } w.onclose && w.onclose(); }
    };
    if (prevEvt) root.__wsEvtFt = prevEvt;
    function makeSocket(url, headers) {
      const B = root.Android;
      if (B && B.wsOpen2) {
        const id = 'hs' + (++wsSeq);
        const w = { send: t => B.wsSend(id, t), close: () => { delete wsMap[id]; B.wsClose(id); } };
        wsMap[id] = w; B.wsOpen2(id, url, JSON.stringify(headers)); return w;
      }
      const s = new WebSocket(url); s.binaryType = 'arraybuffer';
      const w = { send: t => s.send(t), close: () => s.close() };
      s.onopen = () => w.onopen && w.onopen();
      s.onmessage = ev => { if (typeof ev.data === 'string') w.ontext && w.ontext(ev.data); else w.onbin && w.onbin(new Uint8Array(ev.data)); };
      s.onerror = () => w.onerror && w.onerror('error'); s.onclose = () => w.onclose && w.onclose();
      return w;
    }
    function closeWs() { try { if (hs.ws) hs.ws.close(); } catch (e) { } hs.ws = null; hs.wsState = 'off'; clearInterval(hbTimer); }
    let wsFails = 0, wsTimer = null, hbTimer = null;
    function scheduleWs() { clearTimeout(wsTimer); const wait = Math.min(60000, 3000 * Math.pow(2, Math.min(wsFails, 5))); wsTimer = setTimeout(() => { wsTimer = null; openWs(); }, wait); }
    function openWs() {
      if (wsTimer) return;
      if (!hs.ready() || (hs.ws && (hs.wsState === 'open' || hs.wsState === 'connecting'))) return;
      if (hs.ws) closeWs();
      hs.wsState = 'connecting';
      const url = `${WS_URL}?token=${encodeURIComponent(hs.sess.token)}&api_key=${encodeURIComponent(hs.cfg.key)}`;
      let ws; try { ws = makeSocket(url, { 'Authorization': hs.sess.token, 'User-Agent': UA }); } catch (e) { hs.wsState = 'error'; log('ws error', e); wsFails++; scheduleWs(); return; }
      hs.ws = ws;
      ws.onopen = () => {
        hs.wsState = 'open'; wsFails = 0; log('ws open', 'connected');
        sendSub([...hs.wsWanted]);
        clearInterval(hbTimer); hbTimer = setInterval(() => { try { if (hs.ws === ws) ws.send(JSON.stringify({ heart_beat: true })); } catch (e) { } }, 10000);
      };
      ws.onbin = buf => {
        for (const t of decodeFrame(buf)) {
          if (!t.id || t.type === 16) continue;
          const d = t.idx || t.mbp; if (!d) continue;
          const pre = t.idx ? (t.type === 5 ? 'BSE_INDEX_' : 'NSE_INDEX_') : (t.type === 6 || t.type === 15 ? 'BFO_' : t.type === 3 || t.type === 14 || t.type === 13 ? 'NFO_' : null);
          const keys = pre ? [pre + t.id] : ['NFO_' + t.id, 'BFO_' + t.id];
          for (const k of keys) {
            if (!pre && !hs.wsWanted.has(k)) continue;
            const x = hs.live[k] || (hs.live[k] = {});
            for (const f of ['lp', 'c', 'oi', 'v', 'bp1', 'sp1']) if (d[f] !== undefined && (d[f] > 0 || f === 'oi')) x[f] = d[f];
            x.ts = Date.now(); hs.lastTick = x.ts;
            if (x.oi > 0) { const o0 = oi0(k); if (!(o0 > 0)) setOi0(k, x.oi); }
          }
        }
      };
      ws.ontext = t => { log('ws text', t); if (/unauthori|invalid|expired|forbidden/i.test(t)) { hs.err = 'HDFC Sky feed: ' + t.slice(0, 120); } };
      ws.onerror = why => { if (hs.ws !== ws) return; hs.wsState = 'error'; log('ws error', why || 'connection error'); if (/401|403/.test(String(why))) hs.err = 'HDFC Sky feed refused the login (' + why + '). Log in again.'; };
      ws.onclose = () => { if (hs.ws === ws) { hs.ws = null; hs.wsState = 'off'; clearInterval(hbTimer); wsFails++; scheduleWs(); } };
    }
    hs.wsReset = () => { clearTimeout(wsTimer); wsTimer = null; wsFails = 0; closeWs(); openWs(); };
    function sendSub(ids) {
      if (!ids.length || !hs.ws || hs.wsState !== 'open') return;
      for (let i = 0; i < ids.length; i += 100) hs.ws.send(JSON.stringify({ heart_beat: false, subscribe: ids.slice(i, i + 100).map(s => ({ scripId: s, type: 'ALL' })) }));
    }
    function unsub(ids) {
      ids.forEach(k => hs.wsWanted.delete(k));
      if (ids.length && hs.ws && hs.wsState === 'open') hs.ws.send(JSON.stringify({ heart_beat: false, unSubscribe: ids.map(s => ({ scripId: s, type: 'ALL' })) }));
    }
    function want(ids) {
      ids = ids.filter(Boolean);
      const fresh = ids.filter(k => !hs.wsWanted.has(k));
      if (hs.wsWanted.size + fresh.length > 290) return;           // feed limit: 300 per connection
      fresh.forEach(k => hs.wsWanted.add(k));
      openWs(); sendSub(fresh);
    }

    // ---- today's first OI per contract (the base for OI change when the exchange's previous-day OI isn't known)
    let O0 = store.get('oi.hs.oi0', { day: '', m: {} });
    function oi0(k) { if (O0.day !== C.istDate(Date.now())) O0 = { day: C.istDate(Date.now()), m: {} }; return O0.m[k]; }
    let o0Dirty = 0;
    function setOi0(k, v) { O0.m[k] = v; if (!o0Dirty) o0Dirty = setTimeout(() => { o0Dirty = 0; store.set('oi.hs.oi0', O0); }, 5000); }

    // ---- option chain
    hs.prepare = async function (index, iso, spotHint) {
      const M = await hs.loadMaster();
      const sid = spotId(index); want([sid]);
      let spot = hs.spot(index) || spotHint;
      if (!spot && sid) {                     // feed not ticking yet: one LTP snapshot
        try {
          const ex = sid.startsWith('BSE') ? 'BSE_INDEX' : 'NSE_INDEX', token = sid.split('_').pop();
          const j = await rest('PUT', '/oapi/v1/fetch-ltp', {}, { data: [{ exchange: ex, token }] });
          const row = ((j && j.data) || []).find(x => String(x.token) === token);
          if (row && parseFloat(row.ltp) > 0) { spot = parseFloat(row.ltp); const x = hs.live[sid] || (hs.live[sid] = {}); x.lp = spot; if (parseFloat(row.prev_close) > 0) x.c = parseFloat(row.prev_close); x.ts = Date.now(); }
        } catch (e) { if (e && e.login) throw e; }
      }
      if (!spot) return false;
      const step = CFG[index].step, center = Math.round(spot / step) * step;
      const cur = hs.subs[index];
      if (cur && cur.iso === iso && Math.abs(cur.center - center) <= step * 5) return true;
      const all = M[index].opts.filter(o => o[0] === iso);
      if (!all.length) throw { msg: `HDFC Sky: no ${index} options for ${iso} in the contract list.` };
      const ks = [...new Set(all.map(o => o[1]))].sort((a, b) => a - b);
      const ci = ks.reduce((b, k, i) => Math.abs(k - spot) < Math.abs(ks[b] - spot) ? i : b, 0);
      const keep = new Set(ks.slice(Math.max(0, ci - N_SIDE), ci + N_SIDE + 1));
      const pre = CFG[index].exch + '_';
      const tokens = all.filter(o => keep.has(o[1])).map(o => ({ k: pre + o[3], strike: o[1], optt: o[2], tsym: o[4], ls: o[5] }));
      if (cur) unsub(cur.tokens.map(t => t.k).filter(k => !tokens.some(t => t.k === k)));
      hs.subs[index] = { iso, center, tokens };
      want(tokens.map(t => t.k));
      log('chain', `${index} ${iso}: ${tokens.length} contracts around ${center}`);
      return true;
    };
    hs.spot = index => { const x = hs.live[spotId(index)]; return x && x.lp > 0 ? x.lp : 0; };
    hs.hasChain = (index, iso) => { const s = hs.subs[index]; return !!(s && s.iso === iso && s.tokens.some(t => hs.live[t.k] && hs.live[t.k].ts)); };
    const blank = () => ({ oi: 0, poi: 0, ltp: 0, pc: 0, iv: 0, vol: 0 });
    hs.chain = function (index, iso, spotHint) {
      const s = hs.subs[index];
      if (!s || s.iso !== iso) return { spot: 0, rows: [] };
      const prev = hs.prevOi[index + '|' + iso], by = new Map();
      for (const t of s.tokens) {
        const x = hs.live[t.k]; if (!x || !x.ts) continue;
        const row = by.get(t.strike) || { strike: t.strike, ce: blank(), pe: blank() };
        const side = t.optt === 'PE' ? 'pe' : 'ce', oi = x.oi || 0, lp = x.lp || 0;
        const pv = prev && prev.get(t.strike), ppoi = pv ? pv[side].poi : NaN;
        const poi = isFinite(ppoi) && ppoi > 0 ? ppoi : (oi0(t.k) || oi);
        row[side] = { oi, poi, ltp: lp, pc: x.c > 0 ? x.c : lp, iv: 0, vol: x.v || 0, bid: x.bp1 || 0, ask: x.sp1 || 0 };
        by.set(t.strike, row);
      }
      const rows = [...by.values()].filter(r => r.ce.oi > 0 || r.pe.oi > 0 || r.ce.ltp > 0 || r.pe.ltp > 0).sort((a, b) => a.strike - b.strike);
      return { spot: hs.spot(index) || spotHint || 0, rows, poiFrom: prev ? 'exchange' : 'first tick today' };
    };
    /** previous-day OI per strike from the exchange website, so OI change matches NSE/BSE */
    hs.setPrevOi = (index, iso, rows) => { const m = new Map(); for (const r of rows || []) m.set(r.strike, { ce: { poi: r.ce.poi }, pe: { poi: r.pe.poi } }); if (m.size) hs.prevOi[index + '|' + iso] = m; };
    hs.fillOi = async () => 0;

    // ---- NIFTY futures (current month)
    hs.prepareFut = async function () {
      const M = await hs.loadMaster(), today = C.istDate(Date.now());
      const f = (M.NIFTY.futs || []).find(x => x[0] >= today);
      if (!f) throw { msg: 'HDFC Sky: NIFTY futures contract not found.' };
      hs.fut = { k: 'NFO_' + f[1], tsym: f[2], iso: f[0] };
      want([hs.fut.k, spotId('NIFTY')]);
      return true;
    };
    hs.futQuote = function () {
      if (!hs.fut) return null;
      const x = hs.live[hs.fut.k]; if (!x || !(x.lp > 0)) return null;
      const o0 = oi0(hs.fut.k);
      return { iso: hs.fut.iso, ltp: x.lp, prevClose: x.c > 0 ? x.c : NaN, oi: x.oi > 0 ? x.oi : NaN, oiChg: x.oi > 0 && o0 > 0 ? x.oi - o0 : NaN, underlying: hs.spot('NIFTY') };
    };
    hs.vixQuote = function () {
      if (!hs.ready() || !hs.master) return null;
      const id = hs.master.idx.VIX; if (!id) return null; want([id]);
      const x = hs.live[id]; return x && x.lp > 3 && x.lp < 100 ? { v: x.lp, prev: x.c > 0 ? x.c : NaN } : null;
    };
    hs.findGift = async () => null;
    hs.giftQuote = () => null;

    // ---- positions (read-only)
    hs.positions = { list: [], at: 0, err: null };
    hs.loadPositions = async function () {
      if (!hs.ready()) return hs.positions;
      try {
        const M = await hs.loadMaster().catch(() => hs.master);
        let rows = [];
        for (const type of ['live', 'historical']) {
          const j = await rest('GET', '/oapi/v1/positions', Object.assign({ type }, cidParam()));
          const d = j && j.data; rows = Array.isArray(d) ? d : d && Array.isArray(d.positions) ? d.positions : Array.isArray(j) ? j : [];
          if (j && /fail|error/i.test(String(j.status || '')) && !rows.length) hs.positions.err = j.message || 'positions error'; else hs.positions.err = null;
          if (rows.length) break;
        }
        const find = sym => { if (!M) return null; for (const i of ['NIFTY', 'SENSEX']) { const o = M[i].opts.find(x => x[4] === sym); if (o) return { index: i, o }; } return null; };
        hs.positions.list = rows.map(v => {
          const sym = String(v.trading_symbol || v.tradingSymbol || v.symbol || ''), net = parseInt(v.net_quantity != null ? v.net_quantity : v.netQuantity) || 0;
          const f = find(sym), ex = String(v.exchange || (f ? CFG[f.index].exch : '')).toUpperCase();
          const tok = String(v.token || v.exchange_token || (f ? f.o[3] : '')), k = (ex === 'BFO' ? 'BFO_' : 'NFO_') + tok;
          const avg = parseFloat(net > 0 ? v.average_buy_price : net < 0 ? v.average_sell_price : v.average_price) || parseFloat(v.average_price) || 0;
          const buy = parseFloat(v.buy_amount) || 0, sell = parseFloat(v.sell_amount) || 0;
          return { tsym: sym, dname: f ? `${f.index} ${f.o[1]} ${f.o[2]}` : '', exch: ex, token: tok, k, prd: String(v.product || ''), qty: net, avg, lp: parseFloat(v.ltp) || 0,
            rpnl: net === 0 ? sell - buy : 0, ls: f ? f.o[5] : 0 };
        });
        hs.positions.at = Date.now();
        want(hs.positions.list.filter(p => p.qty !== 0 && p.token).map(p => p.k));
      } catch (e) { hs.positions.err = (e && e.msg) || String(e); if (e && e.login) throw e; }
      return hs.positions;
    };
    hs.liveLtp = k => { const x = hs.live[k]; return x && x.lp > 0 ? x.lp : NaN; };

    hs.status = function () {
      if (!hs.configured()) return 'Not set up';
      if (!hs.ready()) return 'Not logged in today';
      if (hs.wsState === 'open') return hs.lastTick ? `Live · last tick ${C.istTime(hs.lastTick, true)}` : 'Connected · waiting for ticks';
      return hs.wsState === 'error' ? 'Live feed error · retrying' : 'Connecting…';
    };
    if (hs.ready()) openWs();
    return hs;
  }

  root.createHS = createHS;
  root.HSKit = { decodeFrame, parseMaster, csvRow, expIso };
})(typeof window !== 'undefined' ? window : globalThis);
