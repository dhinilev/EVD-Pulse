/* EV Pulse — market news: Google News RSS + a rulebook for market impact and impact on society. */
(function (root) {
  'use strict';

  const FEEDS = [
    { scope: 'India', q: 'Sensex OR Nifty OR RBI OR SEBI OR rupee OR "stock market" India' },
    { scope: 'India', q: 'India inflation OR GDP OR "repo rate" OR budget OR FII OR monsoon' },
    { scope: 'World', q: '"Federal Reserve" OR "Wall Street" OR "crude oil" OR "US stocks" OR tariffs' },
    { scope: 'World', q: 'China economy OR "oil prices" OR war OR "global markets" OR dollar' },
  ];
  const url = q => 'https://news.google.com/rss/search?q=' + encodeURIComponent(q + ' when:1d') + '&hl=en-IN&gl=IN&ceid=IN:en';

  const UP = /\b(rises?|rising|rose|gains?|gained|jumps?|jumped|surges?|surged|rall(y|ies|ied)|soars?|soared|climbs?|climbed|advances?|recover(s|ed)?|rebounds?|bounces?|higher|boosts?|strong(er)?|strengthens?|firm(s|er)?|spikes?|spiked|beats?|tops?|better|upgrades?|upgraded|accelerates?)\b/i;
  const DOWN = /\b(falls?|falling|fell|drops?|dropped|slumps?|crash(es|ed)?|plunges?|plunged|declines?|declined|slides?|slid|tumbles?|tumbled|tanks?|tanked|slips?|slipped|sheds?|sinks?|sank|weak(er|ens?)?|lower|sell-?off|dips?|dipped|loses?|lost|eases?|eased|cools?|cooled|softens?|moderates?|misses|missed|worse|downgrades?|downgraded|slows?|slowed)\b/i;

  // topic rules: test, what "up" means for the market (+1 good, -1 bad), and impact on society
  const RULES = [
    { t: 'Fed / US rates', re: /\b(federal reserve|fed|fomc|powell|us rates?)\b/i,
      mkt: h => /cut|dovish|lower|ease/i.test(h) ? 1 : /hike|hawkish|raise|higher for longer/i.test(h) ? -1 : 0,
      soc: () => 'US rates move global money: lower US rates bring foreign money into India, strengthening the rupee and markets.' },
    { t: 'Interest rates', re: /\b(repo|rbi|rate cuts?|rate hikes?|interest rates?|mpc)\b/i,
      mkt: h => /cut|lower|reduce|ease/i.test(h) ? 1 : /hike|raise|increase/i.test(h) ? -1 : 0,
      soc: h => /cut|lower|reduce|ease/i.test(h) ? 'Home and car loan EMIs may fall; fixed deposit rates may also come down.' : /hike|raise|increase/i.test(h) ? 'Loan EMIs may rise; savers may get better deposit rates.' : 'Any change in rates affects loan EMIs and deposit returns for households.' },
    { t: 'Inflation', re: /\b(inflation|cpi|wpi|price rise)\b/i, upIs: -1,
      soc: h => DOWN.test(h) && !UP.test(h) ? 'Prices of daily essentials easing: some relief for household budgets.' : 'Higher prices of food, fuel and essentials squeeze household budgets.' },
    { t: 'Crude oil', re: /\b(crude|oil price|brent|opec)\b/i, upIs: -1,
      soc: h => DOWN.test(h) && !UP.test(h) ? 'Petrol, diesel and transport costs may ease; good for India, which imports most of its oil.' : 'Petrol, diesel, transport and many goods may get costlier; India imports most of its oil.' },
    { t: 'Rupee', re: /\b(rupee|inr)\b/i, upIs: 1,
      soc: h => DOWN.test(h) && !UP.test(h) ? 'Imports get costlier: electronics, fuel, gold and foreign education/travel.' : 'Imports, foreign travel and overseas education get cheaper.' },
    { t: 'Foreign investors', re: /\b(fiis?|fpis?|diis?|foreign (investors?|funds?|portfolio)|outflows?|inflows?)\b/i,
      mkt: h => /sell|outflow|pull out|exit|dump/i.test(h) ? -1 : /buy|inflow|invest/i.test(h) ? 1 : 0,
      soc: () => 'Foreign money flows drive markets, mutual fund NAVs and SIP returns for ordinary investors.' },
    { t: 'Economy / GDP', re: /\b(gdp|growth|economy|recession|slowdown|pmi|iip)\b/i, upIs: 1,
      soc: h => (/recession|slowdown|contract/i.test(h) || (DOWN.test(h) && !UP.test(h))) ? 'Slower growth can mean fewer jobs and slower salary hikes.' : 'Stronger growth supports jobs, incomes and business confidence.' },
    { t: 'War / conflict', re: /\b(war|attack|missile|conflict|tension|strike|sanction|ceasefire)\b/i,
      mkt: h => /ceasefire|peace|truce|de-escalat/i.test(h) ? 1 : -1,
      soc: h => /ceasefire|peace|truce/i.test(h) ? 'Easing tensions can bring down fuel and commodity prices.' : 'Conflict can push up fuel and food prices and disrupt trade and supply.' },
    { t: 'Trade / tariffs', re: /\b(tariffs?|trade war|trade deal|exports?|import duty)\b/i,
      mkt: h => /deal|cut|ease|relief|pact/i.test(h) ? 1 : /tariff|war|hike|ban/i.test(h) ? -1 : 0,
      soc: () => 'Trade rules affect exporters, jobs in export industries and prices of imported goods.' },
    { t: 'Budget / tax', re: /\b(budget|gst|income tax|tax cut|fiscal)\b/i,
      mkt: h => /cut|relief|lower|boost/i.test(h) ? 1 : /hike|raise|deficit widen/i.test(h) ? -1 : 0,
      soc: h => /cut|relief|lower/i.test(h) ? 'Lower taxes leave more money in people\'s hands.' : 'Tax changes affect take-home pay and prices of goods.' },
    { t: 'Monsoon', re: /\b(monsoon|rainfall|drought)\b/i,
      mkt: h => /deficient|weak|below normal|drought|delay/i.test(h) ? -1 : /normal|above|good|surplus/i.test(h) ? 1 : 0,
      soc: () => 'Monsoon drives farm output, rural incomes and food prices.' },
    { t: 'Market regulation', re: /\b(sebi|f&o|derivative|stt)\b/i, mkt: () => 0,
      soc: () => 'Rule changes affect traders, brokers and retail investors directly.' },
    { t: 'Global markets', re: /\b(wall street|dow|nasdaq|s&p|us stocks|nikkei|hang seng|global markets|asian markets)\b/i, upIs: 1,
      soc: () => 'Global market moves set the mood for Indian markets at the next open.' },
    { t: 'Indian markets', re: /\b(sensex|nifty|dalal street|stock market|indian shares|equities|markets?)\b/i, upIs: 1,
      soc: () => 'Market moves affect mutual fund and SIP values held by crores of Indians.' },
  ];

  function classify(title) {
    const up = UP.test(title), dn = DOWN.test(title);
    const dirWord = up && !dn ? 1 : dn && !up ? -1 : 0;
    for (const r of RULES) {
      if (!r.re.test(title)) continue;
      let m = r.mkt ? r.mkt(title) : (r.upIs || 0) * dirWord;
      return { topic: r.t, impact: m > 0 ? 1 : m < 0 ? -1 : 0, society: r.soc(title) };
    }
    return { topic: 'Markets', impact: dirWord, society: '' };
  }

  function parseRss(xml, scope) {
    const out = [];
    try {
      const doc = new DOMParser().parseFromString(xml, 'text/xml');
      for (const it of doc.querySelectorAll('item')) {
        const raw = (it.querySelector('title') || {}).textContent || '';
        const src = (it.querySelector('source') || {}).textContent || '';
        const title = src && raw.endsWith(' - ' + src) ? raw.slice(0, -(src.length + 3)) : raw;
        const link = (it.querySelector('link') || {}).textContent || '';
        const ts = Date.parse((it.querySelector('pubDate') || {}).textContent || '') || 0;
        if (title) out.push(Object.assign({ title, src, link, ts, scope }, classify(title)));
      }
    } catch (e) { }
    return out;
  }

  function createNews(http) {
    const n = { items: [], at: 0, err: null };
    n.refresh = async function (force) {
      if (!force && n.at && Date.now() - n.at < 15 * 60000) return n.items;
      const all = [];
      for (const f of FEEDS) {
        const r = await http('GET', url(f.q), { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/rss+xml, text/xml' });
        if (r.status === 200) all.push(...parseRss(r.text, f.scope));
      }
      if (!all.length) { n.err = 'Could not load news right now.'; return n.items; }
      const seen = new Set();
      n.items = all.filter(x => { const k = x.title.toLowerCase().slice(0, 60); if (seen.has(k)) return false; seen.add(k); return true; })
        .sort((a, b) => b.ts - a.ts).slice(0, 30);
      n.at = Date.now(); n.err = null;
      return n.items;
    };
    /** net news mood of the last 24 h: -1..+1 */
    n.mood = function () {
      const recent = n.items.filter(x => Date.now() - x.ts < 24 * 3600e3 && x.topic !== 'Indian markets');
      if (!recent.length) return { score: 0, pos: 0, neg: 0, n: 0 };
      const pos = recent.filter(x => x.impact > 0).length, neg = recent.filter(x => x.impact < 0).length;
      return { score: (pos - neg) / Math.max(4, recent.length), pos, neg, n: recent.length };
    };
    return n;
  }

  const api = { createNews, classify, parseRss };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.NewsKit = api;
})(typeof window !== 'undefined' ? window : globalThis);
