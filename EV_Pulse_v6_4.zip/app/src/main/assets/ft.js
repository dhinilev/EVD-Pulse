/* EV Pulse — Flattrade live data (Pi API, Noren-style). Login once a day, then a websocket streams ticks. */
(function (root) {
  'use strict';

  const AUTH = 'https://auth.flattrade.in/?app_key=';
  const TOKEN_URL = 'https://authapi.flattrade.in/trade/apitoken';
  const REST = 'https://piconnect.flattrade.in/PiConnectAPI';
  const WS_URL = 'wss://piconnect.flattrade.in/PiConnectWSAPI/';
  const REDIRECT = 'https://127.0.0.1/evdplan';
  const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const CFG = {
    NIFTY: { exch: 'NFO', spot: 'NSE|26000', step: 50 },
    SENSEX: { exch: 'BFO', spot: 'BSE|1', step: 100 },
  };

  function createFT(deps) {
    const { http, store, Core, sha256, openLogin } = deps;
    const C = Core;
    const ft = {
      REDIRECT,
      cfg: Object.assign({ uid: '', key: '', secret: '' }, store.get('oi.ft.cfg', {})),
      sess: store.get('oi.ft.sess', null),      // {token, uid, at}
      live: {},                                  // "EXCH|token" -> {lp, c, oi, poi, v, ts}
      subs: {},                                  // index -> {iso, center, exch, tokens:[{k, strike, optt}]}
      fut: null,                                 // {k, tsym, iso}
      ws: null, wsState: 'off', wsWanted: new Set(), lastTick: 0,
      diag: [], err: null,
    };

    function log(what, detail) {
      ft.diag.unshift({ at: Date.now(), what, detail: String(detail || '').slice(0, 500) });
      ft.diag.length = Math.min(ft.diag.length, 12);
    }

    // ---- session ----------------------------------------------------------
    // Tokens expire daily at 5:00 AM IST.
    function lastReset(now) {
      const p = C.istParts(now);
      const todayReset = Date.UTC(p.y, p.mo - 1, p.d, 5, 0) - 5.5 * 3600e3;
      return now >= todayReset ? todayReset : todayReset - 86400e3;
    }
    ft.configured = () => !!(ft.cfg.uid && ft.cfg.key && ft.cfg.secret);
    ft.ready = () => !!(ft.sess && ft.sess.token && ft.sess.at >= lastReset(Date.now()));
    ft.saveCfg = (cfg) => { ft.cfg = Object.assign({}, ft.cfg, cfg); store.set('oi.ft.cfg', ft.cfg); };
    ft.logout = () => { ft.sess = null; store.set('oi.ft.sess', null); closeWs(); };

    ft.login = function () {
      return new Promise((resolve, reject) => {
        if (!ft.configured()) { reject({ msg: 'Enter your Flattrade client ID, API key and secret first.' }); return; }
        root.__ftCode = async (code, client) => {
          root.__ftCode = null;
          if (!code) { reject({ msg: 'Login cancelled.' }); return; }
          try {
            const hash = sha256(ft.cfg.key + code + ft.cfg.secret);
            const r = await http('POST', TOKEN_URL, { 'Content-Type': 'application/json', 'Accept': 'application/json' },
              JSON.stringify({ api_key: ft.cfg.key, request_code: code, api_secret: hash }));
            log('apitoken HTTP ' + r.status, r.text);
            let j = null; try { j = JSON.parse(r.text); } catch (e) { }
            if (!j || !j.token) { reject({ msg: 'Flattrade login failed: ' + ((j && (j.emsg || j.message)) || ('HTTP ' + r.status)) }); return; }
            ft.sess = { token: j.token, uid: (j.client || client || ft.cfg.uid).toUpperCase(), at: Date.now() };
            store.set('oi.ft.sess', ft.sess);
            ft.subs = {}; ft.fut = null; ft.err = null;
            if (ft.wsReset) ft.wsReset();
            resolve(ft.sess);
          } catch (e) { reject({ msg: 'Flattrade login error: ' + e }); }
        };
        openLogin(AUTH + encodeURIComponent(ft.cfg.key), REDIRECT);
      });
    };

    // ---- REST (jData + jKey form body) -----------------------------------
    async function rest(path, values) {
      if (!ft.ready()) throw { msg: 'Flattrade: log in for today first (Settings).', login: true };
      const body = 'jData=' + JSON.stringify(Object.assign({ uid: ft.sess.uid }, values)) + '&jKey=' + ft.sess.token;
      const r = await http('POST', REST + path, { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }, body);
      let j = null; try { j = JSON.parse(r.text); } catch (e) { }
      log(path + ' HTTP ' + r.status, r.text);
      if (j && /session expired|invalid session|not logged/i.test(String(j.emsg || ''))) {
        ft.logout(); throw { msg: 'Flattrade session expired: log in again in Settings.', login: true };
      }
      if (!j) throw { msg: `Flattrade ${path}: no response (HTTP ${r.status}).` };
      return j;
    }
    const okList = j => (Array.isArray(j) ? j : (j && j.stat === 'Ok' && Array.isArray(j.values) ? j.values : []));

    // ---- websocket ---------------------------------------------------------
    // On the phone, use the app's native socket (forced to IPv4, like the REST calls); in a browser, the normal one.
    let wsSeq = 0; const wsMap = {};
    root.__wsEvt = (id, type, data) => {
      const w = wsMap[id]; if (!w) return;
      if (type === 'open') w.onopen && w.onopen();
      else if (type === 'message') w.onmessage && w.onmessage({ data });
      else { delete wsMap[id]; if (type === 'error') { w.onerror && w.onerror(); } w.onclose && w.onclose(); }
    };
    function makeSocket(url) {
      const B = root.Android;
      if (!(B && B.wsOpen)) return new WebSocket(url);
      const id = 'ws' + (++wsSeq);
      const w = { send: t => B.wsSend(id, t), close: () => { delete wsMap[id]; B.wsClose(id); } };
      wsMap[id] = w; B.wsOpen(id, url);
      return w;
    }
    function closeWs() { try { if (ft.ws) ft.ws.close(); } catch (e) { } ft.ws = null; ft.wsState = 'off'; }
    // Websocket connect: one socket at a time, back-off on failure, and try the known Noren connect formats in turn
    // (the format that works is remembered). Flattrade API v2 changed parts of the websocket flow.
    const WS_VARIANTS = [
      s => ({ t: 'c', uid: s.uid, actid: s.uid, source: 'API', susertoken: s.token }),
      s => ({ t: 'c', uid: s.uid, actid: s.uid, source: 'API', susertoken: s.token, accesstoken: s.token }),
      s => ({ t: 'c', uid: s.uid, actid: s.uid, source: 'API', accesstoken: s.token }),
    ];
    ft.wsVar = store.get('oi.ft.wsvar', 0) % WS_VARIANTS.length;
    let wsFails = 0, wsTimer = null;
    function scheduleWs() {
      clearTimeout(wsTimer);
      const wait = Math.min(60000, 3000 * Math.pow(2, Math.min(wsFails, 5)));   // 3 s, 6 s, 12 s … max 60 s
      wsTimer = setTimeout(() => { wsTimer = null; openWs(); }, wait);
    }
    function openWs() {
      if (wsTimer) return;                                   // a retry is already scheduled (back-off)
      if (!ft.ready() || (ft.ws && (ft.wsState === 'open' || ft.wsState === 'connecting'))) return;
      if (ft.ws) closeWs();                                  // never keep two sockets: Flattrade rejects duplicates
      ft.wsState = 'connecting';
      let ws;
      try { ws = makeSocket(WS_URL); } catch (e) { ft.wsState = 'error'; log('ws error', e); wsFails++; scheduleWs(); return; }
      ft.ws = ws;
      const v = ft.wsVar;
      ws.onopen = () => ws.send(JSON.stringify(WS_VARIANTS[v](ft.sess)));
      ws.onmessage = ev => {
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; }
        if (m.t === 'ck') {
          log('ws connect (format ' + (v + 1) + ')', ev.data);
          if (String(m.s).toUpperCase() === 'OK') { ft.wsState = 'open'; wsFails = 0; store.set('oi.ft.wsvar', v); sendSub([...ft.wsWanted]); }
          else {
            ft.wsState = 'error'; wsFails++;
            ft.wsVar = (v + 1) % WS_VARIANTS.length;        // try the next connect format next time
            if (ft.ws === ws) { ft.ws = null; try { ws.close(); } catch (e) { } }
            scheduleWs();
          }
          return;
        }
        if (m.t === 'tk' || m.t === 'tf' || m.t === 'dk' || m.t === 'df') {
          const k = (m.e || '') + '|' + m.tk;
          const x = ft.live[k] || (ft.live[k] = {});
          for (const f of ['lp', 'c', 'oi', 'poi', 'v', 'pc', 'bp1', 'sp1']) if (m[f] !== undefined && m[f] !== '') x[f] = parseFloat(m[f]);
          x.ts = Date.now(); ft.lastTick = x.ts;
          if (m.t === 'tk' && m.e && !(ft.seenEx = ft.seenEx || {})[m.e]) { ft.seenEx[m.e] = 1; log('first tick ' + m.e, ev.data.slice(0, 400)); }
        }
      };
      ws.onerror = () => { if (ft.ws !== ws) return; ft.wsState = 'error'; log('ws error', 'connection error'); };
      ws.onclose = () => { if (ft.ws === ws) { ft.ws = null; ft.wsState = 'off'; wsFails++; scheduleWs(); } };
    }
    ft.wsReset = () => { clearTimeout(wsTimer); wsTimer = null; wsFails = 0; closeWs(); openWs(); };
    function sendSub(keys) {
      if (!keys.length || !ft.ws || ft.wsState !== 'open') return;
      for (let i = 0; i < keys.length; i += 40) ft.ws.send(JSON.stringify({ t: 't', k: keys.slice(i, i + 40).join('#') }));
    }
    function want(keys) {
      const fresh = keys.filter(k => !ft.wsWanted.has(k));
      fresh.forEach(k => ft.wsWanted.add(k));
      openWs(); sendSub(fresh);
    }

    // ---- option chain for one expiry ---------------------------------------
    function tsym(index, iso, strike, opt) {   // e.g. NIFTY06OCT26C25000
      const [y, m, d] = iso.split('-');
      return `${index}${d}${MON[+m - 1]}${y.slice(2)}${opt}${Math.round(strike)}`;
    }
    ft.prepare = async function (index, iso, spotHint) {
      const cfg = CFG[index];
      let spot = ft.spot(index) || spotHint;
      if (!spot) {                      // no spot yet (e.g. exchange site down): subscribe the index and ask for a quote
        want([cfg.spot]);
        try { const [exch, token] = cfg.spot.split('|'), q = await rest('/GetQuotes', { exch, token }); if (q && parseFloat(q.lp) > 0) spot = parseFloat(q.lp); } catch (e) { if (e && e.login) throw e; }
      }
      if (!spot) return false;
      const center = Math.round(spot / cfg.step) * cfg.step;
      const cur = ft.subs[index];
      if (cur && cur.iso === iso && Math.abs(cur.center - center) <= cfg.step * 6) return true;
      const chainOf = async ts => okList(await rest('/GetOptionChain', { exch: cfg.exch, tsym: ts, strprc: String(center), cnt: '15' }));
      let vals = [];
      // 1) a symbol that worked before for this index/expiry
      const known = (ft.symCache || {})[index + '|' + iso];
      if (known) vals = await chainOf(known);
      // 2) known naming styles (NSE style first for NIFTY; BSE weekly/monthly styles for SENSEX)
      if (!vals.length) {
        for (const ts of candidates(index, iso, center)) {
          vals = await chainOf(ts);
          if (vals.length) { remember(index, iso, ts); break; }
        }
      }
      // 3) ask Flattrade's search for a real option contract of this expiry and use its exact name
      if (!vals.length) {
        const [y, m, d] = iso.split('-'), mon = MON[+m - 1];
        const texts = [`${index} ${d}${mon}${y.slice(2)}`, `${index} ${center}`, `${index} ${mon}`, index];
        for (const stext of texts) {
          let found = [];
          try { found = okList(await rest('/SearchScrip', { exch: cfg.exch, stext })); } catch (e) { if (e && e.login) throw e; }
          const opts = found.filter(v => String(v.tsym || '').toUpperCase().startsWith(index) && !/^SENSEX50|^NIFTYNXT|^NIFTYFPI/i.test(String(v.tsym))
            && (/OPT/i.test(String(v.instname || '')) || /^(CE|PE)$/i.test(String(v.optt || ''))));
          const same = opts.filter(v => expIso(v) === iso || new RegExp(d + '\\s?' + mon, 'i').test(String(v.dname || v.cname || '')));
          const pick = same[0] || null;
          if (pick) { vals = await chainOf(pick.tsym); if (vals.length) { remember(index, iso, pick.tsym); break; } }
        }
      }
      if (!vals.length) throw { msg: `Flattrade: couldn't load the ${index} ${iso} option chain.` };
      const tokens = vals.map(v => ({ k: (v.exch || cfg.exch) + '|' + v.token, strike: parseFloat(v.strprc), optt: /^P/i.test(String(v.optt)) ? 'PE' : 'CE', tsym: String(v.tsym || ''), ls: parseInt(v.ls) || 0 }))
        .filter(t => isFinite(t.strike));
      ft.subs[index] = { iso, center, exch: cfg.exch, tokens };
      want([cfg.spot, ...tokens.map(t => t.k)]);
      return true;
    };
    function candidates(index, iso, strike) {
      const [y, m, d] = iso.split('-'), yy = y.slice(2), mon = MON[+m - 1], k = Math.round(strike);
      const mcode = '123456789OND'[+m - 1];
      const nse = `${index}${d}${mon}${yy}C${k}`;
      const bseWeekly = `${index}${yy}${mcode}${d}${k}CE`, bseMonthly = `${index}${yy}${mon}${k}CE`;
      return index === 'SENSEX' ? [bseWeekly, bseMonthly, nse, `${index}${yy}${+m}${d}${k}CE`] : [nse, bseWeekly, bseMonthly];
    }
    function expIso(v) {
      const e = String(v.exd || v.expiry || '');
      const mm = /^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/.exec(e);
      return mm ? `${mm[3]}-${String(MON.indexOf(mm[2].toUpperCase()) + 1).padStart(2, '0')}-${mm[1].padStart(2, '0')}` : '';
    }
    ft.symCache = store.get('oi.ft.sym', {});
    function remember(index, iso, ts) { ft.symCache[index + '|' + iso] = ts; store.set('oi.ft.sym', ft.symCache); log('chain symbol', `${index} ${iso}: ${ts}`); }
    ft.spot = index => { const x = ft.live[CFG[index].spot]; return x && x.lp > 0 ? x.lp : 0; };
    ft.hasChain = (index, iso) => { const s = ft.subs[index]; return !!(s && s.iso === iso && s.tokens.some(t => ft.live[t.k] && ft.live[t.k].ts)); };
    /** {spot, rows} in the same shape as the NSE/BSE parsers produce. */
    ft.chain = function (index, iso, spotHint) {
      const s = ft.subs[index];
      if (!s || s.iso !== iso) return { spot: 0, rows: [] };
      const by = new Map();
      for (const t of s.tokens) {
        const x = ft.live[t.k]; if (!x || !x.ts) continue;
        const row = by.get(t.strike) || { strike: t.strike, ce: blank(), pe: blank() };
        const oi = x.oi || 0, poi = isFinite(x.poi) ? x.poi : oi, lp = x.lp || 0;
        row[t.optt === 'PE' ? 'pe' : 'ce'] = { oi, poi, ltp: lp, pc: isFinite(x.c) ? x.c : lp, iv: 0, vol: x.v || 0, bid: x.bp1 || 0, ask: x.sp1 || 0 };
        by.set(t.strike, row);
      }
      const rows = [...by.values()].filter(r => r.ce.oi > 0 || r.pe.oi > 0 || r.ce.ltp > 0 || r.pe.ltp > 0).sort((a, b) => a.strike - b.strike);
      return { spot: ft.spot(index) || spotHint || 0, rows };
    };
    const blank = () => ({ oi: 0, poi: 0, ltp: 0, pc: 0, iv: 0, vol: 0 });
    /** Some exchanges' live feed (e.g. BSE options) may not carry OI: fetch it with GetQuotes for strikes near spot. */
    ft.fillOi = async function (index, spot, n) {
      const s = ft.subs[index]; if (!s) return 0;
      const near = s.tokens.slice().sort((a, b) => Math.abs(a.strike - spot) - Math.abs(b.strike - spot)).slice(0, n || 30);
      let got = 0;
      for (const t of near) {
        const [exch, token] = t.k.split('|');
        try {
          const q = await rest('/GetQuotes', { exch, token });
          const x = ft.live[t.k] || (ft.live[t.k] = {});
          if (q && q.oi !== undefined) { x.oi = parseFloat(q.oi); got++; }
          if (q && q.poi !== undefined) x.poi = parseFloat(q.poi);
          if (q && q.lp !== undefined && !(x.lp > 0)) x.lp = parseFloat(q.lp);
          if (q && q.c !== undefined && !isFinite(x.c)) x.c = parseFloat(q.c);
          if (!x.ts) x.ts = Date.now();
          if (got === 1 && !ft.loggedQ) { ft.loggedQ = 1; log('GetQuotes sample', JSON.stringify(q).slice(0, 400)); }
        } catch (e) { if (e && e.login) throw e; }
      }
      if (got) { (ft.oiQuotes = ft.oiQuotes || {})[index] = Date.now(); }
      return got;
    };

    // ---- NIFTY futures (current month) -------------------------------------
    ft.prepareFut = async function () {
      const today = C.istDate(Date.now());
      if (ft.fut && ft.fut.iso >= today) { want([ft.fut.k]); return true; }
      const vals = okList(await rest('/SearchScrip', { exch: 'NFO', stext: 'NIFTY FUT' }));
      const futs = vals.map(v => {
        const m = /^NIFTY(\d{2})([A-Z]{3})(\d{2})F$/.exec(String(v.tsym || ''));
        if (!m || MON.indexOf(m[2]) < 0) return null;
        return { k: 'NFO|' + v.token, tsym: v.tsym, iso: `20${m[3]}-${String(MON.indexOf(m[2]) + 1).padStart(2, '0')}-${m[1]}` };
      }).filter(Boolean).filter(f => f.iso >= today).sort((a, b) => a.iso < b.iso ? -1 : 1);
      if (!futs.length) throw { msg: 'Flattrade: NIFTY futures contract not found.' };
      ft.fut = futs[0];
      want([ft.fut.k, CFG.NIFTY.spot]);
      return true;
    };
    ft.futQuote = function () {
      if (!ft.fut) return null;
      const x = ft.live[ft.fut.k];
      if (!x || !(x.lp > 0)) return null;
      return { iso: ft.fut.iso, ltp: x.lp, prevClose: isFinite(x.c) ? x.c : NaN, oi: isFinite(x.oi) ? x.oi : NaN,
               oiChg: isFinite(x.oi) && isFinite(x.poi) ? x.oi - x.poi : NaN, underlying: ft.spot('NIFTY') };
    };

    // ---- GIFT Nifty: normally NOT on Flattrade (it trades on NSE IX). Search once a day; if Flattrade ever lists it, stream it live.
    ft.gift = store.get('oi.ft.gift', null);
    ft.findGift = async function () {
      const today = C.istDate(Date.now());
      if (!ft.ready() || (ft.gift && ft.gift.day === today)) return ft.gift && ft.gift.k;
      let k = null;
      for (const [exch, stext] of [['NSE', 'GIFT NIFTY'], ['NSE', 'GIFTNIFTY'], ['NFO', 'GIFT NIFTY']]) {
        try { const v = okList(await rest('/SearchScrip', { exch, stext })).find(x => /GIFT/i.test(String(x.tsym || '') + ' ' + String(x.cname || '')));
          if (v) { k = (v.exch || exch) + '|' + v.token; log('GIFT Nifty found', JSON.stringify(v).slice(0, 200)); break; } } catch (e) { if (e && e.login) throw e; }
      }
      if (!k) log('GIFT Nifty', 'Not available in Flattrade (it trades on NSE IX). Using the NSE website instead.');
      ft.gift = { day: today, k }; store.set('oi.ft.gift', ft.gift);
      if (k) want([k]);
      return k;
    };
    ft.giftQuote = function () {
      if (!ft.gift || !ft.gift.k) return null;
      want([ft.gift.k]);
      const x = ft.live[ft.gift.k];
      return x && x.lp > 1000 ? { v: x.lp, prev: x.c } : null;
    };

    // ---- India VIX (NSE index feed). Token 26017 is the usual Noren code; if it never ticks, the app falls back to NSE/Yahoo.
    const VIXK = 'NSE|26017';
    ft.vixQuote = function () {
      if (!ft.ready()) return null;
      want([VIXK]);
      const x = ft.live[VIXK];
      return x && x.lp > 3 && x.lp < 100 ? { v: x.lp, prev: isFinite(x.c) && x.c > 0 ? x.c : NaN } : null;
    };

    // ---- positions (read-only): PositionBook every minute, live LTP via the feed
    ft.positions = { list: [], at: 0, err: null };
    ft.trades = { list: [], at: 0 };
    ft.loadPositions = async function () {
      if (!ft.ready()) return ft.positions;
      try {
        const j = await rest('/PositionBook', { actid: ft.sess.uid });
        const vals = Array.isArray(j) ? j : okList(j);
        if (!Array.isArray(j) && j && j.stat && j.stat !== 'Ok' && !/no data/i.test(String(j.emsg || ''))) ft.positions.err = j.emsg || 'PositionBook error';
        else ft.positions.err = null;
        ft.positions.list = vals.map(v => ({ tsym: String(v.tsym || ''), dname: String(v.dname || ''), exch: v.exch, token: v.token, k: v.exch + '|' + v.token, prd: v.prd,
          qty: parseInt(v.netqty) || 0, avg: parseFloat(v.netavgprc || v.daybuyavgprc || v.totbuyavgprc) || 0, lp: parseFloat(v.lp) || 0,
          rpnl: parseFloat(v.rpnl) || 0, urmtom: parseFloat(v.urmtom) || 0, ls: parseInt(v.ls) || 0 }));
        ft.positions.at = Date.now();
        want(ft.positions.list.filter(p => p.qty !== 0).map(p => p.k));
        try {                                                   // individual buys and sells (to show each purchase separately)
          const t = await rest('/TradeBook', { actid: ft.sess.uid }), tv = Array.isArray(t) ? t : okList(t);
          ft.trades = { at: Date.now(), list: tv.map(v => ({ tsym: String(v.tsym || ''), exch: v.exch, token: v.token, side: String(v.trantype || '').toUpperCase(),
            qty: parseInt(v.flqty || v.qty) || 0, prc: parseFloat(v.flprc || v.avgprc || v.prc) || 0, ord: String(v.norenordno || v.flid || ''), ts: String(v.fltm || v.norentm || v.exch_tm || '') })).filter(x => x.qty > 0 && x.prc > 0) };
        } catch (e) { if (e && e.login) throw e; }
      } catch (e) { ft.positions.err = (e && e.msg) || String(e); if (e && e.login) throw e; }
      return ft.positions;
    };
    // ---- orders (placed only after the user confirms in the app) ----
    ft.contract = async function (index, iso, strike, side) {
      const s = ft.subs[index];
      let t = s && s.iso === iso ? s.tokens.find(x => x.strike === strike && x.optt === side && x.tsym) : null;
      if (!t) {
        const known = (ft.symCache || {})[index + '|' + iso]; if (!known) throw { msg: 'Contract not found in the Flattrade chain. Open the Chain once so it loads.' };
        const vals = okList(await rest('/GetOptionChain', { exch: CFG[index].exch, tsym: known, strprc: String(strike), cnt: '2' }));
        const v = vals.find(x => parseFloat(x.strprc) === strike && (/^P/i.test(String(x.optt)) ? 'PE' : 'CE') === side);
        if (!v) throw { msg: `Flattrade has no ${index} ${strike} ${side} for ${iso}.` };
        t = { k: (v.exch || CFG[index].exch) + '|' + v.token, tsym: String(v.tsym), ls: parseInt(v.ls) || 0 };
      }
      const [exch, token] = t.k.split('|');
      return { exch, token, tsym: t.tsym, ls: t.ls };
    };
    ft.placeOrder = async function (o) {
      const j = await rest('/PlaceOrder', { actid: ft.sess.uid, exch: o.exch, tsym: o.tsym, qty: String(o.qty), prc: o.prctyp === 'MKT' ? '0' : String(o.prc), prd: o.prd, trantype: o.trantype,
        prctyp: o.prctyp, ret: 'DAY', ordersource: 'API', remarks: 'EV Pulse', ...(o.trgprc ? { trgprc: String(o.trgprc) } : {}) });
      if (j && j.stat === 'Ok' && j.norenordno) return { ok: true, no: String(j.norenordno) };
      return { ok: false, err: (j && (j.emsg || j.stat)) || 'No reply from Flattrade' };
    };
    ft.orderBook = async function () {
      const j = await rest('/OrderBook', {});
      const v = Array.isArray(j) ? j : okList(j);
      ft.orders = { at: Date.now(), list: v.map(x => ({ no: String(x.norenordno || ''), tsym: String(x.tsym || ''), side: String(x.trantype || ''), qty: parseInt(x.qty) || 0, fill: parseInt(x.fillshares) || 0,
        prc: parseFloat(x.prc) || 0, avg: parseFloat(x.avgprc) || 0, type: String(x.prctyp || ''), prd: String(x.prd || ''), status: String(x.status || '').toUpperCase(), why: String(x.rejreason || ''), ts: String(x.norentm || x.exch_tm || '') })) };
      return ft.orders;
    };
    ft.modifyOrder = async function (o) {
      const j = await rest('/ModifyOrder', { exch: o.exch, tsym: o.tsym, norenordno: String(o.no), prctyp: o.prctyp, prc: String(o.prc), qty: String(o.qty), ret: 'DAY', ...(o.trgprc ? { trgprc: String(o.trgprc) } : {}) });
      return j && j.stat === 'Ok' ? { ok: true, no: String(o.no) } : { ok: false, err: (j && j.emsg) || 'Modify failed' };
    };
    ft.cancelOrder = async function (no) {
      const j = await rest('/CancelOrder', { norenordno: String(no) });
      return j && j.stat === 'Ok' ? { ok: true } : { ok: false, err: (j && j.emsg) || 'Cancel failed' };
    };
    ft.orders = { at: 0, list: [] };
    ft.limits = async function () {                       // funds available for new orders
      const j = await rest('/Limits', { actid: ft.sess.uid });
      if (!j || j.stat !== 'Ok') throw { msg: (j && j.emsg) || 'Could not read funds from Flattrade' };
      const n = k => parseFloat(j[k]) || 0;
      const avail = n('cash') + n('payin') + n('brkcollamt') - n('marginused') - n('payout');
      ft.funds = { at: Date.now(), avail: Math.max(0, avail), cash: n('cash'), used: n('marginused') };
      return ft.funds;
    };
    ft.liveLtp = k => { const x = ft.live[k]; return x && x.lp > 0 ? x.lp : NaN; };

    ft.status = function () {
      if (!ft.configured()) return 'Not set up';
      if (!ft.ready()) return 'Not logged in today';
      if (ft.wsState === 'open') return ft.lastTick ? `Live · last tick ${C.istTime(ft.lastTick, true)}` : 'Connected · waiting for ticks';
      return ft.wsState === 'error' ? 'Live feed error · retrying' : 'Connecting…';
    };
    if (ft.ready()) openWs();
    return ft;
  }

  root.createFT = createFT;
})(typeof window !== 'undefined' ? window : globalThis);
