/* EV Pulse colour themes. Applied before the splash so there is no flash. */
(function () {
  var T = {
    "kblgold": { name: "KBL Violet & Gold", css: ":root{--bg:#120B18;--panel:#1B1222;--panel2:#26192F;--line:#36263F;--text:#F3ECF5;--muted:#AB9BB3;--dim:#71617A;--acc:#E8B04B;--acc-ink:#2A1430;--acc-a:rgba(232,176,75,.16)} .top{background:linear-gradient(90deg,#5E2468,#853A93)!important;border-bottom:2px solid #E8B04B!important} .top .brand,.top .brand b{color:#fff!important} .top .brand b{color:#F4C766!important} .top select{background:rgba(0,0,0,.25)!important;border-color:rgba(255,255,255,.25)!important;color:#fff!important} .seg{background:rgba(0,0,0,.25)!important} .seg button{color:#E9DDEE!important} .seg button.on{background:#E8B04B!important;color:#2A1430!important} nav{background:rgba(27,18,34,.97)!important} nav button.on{color:#E8B04B!important}" },
    "kblnight": { name: "KBL Night Violet", css: ":root{--bg:#110A16;--panel:#1A1121;--panel2:#24182D;--line:#33243D;--text:#F1EAF4;--muted:#A897B0;--dim:#6F5F78;--acc:#B57CC2;--acc-a:rgba(133,58,147,.28)} .top{background:rgba(17,10,22,.96)!important} nav{background:rgba(26,17,33,.97)!important} .seg button.on{background:#853A93!important;color:#fff!important} .brand b{color:#C08BCB!important}" },
    "kblday": { name: "KBL Daylight", css: ":root{--bg:#F6F2F8;--panel:#FFFFFF;--panel2:#F1EAF4;--line:#E6DCEB;--text:#1D1322;--muted:#6B5A73;--dim:#A393AB;--acc:#853A93;--acc-a:rgba(133,58,147,.12);--ce:#D33A45;--ce-a:rgba(211,58,69,.13);--pe:#14925C;--pe-a:rgba(20,146,92,.13)} .top{background:#853A93!important;border-bottom:0!important} .top .brand,.top .brand b{color:#fff!important} .top .brand b{color:#F7D27A!important} .top select{background:rgba(255,255,255,.15)!important;border-color:rgba(255,255,255,.3)!important;color:#fff!important} .seg{background:rgba(255,255,255,.15)!important} .seg button{color:#F3E6F6!important} .seg button.on{background:#fff!important;color:#853A93!important} .srcstrip .src{background:rgba(255,255,255,.18)!important;color:#fff!important} .srcstrip .src b{color:#fff!important} .pill{background:rgba(255,255,255,.18)!important;color:#fff!important} .iconbtn{color:#fff!important;background:rgba(255,255,255,.15)!important} nav{background:#fff!important}" },
    "navy": { name: "Midnight Navy", css: "" },
    "amoled": { name: "AMOLED Black", css: ":root{--bg:#000;--panel:#0B0B0D;--panel2:#141418;--line:#1F2026;--text:#F2F4F8;--muted:#8C93A0;--dim:#5A6170;--acc:#4C7DFF;--acc-a:rgba(76,125,255,.16)} .top{background:rgba(0,0,0,.96)!important} nav{background:rgba(8,8,10,.97)!important}" },
    "gold": { name: "Terminal Gold", css: ":root{--bg:#0A0A0A;--panel:#131210;--panel2:#1C1A16;--line:#2A2720;--text:#F1EADB;--muted:#A39A86;--dim:#6E6656;--acc:#F5A524;--acc-ink:#111;--acc-a:rgba(245,165,36,.16)} .top{background:rgba(10,10,10,.96)!important} nav{background:rgba(19,18,16,.97)!important} .seg .on,.chip.on,nav button.on{color:#F5A524} .seg button.on{background:#F5A524!important;color:#111!important}" },
    "teal": { name: "Ocean Teal", css: ":root{--bg:#06171B;--panel:#0C2329;--panel2:#123039;--line:#1B3B44;--text:#E4F2F2;--muted:#86A6AA;--dim:#557479;--acc:#22C3B5;--acc-ink:#04201D;--acc-a:rgba(34,195,181,.16)} .top{background:rgba(6,23,27,.96)!important} nav{background:rgba(12,35,41,.97)!important} .seg button.on{background:#22C3B5!important;color:#04201D!important}" },
    "purple": { name: "Royal Purple", css: ":root{--bg:#100D1C;--panel:#18142A;--panel2:#221C3A;--line:#2E2748;--text:#ECE8FA;--muted:#9D95BC;--dim:#6A6388;--acc:#8B6CFF;--acc-a:rgba(139,108,255,.18)} .top{background:rgba(16,13,28,.96)!important} nav{background:rgba(24,20,42,.97)!important} .seg button.on{background:#8B6CFF!important}" },
    "day": { name: "Daylight", css: ":root{--bg:#F3F5F9;--panel:#FFFFFF;--panel2:#EEF1F6;--line:#E1E5EC;--text:#111827;--muted:#5B6474;--dim:#9AA3B2;--acc:#2F5BEA;--acc-a:rgba(47,91,234,.12);--ce:#D93A40;--ce-a:rgba(217,58,64,.14);--pe:#12925A;--pe-a:rgba(18,146,90,.14)} .top{background:rgba(255,255,255,.97)!important} nav{background:rgba(255,255,255,.98)!important} .seg button.on{background:#2F5BEA!important;color:#fff!important}" }
  };
  window.EV_THEMES = T;
  window.applyTheme = function (id) {
    if (!T[id]) id = 'kblgold';
    var el = document.getElementById('themeCss');
    if (!el) { el = document.createElement('style'); el.id = 'themeCss'; (document.head || document.documentElement).appendChild(el); }
    el.textContent = T[id].css; document.documentElement.setAttribute('data-theme', id);
    return id;
  };
  var id = 'kblgold';
  try { var s = JSON.parse(localStorage.getItem('oi.settings') || '{}'); if (s && s.theme) id = s.theme; } catch (e) { }
  window.applyTheme(id);
})();
