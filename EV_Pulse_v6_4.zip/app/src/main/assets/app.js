/* OI Tracker — app shell: NSE/BSE polling, storage, rendering. */
(function () {
  'use strict';
  const C = window.Core;
  const Bridge = window.Android || null;
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const NSE = 'https://www.nseindia.com';
  const BSE_API = 'https://api.bseindia.com/BseIndiaAPI/api';
  const UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36';
  const WINDOWS = [['prev', 'Prev close'], ['open', '9:15'], ['5', '5 min'], ['15', '15 min'], ['30', '30 min'], ['60', '1 hr']];
  const MEM_SNAPS = 150;

  // ------------------------------------------------------------------ storage
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } },
  };

  const st = {
    settings: Object.assign({}, C.DEFAULT_SETTINGS, store.get('oi.settings', {})),
    ui: Object.assign({ index: 'NIFTY', win: 'prev', view: 'home', oiMode: 'oi', bg: true }, store.get('oi.ui', {})),
    expiries: {}, expRaw: {}, expFetchedAt: {}, sel: {},
    snaps: {}, first: {}, series: {},
    alerts: [], cool: {}, heroLast: {}, unseen: 0, peaks: {}, hilo: {}, ast: {}, snooze: {},
    fut: { series: [], meta: null, lastLabel: '', err: null },
    live: {}, srcUsed: {}, ftErr: null,
    lastOk: null, errors: {}, diag: {}, busy: false,
    nseWarmAt: 0, bseWarmAt: 0,
    openRow: null, scrolledFor: null, day: C.istDate(Date.now()), timer: null,
  };

  const F = ['oi', 'poi', 'ltp', 'pc', 'iv', 'vol'];
  function pack(s) { return { ts: s.ts, spot: s.spot, r: s.rows.map(r => [r.strike, ...F.map(f => r.ce[f]), ...F.map(f => r.pe[f])]) }; }
  function unpack(p) {
    const rows = p.r.map(a => { const ce = {}, pe = {}; F.forEach((f, i) => { ce[f] = a[1 + i]; pe[f] = a[7 + i]; }); return { strike: a[0], ce, pe }; });
    return C.makeSnap(p.ts, p.spot, rows);
  }
  function saveDay() {
    const last = {}, first = {};
    for (const k in st.snaps) { const h = st.snaps[k]; if (h.length) last[k] = pack(h[h.length - 1]); }
    for (const k in st.first) first[k] = pack(st.first[k]);
    store.set('oi.day.' + st.day, { path: st.path || {}, series: st.series, first, last, alerts: st.alerts.slice(-200), cool: st.cool, heroLast: st.heroLast, peaks: st.peaks, hilo: st.hilo, ast: st.ast, vix: st.vix, iv: st.iv, cas: st.cas, fut: { series: st.fut.series, meta: st.fut.meta, lastLabel: st.fut.lastLabel } });
  }
  function loadDay() {
    try { for (let i = localStorage.length - 1; i >= 0; i--) { const k = localStorage.key(i); if (k && k.startsWith('oi.day.') && k !== 'oi.day.' + st.day) localStorage.removeItem(k); } } catch (e) { }
    const d = store.get('oi.day.' + st.day, null);
    if (!d) return;
    st.path = d.path || {};
    st.series = d.series || {}; st.alerts = d.alerts || []; st.cool = d.cool || {}; st.heroLast = d.heroLast || {}; st.peaks = d.peaks || {}; st.hilo = d.hilo || {}; st.ast = d.ast || {}; if (d.vix) st.vix = d.vix; if (d.iv) st.iv = d.iv; if (d.cas) st.cas = d.cas;
    if (d.fut) { st.fut.series = d.fut.series || []; st.fut.meta = d.fut.meta || null; st.fut.lastLabel = d.fut.lastLabel || ''; }
    for (const k in d.first || {}) st.first[k] = unpack(d.first[k]);
    for (const k in d.last || {}) st.snaps[k] = [unpack(d.last[k])];
    for (const k in st.snaps) { const [i, e] = k.split('|'); (st.expiries[i] = st.expiries[i] || []).includes(e) || st.expiries[i].push(e); }
    for (const i in st.expiries) st.expiries[i].sort();
  }

  // ------------------------------------------------------------------- network
  let reqId = 0; const pending = {};
  window.__httpCb = function (id, status, b64) {
    const p = pending[id]; if (!p) return; delete pending[id];
    let text = '';
    try { text = decodeURIComponent(escape(atob(b64 || ''))); } catch (e) { try { text = atob(b64 || ''); } catch (e2) { } }
    p({ status: status, text: text });
  };
  function http(method, url, headers, body, waitMs) {
    if (Bridge && Bridge.http) {
      return new Promise(res => {
        const id = 'r' + (++reqId); pending[id] = res;
        Bridge.http(id, method, url, JSON.stringify(headers || {}), body || '');
        setTimeout(() => { if (pending[id]) { delete pending[id]; res({ status: 0, text: 'timeout' }); } }, waitMs || 30000);
      });
    }
    // In a normal browser some headers are not allowed; send only the safe ones.
    const h = {}; for (const k in headers || {}) if (/^(accept|content-type)$/i.test(k) || /anthropic\.com/.test(url)) h[k] = headers[k];
    return fetch(url, { method, headers: h, body: body || undefined, credentials: 'include' })
      .then(r => r.text().then(t => ({ status: r.status, text: t })))
      .catch(e => ({ status: 0, text: String(e) }));
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const FT = window.createFT({
    http, store, Core: C,
    sha256: x => (Bridge && Bridge.sha256 ? Bridge.sha256(x) : ''),
    openLogin: (u, r) => { if (Bridge && Bridge.ftLogin) Bridge.ftLogin(u, r); else { toast('Flattrade login works in the Android app'); window.__ftCode && window.__ftCode('', ''); } },
  });
  // HDFC Sky: same data shape as Flattrade; contract list comes as a ZIP (cut down on the phone)
  function zipCsv(url, headers, regex) {
    if (Bridge && Bridge.httpZipCsv) return new Promise(res => {
      const id = 'r' + (++reqId); pending[id] = res;
      Bridge.httpZipCsv(id, url, JSON.stringify(headers || {}), regex);
      setTimeout(() => { if (pending[id]) { delete pending[id]; res({ status: 0, text: 'timeout' }); } }, 200000);
    });
    return http('GET', url + (url.includes('?') ? '&' : '?') + 'csv=1', headers, '', 60000);   // browser test: server returns plain CSV
  }
  const HS = window.createHS({
    http, store, Core: C, zipCsv,
    openLogin: (u, r, cb) => { if (Bridge && Bridge.brokerLogin) Bridge.brokerLogin(u, r, cb); else { toast('HDFC Sky login works in the Android app'); window[cb] && window[cb](''); } },
  });
  const NEWS = window.NewsKit.createNews(http);
  /** the live broker feed in use: Flattrade or HDFC Sky */
  const LD = () => st.settings.source === 'hs' ? HS : FT;
  const isLive = s => s === 'Flattrade' || s === 'HDFC Sky';
  const wantFT = () => st.settings.source === 'ft' || st.settings.source === 'hs';
  const useFT = () => wantFT() && LD().ready();
  function lastSpot(index) {
    const e = st.sel[index] || (st.expiries[index] || [])[0], h = e ? st.snaps[index + '|' + e] : null;
    return h && h.length ? h[h.length - 1].spot : 0;
  }
  function parseJson(t) { try { const j = JSON.parse(t); return j && typeof j === 'object' && Object.keys(j).length ? j : null; } catch (e) { return null; } }
  function note(src, url, r, ok) {
    st.diag[src] = { at: Date.now(), url, status: r.status, ok, snippet: (r.text || '').slice(0, 600) };
  }

  // NSE needs its cookies first: open the option-chain page once, then call the API.
  async function nseWarm() {
    await http('GET', NSE + '/option-chain', { 'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'en-US,en;q=0.9' });
    st.nseWarmAt = Date.now();
    await sleep(300);
  }
  async function nseGet(path) {
    const url = NSE + path;
    const hdr = { 'User-Agent': UA, 'Accept': 'application/json, text/plain, */*', 'Accept-Language': 'en-US,en;q=0.9', 'Referer': NSE + '/option-chain', 'X-Requested-With': 'XMLHttpRequest' };
    if (!st.nseWarmAt || Date.now() - st.nseWarmAt > 4 * 60000) await nseWarm();
    let r = await http('GET', url, hdr), j = parseJson(r.text);
    if (!j) { await nseWarm(); r = await http('GET', url, hdr); j = parseJson(r.text); }
    note('NSE', url, r, !!j);
    if (!j) throw { msg: r.status === 0 ? 'No internet, or NSE not reachable.' : `NSE didn't return data (HTTP ${r.status}). It may be blocking requests; retrying every minute.` };
    return j;
  }
  async function bseGet(url) {
    const hdr = { 'User-Agent': UA, 'Accept': 'application/json, text/plain, */*', 'Accept-Language': 'en-US,en;q=0.9', 'Referer': 'https://www.bseindia.com/', 'Origin': 'https://www.bseindia.com' };
    if (!st.bseWarmAt || Date.now() - st.bseWarmAt > 10 * 60000) {
      await http('GET', 'https://www.bseindia.com/', { 'User-Agent': UA, 'Accept': 'text/html,*/*' });
      st.bseWarmAt = Date.now();
    }
    let r = await http('GET', url, hdr), j = parseJson(r.text);
    if (!j) { await sleep(800); r = await http('GET', url, hdr); j = parseJson(r.text); }
    note('BSE', url, r, !!j);
    if (!j) throw { msg: r.status === 0 ? 'No internet, or BSE not reachable.' : `BSE didn't return data (HTTP ${r.status}); retrying every minute.` };
    return j;
  }

  async function getExpiries(index) {
    const now = Date.now();
    if (st.expFetchedAt[index] && now - st.expFetchedAt[index] < 30 * 60000 && (st.expiries[index] || []).length) return st.expiries[index];
    let list = [];
    try {
      if (index === 'NIFTY') {
        try { list = C.nseExpiries(await nseGet('/api/option-chain-contract-info?symbol=NIFTY')); } catch (e) { }
        if (!list.length) list = C.nseExpiries(await nseGet('/api/option-chain-indices?symbol=NIFTY'));
      } else {
        list = C.bseExpiries(await bseGet(`${BSE_API}/ddlExpiry_IV/w?ProductType=IO&scrip_cd=1`));
      }
    } catch (e) { if (!HS.ready()) throw e; }
    const today = C.istDate(now);
    list = list.filter(x => x.iso >= today);
    if (!list.length && HS.ready()) { try { await HS.loadMaster(); list = HS.expiries(index).filter(x => x >= today).map(x => ({ iso: x, raw: x })); } catch (e) { } }
    if (!list.length) throw { msg: `${index}: couldn't read expiry dates from ${C.INDICES[index].src}.` };
    st.expRaw[index] = {}; list.forEach(x => { st.expRaw[index][x.iso] = x.raw; });
    st.expiries[index] = list.map(x => x.iso);
    st.expFetchedAt[index] = now;
    return st.expiries[index];
  }
  async function getChain(index, iso) {
    if (useFT()) {
      const L = LD();
      try {
        await L.prepare(index, iso, lastSpot(index));
        if (L === HS) await hsPrevOi(index, iso);
        if (L.hasChain(index, iso)) { const p = L.chain(index, iso, lastSpot(index)); if (p.rows.length && p.spot) { p.src = L.name || 'Flattrade'; st.ftErr = null; await fixOi(index, iso, p); return p; } }
      } catch (e) { st.ftErr = (e && e.msg) || String(e); }
    }
    const p = await getChainExchange(index, iso);
    p.src = C.INDICES[index].src;
    return p;
  }
  /**
   * Flattrade's live feed may carry no OI for BSE (SENSEX) options. Then OI / OI change come from
   * the BSE website (refreshed each minute) while prices stay live; last resort: Flattrade GetQuotes.
   */
  st.exOi = {};
  /** HDFC Sky's feed has today's OI but not yesterday's: take previous-day OI from the exchange website every 10 min */
  st.hsPoiAt = {};
  async function hsPrevOi(index, iso) {
    const k = index + '|' + iso; if (Date.now() - (st.hsPoiAt[k] || 0) < 10 * 60000) return;
    st.hsPoiAt[k] = Date.now();
    try { const ex = await getChainExchange(index, iso); if (ex.rows.length && !noOi(ex)) HS.setPrevOi(index, iso, ex.rows); } catch (e) { }
  }
  function noOi(p) { return !p.rows.some(r => r.ce.oi > 0 || r.pe.oi > 0); }
  function applyOi(index, iso, p) {
    let m = st.exOi[index + '|' + iso];
    if (!m) {                                  // fall back to the last saved snapshot that had OI
      const h = st.snaps[index + '|' + iso] || [], last = h.slice().reverse().find(x => !noOi(x));
      if (last) { m = new Map(last.rows.map(r => [r.strike, r])); m.src = C.INDICES[index].src; }
    }
    if (!m || !noOi(p)) return false;
    for (const r of p.rows) { const x = m.get(r.strike); if (!x) continue;
      r.ce.oi = x.ce.oi; r.ce.poi = x.ce.poi; r.pe.oi = x.pe.oi; r.pe.poi = x.pe.poi;
      if (!(r.ce.iv > 0)) r.ce.iv = x.ce.iv; if (!(r.pe.iv > 0)) r.pe.iv = x.pe.iv; }
    p.oiSrc = m.src; return true;
  }
  async function fixOi(index, iso, p) {
    const L = LD(), q = L.oiQuotes && L.oiQuotes[index];
    if (!noOi(p)) {                     // OI present: from the feed, or from earlier quotes (refresh those every minute)
      if (q && !st.exOi[index + '|' + iso]) {
        if (Date.now() - q > 55000) { try { await L.fillOi(index, p.spot, 30); p.rows = L.chain(index, iso, p.spot).rows; } catch (e) { } }
        st.oiSrc[index] = 'Flattrade quotes';
      } else st.oiSrc[index] = '';
      return;
    }
    try {
      const ex = await getChainExchange(index, iso);
      if (ex.rows.length && !noOi(ex)) { const m = new Map(ex.rows.map(r => [r.strike, r])); m.src = C.INDICES[index].src; st.exOi[index + '|' + iso] = m; }
    } catch (e) { }
    if (!applyOi(index, iso, p)) {
      try { if (await L.fillOi(index, p.spot, 30)) { const q = L.chain(index, iso, p.spot); p.rows = q.rows; p.oiSrc = 'Flattrade quotes'; } } catch (e) { }
    }
    st.oiSrc[index] = p.oiSrc || (noOi(p) ? 'none' : '');
  }
  st.oiSrc = {}; st.oiTry = {};
  async function getChainExchange(index, iso) {
    const raw = (st.expRaw[index] || {})[iso] || iso;
    if (index === 'NIFTY') {
      let p = { rows: [] };
      try { p = C.parseNSE(await nseGet(`/api/option-chain-v3?type=Indices&symbol=NIFTY&expiry=${encodeURIComponent(raw)}`)); } catch (e) { }
      if (!p.rows.length) p = C.parseNSE(await nseGet('/api/option-chain-indices?symbol=NIFTY'), raw);
      return p;
    }
    return C.parseBSE(await bseGet(`${BSE_API}/DerivOptionChain_IV/w?Expiry=${encodeURIComponent(raw)}&scrip_cd=1&strprice=0`));
  }

  // --------------------------------------------------------------- poll cycle
  async function cycle(manual) {
    if (st.busy) return;
    clearTimeout(st.timer);
    st.busy = true; setSpin(true);
    try {
      const today = C.istDate(Date.now());
      if (today !== st.day) { st.day = today; st.path = {}; st.snaps = {}; st.first = {}; st.series = {}; st.alerts = []; st.cool = {}; st.heroLast = {}; st.peaks = {}; st.hilo = {}; st.ast = {}; st.snooze = {}; vixReset(); st.cas = {}; st.fut = { series: [], meta: null, lastLabel: '', err: null }; st.expFetchedAt = {}; }
      const open = C.marketOpen(Date.now());
      try { await fetchFutures(open, manual); st.fut.err = null; } catch (e) { st.fut.err = (e && e.msg) || String(e); }
      try { await fetchVix(open, manual); fetchVixHist().catch(() => { }); } catch (e) { }
      try { await fetchGift(manual); } catch (e) { }
      NEWS.refresh(false).then(() => { if (st.ui.view === 'daily') render(); }).catch(() => { });
      for (const index of Object.keys(C.INDICES)) {
        try {
          const exps = await getExpiries(index);
          if (st.sel[index] && !exps.includes(st.sel[index])) st.sel[index] = null;
          if (!st.sel[index]) st.sel[index] = exps[0];
          const tracked = [exps[0]];
          if (st.sel[index] !== exps[0]) tracked.push(st.sel[index]);
          for (const expiry of tracked) {
            const key = index + '|' + expiry;
            if (!open && (st.snaps[key] || []).length && !manual) continue;
            const parsed = await getChain(index, expiry);
            st.srcUsed[index] = parsed.src;
            if (!parsed.rows.length) throw { msg: `${index}: option chain came back empty.` };
            const snap = C.makeSnap(Date.now(), parsed.spot, parsed.rows);
            const h = st.snaps[key] = st.snaps[key] || [];
            h.push(snap); if (h.length > MEM_SNAPS) h.shift();
            if (!st.first[key]) st.first[key] = snap;
            updatePeaks(key, snap);
            if (expiry === exps[0]) recordIv(index, expiry, snap);
            (st.series[key] = st.series[key] || []).push(C.summary(snap));
            if (st.series[key].length > 800) st.series[key].shift();
            if (open) {
              const S2 = Object.assign({}, st.settings, { pcrAlerts: true, levelAlerts: true, spikeAlerts: true });
              for (const a of C.checkAlerts(index, expiry, h, S2, st.cool)) if (expiry === exps[0]) pushAlert(a);
              if (expiry === exps[0]) { heroAlert(index, expiry); try { runAlerts(index, expiry, h); vixCrushAlert(index, expiry); casTick(index); } catch (e) { console.error(e); } }
            }
            await sleep(400);
          }
          delete st.errors[index];
        } catch (e) {
          st.errors[index] = (e && e.msg) || String(e);
        }
      }
      if (Object.keys(st.errors).length < Object.keys(C.INDICES).length) st.lastOk = Date.now();
      alertOutcomes(); syncAlertLog();
      if (FT.ready()) { try { await FT.loadPositions(); } catch (e) { } }
      if (HS.ready()) { try { await HS.loadPositions(); } catch (e) { } }
      try { adviseAll(true); } catch (e) { console.error(e); }
      try { await morningTick(); } catch (e) { console.error(e); }
    } finally {
      st.busy = false; setSpin(false);
      saveDay(); render();
      const pp = C.istParts(Date.now()), pm = pp.h * 60 + pp.mi, wd = new Date(Date.now() + 5.5 * 3600e3).getUTCDay();
      const preOpen = wd > 0 && wd < 6 && pm >= 8 * 60 && pm < 9 * 60 + 15;      // GIFT Nifty + morning call window
      st.timer = setTimeout(() => cycle(false), C.marketOpen(Date.now()) || preOpen ? 60000 : 5 * 60000);
    }
  }

  // today's highest OI change per strike (for the "going to zero" highlight)
  function updatePeaks(key, snap) {
    const pk = st.peaks[key] = st.peaks[key] || {};
    for (const r of snap.rows) {
      const p = pk[r.strike] || (pk[r.strike] = [-Infinity, -Infinity]);
      p[0] = Math.max(p[0], r.ce.oi - r.ce.poi);
      p[1] = Math.max(p[1], r.pe.oi - r.pe.poi);
    }
    if (!C.marketOpen(snap.ts)) return;
    recordPath(key, snap);
    const hl = st.hilo[key] = st.hilo[key] || {};
    for (const r of snap.rows) {
      const x = hl[r.strike] || (hl[r.strike] = {});
      if (r.ce.ltp > 0) { x.ceHi = Math.max(x.ceHi || 0, r.ce.ltp); x.ceLo = Math.min(x.ceLo || Infinity, r.ce.ltp); }
      if (r.pe.ltp > 0) { x.peHi = Math.max(x.peHi || 0, r.pe.ltp); x.peLo = Math.min(x.peLo || Infinity, r.pe.ltp); }
    }
  }

  /** one point per minute: spot and premiums of strikes near the money, for 'how many times did it rally' stats */
  function recordPath(key, snap) {
    const P = (st.path = st.path || {})[key] = (st.path || {})[key] || [];
    const tp = C.istParts(snap.ts), m = tp.h * 60 + tp.mi;
    const step = C.INDICES[key.split('|')[0]].step, pr = {};
    for (const r of snap.rows) if (Math.abs(r.strike - snap.spot) <= step * 12) pr[r.strike] = [+(r.ce.ltp || 0).toFixed(2), +(r.pe.ltp || 0).toFixed(2), r.ce.vol || 0, r.pe.vol || 0];
    const pt = { m, s: +(+snap.spot).toFixed(2), p: pr };
    tickPush(key.split('|')[0], snap.spot);
    if (P.length && P[P.length - 1].m === m) P[P.length - 1] = pt; else P.push(pt);
    if (P.length > 400) P.shift();
  }
  /**
   * How often today did this option rally from a bottom by at least the move the plan needs (entry → target)?
   * And the chance it does it again before 3:30: blend of the index-move probability (volatility model) and today's own rally rate.
   */
  function rallyStats(ctx, side, K, ltp, target, tgtLevel) {
    const P = ((st.path || {})[ctx.key] || []).filter(x => x.p[K] && x.p[K][side === 'ce' ? 0 : 1] > 0);
    const need = isFinite(target) && target > ltp ? target / ltp - 1 : 0.5;          // gain needed, e.g. 0.65 = +65%
    const idx = side === 'ce' ? 0 : 1;
    let low = Infinity, lowM = 0, best = 0, times = [], low2 = Infinity;
    for (const x of P) {
      const v = x.p[K][idx];
      if (v < low) { low = v; lowM = x.m; }
      low2 = Math.min(low2, v); if (v / low2 - 1 > best) best = v / low2 - 1;
      const g = v / low - 1;
      if (g >= need) { times.push({ from: lowM, at: x.m, lo: low, hi: v }); low = Infinity; }
    }
    const nowP = C.istParts(Date.now()), nowM = nowP.h * 60 + nowP.mi;
    const left = C.minsLeft(Date.now()), elapsed = P.length ? P[P.length - 1].m - P[0].m : 0;
    const dist = isFinite(tgtLevel) ? Math.abs(tgtLevel - ctx.spot) : NaN;
    const model = isFinite(dist) && left > 0 ? C.touchProb(dist, C.expMove(ctx.spot, ctx.volPct, left)) : NaN;
    let emp = NaN; if (elapsed >= 30 && left > 0) emp = 1 - Math.exp(-(times.length / elapsed) * left);
    let chance = isFinite(model) && isFinite(emp) ? 0.6 * model + 0.4 * emp : isFinite(model) ? model : emp;
    if (left <= 0) chance = 0;
    return { count: times.length, times, need, best, chance, model, emp, elapsed, left, points: P.length, nowM };
  }

  // ------- NIFTY futures (current month) — used as the direction read for both tabs
  async function fetchFutures(open, manual) {
    if (!open && st.fut.series.length && !manual) return;
    let list = [];
    if (useFT()) {
      const L = LD();
      try { await L.prepareFut(); const q = L.futQuote(); if (q) { list = [q]; st.fut.src = L.name || 'Flattrade'; } } catch (e) { st.ftErr = (e && e.msg) || String(e); }
    }
    if (!list.length) st.fut.src = 'NSE';
    if (!list.length) try { list = C.parseNseFutures(await nseGet('/api/liveEquity-derivatives?index=nse50_fut')); } catch (e) { }
    if (!isLive(st.fut.src) && (!list.length || !isFinite(list[0].oi))) {
      const b = C.parseNseFutures(await nseGet('/api/quote-derivative?symbol=NIFTY'));
      if (b.length) list = b;
    }
    const today = C.istDate(Date.now());
    const f = list.find(x => x.iso >= today) || list[0];
    if (!f) throw { msg: 'NIFTY futures: no data from NSE.' };
    if (st.fut.meta && st.fut.meta.iso !== f.iso) { st.fut.series = []; st.fut.lastLabel = ''; }  // monthly rollover
    const spot = isFinite(f.underlying) && f.underlying > 0 ? f.underlying : niftySpot();
    st.fut.meta = { iso: f.iso, prevClose: f.prevClose, prevOi: isFinite(f.oiChg) && isFinite(f.oi) ? f.oi - f.oiChg : NaN, vol: f.vol };
    st.fut.series.push({ ts: Date.now(), ltp: f.ltp, oi: isFinite(f.oi) ? f.oi : NaN, spot });
    if (st.fut.series.length > 800) st.fut.series.shift();
    if (open) futAlert();
  }
  function niftySpot() {
    const e = (st.expiries.NIFTY || [])[0], h = e ? st.snaps['NIFTY|' + e] : null;
    return h && h.length ? h[h.length - 1].spot : NaN;
  }
  function futBase(win) {
    const s = st.fut.series, m = st.fut.meta;
    if (!s.length) return null;
    if (win === 'prev') {
      if (m && isFinite(m.prevClose) && isFinite(m.prevOi)) return { ltp: m.prevClose, oi: m.prevOi, ts: null, label: 'vs prev close' };
      return Object.assign({ label: 'since ' + C.istTime(s[0].ts) }, s[0]);
    }
    if (win === 'open') return Object.assign({ label: 'since ' + C.istTime(s[0].ts) }, s[0]);
    const cut = s[s.length - 1].ts - (+win) * 60000 + 5000;
    let b = s[0]; for (const x of s) if (x.ts <= cut) b = x;
    return Object.assign({ label: b === s[0] && s[0].ts > cut ? 'since ' + C.istTime(s[0].ts) : 'last ' + win + ' min' }, b);
  }
  function fut15() {
    const s = st.fut.series; if (s.length < 2) return { label: '', bias: '' };
    const b = futBase('15');
    if (!b || s[s.length - 1].ts - b.ts < 5 * 60000) return { label: '', bias: '' };
    return C.futBuildup(s[s.length - 1], b);
  }
  function futAlert() {
    const r = fut15();
    if (!r.label || r.label === st.fut.lastLabel) return;
    const prev = st.fut.lastLabel;
    st.fut.lastLabel = r.label;
    if (!prev) return;   // first reading of the day: just remember it
    const k = 'FUT|' + r.label, now = Date.now();
    if (st.cool[k] && now - st.cool[k] < st.settings.cooldown * 60000) return;
    st.cool[k] = now;
    const cur = st.fut.series[st.fut.series.length - 1];
    pushAlert({ ts: now, index: 'NIFTY', expiry: st.fut.meta.iso, kind: 'Futures', tone: r.bias === 'Bullish' ? 'bull' : 'bear', key: r.label, cool: st.settings.cooldown,
      msg: `NIFTY futures turned ${prev} → ${r.label} (${r.bias}) in the last 15 min. Price ${sgn(r.dp, f1)}, OI ${sQ(r.doi)}. Fut ${f2(cur.ltp)}.` });
  }

  function heroFor(index) {
    const exps = st.expiries[index] || [];
    if (!exps.length) return null;
    const key = index + '|' + exps[0], h = st.snaps[key] || [];
    const cur = h.length ? h[h.length - 1] : null;
    return C.heroZero(st.series[key] || [], cur, cur ? C.compare(cur, null) : [], exps[0], st.settings, Date.now());
  }
  function heroAlert(index, expiry) {
    const hz = heroFor(index);
    if (!hz || !hz.active || hz.closed) return;
    const prev = st.heroLast[index];
    if (hz.state === prev) return;
    st.heroLast[index] = hz.state;
    if (hz.state === 'none') return;
    const picks = hz.picks.map(p => `${fmtK(p.strike)} ${p.side} ₹${f2(p.ltp)}`).join(', ');
    const msg = hz.state === 'both' ? 'OI change falling on both sides. Wait for one side to stand out.'
      : `${hz.state} side: ${hz.state === 'CE' ? 'call' : 'put'} writers exiting. Near-ATM ${hz.state} OI change down ${Math.round(hz[hz.state.toLowerCase()].drop)}% from today's peak.` + (picks ? ` Strikes: ${picks}` : '');
    const r15 = fut15(), conf = C.futConfirm(hz.state, r15.bias);
    const fmsg = conf === 'agree' ? ` Futures agree (${r15.label}).` : conf === 'disagree' ? ` Careful: futures show ${r15.label} (${r15.bias}).` : '';
    const vn = (hz.state === 'CE' || hz.state === 'PE') ? heroVolNote(index) : null, sp = (dataNear(index) || {}).cur;
    const rp = sp && hz.picks[0] ? ` Chance ${fmtK(hz.picks[0].strike)} is reached by 3:30: ${pctTxt(reachProb(index, sp.spot, hz.picks[0].strike))}.` : '';
    pushAlert({ ts: Date.now(), index, expiry, kind: 'Hero-zero', type: hz.state === 'both' ? 'heroWatch' : 'heroSignal', title: hz.state === 'both' ? `${index} · Hero-zero: both sides falling` : `🚀 ${index} HERO-ZERO: ${hz.state} side`, tone: hz.state === 'CE' ? 'bull' : hz.state === 'PE' ? 'bear' : '', key: hz.state, cool: 30, msg: (fmsg ? msg.replace(/\.?$/, '.') : msg) + fmsg + rp + (vn ? ' ' + vn.t + '.' : '') });
  }

  // =====================================================================================
  // ALERT ENGINE — every alert has an id, a level (critical / important / info) and settings
  // =====================================================================================
  const ALERTS = [
    { id: 'reversalWarn', name: 'Reversal warning (early)', lvl: 'critical', desc: 'BEFORE the turn: price still near the day high/low, but option writers, PCR, futures or big OI additions point the other way' },
    { id: 'reversal', name: 'Reversal confirmed', lvl: 'critical', desc: 'Spot has turned 0.3%+ off a fresh intraday high/low, confirmed by futures or writers' },
    { id: 'heroSignal', name: 'Hero-zero signal (80%)', lvl: 'critical', exp: true, desc: 'Writers on one side have left: CE or PE side signal with strikes' },
    { id: 'rangeBreak', name: 'Range break', lvl: 'critical', desc: 'Spot crosses resistance or support' },
    { id: 'resShift', name: 'Resistance shifted', lvl: 'critical', desc: 'Max Call OI strike moved (confirmed over 2 readings)' },
    { id: 'supShift', name: 'Support shifted', lvl: 'critical', desc: 'Max Put OI strike moved (confirmed over 2 readings)' },
    { id: 'hzTrigger', name: 'HZ strike given / forming', lvl: 'important', exp: true, desc: 'Expiry day: hero-zero starting to form, and the moment a strike is given (writers exiting or straddle spike)' },
    { id: 'hzMove', name: 'HZ moving now', lvl: 'important', exp: true, desc: 'Expiry day: a cheap strike premium jumps 30%+ within 10 minutes. Critical when it matches the hero-zero side' },
    { id: 'hzSpeed', name: 'HZ speed burst', lvl: 'important', exp: true, desc: 'Expiry afternoon: the index moves fast (NIFTY 25+ pts or SENSEX 80+ pts in 2 min). Critical when it matches the hero-zero side' },
    { id: 'heroWatch', name: 'Hero-zero watch (50%)', lvl: 'important', exp: true, desc: 'Near-ATM OI change already down 50% from peak' },
    { id: 'oiDecline', name: 'Steady OI-change fall', lvl: 'important', exp: true, desc: 'CE/PE OI change falling 5 readings in a row, or 30% in 10 min' },
    { id: 'strikeDump', name: 'Strike OI dump', lvl: 'important', desc: 'A near-ATM strike loses 20%+ OI in 5 min' },
    { id: 'bigOi', name: 'Sudden big OI (live, seconds)', lvl: 'critical', desc: 'Within 30 seconds a strike\'s OI jumps or drops far more than usual (2.5%+ of its OI and 4× its normal change): writers running or piling in. Comes with a strike to buy and a penny idea. Needs Flattrade or HDFC Sky live data' },
    { id: 'resForecast', name: 'Resistance shift forecast', lvl: 'important', desc: 'Resistance weakening or another strike taking over' },
    { id: 'supForecast', name: 'Support shift forecast', lvl: 'important', desc: 'Support weakening or another strike taking over' },
    { id: 'futFlip', name: 'Futures buildup flip', lvl: 'important', desc: 'NIFTY futures 15-min buildup changes (e.g. short buildup → short covering)' },
    { id: 'premJump', name: 'Hero strike 2x / 3x', lvl: 'important', desc: 'A strike suggested by the app doubles or triples' },
    { id: 'oiSpike', name: 'Sudden OI change', lvl: 'important', desc: 'Sharp OI change at near-ATM strikes' },
    { id: 'casClose', name: 'Closing auction estimate', lvl: 'important', desc: 'After 3:15: where the auction will close, the size of the final candle, and expiry settlement values' },
    { id: 'casIdea', name: 'Closing auction strike idea', lvl: 'important', desc: 'Every day after 3:15: a CE or PE priced below its expected value at the auction close' },
    { id: 'posAdvice', name: 'My position advice', lvl: 'important', desc: 'Hold / book profit / exit changes for your open positions (Flattrade or journal)' },
    { id: 'vixSpike', name: 'India VIX spike', lvl: 'important', desc: 'India VIX up 8%+ on the day, or 5%+ in 15 min' },
    { id: 'vixCrush', name: 'VIX / IV crush (expiry)', lvl: 'info', exp: true, desc: 'Volatility down 8%+ since 1 PM on expiry: premiums melting' },
    { id: 'zeroFlip', name: 'Zero-OI side flip', lvl: 'info', desc: 'More zero-OI strikes switches between above and below spot' },
    { id: 'timeRemind', name: 'Expiry-day reminders', lvl: 'info', exp: true, desc: '1:15 PM hero-zero window, 3:00 PM last 30 minutes' },
    { id: 'pcr', name: 'PCR crossing', lvl: 'info', desc: 'PCR crosses your levels' },
    { id: 'maxPain', name: 'Max pain shift', lvl: 'info', desc: 'Max pain strike moves' },
  ];
  const ALERT = Object.fromEntries(ALERTS.map(a => [a.id, a]));
  function acfg(id) {
    const c = (st.settings.alertCfg || {})[id] || {};
    const d = ALERT[id];
    return { on: c.on !== undefined ? c.on : true, lvl: c.lvl || d.lvl, exp: c.exp !== undefined ? c.exp : !!d.exp };
  }
  const isExpiryDay = index => (st.expiries[index] || [])[0] === C.istDate(Date.now());
  st.snooze = st.snooze || {};

  /** Raise an alert. key: dedupe key; cool: minutes before the same key can fire again. */
  function fire(id, index, expiry, title, msg, tone, key, cool, lvlOver) {
    const c = acfg(id); if (!c.on) return false;
    if (c.exp && !isExpiryDay(index)) return false;
    const now = Date.now();
    if (st.snooze[id] && now < st.snooze[id]) return false;
    const k = 'A|' + id + '|' + index + '|' + (key || '');
    if (st.cool[k] && now - st.cool[k] < (cool === undefined ? 15 : cool) * 60000) return false;
    st.cool[k] = now;
    const d = dataNear(index);
    const a = { ts: now, index, expiry, type: id, kind: ALERT[id].name, lvl: lvlOver && c.lvl !== 'info' ? lvlOver : c.lvl, tone: tone || '', title, msg, spot0: d ? d.cur.spot : NaN };
    attachPlan(a);
    try { if (a.plan) planTrackAdd(a); } catch (e) { console.error(e); }
    st.alerts.push(a); st.unseen++; logAlert(a);
    deliver(a);
    return true;
  }
  // legacy alerts from core.checkAlerts: map onto the engine
  function pushAlert(a) {
    const map = { 'PCR': 'pcr', 'OI spike': 'oiSpike', 'Max pain': 'maxPain', 'Futures': 'futFlip', 'Hero-zero': 'heroSignal' };
    const id = a.type || map[a.kind];
    if (!id) return;                                    // Support/Resistance are handled by the new rules
    fire(id, a.index, a.expiry, a.title || `${a.index} · ${ALERT[id].name}`, a.msg, a.tone || '', a.key || a.msg.slice(0, 40), a.cool);
  }

  // ---- delivery: phone notification + in-app pop-up / banner / toast
  const alertQueue = [];
  function deliver(a) {
    if (st.settings.notify && Bridge && Bridge.alert) Bridge.alert((a.lvl === 'critical' && st.settings.alarm === false ? 'critical_quiet' : a.lvl) + ':' + (a.tone || ''), a.title, a.msg + (a.plan ? '\n' + planText(a.plan) : ''));
    if (a.lvl === 'critical') { alertQueue.push(a); showOverlay(); }
    else if (a.lvl === 'important') showBanner(a);
    else toast(`${a.title}: ${a.msg}`);
  }
  function showOverlay() {
    const o = $('ovl'); if (!o || o.classList.contains('on') || !alertQueue.length) return;
    const a = alertQueue[0];
    o.className = 'ovl on ' + (a.tone === 'bull' ? 'bull' : a.tone === 'bear' ? 'bear' : 'warn');
    $('ovT').textContent = a.title; $('ovM').textContent = a.msg; $('ovP').innerHTML = planHtmlBox(a.plan);
    $('ovTime').textContent = `${C.istTime(a.ts, true)} IST` + (alertQueue.length > 1 ? ` · ${alertQueue.length - 1} more` : '');
  }
  function closeOverlay(snooze) {
    const a = alertQueue.shift();
    if (snooze && a) { st.snooze[a.type] = Date.now() + 15 * 60000; toast(`${ALERT[a.type].name} snoozed for 15 min`); }
    $('ovl').className = 'ovl';
    if (Bridge && Bridge.clearAlerts) Bridge.clearAlerts();
    setTimeout(showOverlay, 250);
  }
  let bannerT;
  function showBanner(a) {
    const b = $('abanner'); if (!b) return;
    b.className = 'abanner on ' + (a.tone === 'bull' ? 'bull' : a.tone === 'bear' ? 'bear' : '');
    b.innerHTML = `<b>${esc(a.title)}</b><span>${esc(a.msg)}</span>${a.plan ? `<span class="bplan">${esc(planText(a.plan))}</span>` : ''}`;
    clearTimeout(bannerT); bannerT = setTimeout(() => { b.className = 'abanner'; }, 10000);
  }
  window.__alertOpened = () => { showOverlay(); };

  // ---- per-index rule state (kept for the day)
  const AS = index => (st.ast[index] = st.ast[index] || {});

  function runAlerts(index, expiry, h) {
    const d = dataNear(index); if (!d || h.length < 2) return;
    const { cur, key, series } = d, prev = h[h.length - 2], s = AS(index), step = C.INDICES[index].step;
    const now = Date.now(), p = C.istParts(now), mins = p.h * 60 + p.mi;
    const rowsPrev = C.compare(cur, null), view = C.windowRows(rowsPrev, cur.spot, st.settings.strikes);

    const frozen = mins >= 15 * 60 + 15;                 // stocks stop at 3:15 (closing auction): spot-based alerts would misfire on the jump
    // 1) steady OI-change fall (near-ATM totals, per side)
    for (const sd of ['nce', 'npe']) {
      const v = series.slice(-6).map(x => x[sd]).filter(isFinite);
      const sideTxt = sd === 'nce' ? 'CE' : 'PE', who = sd === 'nce' ? 'Call' : 'Put';
      const peakAbs = Math.max(1, ...series.map(x => Math.abs(x[sd] || 0)));
      let falls = 0; for (let i = 1; i < v.length; i++) if (v[i] < v[i - 1]) falls++; else falls = 0;
      const ten = series.length > 10 ? series[series.length - 11][sd] : NaN, nowV = v[v.length - 1];
      const drop10 = isFinite(ten) && ten > 0 ? (ten - nowV) / ten * 100 : 0;
      if ((falls >= 5 && v[0] - nowV > peakAbs * 0.05) || (drop10 >= 30 && ten > peakAbs * 0.1))
        fire('oiDecline', index, expiry, `${index} · ${who} writers steadily exiting`,
          `Near-ATM ${sideTxt} OI change ${Q(isFinite(ten) ? ten : v[0])} → ${Q(nowV)} (${drop10 >= 30 ? '−' + Math.round(drop10) + '% in 10 min' : falls + ' falls in a row'}). Watch the ${sideTxt} side.`,
          sd === 'nce' ? 'bull' : 'bear', sd, 15);
    }

    // 2) hero-zero watch at 50% (signal at 80% is heroAlert)
    const hz = heroFor(index);
    if (hz && hz.expiryDay && mins >= st.settings.heroStart - 60 && mins <= 15 * 60 + 25) {
      for (const sd of ['ce', 'pe']) {
        const x = hz[sd];
        if (x && x.peak > 0 && x.drop >= 50 && x.drop < st.settings.heroDrop)
          fire('heroWatch', index, expiry, `${index} · Hero-zero watch: ${sd.toUpperCase()} side`,
            `Near-ATM ${sd.toUpperCase()} OI change is down ${Math.round(x.drop)}% from today's peak (${sQ(x.now)} / ${sQ(x.peak)}). Signal at ${st.settings.heroDrop}%.`,
            sd === 'ce' ? 'bull' : 'bear', sd, 60);
      }
    }

    // 3) strike OI dump: ≥20% OI lost in 5 min at a near-ATM strike
    const b5 = C.baseline(h, st.first[key], '5');
    if (b5 && b5 !== cur && cur.ts - b5.ts >= 4 * 60000) {
      const bm = new Map(b5.rows.map(r => [r.strike, r]));
      const near = C.windowRows(cur.rows, cur.spot, 5);
      const top = Math.max(1, ...cur.rows.map(r => Math.max(r.ce.oi, r.pe.oi)));
      const hits = [];
      for (const r of near) { const o = bm.get(r.strike); if (!o) continue;
        for (const sd of ['ce', 'pe']) if (o[sd].oi >= top * 0.1 && r[sd].oi <= o[sd].oi * 0.8) hits.push(`${fmtK(r.strike)} ${sd.toUpperCase()} −${Math.round((1 - r[sd].oi / o[sd].oi) * 100)}% (${Q(o[sd].oi)}→${Q(r[sd].oi)})`); }
      if (hits.length) fire('strikeDump', index, expiry, `${index} · OI dump at ${hits.length} strike${hits.length > 1 ? 's' : ''}`,
        `In 5 min: ${hits.slice(0, 3).join(' · ')}. Big writers covering: a sharp move can follow.`, '', hits[0].slice(0, 12), 10);
    }

    // 4-7) support / resistance: forecasts and confirmed shifts
    let b15 = C.baseline(h, st.first[key], '15'); if (b15 && (b15 === cur || cur.ts - b15.ts < 4 * 60000)) b15 = null;
    const R = C.srSide(cur, b15, 'ce'), S = C.srSide(cur, b15, 'pe');
    const fState = x => x ? x.state + (x.dir || '') + (x.target || '') : '';
    if (R && fState(R) !== s.rf && (R.state === 'Shift' || R.state === 'Weakening'))
      fire('resForecast', index, expiry, `${index} · Resistance ${fmtK(R.level)} ${R.state === 'Shift' ? 'may shift ' + R.dir : 'weakening'}`,
        R.state === 'Shift' ? `Call writers adding faster at ${fmtK(R.target)} (${sQ(R.ch.move)}); resistance may move ${R.dir} to ${fmtK(R.target)}.` : `Call writers exiting ${fmtK(R.level)}; resistance may shift up${R.target ? ' toward ' + fmtK(R.target) : ''}.`,
        R.dir === 'up' || R.state === 'Weakening' ? 'bull' : 'bear', fState(R), 20);
    if (S && fState(S) !== s.sf && (S.state === 'Shift' || S.state === 'Weakening'))
      fire('supForecast', index, expiry, `${index} · Support ${fmtK(S.level)} ${S.state === 'Shift' ? 'may shift ' + S.dir : 'weakening'}`,
        S.state === 'Shift' ? `Put writers adding faster at ${fmtK(S.target)} (${sQ(S.ch.move)}); support may move ${S.dir} to ${fmtK(S.target)}.` : `Put writers exiting ${fmtK(S.level)}; support may shift down${S.target ? ' toward ' + fmtK(S.target) : ''}.`,
        S.dir === 'up' ? 'bull' : 'bear', fState(S), 20);
    s.rf = fState(R); s.sf = fState(S);
    if (h.length >= 3) {
      const [a3, a2, a1] = h.slice(-3);
      if (a1.res === a2.res && a2.res !== a3.res && isFinite(a3.res))
        fire('resShift', index, expiry, `${index} · Resistance moved ${a1.res > a3.res ? 'UP' : 'DOWN'}`,
          `Resistance (max Call OI) ${fmtK(a3.res)} → ${fmtK(a1.res)}. Spot ${f2(cur.spot)}.`, a1.res > a3.res ? 'bull' : 'bear', String(a1.res), 15);
      if (a1.sup === a2.sup && a2.sup !== a3.sup && isFinite(a3.sup))
        fire('supShift', index, expiry, `${index} · Support moved ${a1.sup > a3.sup ? 'UP' : 'DOWN'}`,
          `Support (max Put OI) ${fmtK(a3.sup)} → ${fmtK(a1.sup)}. Spot ${f2(cur.spot)}.`, a1.sup > a3.sup ? 'bull' : 'bear', String(a1.sup), 15);
    }

    // 8) range break: spot crosses the previous reading's resistance / support
    const beyond = (lvl, side, up) => { const c = cur.rows.filter(r => up ? r.strike > lvl : r.strike < lvl).sort((a, b) => b[side].oi - a[side].oi)[0]; return c ? fmtK(c.strike) : fmtK(lvl + (up ? step : -step)); };
    if (!frozen && isFinite(prev.res) && prev.spot <= prev.res && cur.spot > prev.res)
      fire('rangeBreak', index, expiry, `🚀 ${index} broke above resistance ${fmtK(prev.res)}`, `Spot ${f2(cur.spot)} crossed resistance ${fmtK(prev.res)}. Next resistance: ${beyond(prev.res, 'ce', true)}.`, 'bull', 'up' + prev.res, 20);
    if (!frozen && isFinite(prev.sup) && prev.spot >= prev.sup && cur.spot < prev.sup)
      fire('rangeBreak', index, expiry, `🔻 ${index} broke below support ${fmtK(prev.sup)}`, `Spot ${f2(cur.spot)} broke support ${fmtK(prev.sup)}. Next support: ${beyond(prev.sup, 'pe', false)}.`, 'bear', 'dn' + prev.sup, 20);

    // 9) zero-OI side flip
    const z = zeroTester(key, view);
    if (z.hasData && !frozen) {
      const up = view.filter(r => r.strike > cur.spot && (z(r, 0) || z(r, 1))).length, dn = view.filter(r => r.strike < cur.spot && (z(r, 0) || z(r, 1))).length;
      const side = up > dn ? 'above' : dn > up ? 'below' : s.zside;
      if (s.zside && side !== s.zside)
        fire('zeroFlip', index, expiry, `${index} · Zero-OI now more ${side} spot`, `Zero OI change: ${up} above vs ${dn} below spot (was more ${s.zside}).`, side === 'above' ? 'bull' : 'bear', side, 20);
      s.zside = side;
    }

    // 10) reversal (critical)
    if (!frozen) { earlyReversal(index, expiry); checkReversal(index, expiry, d, s); }

    // 11) expiry-day time reminders
    if (isExpiryDay(index)) {
      const hs = st.settings.heroStart;
      if (mins >= hs - 15 && mins < hs - 5) fire('timeRemind', index, expiry, `${index} · Hero-zero window opens at ${hhmm(hs)}`, 'Expiry day: check the Hero-zero box and Zero-OI card.', '', 'hz', 600);
      if (mins >= 15 * 60 + 5 && mins < 15 * 60 + 14) fire('timeRemind', index, expiry, `${index} · Closing auction at 3:15`, 'At 3:15 stocks stop trading and the index freezes. Settlement comes from the auction close (published ~3:35); a big final candle can come. Options trade till 3:40. Flattrade F&O intraday square-off: 3:25.', '', 'cas', 600);
    }

    // 12) hero strike premium jumps + outcome tracking
    trackHero(index, expiry, cur);
    try { heroSafeTick(index, expiry); } catch (e) { console.error(e); }
    try { hzTick(index, expiry); } catch (e) { console.error(e); }
    try { planTrack(index); } catch (e) { console.error(e); }
  }

  // ---- EARLY reversal warning: fires while price is still near the day's extreme, BEFORE the turn,
  //      when the option chain and futures (big-money footprints) point the other way.
  function earlyReversal(index, expiry, spotOverride) {
    const d = dataNear(index); if (!d || d.series.length < 20) return;
    const ser = d.series, cur = d.cur, step = C.INDICES[index].step, now = Date.now();
    const spot = isFinite(spotOverride) ? spotOverride : cur.spot;
    const at = m => { const t = now - m * 60000; let x = ser[0]; for (const y of ser) if (y.ts <= t) x = y; return x; };
    const last = ser[ser.length - 1], m5 = at(5), m10 = at(10), m20 = at(20);
    let hi = -Infinity, hiTs = 0, lo = Infinity, loTs = 0;
    for (const x of ser) { if (x.spot > hi) { hi = x.spot; hiTs = x.ts; } if (x.spot < lo) { lo = x.spot; loTs = x.ts; } }
    hi = Math.max(hi, spot); lo = Math.min(lo, spot);
    const need = (st.settings.revPct || 0.3) * 1.3;                       // the move into the extreme must be meaningful
    // futures footprints (NIFTY futures; used for both indices)
    const fs = st.fut.series, fl = futLast();
    const fAt = m => { const t = now - m * 60000; let x = null; for (const y of fs) if (y.ts <= t) x = y; return x; };
    const f3 = fAt(3), f10 = fAt(10);
    const fut = { burstUp: false, burstDn: false, basisUp: false, basisDn: false, txt: '' };
    if (fl && f3 && isFinite(fl.oi) && isFinite(f3.oi) && f3.oi > 0) {
      const dOi = (fl.oi - f3.oi) / f3.oi * 100, dP = fl.ltp - f3.ltp;
      if (Math.abs(dOi) >= 0.4) {
        if (dP > 0) { fut.burstUp = true; fut.txt = dOi > 0 ? `Big futures buying: OI +${dOi.toFixed(1)}% in 3 min with price up (fresh longs)` : `Big futures short covering: OI ${dOi.toFixed(1)}% in 3 min with price up`; }
        if (dP < 0) { fut.burstDn = true; fut.txt = dOi > 0 ? `Big futures selling: OI +${dOi.toFixed(1)}% in 3 min with price down (fresh shorts)` : `Big futures long exit: OI ${dOi.toFixed(1)}% in 3 min with price down`; }
      }
    }
    if (fl && f10 && isFinite(fl.spot) && isFinite(f10.spot)) {
      const b1 = fl.ltp - fl.spot, b0 = f10.ltp - f10.spot, db = (b1 - b0) / fl.spot * 100;
      if (db >= 0.03) fut.basisUp = true; if (db <= -0.03) fut.basisDn = true;
      fut.db = b1 - b0;
    }
    // big single-strike writing in the last 5 min (institution-size)
    const h = d.h, b5 = C.baseline(h, st.first[d.key], '5');
    const bigWrite = side => {
      if (!b5 || b5 === cur || cur.ts - b5.ts < 4 * 60000) return null;
      const bm = new Map(b5.rows.map(r => [r.strike, r])), top = Math.max(1, ...cur.rows.map(r => r[side].oi));
      let best = null;
      for (const r of C.windowRows(cur.rows, spot, 4)) {
        if (side === 'pe' ? r.strike > spot + step : r.strike < spot - step) continue;
        const o = bm.get(r.strike); if (!o) continue;
        const add = r[side].oi - o[side].oi;
        if (add >= top * 0.08 && add >= o[side].oi * 0.12 && (!best || add > best.add)) best = { strike: r.strike, add };
      }
      return best;
    };
    const dce = last.nce - m10.nce, dpe = last.npe - m10.npe, dpcr = last.pcr - m10.pcr;
    const S = C.srSide(cur, b5 && b5 !== cur ? b5 : null, 'pe'), R = C.srSide(cur, b5 && b5 !== cur ? b5 : null, 'ce');

    const check = (dir) => {
      const up = dir === 'up';
      const ext = up ? lo : hi, extTs = up ? loTs : hiTs;
      const before = ser.filter(x => x.ts <= (extTs || now)), far = up ? Math.max(...before.map(x => x.spot), m20.spot) : Math.min(...before.map(x => x.spot), m20.spot);
      const move = Math.abs(far - ext) / ext * 100;
      const near = Math.abs(spot - ext) / ext * 100;
      if (move < need || near > 0.12 || now - (extTs || now) > 25 * 60000) return;   // not at a fresh extreme after a real move
      const sig = [];
      // 1. writers defending in the direction of the turn
      if (up ? dpe > 0 && dpe > Math.abs(dce) * 0.5 : dce > 0 && dce > Math.abs(dpe) * 0.5)
        sig.push({ k: 'chain', t: up ? `Put writers adding ${sQ(dpe)} near ATM in 10 min even as price falls (they expect a bounce)` : `Call writers adding ${sQ(dce)} near ATM in 10 min even as price rises (they expect a fall)` });
      // 2. opposite writers covering into the move
      if (up ? dce < 0 : dpe < 0)
        sig.push({ k: 'chain', t: up ? `Call writers exiting ${sQ(dce)} in 10 min: shorts booking profit at the low` : `Put writers exiting ${sQ(dpe)} in 10 min: longs booking profit at the high` });
      // 3. PCR divergence
      if (up ? dpcr >= 0.05 : dpcr <= -0.05) sig.push({ k: 'pcr', t: `PCR ${up ? 'rising' : 'falling'} ${m10.pcr.toFixed(2)} → ${last.pcr.toFixed(2)} against the price move` });
      // 4. at a strong OI wall that is still being defended
      if (up && S && Math.abs(spot - S.level) <= step * 0.8 && S.state === 'Holding') sig.push({ k: 'wall', t: `Spot at support ${fmtK(S.level)}, put writers still adding there` });
      if (!up && R && Math.abs(spot - R.level) <= step * 0.8 && R.state === 'Holding') sig.push({ k: 'wall', t: `Spot at resistance ${fmtK(R.level)}, call writers still adding there` });
      // 5. momentum fading
      const v5 = (up ? m5.spot - spot : spot - m5.spot) / 5, v15 = (up ? m20.spot - m5.spot : m5.spot - m20.spot) / 15;
      if (v15 > 0 && v5 < v15 * 0.35) sig.push({ k: 'mom', t: `${up ? 'Fall' : 'Rise'} is slowing: ${Math.max(0, v5).toFixed(1)} pts/min now vs ${v15.toFixed(1)} earlier` });
      // 6. big money in futures
      if (up ? fut.burstUp : fut.burstDn) sig.push({ k: 'big', t: fut.txt });
      if (up ? fut.basisUp : fut.basisDn) sig.push({ k: 'big', t: `Futures premium ${up ? 'widening' : 'shrinking'} ${sgn(fut.db, f1)} pts vs spot: ${up ? 'aggressive buying' : 'aggressive selling'} in futures` });
      // 8. India VIX divergence (fear not confirming the price extreme)
      const vs = st.vix.series.filter(x => x.ts >= now - 30 * 60000);
      if (vs.length >= 5) { const vNow = vs[vs.length - 1].v, vHi = Math.max(...vs.map(x => x.v)), vLo = Math.min(...vs.map(x => x.v));
        if (up && (vHi - vNow) / vHi * 100 >= 3) sig.push({ k: 'vix', t: `India VIX not making a new high (${f2(vHi)} → ${f2(vNow)}) while price is at the low: panic fading` });
        if (!up && (vNow - vLo) / vLo * 100 >= 3) sig.push({ k: 'vix', t: `India VIX rising +${((vNow / vLo - 1) * 100).toFixed(1)}% while price is at the high: smart money buying protection` }); }
      // 7. big single-strike writing
      const bw = bigWrite(up ? 'pe' : 'ce');
      if (bw) sig.push({ k: 'big', t: `Big ${up ? 'put' : 'call'} writing at ${fmtK(bw.strike)}: ${sQ(bw.add)} OI in 5 min (institution-size)` });
      const strong = sig.some(x => x.k === 'big' || x.k === 'chain' || x.k === 'vix');
      if (sig.length < 3 || !strong) return;
      const confirm = up ? Math.max(m5.spot, spot + step / 2) : Math.min(m5.spot, spot - step / 2);
      const score = Math.min(10, sig.length * 1.5 + sig.filter(x => x.k === 'big').length);
      fire('reversalWarn', index, expiry, `⚠ ${index} may turn ${up ? 'UP' : 'DOWN'} · reversal warning`,
        `Spot ${f2(spot)} is near today's ${up ? 'low' : 'high'} ${fmtK(ext)} after a ${move.toFixed(2)}% ${up ? 'fall' : 'rise'}, but ${sig.length} signs point to a turn ${up ? 'up' : 'down'}: ` +
        sig.map((x, i) => `${i + 1}) ${x.t}`).join('; ') + `. Strength ${score.toFixed(0)}/10. Confirmation: spot ${up ? 'above' : 'below'} ${fmtK(confirm)}. Early signal, can fail: keep a stop beyond ${fmtK(ext)}.`,
        up ? 'bull' : 'bear', dir, 20);
    };
    check('up'); check('down');
  }

  function checkReversal(index, expiry, d, s) {
    const ser = d.series; if (ser.length < 20) return;
    const pct = st.settings.revPct || 0.3, now = Date.now(), cur = d.cur.spot;
    let hi = -Infinity, hiTs = 0, lo = Infinity, loTs = 0;
    for (const x of ser) { if (x.spot > hi) { hi = x.spot; hiTs = x.ts; } if (x.spot < lo) { lo = x.spot; loTs = x.ts; } }
    const r15 = fut15();
    const last15 = ser.filter(x => x.ts >= now - 15 * 60000), f = last15[0], l = ser[ser.length - 1];
    const writersUp = f && l ? (l.npe - f.npe) > 0 && (l.nce - f.nce) < 0 : false;   // puts added, calls cut
    const writersDn = f && l ? (l.nce - f.nce) > 0 && (l.npe - f.npe) < 0 : false;
    // up-reversal: a meaningful fall into a fresh low (within 90 min), then a bounce of pct%
    const before = ser.filter(x => x.ts <= loTs), peakBefore = before.length ? Math.max(...before.map(x => x.spot)) : lo;
    if (now - loTs <= 90 * 60000 && (peakBefore - lo) / lo * 100 >= pct * 1.3 && (cur - lo) / lo * 100 >= pct && (r15.bias === 'Bullish' || writersUp))
      fire('reversal', index, expiry, `🔄 REVERSAL CONFIRMED UP · ${index}`,
        (`${index} bounced ${fmtK(cur - lo)} pts (+${((cur - lo) / lo * 100).toFixed(2)}%) from today's low ${fmtK(lo)} (${C.istTime(loTs)}). ` +
        (r15.bias === 'Bullish' ? `Futures: ${r15.label}. ` : '') + (writersUp ? 'Put writers adding, call writers exiting.' : '')).trim(), 'bull', 'up' + Math.round(lo), 24 * 60);
    const after = ser.filter(x => x.ts <= hiTs), troughBefore = after.length ? Math.min(...after.map(x => x.spot)) : hi;
    if (now - hiTs <= 90 * 60000 && (hi - troughBefore) / hi * 100 >= pct * 1.3 && (hi - cur) / hi * 100 >= pct && (r15.bias === 'Bearish' || writersDn))
      fire('reversal', index, expiry, `🔄 REVERSAL CONFIRMED DOWN · ${index}`,
        (`${index} fell ${fmtK(hi - cur)} pts (−${((hi - cur) / hi * 100).toFixed(2)}%) from today's high ${fmtK(hi)} (${C.istTime(hiTs)}). ` +
        (r15.bias === 'Bearish' ? `Futures: ${r15.label}. ` : '') + (writersDn ? 'Call writers adding, put writers exiting.' : '')).trim(), 'bear', 'dn' + Math.round(hi), 24 * 60);
  }

  // alert follow-up: what the index did 15 / 30 min after each alert
  function alertOutcomes() {
    const now = Date.now();
    for (const a of st.alerts) {
      if (!isFinite(a.spot0)) continue;
      const d = dataNear(a.index); if (!d) continue;
      if (a.s15 === undefined && now - a.ts >= 15 * 60000) a.s15 = d.cur.spot - a.spot0;
      if (a.s30 === undefined && now - a.ts >= 30 * 60000) a.s30 = d.cur.spot - a.spot0;
      if (a.type === 'reversalWarn' && !a.result) {
        const mv = (d.cur.spot - a.spot0) / a.spot0 * 100 * (a.tone === 'bull' ? 1 : -1);
        a.best = Math.max(a.best || 0, mv);
        if (a.best >= 0.25) { a.result = 'worked'; a.resTs = now; }
        else if (now - a.ts >= 45 * 60000 || mv <= -0.25) a.result = 'failed';
      }
    }
  }

  // =====================================================================================
  // RECORDS — hero-zero outcome log, morning call scorecard, end-of-day record, trade journal
  // =====================================================================================
  const REC = {
    hero: () => store.get('oi.rec.hero', []), setHero: v => store.set('oi.rec.hero', v.slice(-400)),
    calls: () => store.get('oi.rec.calls', {}), setCalls: v => { const ks = Object.keys(v).sort(); while (ks.length > 120) delete v[ks.shift()]; store.set('oi.rec.calls', v); },
    eod: () => store.get('oi.eod', {}), setEod: v => { const ks = Object.keys(v).sort(); while (ks.length > 40) delete v[ks.shift()]; store.set('oi.eod', v); },
    trades: () => store.get('oi.rec.trades', []), setTrades: v => store.set('oi.rec.trades', v.slice(-1000)),
    plans: () => store.get('oi.rec.plans', []), setPlans: v => store.set('oi.rec.plans', v.slice(-3000)),
  };
  const LOT = { NIFTY: 65, SENSEX: 20 };
  function dataNear(index) {
    const exps = st.expiries[index] || []; if (!exps.length) return null;
    const key = index + '|' + exps[0], h = st.snaps[key] || []; if (!h.length) return null;
    return { index, iso: exps[0], key, h, cur: h[h.length - 1], series: st.series[key] || [] };
  }
  const rowLtp = (snap, strike, side) => { const r = snap && snap.rows.find(x => x.strike === strike); return r ? r[side.toLowerCase()].ltp : NaN; };

  // ---------- trade-plan accuracy: did each suggested buy hit its target or its stop-loss first? ----------
  function planTrackAdd(a) {
    const p = a.plan; if (!p || !(p.ltp > 0) || !isFinite(p.strike)) return;
    const L = REC.plans(), now = a.ts;
    const dup = L.find(x => x.res === 'open' && x.index === p.index && x.strike === p.strike && x.side === p.side && now - x.ts < 10 * 60000);
    if (dup) { if (!dup.also.includes(a.type)) dup.also.push(a.type); REC.setPlans(L); return; }
    L.push({ id: now + ':' + p.index + p.strike + p.side, ts: now, day: C.istDate(now), index: p.index, iso: p.iso, type: a.type, kind: a.kind, also: [], dir: p.dir,
      strike: p.strike, side: p.side, verdict: p.verdict, entry: +p.ltp.toFixed(2), target: isFinite(p.target) ? +p.target.toFixed(2) : null, stop: +p.stop.toFixed(2),
      tgtLevel: isFinite(p.tgtLevel) ? p.tgtLevel : null, stopLevel: isFinite(p.stopLevel) ? p.stopLevel : null, spot0: a.spot0,
      chance: p.rally && isFinite(p.rally.chance) ? +p.rally.chance.toFixed(3) : p.hero && isFinite(p.reach) ? +p.reach.toFixed(3) : null, rallies: p.rally ? p.rally.count : null,
      safe: p.safe ? p.safe.ok : null, hero: !!p.hero, be: p.be ? +p.be.toFixed(2) : null, lots: p.lots || null,
      res: 'open', resTs: 0, last: p.ltp, hi: p.ltp, lo: p.ltp, hiTs: now, upd: now });
    REC.setPlans(L);
  }
  /** update open plans with the latest premium; close at target, stop, or 3:25 PM (broker square-off) */
  function planTrack(index) {
    const L = REC.plans(); if (!L.length) return;
    const now = Date.now(), today = C.istDate(now), tp = C.istParts(now), mins = tp.h * 60 + tp.mi;
    const d = dataNear(index), lv = d && st.live[d.key], cur = d ? (lv && lv.ts > d.cur.ts ? lv : d.cur) : null;
    let ch = false;
    for (const x of L) {
      if (x.res !== 'open' || x.index !== index) continue;
      if (x.day !== today) { x.res = x.last !== x.entry || x.upd - x.ts > 60000 ? 'neither' : 'nodata'; x.resTs = x.upd; ch = true; continue; }
      if (!cur || !d || d.iso !== x.iso) continue;
      const v = rowLtp(cur, x.strike, x.side); if (!(v > 0)) continue;
      x.last = v; x.upd = cur.ts || now;
      if (v > x.hi) { x.hi = v; x.hiTs = x.upd; } if (v < x.lo) x.lo = v;
      const beOn = x.be && x.hi >= x.be, stopNow = beOn ? Math.max(x.stop, x.entry) : x.stop;
      const lastExit = x.hero ? 15 * 60 + 20 : 15 * 60 + 25;
      if (x.target && v >= x.target) { x.res = 'target'; x.resTs = x.upd; x.out = v; }
      else if (v <= stopNow) { x.res = beOn ? 'be' : 'stop'; x.resTs = x.upd; x.out = beOn ? Math.max(v, x.entry) : v; }
      else if (x.hero && now - x.ts >= 25 * 60000 && x.hi < x.entry * 1.3) { x.res = 'neither'; x.resTs = x.upd; x.out = v; x.why = 'time stop'; }
      else if (mins >= lastExit) { x.res = 'neither'; x.resTs = x.upd; x.out = v; }
      ch = true;
    }
    if (ch) REC.setPlans(L);
  }
  const planPct = x => { const out = x.res === 'open' ? x.last : (x.out || x.last); return x.entry > 0 ? (out / x.entry - 1) * 100 : NaN; };
  function planStats(list) {
    const done = list.filter(x => x.res === 'target' || x.res === 'stop' || x.res === 'neither' || x.res === 'be');
    const n = done.length, t = done.filter(x => x.res === 'target').length, sl = done.filter(x => x.res === 'stop').length;
    const avg = n ? done.reduce((a, x) => a + planPct(x), 0) / n : NaN;
    const rs = done.reduce((a, x) => a + (x.entry > 0 ? ((x.out || x.last) - x.entry) * (LOT[x.index] || 1) : 0), 0);
    return { n, t, sl, nei: n - t - sl, open: list.filter(x => x.res === 'open').length, tPct: n ? t / n * 100 : NaN, sPct: n ? sl / n * 100 : NaN, avg, rs };
  }
  function plansCsv() {
    const rows = [['Date', 'Time (IST)', 'Index', 'Expiry', 'Alert type', 'Also flagged by', 'Direction', 'Strike', 'Side', 'Premium verdict', 'Entry (Rs)', 'Target (Rs)', 'Stop-loss (Rs)',
      'Index target level', 'Index stop level', 'Spot at alert', 'Predicted chance %', 'Rallies from bottom before alert', 'Result', 'Result time (IST)', 'Minutes taken',
      'Exit price (Rs)', 'Highest (Rs)', 'Highest time (IST)', 'Lowest (Rs)', 'Result %', 'P&L for 1 lot (Rs)', 'Safe mode', 'Hero-zero']];
    for (const x of REC.plans()) {
      const out = x.res === 'open' ? x.last : (x.out || x.last), pct = planPct(x);
      rows.push([x.day, tOf(x.ts), x.index, x.iso, x.kind, x.also.map(t => (ALERT[t] || {}).name || t).join(' + '), x.dir === 'up' ? 'UP' : 'DOWN', x.strike, x.side, x.verdict,
        x.entry, x.target === null ? '' : x.target, x.stop, x.tgtLevel === null ? '' : x.tgtLevel, x.stopLevel === null ? '' : x.stopLevel, x.spot0,
        x.chance === null ? '' : +(x.chance * 100).toFixed(0), x.rallies === null ? '' : x.rallies,
        { target: 'TARGET HIT', stop: 'STOP HIT', be: 'BREAKEVEN STOP (no loss)', neither: x.why === 'time stop' ? 'TIME STOP (25 min)' : 'NEITHER (closed 3:25)', open: 'OPEN', nodata: 'NO DATA (app closed)' }[x.res],
        tOf(x.resTs), x.resTs ? minsBetween(x.ts, x.resTs) : '', +(+out).toFixed(2), x.hi, tOf(x.hiTs), x.lo, isFinite(pct) ? +pct.toFixed(1) : '', +((out - x.entry) * (LOT[x.index] || 1)).toFixed(0), x.safe === true ? 'PASSED' : x.safe === false ? 'NO TRADE' : 'off', x.hero ? 'YES' : '']);
    }
    return rows;
  }

  // ---------- hero-zero outcome log ----------
  function heroAdd(log, e) {
    if (log.some(x => x.day === e.day && x.index === e.index && x.strike === e.strike && x.side === e.side)) return false;
    log.push(e); return true;
  }
  function trackHero(index, expiry, cur) {
    const now = Date.now(), day = C.istDate(now), p = C.istParts(now), mins = p.h * 60 + p.mi;
    const log = REC.hero(); let changed = false;
    // 1) new predictions: hero-zero signal picks + the hero plan's "strike to watch" (expiry day, from the hero window)
    if (isExpiryDay(index) && mins >= st.settings.heroStart && mins <= 15 * 60 + 25) {
      const hz = heroFor(index);
      const todays = log.filter(x => x.day === day && x.index === index).length;
      if (hz && (hz.state === 'CE' || hz.state === 'PE') && todays < 10) for (const pk of hz.picks.slice(0, 2)) {
        if (!(pk.ltp > 0)) continue;
        changed = heroAdd(log, { id: now + '' + pk.strike, day, index, expiry, strike: pk.strike, side: pk.side, src: 'Hero signal', entry: pk.ltp, entryTs: now, spot0: cur.spot, vol: (volFor(index) || {}).vol, reach: reachProb(index, cur.spot, pk.strike), volTrend: volSince13(index),
          targets: [{ lbl: '2x', price: pk.ltp * 2 }, { lbl: '3x', price: pk.ltp * 3 }, { lbl: '5x', price: pk.ltp * 5 }], peak: pk.ltp, peakTs: now }) || changed;
      }
      const key = index + '|' + expiry, view = C.windowRows(C.compare(cur, null), cur.spot, st.settings.strikes), z = zeroTester(key, view);
      if (z.hasData) {
        const pl = C.heroPlan(view, cur.spot, z, st.settings);
        if (pl.side && pl.buy && pl.buy.ltp >= st.settings.heroMin && pl.buy.ltp <= st.settings.heroMax) {
          const tg = pl.targets.filter(t => isFinite(t.est) && t.est > pl.buy.ltp).map(t => ({ lbl: 'at ' + fmtK(t.level), level: t.level, price: +t.est.toFixed(2) }));
          tg.push({ lbl: '2x', price: pl.buy.ltp * 2 });
          changed = heroAdd(log, { id: now + 'p' + pl.buy.strike, day, index, expiry, strike: pl.buy.strike, side: pl.side, src: 'Hero plan', entry: pl.buy.ltp, entryTs: now, spot0: cur.spot, vol: (volFor(index) || {}).vol, reach: reachProb(index, cur.spot, pl.buy.strike), volTrend: volSince13(index),
            targets: tg, peak: pl.buy.ltp, peakTs: now }) || changed;
        }
      }
    }
    // 2) follow every open prediction: peak, target hits (with time stamps), close
    for (const e of log) {
      if (e.done || e.index !== index || e.expiry !== expiry) continue;
      const ltp = rowLtp(cur, e.strike, e.side); if (!(ltp >= 0)) continue;
      e.last = ltp; e.lastTs = now;
      if (ltp > e.peak) { e.peak = ltp; e.peakTs = now; }
      for (const t of e.targets) if (!t.hitTs && ltp >= t.price) {
        t.hitTs = now; t.hitLtp = ltp; t.spot = cur.spot; changed = true;
        fire('premJump', index, expiry, `🎯 ${index} ${fmtK(e.strike)} ${e.side} hit ${t.lbl.startsWith('at') ? 'its predicted price' : t.lbl}`,
          `${e.src} at ${C.istTime(e.entryTs)}: ₹${f2(e.entry)}. Now ₹${f2(ltp)} (${(ltp / e.entry).toFixed(1)}x) at ${C.istTime(now)}. Predicted ₹${f2(t.price)}${t.level ? ' if spot reached ' + fmtK(t.level) : ''}.`,
          e.side === 'CE' ? 'bull' : 'bear', e.id + t.lbl, 0);
      }
      if (mins >= 15 * 60 + 40 || day > e.expiry) { e.close = ltp; e.done = true; changed = true;
        const cs = st.cas[index]; if (cs && cs.official && e.expiry === day) e.settle = Math.max(0, e.side === 'CE' ? cs.official - e.strike : e.strike - cs.official); }
      changed = true;
    }
    if (changed) REC.setHero(log);
  }

  // ---------- overseas markets (Yahoo Finance chart API) ----------
  const GLOBAL = [
    ['us', '^GSPC', 'S&P 500 (US)'], ['usFut', 'ES=F', 'US futures'], ['nikkei', '^N225', 'Nikkei (Japan)'], ['hsi', '^HSI', 'Hang Seng (HK)'],
    ['crude', 'BZ=F', 'Brent crude'], ['dxy', 'DX-Y.NYB', 'Dollar index'], ['inr', 'INR=X', 'USD / INR'], ['usVix', '^VIX', 'US VIX (fear)'], ['indiaVix', '^INDIAVIX', 'India VIX (last)'],
    ['NIFTY', '^NSEI', 'NIFTY 50'], ['SENSEX', '^BSESN', 'SENSEX'],
  ];
  st.glob = store.get('oi.glob', null);
  async function fetchGlobal(force) {
    if (!force && st.glob && Date.now() - st.glob.at < 10 * 60000) return st.glob;
    const out = { at: Date.now(), q: {} };
    await Promise.all(GLOBAL.map(async ([k, sym]) => {
      const r = await http('GET', `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?range=1d&interval=5m`, { 'User-Agent': UA, 'Accept': 'application/json' });
      const j = parseJson(r.text), m = j && j.chart && j.chart.result && j.chart.result[0] && j.chart.result[0].meta;
      if (m && m.regularMarketPrice > 0) {
        const prev = m.chartPreviousClose || m.previousClose;
        out.q[k] = { price: m.regularMarketPrice, prev, pct: prev ? (m.regularMarketPrice / prev - 1) * 100 : NaN, t: (m.regularMarketTime || 0) * 1000 };
      }
    }));
    if (!Object.keys(out.q).length) { st.globErr = 'Overseas market data not reachable right now.'; return st.glob; }
    st.glob = out; st.globErr = null; store.set('oi.glob', out);
    return out;
  }
  /** an Indian quote's last full session: before today's open Yahoo shows yesterday as "now" */
  function prevSession(q) {
    const today = C.istDate(Date.now()), [y, m, d] = today.split('-').map(Number), open915 = Date.UTC(y, m - 1, d, 3, 45);
    return q.t && q.t < open915 ? { price: q.price, pct: q.pct } : { price: q.prev, pct: NaN };
  }
  /** previous close of an Indian index for today's call */
  function prevCloseFor(index) {
    const eod = REC.eod(), today = C.istDate(Date.now());
    const days = Object.keys(eod).filter(d => d < today).sort();
    const last = days.length ? eod[days[days.length - 1]][index] : null;
    if (last && isFinite(last.close)) return last.close;
    const q = st.glob && st.glob.q[index]; if (!q) return NaN;
    const [y, m, d] = today.split('-').map(Number), open915 = Date.UTC(y, m - 1, d, 3, 45);
    return q.t && q.t < open915 ? q.price : q.prev;     // before today's open, the "price" is yesterday's close
  }
  function prevEod(index) {
    const eod = REC.eod(), today = C.istDate(Date.now());
    const days = Object.keys(eod).filter(d => d < today).sort();
    if (!days.length) return null;
    const e = eod[days[days.length - 1]];
    return Object.assign({}, e[index] || {}, { futBias: e.fut && e.fut.bias, futLabel: e.fut && e.fut.label });
  }
  function morningFor(index) {
    const g = st.glob ? st.glob.q : {}, gift = giftGet(), fl = futLast();
    const asiaV = [g.nikkei, g.hsi].filter(x => x && isFinite(x.pct));
    return C.morningCall({
      giftPct: gift && fl ? (gift.v - fl.ltp) / fl.ltp * 100 : NaN,
      us: g.us, usFut: g.usFut, asia: asiaV.length ? { pct: asiaV.reduce((a, x) => a + x.pct, 0) / asiaV.length } : null,
      crude: g.crude, dxy: g.dxy, inr: g.inr, news: NEWS.mood(), prev: prevEod(index),
      vix: g.indiaVix ? { pct: prevSession(g.indiaVix).pct, mktPct: g.NIFTY ? prevSession(g.NIFTY).pct : NaN, level: (vixNow() || {}).v || prevSession(g.indiaVix).price } : null,
    });
  }
  /** best strike to buy for a direction (bull → CE, bear → PE) */
  function strikeIdeas(index, tone) {
    const d = dataNear(index); if (!d || !tone) return null;
    const { cur, iso, key } = d, side = tone === 'up' ? 'ce' : 'pe', step = C.INDICES[index].step;
    const R = C.srSide(cur, null, 'ce'), S = C.srSide(cur, null, 'pe');
    const target = nearLevel(index, cur, side);
    const rows = C.windowRows(cur.rows, cur.spot, 12);
    const a = C.analyzeStrikes(rows, side, cur.spot, iso, Date.now(), st.hilo[key] || {}, target, { step });
    return Object.assign(a, { side: side.toUpperCase(), target, iso, spot: cur.spot, reach: reachProb(index, cur.spot, target) });
  }
  /**
   * A realistic target for a buy: the strongest OI wall within 1.5× today's expected move (VIX/IV based).
   * Far-away max-OI strikes (e.g. a 67,000 put wall with SENSEX at 72,000) are ignored.
   */
  function nearLevel(index, cur, side) {
    const step = C.INDICES[index].step, vf = volFor(index);
    const em = vf ? C.expMove(cur.spot, vf.vol, 375) : cur.spot * 0.008;
    const maxD = Math.max(2 * step, 1.5 * em), up = side === 'ce';
    const cand = cur.rows.filter(r => up ? r.strike > cur.spot + step / 2 && r.strike <= cur.spot + maxD : r.strike < cur.spot - step / 2 && r.strike >= cur.spot - maxD);
    if (!cand.length) return Math.round((cur.spot + (up ? em : -em)) / step) * step;
    return cand.reduce((a, b) => b[side].oi > a[side].oi ? b : a).strike;
  }
  function lockCall(late) {
    const today = C.istDate(Date.now()), calls = REC.calls();
    const day = calls[today] = calls[today] || {};
    const p = C.istParts(Date.now()), mins = p.h * 60 + p.mi;
    for (const index of Object.keys(C.INDICES)) {
      if (day[index]) continue;
      const m = morningFor(index); if (!m.factors.length) continue;
      const ideas = strikeIdeas(index, m.tone), top = ideas && ideas.list[0];
      const pc = prevCloseFor(index), vf = volFor(index), vlv = vf ? vf.vol : (st.glob && st.glob.q.indiaVix ? prevSession(st.glob.q.indiaVix).price : NaN);
      const half = pc > 0 && vlv > 0 ? pc * vlv / 100 / Math.sqrt(252) : NaN;
      day[index] = { ts: Date.now(), late: !!late || mins > 9 * 60 + 15, label: m.label, r: m.r, conf: m.conf, tone: m.tone, risk: m.risk,
        vix: (vixNow() || {}).v || (st.glob && st.glob.q.indiaVix ? prevSession(st.glob.q.indiaVix).price : NaN), vol: vlv, volSrc: vf ? vf.src : 'India VIX',
        range: isFinite(half) ? [pc - half, pc + half] : null,
        factors: m.factors.map(f => ({ txt: f.txt, val: f.val })), prevClose: prevCloseFor(index),
        rec: top ? { strike: top.strike, side: top.side, ltp: top.ltp, est: top.est, target: ideas.target, iv: top.iv, theta: top.theta, thetaUnit: top.thetaUnit, iso: ideas.iso } : null };
    }
    if (!day.VIX) { const o = vixOutlookNow(), vx = vixNow();
      if (o.factors.length) day.VIX = { ts: Date.now(), label: o.label, r: o.r, tone: o.tone, range: o.range, factors: o.factors.map(f => ({ txt: f.txt, val: f.val })),
        prev: vx && vx.prev > 0 ? vx.prev : (st.glob && st.glob.q.indiaVix ? prevSession(st.glob.q.indiaVix).price : NaN) }; }
    REC.setCalls(calls);
    return day;
  }
  async function morningTick() {
    const now = Date.now(), p = C.istParts(now), mins = p.h * 60 + p.mi, wd = new Date(now + 5.5 * 3600e3).getUTCDay();
    if (wd === 0 || wd === 6) return;
    const today = C.istDate(now), calls = REC.calls();
    if (mins >= 8 * 60 && mins <= 15 * 60 + 30) { try { await fetchGlobal(false); } catch (e) { } }
    // lock automatically from 9:00; if the app was not running then, lock at the first chance (marked late) so every day is recorded
    if (mins >= 9 * 60 && mins <= 15 * 60 + 15 && !(calls[today] && calls[today].NIFTY)) {
      const day = lockCall(false);
      if (day.NIFTY) fire('timeRemind', 'NIFTY', (st.expiries.NIFTY || [''])[0], `Morning call locked${day.NIFTY.late ? ' (late)' : ''}: NIFTY ${day.NIFTY.label}`,
        `${day.NIFTY.conf} confidence. ${day.NIFTY.rec ? 'Strike idea: ' + fmtK(day.NIFTY.rec.strike) + ' ' + day.NIFTY.rec.side + ' @ ₹' + f2(day.NIFTY.rec.ltp) : ''}`, day.NIFTY.tone === 'up' ? 'bull' : day.NIFTY.tone === 'dn' ? 'bear' : '', 'call' + today, 600);
    }
    if (mins >= 15 * 60 + 37) closeDay();
    if (mins >= 15 * 60 + 42) autoSaveDay();
    gradeMissed();
  }
  /** a past call that was never graded (app was off at the close): grade it from the official close on Yahoo */
  function gradeMissed() {
    const calls = REC.calls(), today = C.istDate(Date.now()), g = st.glob && st.glob.q; if (!g) return;
    let ch = false;
    for (const d of Object.keys(calls)) { if (d >= today) continue;
      for (const index of Object.keys(C.INDICES)) { const c = calls[d][index], q = g[index]; if (!c || c.grade || !q) continue;
        let close = NaN;
        if (q.t && C.istDate(q.t) === d) close = q.price;                                     // last session shown is that day
        else if (q.t && C.istDate(q.t) === today) { const ds = Object.keys(calls).filter(x => x < today).sort(); if (ds[ds.length - 1] === d) close = q.prev; }   // yesterday's close
        if (!(close > 0)) continue;
        const base = isFinite(c.prevClose) ? c.prevClose : close;
        c.close = close; c.chgPct = (close - base) / base * 100; c.grade = C.gradeCall(c.label, c.chgPct); c.gradedLate = true;
        if (c.range) c.inRange = close >= c.range[0] && close <= c.range[1] ? 'Inside' : 'Outside';
        ch = true; } }
    if (ch) REC.setCalls(calls);
  }
  /** end of each trading day: save all records to Downloads/EV Pulse/<date>/ without anyone tapping anything */
  function autoSaveDay() {
    const today = C.istDate(Date.now());
    if (st.settings.autoSave === false || store.get('oi.autosave', '') === today) return;
    if (!(Bridge && Bridge.saveFile)) return;
    closeDay(); syncAlertLog();
    let n = 0, err = '';
    for (const k of Object.keys(EXPORTS)) {
      const [title, base, fn] = EXPORTS[k], rows = fn();
      if (rows.length < 2) continue;                                  // nothing recorded yet for this file
      const r = String(Bridge.saveFile(`${today}/EV_Pulse_${base}_${today}.csv`, 'text/csv', csv(rows)));
      if (r.startsWith('ok|')) n++; else err = r.slice(r.indexOf('|') + 1);
    }
    store.set('oi.autosave', today);
    st.lastDl = { title: `${n} files (auto)`, where: `Downloads/EV Pulse/${today}`, rows: 0, ts: Date.now() };
    fire('timeRemind', 'NIFTY', (st.expiries.NIFTY || [''])[0], `Today's records saved (${n} files)`,
      err ? `Saved ${n} files to Downloads/EV Pulse/${today}. Problem: ${err}` : `Morning call result, hero-zero log, scorecard, alerts, closing auction and journal saved to Downloads/EV Pulse/${today}. Open them in Excel or Notepad.`, '', 'save' + today, 600);
  }
  /** end of day: grade the morning call, record closes and the day's OI state for tomorrow's call */
  function closeDay() {
    const today = C.istDate(Date.now()), eod = REC.eod();
    if (eod[today] && eod[today].done) return;
    const rec = {};
    for (const index of Object.keys(C.INDICES)) {
      const d = dataNear(index); if (!d) continue;
      const p = C.istParts(d.cur.ts); if (C.istDate(d.cur.ts) !== today || p.h * 60 + p.mi < 15 * 60 + 36) continue;   // need a reading after the auction close (~3:35)
      const first = st.first[d.key];
      rec[index] = { close: (st.cas[index] && st.cas[index].official) || d.cur.spot, frozen315: st.cas[index] && st.cas[index].spot315, open: first ? first.spot : NaN, pcr: d.cur.pcr, sup: d.cur.sup, res: d.cur.res, mp: d.cur.mp };
    }
    if (!rec.NIFTY && !rec.SENSEX) return;
    const fl = futLast(), fb = futBase('prev'), fd = fl && fb ? C.futBuildup(fl, fb) : null;
    rec.fut = fd ? { label: fd.label, bias: fd.bias } : null; rec.done = true;
    const vxc = vixNow(); if (vxc) rec.vix = vxc.v;
    eod[today] = rec; REC.setEod(eod);
    const calls = REC.calls(), day = calls[today];
    if (day) {
      for (const index of Object.keys(C.INDICES)) {
        const c = day[index], e = rec[index]; if (!c || !e) continue;
        const base = isFinite(c.prevClose) ? c.prevClose : e.open;
        c.close = e.close; c.chgPct = (e.close - base) / base * 100; c.grade = C.gradeCall(c.label, c.chgPct);
        if (c.range) c.inRange = e.close >= c.range[0] && e.close <= c.range[1] ? 'Inside' : 'Outside';
        if (c.rec) {
          const d = dataNear(index), key = index + '|' + c.rec.iso, hl = (st.hilo[key] || {})[c.rec.strike] || {};
          const snap = (st.snaps[key] || []).slice(-1)[0];
          c.rec.close = rowLtp(snap, c.rec.strike, c.rec.side);
          c.rec.hi = c.rec.side === 'CE' ? hl.ceHi : hl.peHi;
        }
      }
      if (day.VIX && vxc && day.VIX.prev > 0) { const ch = (vxc.v / day.VIX.prev - 1) * 100; day.VIX.close = vxc.v; day.VIX.chgPct = ch;
        day.VIX.grade = /UP/.test(day.VIX.label) ? (ch > 0 ? 'Right' : 'Wrong') : /DOWN/.test(day.VIX.label) ? (ch < 0 ? 'Right' : 'Wrong') : (Math.abs(ch) <= 3 ? 'Right' : 'Wrong'); }
      REC.setCalls(calls);
    }
  }

  // ---------- trade journal ----------
  function tradePnl(t) { return isFinite(t.sell) ? (t.sell - t.buy) * t.lots * t.lotSize : NaN; }
  function journalStats(list) {
    const closed = list.filter(t => isFinite(tradePnl(t)));
    const wins = closed.filter(t => tradePnl(t) > 0), losses = closed.filter(t => tradePnl(t) <= 0);
    const sum = a => a.reduce((s, t) => s + tradePnl(t), 0);
    return { n: closed.length, open: list.length - closed.length, pnl: sum(closed), win: closed.length ? wins.length / closed.length * 100 : NaN,
      avgW: wins.length ? sum(wins) / wins.length : NaN, avgL: losses.length ? sum(losses) / losses.length : NaN };
  }

  // ---------- Downloads for audit: CSV files (open in Excel or Notepad), saved to Downloads/EV Pulse ----------
  const n2 = v => (typeof v === 'number' && isFinite(v)) ? +v.toFixed(2) : (v === undefined || v === null || (typeof v === 'number') ? '' : v);
  function csv(rows) { return rows.map(r => r.map(v => { v = n2(v); const s = String(v); return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(',')).join('\r\n') + '\r\n'; }
  const dOf = ts => ts ? C.istDate(ts) : '', tOf = ts => ts ? C.istTime(ts, true) : '';
  const minsBetween = (a, b) => a && b ? Math.round((b - a) / 60000) : '';
  function stamp() { const p = C.istParts(Date.now()); return `${p.y}-${String(p.mo).padStart(2, '0')}-${String(p.d).padStart(2, '0')}_${String(p.h).padStart(2, '0')}${String(p.mi).padStart(2, '0')}`; }
  function heroCsv() {
    const rows = [['Prediction date', 'Prediction time (IST)', 'Index', 'Expiry', 'Strike', 'Side', 'Source', 'Price at prediction (Rs)', 'Spot at prediction', 'Target', 'Predicted price (Rs)',
      'Reached?', 'Reached date', 'Reached time (IST)', 'Price when reached (Rs)', 'Spot when reached', 'Minutes taken', 'Peak price (Rs)', 'Peak time (IST)', 'Peak multiple (x)', 'Closing price (Rs)', 'Volatility at prediction (VIX/IV)', 'Reach chance at prediction %', 'Vol change since 1 PM %', 'Expiry settlement value (Rs)']];
    for (const e of REC.hero()) for (const t of e.targets) rows.push([e.day, tOf(e.entryTs), e.index, e.expiry, e.strike, e.side, e.src, e.entry, e.spot0, t.lbl, t.price,
      t.hitTs ? 'YES' : (e.done ? 'NO' : 'OPEN'), dOf(t.hitTs), tOf(t.hitTs), t.hitLtp, t.spot, minsBetween(e.entryTs, t.hitTs), e.peak, tOf(e.peakTs), e.entry ? e.peak / e.entry : '', e.close, e.vol, isFinite(e.reach) ? e.reach * 100 : '', e.volTrend, e.settle]);
    return rows;
  }
  function callsCsv() {
    const rows = [['Date', 'Index', 'Prediction', 'Confidence', 'Score (-1 to +1)', 'Locked time (IST)', 'Locked late?', 'Previous close', 'Closing value', 'Change %', 'Result',
      'Strike idea', 'Idea expiry', 'Idea price at lock (Rs)', 'Idea target level', 'Idea est. price at target (Rs)', 'Idea day high (Rs)', 'Idea close (Rs)', 'Idea best multiple (x)', 'India VIX at lock', 'Volatility used', 'Vol source', 'Expected range low', 'Expected range high', 'Close inside range?', 'Risk note', 'Reasons used']];
    const calls = REC.calls();
    for (const d of Object.keys(calls).sort()) for (const index of Object.keys(calls[d]).filter(k => k !== 'VIX')) { const c = calls[d][index], r = c.rec || {};
      rows.push([d, index, c.label, c.conf, c.r, tOf(c.ts), c.late ? 'YES' : 'NO', c.prevClose, c.close, c.chgPct, c.grade || 'Pending',
        r.strike ? r.strike + ' ' + r.side : '', r.iso, r.ltp, r.target, r.est, r.hi, r.close, r.hi && r.ltp ? r.hi / r.ltp : '', c.vix, c.vol, c.volSrc, c.range && c.range[0], c.range && c.range[1], c.inRange || '', c.risk || '', (c.factors || []).map(f => f.txt).join(' | ')]); }
    return rows;
  }
  function scoreCsv() {
    const calls = REC.calls(), all = [];
    for (const d of Object.keys(calls).sort()) for (const index of Object.keys(calls[d]).filter(k => k !== 'VIX')) all.push(Object.assign({ d, index }, calls[d][index]));
    const g = all.filter(c => c.grade);
    const line = (name, list) => { const gr = list.filter(c => c.grade), ok = gr.filter(c => c.grade === 'Right').length; return [name, list.length, gr.length, ok, gr.length - ok, gr.length ? ok / gr.length * 100 : '']; };
    const rows = [['EV Pulse prediction scorecard', 'generated ' + C.istDate(Date.now()) + ' ' + C.istTime(Date.now(), true) + ' IST'], [],
      ['Group', 'Calls made', 'Graded', 'Right', 'Wrong', 'Hit rate %'], line('All calls', all)];
    for (const i of Object.keys(C.INDICES)) rows.push(line(i, all.filter(c => c.index === i)));
    for (const k of ['High', 'Medium', 'Low']) rows.push(line('Confidence ' + k, all.filter(c => c.conf === k)));
    for (const k of ['Bullish', 'Bearish', 'Flat / sideways']) rows.push(line('Call ' + k, all.filter(c => c.label === k)));
    rows.push(line('Locked on time', all.filter(c => !c.late)), line('Locked late', all.filter(c => c.late)));
    for (const m of [...new Set(all.map(c => c.d.slice(0, 7)))]) rows.push(line('Month ' + m, all.filter(c => c.d.startsWith(m))));
    for (const b of ['Very calm', 'Normal', 'Nervous', 'Fear']) rows.push(line('VIX ' + b, all.filter(c => C.vixBand(c.vix) === b)));
    const rg = all.filter(c => c.inRange), ins = rg.filter(c => c.inRange === 'Inside').length;
    rows.push([], ['Expected range (from VIX)', 'Days graded', 'Close inside', 'Outside', 'Inside %'], ['All', rg.length, ins, rg.length - ins, rg.length ? ins / rg.length * 100 : '']);
    const vo = Object.keys(calls).map(d => calls[d].VIX).filter(v => v && v.grade), vok = vo.filter(v => v.grade === 'Right').length;
    rows.push([], ['India VIX outlook', 'Graded', 'Right', 'Wrong', 'Hit rate %'], ['All', vo.length, vok, vo.length - vok, vo.length ? vok / vo.length * 100 : '']);
    const h = REC.hero(), hit1 = h.filter(e => e.targets[0] && e.targets[0].hitTs).length, x2 = h.filter(e => e.targets.some(t => t.lbl === '2x' && t.hitTs)).length;
    rows.push([], ['Hero-zero predictions', 'Total', 'Hit 1st target', 'Doubled (2x)', '1st target %', '2x %'], ['All', h.length, hit1, x2, h.length ? hit1 / h.length * 100 : '', h.length ? x2 / h.length * 100 : '']);
    for (const b of ['Very calm', 'Normal', 'Nervous', 'Fear']) { const hb = h.filter(e => C.vixBand(e.vol) === b); if (!hb.length) continue;
      const a1 = hb.filter(e => e.targets[0] && e.targets[0].hitTs).length, a2 = hb.filter(e => e.targets.some(t => t.lbl === '2x' && t.hitTs)).length;
      rows.push(['Vol ' + b, hb.length, a1, a2, a1 / hb.length * 100, a2 / hb.length * 100]); }
    for (const [nm, f] of [['VIX rising after 1 PM', e => e.volTrend >= 3], ['VIX falling after 1 PM', e => e.volTrend <= -5]]) { const hb = h.filter(f); if (!hb.length) continue;
      const a1 = hb.filter(e => e.targets[0] && e.targets[0].hitTs).length, a2 = hb.filter(e => e.targets.some(t => t.lbl === '2x' && t.hitTs)).length;
      rows.push([nm, hb.length, a1, a2, a1 / hb.length * 100, a2 / hb.length * 100]); }
    const ca = casAccuracy();
    if (ca) rows.push([], ['Closing auction estimate', 'Days', 'Avg error at 3:25 (pts)', 'Direction right %'], ['All', ca.n, ca.avgErr, ca.dirPct]);
    const ci = store.get('oi.rec.casideas', []).filter(x => isFinite(x.resultPct));
    if (ci.length) { const win = ci.filter(x => x.resultPct > 0).length; rows.push([], ['Auction strike ideas', 'Ideas', 'Profitable', 'Win %', 'Avg result %'], ['All', ci.length, win, win / ci.length * 100, ci.reduce((a, x) => a + x.resultPct, 0) / ci.length]); }
    const w = auditAlerts().filter(a => a.type === 'reversalWarn' && a.result), wk = w.filter(a => a.result === 'worked').length;
    rows.push([], ['Reversal warnings', 'Graded', 'Worked', 'Failed', 'Success %'], ['All', w.length, wk, w.length - wk, w.length ? wk / w.length * 100 : '']);
    return rows;
  }
  // every alert is also kept in a long-term log (today's list resets each day)
  const auditAlerts = () => store.get('oi.rec.alerts', []);
  function logAlert(a) { const l = auditAlerts(); l.push(a); store.set('oi.rec.alerts', l.slice(-3000)); }
  function syncAlertLog() {          // copy follow-up results (15/30 min, worked/failed) into the long-term log
    const l = auditAlerts(); let ch = false;
    for (const a of st.alerts) { const x = l.find(y => y.ts === a.ts && y.type === a.type && y.index === a.index); if (!x) continue;
      for (const k of ['s15', 's30', 'result', 'best', 'resTs']) if (a[k] !== undefined && x[k] !== a[k]) { x[k] = a[k]; ch = true; } }
    if (ch) store.set('oi.rec.alerts', l);
  }
  function alertsCsv() {
    const rows = [['Date', 'Time (IST)', 'Index', 'Alert', 'Level', 'Direction', 'Title', 'Message', 'Spot at alert', 'Spot move after 15 min', 'Spot move after 30 min', 'Warning result']];
    for (const a of auditAlerts()) rows.push([dOf(a.ts), tOf(a.ts), a.index, a.kind, a.lvl, a.tone === 'bull' ? 'Up' : a.tone === 'bear' ? 'Down' : '', a.title, a.msg, a.spot0, a.s15, a.s30, a.result || '']);
    return rows;
  }
  function tradesCsv() {
    const rows = [['Date', 'Time (IST)', 'Index', 'Strike', 'Side', 'Buy (Rs)', 'Sell (Rs)', 'Lots', 'Lot size', 'Quantity', 'P&L (Rs)', 'Exit date', 'Exit time', 'Reason', 'Mood', 'PCR at entry', 'Futures 15m at entry', 'Hero-zero at entry', 'Spot at entry', 'Note']];
    for (const t of REC.trades()) rows.push([dOf(t.ts), tOf(t.ts), t.index, t.strike, t.side, t.buy, t.sell, t.lots, t.lotSize, t.lots * t.lotSize, isFinite(tradePnl(t)) ? Math.round(tradePnl(t)) : '',
      dOf(t.closeTs), tOf(t.closeTs), (t.reasons || []).join(' / '), t.mood, t.ctx && t.ctx.pcr, t.ctx && t.ctx.fut, t.ctx && t.ctx.hero, t.ctx && t.ctx.spot, t.note]);
    return rows;
  }
  function vixCsv() {
    const rows = [['Date', 'Locked time (IST)', 'VIX outlook', 'Score (-1 to +1)', 'VIX prev close', 'Expected low', 'Expected high', 'VIX close', 'VIX change %', 'Result', 'Reasons used']];
    const calls = REC.calls();
    for (const d of Object.keys(calls).sort()) { const v = calls[d].VIX; if (!v) continue;
      rows.push([d, tOf(v.ts), v.label, v.r, v.prev, v.range && v.range[0], v.range && v.range[1], v.close, v.chgPct, v.grade || 'Pending', (v.factors || []).map(f => f.txt).join(' | ')]); }
    return rows;
  }
  function casCsv() {
    const rows = [['Date', 'Index', 'Expiry day?', 'Frozen at 3:15', 'Expected close at 3:20', 'at 3:25', 'at 3:30', 'Official close', 'Final candle (pts)', 'Error at 3:25 (pts)', 'Direction right?']];
    for (const x of store.get('oi.rec.cas', [])) rows.push([x.day, x.index, x.expiry ? 'YES' : 'NO', x.spot315, x.est320, x.est325, x.est330, x.official,
      isFinite(x.official) && isFinite(x.spot315) ? x.official - x.spot315 : '', isFinite(x.official) && isFinite(x.est325) ? x.est325 - x.official : '',
      isFinite(x.official) && isFinite(x.est325) ? (Math.sign(x.est325 - x.spot315) === Math.sign(x.official - x.spot315) ? 'YES' : 'NO') : '']);
    return rows;
  }
  const EXPORTS = {
    hero: ['Hero-zero log', 'HeroZero_Log', heroCsv],
    calls: ['Morning predictions', 'Morning_Predictions', callsCsv],
    score: ['Scorecard summary', 'Scorecard', scoreCsv],
    vix: ['India VIX outlook', 'India_VIX_Outlook', vixCsv],
    cas: ['Closing auction log', 'Closing_Auction', casCsv],
    casideas: ['Auction strike ideas', 'Auction_Strike_Ideas', () => {
      const rows = [['Date', 'Time (IST)', 'Index', 'Strike', 'Side', 'Price at idea (Rs)', 'Expected close', '± band', 'Expected settlement (Rs)', 'Worst case (Rs)', 'Chance in profit %', 'Official close', 'Actual value (Rs): settlement on expiry, price at 3:37+ otherwise', 'Result %']];
      for (const x of store.get('oi.rec.casideas', [])) rows.push([x.day, tOf(x.ts), x.index, x.strike, x.side, x.ltp, x.estClose, x.band, x.settleEst, x.worst, x.chance * 100, x.official, x.settleActual, x.resultPct]);
      return rows; }],
    plans: ['Alert accuracy (target vs stop)', 'Alert_Accuracy', plansCsv],
    alerts: ['Alert history', 'Alert_History', alertsCsv],
    orders: ['Orders placed from EV Pulse', 'Orders', () => { const rows = [['Date', 'Time (IST)', 'Index', 'Strike', 'Side', 'Buy/Sell', 'Qty', 'Price (Rs)', 'Type', 'Product', 'Symbol', 'Sent OK', 'Order no.', 'Error', 'From']];
      for (const x of store.get('oi.rec.orders', [])) rows.push([x.day, tOf(x.ts), x.i, x.k, x.s, x.t === 'B' ? 'BUY' : 'SELL', x.qty, x.prc || 'MKT', x.type, x.prd === 'M' ? 'NRML' : 'MIS', x.tsym, x.ok ? 'YES' : 'NO', x.no, x.err, x.from]); return rows; }],
    trades: ['Trade journal', 'Trade_Journal', tradesCsv],
  };
  function download(kind) {
    syncAlertLog();
    const [title, base, fn] = EXPORTS[kind], rows = fn(), name = `EV_Pulse_${base}_${stamp()}.csv`, text = csv(rows);
    if (Bridge && Bridge.saveFile) {
      const r = String(Bridge.saveFile(name, 'text/csv', text)), ok = r.startsWith('ok|'), where = r.slice(r.indexOf('|') + 1);
      st.lastDl = ok ? { title, where, rows: rows.length - 1, ts: Date.now() } : null;
      toast(ok ? `${title} saved: ${where}` : where);
      render(); return ok;
    }
    const a = document.createElement('a');                     // browser preview
    a.href = URL.createObjectURL(new Blob(['﻿' + text], { type: 'text/csv' })); a.download = name; document.body.appendChild(a); a.click(); a.remove();
    st.lastDl = { title, where: 'Downloads/' + name, rows: rows.length - 1, ts: Date.now() }; toast(`${title} downloaded`); render(); return true;
  }
  function downloadAll() { let n = 0; for (const k of Object.keys(EXPORTS)) if (download(k)) n++; if (n) { st.lastDl = { title: `${n} files`, where: 'Downloads/EV Pulse', rows: 0, ts: Date.now() }; toast(`${n} files saved to Downloads/EV Pulse`); render(); } }
  function auditCard(keys) {
    const dl = st.lastDl && Date.now() - st.lastDl.ts < 10 * 60000 ? st.lastDl : null;
    return `<div class="card audit"><div class="fhead"><h3>⬇ Download for audit</h3><span class="dim" style="font-size:11px">CSV · Excel / Notepad</span></div>
      <div class="dlgrid">${keys.map(k => `<button class="dlb" data-dl="${k}"><b>${EXPORTS[k][0]}</b><span>.csv</span></button>`).join('')}
        <button class="dlb all" data-dl="all"><b>Download all</b><span>${Object.keys(EXPORTS).length} files</span></button></div>
      ${dl ? `<div class="dlok">✓ ${esc(dl.title)} saved to <b>${esc(dl.where)}</b>${dl.rows ? ` · ${dl.rows} rows` : ''}${Bridge && Bridge.openSaved && dl.rows ? ' <button class="chip" data-dlopen>Open</button>' : ''}</div>` : ''}
      <label class="exp" style="margin-top:10px;font-size:12px;color:var(--text)"><input type="checkbox" id="autoSave" ${st.settings.autoSave === false ? '' : 'checked'}> Save automatically every trading day after 3:42 PM to Downloads/EV Pulse/&lt;date&gt;${store.get('oi.autosave', '') ? ` · last: ${store.get('oi.autosave', '')}` : ''}</label>
      <div class="hzcap">Files are saved in your phone's Downloads → EV Pulse folder, with date and time in the file name. Every row has its date and IST time. Open with Excel, Google Sheets or any text editor.</div></div>`;
  }

  // =====================================================================================
  // INDIA VIX + each index's own ATM implied volatility (SENSEX "VIX")
  // =====================================================================================
  function vixReset() { st.vix = { series: [], prev: NaN, src: '' }; st.iv = {}; }
  if (!st.vix) vixReset();
  st.vixHist = store.get('oi.vixhist', null);
  async function fetchVix(open, manual) {
    if (!open && st.vix.series.length && !manual) return;
    let v = NaN, prev = NaN, src = '';
    const q = useFT() ? LD().vixQuote() : null;
    if (q) { v = q.v; prev = q.prev; src = LD().name || 'Flattrade'; }
    if (!(v > 0)) {
      try { const j = await nseGet('/api/allIndices'), row = (j.data || []).find(x => /INDIA\s*VIX/i.test(x.index || x.indexSymbol || ''));
        if (row) { v = parseFloat(row.last); prev = parseFloat(row.previousClose); src = 'NSE'; } } catch (e) { }
    }
    if (!(v > 0)) { const y = st.glob && st.glob.q.indiaVix; if (y) { v = y.price; prev = y.prev; src = 'Yahoo'; } }
    if (!(v > 0)) return;
    if (prev > 0) st.vix.prev = prev;
    st.vix.src = src;
    st.vix.series.push({ ts: Date.now(), v });
    if (st.vix.series.length > 800) st.vix.series.shift();
    if (open) vixAlerts();
  }
  /** 20-day average of India VIX (once a day from Yahoo daily closes, else from our own end-of-day records) */
  async function fetchVixHist() {
    const today = C.istDate(Date.now());
    if (st.vixHist && st.vixHist.day === today) return;
    let closes = [];
    try { const r = await http('GET', 'https://query1.finance.yahoo.com/v8/finance/chart/%5EINDIAVIX?range=2mo&interval=1d', { 'User-Agent': UA, 'Accept': 'application/json' });
      const j = parseJson(r.text), res = j && j.chart && j.chart.result && j.chart.result[0];
      closes = res ? ((res.indicators.quote[0] || {}).close || []).filter(x => x > 0) : []; } catch (e) { }
    if (closes.length < 5) { const e = REC.eod(); closes = Object.keys(e).sort().map(d => e[d].vix).filter(x => x > 0); }
    if (closes.length < 5) return;
    const last = closes.slice(-20);
    st.vixHist = { day: today, avg20: last.reduce((a, b) => a + b, 0) / last.length, n: last.length };
    store.set('oi.vixhist', st.vixHist);
  }
  function vixNow() {
    const s = st.vix.series; if (!s.length) return null;
    const v = s[s.length - 1].v, prev = st.vix.prev;
    let hi = -Infinity, lo = Infinity; for (const x of s) { hi = Math.max(hi, x.v); lo = Math.min(lo, x.v); }
    const today = C.istDate(Date.now()), [y, m, d] = today.split('-').map(Number), t13 = Date.UTC(y, m - 1, d, 7, 30);
    let at13 = null; for (const x of s) if (x.ts <= t13) at13 = x;
    return { v, prev, pct: prev > 0 ? (v / prev - 1) * 100 : NaN, hi, lo, open: s[0].v, ts: s[s.length - 1].ts, since13: at13 ? (v / at13.v - 1) * 100 : NaN, band: C.vixBand(v), src: st.vix.src };
  }
  /** ATM implied vol (%) of a snapshot: average of ATM CE and PE IV */
  function atmIv(snap, iso) {
    if (!snap || !snap.rows.length) return NaN;
    const T = C.yearsToExpiry(iso, snap.ts);
    const atm = snap.rows.reduce((a, b) => Math.abs(b.strike - snap.spot) < Math.abs(a.strike - snap.spot) ? b : a);
    const ivs = [];
    for (const sd of ['ce', 'pe']) { const x = atm[sd]; if (!(x.ltp > 0)) continue;
      let iv = C.impliedVol(x.ltp, snap.spot, atm.strike, T, sd === 'ce'); if (!(iv > 0) && x.iv > 0) iv = x.iv / 100;
      if (iv > 0.02 && iv < 1.5) ivs.push(iv * 100); }
    return ivs.length ? ivs.reduce((a, b) => a + b, 0) / ivs.length : NaN;
  }
  function recordIv(index, iso, snap) {
    const v = atmIv(snap, iso); if (!isFinite(v)) return;
    const a = st.iv[index] = st.iv[index] || []; a.push({ ts: snap.ts, v }); if (a.length > 800) a.shift();
  }
  const median3 = a => { const x = a.slice(-3).map(y => y.v).sort((p, q) => p - q); return x.length ? x[Math.floor(x.length / 2)] : NaN; };
  /** the volatility to use for an index: NIFTY → India VIX, SENSEX → its own ATM IV (kept within 0.6–2× VIX) */
  function volFor(index) {
    const vx = vixNow(), V = vx ? vx.v : NaN, own = median3(st.iv[index] || []);
    if (index === 'NIFTY') return isFinite(V) ? { vol: V, src: 'India VIX' } : isFinite(own) ? { vol: own, src: 'NIFTY ATM IV' } : null;
    if (isFinite(own)) return { vol: isFinite(V) ? Math.min(2 * V, Math.max(0.6 * V, own)) : own, src: 'SENSEX ATM IV' };
    return isFinite(V) ? { vol: V, src: 'India VIX' } : null;
  }
  /** % change of the index's volatility since 1:00 PM (for the hero-zero window) */
  function volSince13(index) {
    if (index === 'NIFTY') { const x = vixNow(); return x ? x.since13 : NaN; }
    const a = st.iv[index] || []; if (a.length < 5) return NaN;
    const today = C.istDate(Date.now()), [y, m, d] = today.split('-').map(Number), t13 = Date.UTC(y, m - 1, d, 7, 30);
    const before = a.filter(x => x.ts <= t13); if (!before.length) return NaN;
    return (median3(a) / median3(before) - 1) * 100;
  }
  /** chance spot touches `level` before 3:30 PM */
  function reachProb(index, spot, level) {
    const vf = volFor(index); if (!vf) return NaN;
    return C.touchProb(Math.abs(level - spot), C.expMove(spot, vf.vol, C.minsLeft(Date.now())));
  }
  const pctTxt = p => isFinite(p) ? `${Math.round(p * 100)}%` : '–';
  function heroVolNote(index) {
    const ch = volSince13(index), name = index === 'NIFTY' ? 'India VIX' : 'SENSEX IV';
    if (!isFinite(ch)) return '';
    if (ch >= 3) return { ok: true, t: `${name} rising ${ch.toFixed(1)}% since 1 PM: premiums supported, a big move is more likely` };
    if (ch <= -5) return { ok: false, t: `${name} falling ${ch.toFixed(1)}% since 1 PM: premiums melting, hero-zero is weaker` };
    return { ok: null, t: `${name} ${ch >= 0 ? '+' : ''}${ch.toFixed(1)}% since 1 PM: steady` };
  }
  function vixEvents() {
    const EV = /^(Fed \/ US rates|Interest rates|Budget \/ tax|War \/ conflict|Trade \/ tariffs)$/;
    return NEWS.items.filter(x => Date.now() - x.ts < 24 * 3600e3 && EV.test(x.topic)).length;
  }
  function vixOutlookNow() {
    const vx = vixNow(), g = st.glob ? st.glob.q : {}, gift = giftGet(), fl = futLast();
    const iv = g.indiaVix, before = vx && C.marketOpen(Date.now()) ? null : iv;
    const prevClose = vx && vx.prev > 0 ? vx.prev : iv ? iv.price : NaN;
    const mk = g.NIFTY;
    const fd = fl && futBase('prev') ? C.futBuildup(fl, futBase('prev')) : null;
    return C.vixOutlook({
      vix: vx ? vx.v : iv ? iv.price : NaN, prevClose, avg20: st.vixHist ? st.vixHist.avg20 : NaN,
      usVixPct: g.usVix ? g.usVix.pct : NaN, giftPct: gift && fl ? (gift.v - fl.ltp) / fl.ltp * 100 : NaN,
      mktPct: mk ? mk.pct : NaN, events: vixEvents(), futBias: C.marketOpen(Date.now()) && fd ? fd.bias : '',
      nowPct: vx && C.marketOpen(Date.now()) ? vx.pct : NaN,
    });
  }
  const VIX_MEANING = {
    up: ['If India VIX goes UP', 'Fear is rising. Option premiums (both CE and PE) get costlier and swings get bigger; the market usually falls. Good for option buyers already holding, bad for option sellers. Hero-zero moves become more likely. Use a wider stop-loss and smaller quantity.'],
    dn: ['If India VIX goes DOWN', 'Fear is falling. Premiums shrink even if price does not move (IV crush), so buyers lose value while waiting. The market is usually steady or rising, often range-bound. Prefer near-ATM strikes and quick exits; option sellers are favoured.'],
    flat: ['If India VIX stays steady', 'Normal conditions. Premiums decay at the usual pace; trust the option-chain signals as usual.'],
  };
  function vixCardHtml(full) {
    const vx = vixNow(), o = vixOutlookNow();
    if (!vx && !o.factors.length) return full ? `<div class="card"><h3>India VIX</h3><div class="hzmsg">Waiting for India VIX data…</div></div>` : '';
    const v = vx ? vx.v : (st.glob && st.glob.q.indiaVix ? st.glob.q.indiaVix.price : NaN);
    const n = dataNear('NIFTY'), s = dataNear('SENSEX'), left = C.minsLeft(Date.now());
    const em = (d, idx) => { const vf = volFor(idx); return d && vf && left ? `±${fmtK(C.expMove(d.cur.spot, vf.vol, left))}` : '–'; };
    const sv = volFor('SENSEX');
    const lockC = (REC.calls()[C.istDate(Date.now())] || {}).VIX;
    const out = lockC || o;
    return `<div class="card vixc">
      <div class="fhead"><h3>India VIX <span class="dim">· ${C.vixBand(v)}</span></h3><span class="pl ${out.tone === 'up' ? 'bear' : out.tone === 'dn' ? 'bull' : ''}">${out.label}${lockC ? ' 🔒' : ''}</span></div>
      <div class="fgrid num">
        <div><div class="k">India VIX</div><div class="v">${f2(v)}</div><div class="d ${vx ? cls(vx.pct) : ''}">${vx && isFinite(vx.pct) ? sgn(vx.pct, x => x.toFixed(2)) + '% today' : 'prev close'}</div></div>
        <div><div class="k">SENSEX IV</div><div class="v">${sv && sv.src === 'SENSEX ATM IV' ? f1(sv.vol) : '–'}</div><div class="d">own ATM options</div></div>
        <div><div class="k">Move left today</div><div class="v" style="font-size:13px">N ${em(n, 'NIFTY')}<br>S ${em(s, 'SENSEX')}</div></div>
      </div>
      ${vx && isFinite(vx.hi) ? `<div class="hzcap" style="margin-top:6px">Day range ${f2(vx.lo)} – ${f2(vx.hi)} · prev close ${f2(vx.prev)}${isFinite(vx.since13) ? ` · since 1 PM ${sgn(vx.since13, x => x.toFixed(1))}%` : ''} · ${vx.src}</div>` : ''}
      ${full ? `<div class="flist">${out.factors.map(f => `<div class="fr"><span class="fi ${f.val > 0.15 ? 'dn' : f.val < -0.15 ? 'up' : ''}">${f.val > 0.15 ? '▲' : f.val < -0.15 ? '▼' : '●'}</span><span>${f.txt}</span></div>`).join('')}</div>
        ${out.range ? `<div class="hzmsg" style="margin-top:6px">Expected VIX range today: <b>${f2(out.range[0])} – ${f2(out.range[1])}</b></div>` : ''}
        <div class="vmean">${['up', 'dn', 'flat'].map(k => `<div class="vm ${k} ${(out.tone || 'flat') === k ? 'on' : ''}"><b>${VIX_MEANING[k][0]}</b><span>${VIX_MEANING[k][1]}</span></div>`).join('')}</div>`
        : `<div class="hzcap">${out.label === 'Likely UP' ? 'Fear may rise: bigger swings, costlier premiums.' : out.label === 'Likely DOWN' ? 'Fear may ease: premiums shrink, range-bound bias.' : 'Normal volatility expected.'} Details in Daily → Morning call.</div>`}
    </div>`;
  }
  function renderVix() { const el = $('vixCard'); if (el) el.innerHTML = vixCardHtml(false); }
  function vixAlerts() {
    const vx = vixNow(); if (!vx) return;
    const e = (st.expiries.NIFTY || [''])[0];
    if (vx.pct >= 8) fire('vixSpike', 'NIFTY', e, `⚡ India VIX spike +${vx.pct.toFixed(1)}%`, `India VIX ${f2(vx.v)} (prev ${f2(vx.prev)}). Fear rising: expect bigger swings, costlier premiums. Market often falls; watch for a panic bottom.`, 'bear', 'day8', 600);
    const s = st.vix.series, cut = Date.now() - 15 * 60000; let b = null; for (const x of s) if (x.ts <= cut) b = x;
    if (b && (vx.v / b.v - 1) * 100 >= 5) fire('vixSpike', 'NIFTY', e, `⚡ India VIX +${((vx.v / b.v - 1) * 100).toFixed(1)}% in 15 min`, `India VIX ${f2(b.v)} → ${f2(vx.v)}. Sudden fear: a sharp move is likely.`, 'bear', 'q', 30);
  }
  function vixCrushAlert(index, expiry) {
    if (!isExpiryDay(index)) return;
    const p = C.istParts(Date.now()), m = p.h * 60 + p.mi; if (m < 13 * 60 + 30) return;
    const ch = volSince13(index);
    if (ch <= -8) fire('vixCrush', index, expiry, `${index} · ${index === 'NIFTY' ? 'India VIX' : 'SENSEX IV'} crushed ${ch.toFixed(1)}% since 1 PM`, 'Option premiums are melting fast. Hero-zero buys lose value quickly unless a sharp move comes now.', '', 'crush', 600);
  }

  // =====================================================================================
  // CLOSING AUCTION SESSION (since 3 Aug 2026): stocks stop at 3:15, the close comes from an auction.
  // The app estimates that close from what still trades till 3:40: the expiring options (put-call parity) and futures.
  // =====================================================================================
  st.cas = st.cas || {};
  const minsOf = ts => { const p = C.istParts(ts); return p.h * 60 + p.mi + p.s / 60; };
  /** synthetic future from put-call parity on the 5 strikes nearest spot, using bid/ask mid when the quote is tight (last trade can be stale) */
  function synMid(rows, spot) {
    const px = o => o.bid > 0 && o.ask > 0 && (o.ask - o.bid) <= Math.max(0.5, 0.05 * o.ltp) ? (o.bid + o.ask) / 2 : o.ltp;
    const near = rows.filter(r => r.ce.ltp > 0 && r.pe.ltp > 0).sort((a, b) => Math.abs(a.strike - spot) - Math.abs(b.strike - spot)).slice(0, 5);
    if (!near.length) return NaN;
    const f = near.map(r => r.strike + px(r.ce) - px(r.pe)).sort((a, b) => a - b);
    return f[Math.floor(f.length / 2)];
  }
  // starting error (points) per source until 5+ real days are recorded: the exchange's indicative is the auction itself
  const CAS_PRIOR = { 'exchange indicative': 0.12, options: 1.0, futures: 0.8 };
  function casRmse(index, src, exp) {
    const step = C.INDICES[index].step, L = store.get('oi.rec.casSrc', []).filter(x => x.index === index && x.src === src && (src !== 'options' || x.exp === exp)).slice(-20);
    const prior = (CAS_PRIOR[src] || 1) * step;
    if (L.length < 5) return { rmse: prior, n: L.length };
    const r = Math.sqrt(L.reduce((a, x) => a + x.err * x.err, 0) / L.length);
    return { rmse: Math.max(step * 0.03, (r * L.length + prior * 3) / (L.length + 3)), n: L.length };   // blend with the prior so one lucky day can't dominate
  }
  function casLearn(index, cs) {
    if (!cs.lastParts || !isFinite(cs.official)) return;
    const L = store.get('oi.rec.casSrc', []), day = C.istDate(Date.now()), exp = isExpiryDay(index);
    if (L.some(x => x.day === day && x.index === index)) return;
    for (const p of cs.lastParts) if (isFinite(p.v)) L.push({ day, index, exp, src: p.src, v: +p.v.toFixed(2), err: +(p.v - cs.official).toFixed(2) });
    store.set('oi.rec.casSrc', L.slice(-400));
  }
  /** how good the expected close has been on past days (last 20 with an official close) */
  function casTrack(index) {
    const L = store.get('oi.rec.cas', []).filter(x => x.index === index && isFinite(x.official) && isFinite(x.est330) && isFinite(x.spot315)).slice(-20);
    if (!L.length) return null;
    const err = L.reduce((a, x) => a + Math.abs(x.est330 - x.official), 0) / L.length;
    const dir = L.filter(x => Math.abs(x.official - x.spot315) >= C.INDICES[index].step * 0.1).map(x => Math.sign(x.est330 - x.spot315) === Math.sign(x.official - x.spot315));
    return { n: L.length, err, dirN: dir.length, dirOk: dir.filter(Boolean).length };
  }
  function casState(index) { return (st.cas[index] = st.cas[index] || { b: [], track: [] }); }
  function casTick(index, liveSnap) {
    const d = dataNear(index); if (!d) return null;
    const snap = liveSnap || d.cur, m = minsOf(snap.ts), cs = casState(index);
    if (m < 15 * 60 + 5 || m > 15 * 60 + 41) return cs;
    const syn = synMid(snap.rows, snap.spot);
    const lq = index === 'NIFTY' && useFT() && LD().futQuote ? LD().futQuote() : null;
    const fl = index === 'NIFTY' ? futLast() : null, fut = lq && lq.ltp > 0 ? lq.ltp : fl && Math.abs(fl.ts - snap.ts) < 120000 ? fl.ltp : NaN;
    if (m < 15 * 60 + 15) {                                         // 3:05–3:15: normal premium of options/futures over spot
      cs.b.push({ ts: snap.ts, spot: snap.spot, syn, fut }); if (cs.b.length > 700) cs.b.shift();
      cs.spot315 = snap.spot; return cs;
    }
    if (!isFinite(cs.spot315)) { const pre = d.series.filter(x => minsOf(x.ts) < 15 * 60 + 15.5); if (pre.length) cs.spot315 = pre[pre.length - 1].spot; }
    const med = a => { a = a.filter(isFinite).sort((x, y) => x - y); return a.length ? a[Math.floor(a.length / 2)] : NaN; };
    const ref = { spot315: cs.spot315, synBasis: med(cs.b.map(x => x.syn - x.spot)), futBasis: med(cs.b.map(x => x.fut - x.spot)) };
    const exp = isExpiryDay(index);
    if (m >= 15 * 60 + 35.5) {                                      // auction matched: the index now shows the official close
      if (isFinite(cs.spot315) && Math.abs(snap.spot - cs.spot315) > 0.01 || m >= 15 * 60 + 38) { if (!cs.official) { cs.official = snap.spot; cs.offTs = snap.ts; casRecord(index, cs); casLearn(index, cs); casIdeaSettle(index, cs.official); } }
      if (cs.official && !isExpiryDay(index) && m >= 15 * 60 + 37) {
        const log = store.get('oi.rec.casideas', []), day = C.istDate(Date.now()); let ch = false;
        for (const x of log) if (x.day === day && x.index === index && x.expiry === false && !isFinite(x.settleActual)) {
          const r = snap.rows.find(y => y.strike === x.strike), v = r ? r[x.side.toLowerCase()].ltp : NaN;
          if (v > 0) { x.settleActual = v; x.official = cs.official; x.resultPct = (v - x.ltp) / x.ltp * 100; ch = true; } }
        if (ch) store.set('oi.rec.casideas', log);
      }
      if (cs.official && isExpiryDay(index) && m < 15 * 60 + 40) {           // close known, options trade till 3:40
        cs.est = Object.assign({}, cs.est || {}, { ts: snap.ts, v: cs.official, band: C.INDICES[index].step * 0.05, move: cs.official - cs.spot315, parts: [{ src: 'official close', v: cs.official, w: 1 }] });
        cs.ideas = casIdeas(index, cs, snap);
        try { cs.pair = casPair(index, cs, snap, true); } catch (e) { }
      }
      return cs;
    }
    // an index value that moves after 3:20 while stocks are not trading = the exchange's indicative auction value
    const ind = m >= 15 * 60 + 20 && isFinite(cs.spot315) && Math.abs(snap.spot - cs.spot315) > 0.5 ? snap.spot : NaN;
    const e = C.casEstimate(ref, { syn, fut }, exp);
    if (!e && !isFinite(ind)) return cs;
    const step = C.INDICES[index].step;
    let parts = e ? e.parts.map(p => ({ src: p.src, v: p.v })) : [];
    if (isFinite(ind)) parts.push({ src: 'exchange indicative', v: ind });
    // weights from each source's real error on past days (1 / error²); the exchange's own auction value starts far ahead
    for (const p of parts) { const r = casRmse(index, p.src, exp); p.rmse = r.rmse; p.n = r.n; p.w = 1 / (r.rmse * r.rmse); }
    // a source that disagrees with the exchange's auction value by more than ~half a strike is lagging: leave it out
    if (isFinite(ind)) for (const p of parts) if (p.src !== 'exchange indicative' && Math.abs(p.v - ind) > step * 0.6) { p.ignored = true; p.w = 0; }
    const use = parts.filter(p => p.w > 0), W = use.reduce((a, p) => a + p.w, 0);
    const v = use.reduce((a, p) => a + p.v * p.w, 0) / W;
    for (const p of parts) p.share = W ? p.w / W : 0;
    const vf = volFor(index), rm = Math.sqrt(1 / W);                    // combined error of the weighted sources
    const band = isFinite(ind) ? Math.max(step * (m >= 15 * 60 + 28 ? 0.05 : 0.1), Math.min(rm, step * 0.6))
      : Math.max(use.length > 1 ? Math.max(...use.map(p => p.v)) - Math.min(...use.map(p => p.v)) : 0, vf ? C.expMove(snap.spot, vf.vol, Math.max(2, 15 * 60 + 30 - m)) / 2 : 0, step * 0.2);
    cs.est = { ts: snap.ts, v, band, parts, move: isFinite(cs.spot315) ? v - cs.spot315 : NaN, hasInd: isFinite(ind) };
    if (m >= 15 * 60 + 25 && m < 15 * 60 + 29.75) cs.lastParts = parts.map(p => ({ src: p.src, v: p.v }));   // what each source said near the end (for learning)
    const last = cs.track[cs.track.length - 1];
    if (!last || snap.ts - last.ts >= 5000) { cs.track.push({ ts: snap.ts, v }); if (cs.track.length > 500) cs.track.shift(); }
    if (exp) { cs.ideas = casIdeas(index, cs, snap); if (cs.ideas && m >= 15 * 60 + 18) casIdeaLog(index, cs, cs.ideas); } else cs.ideas = null;
    try { cs.pair = casPair(index, cs, snap, exp); } catch (e) { cs.pair = null; }
    if (!exp && cs.pair && m >= 15 * 60 + 18) for (const b of [cs.pair.ce, cs.pair.pe]) if (b && b.vcls === 'g') casPairLog(index, b, cs.pair);
    casAlert(index, cs, exp);
    return cs;
  }
  setInterval(() => {                                                 // 3:05–3:41: read the auction every second, both indices
    const now = Date.now(), m = minsOf(now), wd = C.istParts(now).wd;
    if (wd === 0 || wd === 6 || m < 15 * 60 + 5 || m > 15 * 60 + 41) return;
    for (const index of Object.keys(C.INDICES)) {
      const iso = (st.expiries[index] || [])[0]; if (!iso) continue;
      let snap = null; const L = LD();
      if (useFT() && L.hasChain(index, iso)) { try { const p = L.chain(index, iso, lastSpot(index)); if (p.rows.length && p.spot) snap = { ts: now, spot: p.spot, rows: p.rows }; } catch (e) { } }
      if (!snap) { const d = dataNear(index); if (d) { const lv = st.live[d.key]; snap = lv && lv.ts > d.cur.ts ? lv : d.cur; } }
      if (snap) { try { casTick(index, snap); } catch (e) { console.error(e); } }
    }
    if (st.ui.view === 'home' && document.visibilityState === 'visible') { const ce = $('casCard'); if (ce) ce.innerHTML = casCardHtml(st.ui.index); }
  }, 1000);
  function casAlert(index, cs, exp) {
    const e = cs.est, m = minsOf(e.ts); if (m < 15 * 60 + 20 || !isFinite(e.move)) return;
    if (!e.hasInd && m < 15 * 60 + 26) return;                       // wait for the exchange's own auction value: options alone can lag
    const big = Math.abs(e.move) >= C.INDICES[index].step * 0.8;
    const key = 'm' + Math.round(e.v / C.INDICES[index].step);          // re-alert only when the estimate moves a full strike
    cs.nAl = cs.nAl || 0; if (cs.nAl >= 4) return;
    const settle = exp ? casSettleText(index, e.v) : '';
    if (big || m >= 15 * 60 + 24) fire('casClose', index, (st.expiries[index] || [''])[0],
      `${index} closing auction: expected close ${fmtK(e.v)} (${sgn(e.move, fmtK)} vs 3:15)`,
      `Stocks stopped at ${fmtK(cs.spot315)}; ${e.hasInd ? "the exchange's auction value" : 'options' + (index === 'NIFTY' ? ' and futures' : '')} now point${e.hasInd ? 's' : ''} to a close near ${fmtK(e.v)} ± ${fmtK(e.band)}. ` +
      (big ? `Expect a big ${e.move > 0 ? 'GREEN' : 'RED'} final candle.` : 'Small final candle expected.') + (settle ? ' ' + settle : '') + casPairText(cs),
      e.move > 0 ? 'bull' : 'bear', key, 10) && cs.nAl++;
  }
  /** settlement values of today's hero strikes at the expected close */
  function casSettleText(index, close) {
    const hs = REC.hero().filter(x => x.day === C.istDate(Date.now()) && x.index === index).slice(-3);
    if (!hs.length) return '';
    return 'Expiry settlement at that close: ' + hs.map(x => { const v = Math.max(0, x.side === 'CE' ? close - x.strike : x.strike - close); return `${fmtK(x.strike)} ${x.side} ≈ ₹${f1(v)}`; }).join(', ') + '.';
  }
  function casRecord(index, cs) {
    const log = store.get('oi.rec.cas', []), day = C.istDate(Date.now());
    if (log.some(x => x.day === day && x.index === index)) return;
    const at = mm => { let v = NaN; for (const t of cs.track) if (minsOf(t.ts) <= mm) v = t.v; return v; };
    log.push({ day, index, expiry: isExpiryDay(index), spot315: cs.spot315, est320: at(15 * 60 + 20.5), est325: at(15 * 60 + 25.5), est330: at(15 * 60 + 30.5), official: cs.official, offTs: cs.offTs });
    store.set('oi.rec.cas', log.slice(-300));
  }
  function casCardHtml(index) {
    const cs = st.cas[index], m = minsOf(Date.now()), wd = C.istParts(Date.now()).wd;
    if (wd === 0 || wd === 6 || m < 15 * 60 + 5 || m > 15 * 60 + 50) return '';
    const exp = isExpiryDay(index);
    if (m < 15 * 60 + 15) return `<div class="card cas"><div class="fhead"><h3>⏱ Closing auction at 3:15</h3><span class="pl">${exp ? 'EXPIRY' : 'today'}</span></div>
      <div class="hzmsg">At <b>3:15</b> stocks stop trading and ${index} will freeze. The official close (${exp ? 'and today\'s option settlement' : 'used for settlement'}) comes from an auction at 3:20–3:30, published about 3:35. Options and futures keep trading till 3:40, and the app will read the expected close from them.</div></div>`;
    if (!cs) return '';
    const e = cs.est;
    const off = cs.official ? `<div class="grade ${Math.abs(cs.official - (cs.track.length ? cs.track[cs.track.length - 1].v : cs.official)) <= (e ? e.band : 0) ? 'ok' : 'bad'}">Official close ${f2(cs.official)} (${sgn(cs.official - cs.spot315, fmtK)} vs 3:15)${cs.track.length ? ` · app expected ${fmtK(cs.track[cs.track.length - 1].v)}` : ''}</div>` : '';
    const strikes = e && exp ? (() => { const d = dataNear(index); if (!d) return ''; const step = C.INDICES[index].step, k0 = Math.round(e.v / step) * step;
      return `<div class="ptab num"><div class="pth">Strike</div><div class="pth">CE settles ≈</div><div class="pth">PE settles ≈</div>` + [k0 - step, k0, k0 + step].map(k => `<div>${fmtK(k)}</div><div>₹${f1(Math.max(0, e.v - k))}</div><div>₹${f1(Math.max(0, k - e.v))}</div>`).join('') + '</div>'; })() : '';
    return `<div class="card cas"><div class="fhead"><h3>🔔 Closing auction · ${index}</h3><span class="pl ${e && e.move > 0 ? 'bull' : e && e.move < 0 ? 'bear' : ''}">${e && isFinite(e.move) ? (e.move >= 0 ? '▲ ' : '▼ ') + fmtK(Math.abs(e.move)) + ' pts' : 'reading…'}</span></div>
      <div class="fgrid num"><div><div class="k">Frozen at 3:15</div><div class="v">${f2(cs.spot315)}</div></div>
        <div><div class="k">Expected close</div><div class="v ${e ? cls(e.move) : ''}">${e ? fmtK(e.v) : '–'}</div><div class="d">${e ? '± ' + fmtK(e.band) : ''}</div></div>
        <div><div class="k">Final candle</div><div class="v ${e ? cls(e.move) : ''}">${e && isFinite(e.move) ? (Math.abs(e.move) < C.INDICES[index].step * 0.3 ? 'Small' : e.move > 0 ? 'GREEN' : 'RED') : '–'}</div></div></div>
      ${e ? `<div class="hzcap" style="margin-top:6px">From: ${e.parts.map(p => p.ignored ? `<s>${p.src} ${fmtK(p.v)}</s> (ignored: lags the auction)` : `${p.src} ${fmtK(p.v)}${isFinite(p.share) ? ` <b>${Math.round(p.share * 100)}%</b>` : ''}`).join(' · ')}${e.hasInd ? '' : ' · <b class="dn">early estimate from options only</b>: firm once the exchange\'s auction value appears (about 3:20)'} · updated ${C.istTime(e.ts, true)}</div>` : ''}
      ${(() => { const t = casTrack(index); return t ? `<div class="hzcap">Track record (${t.n} day${t.n > 1 ? 's' : ''}): average error ${fmtK(Math.round(t.err))} pts${t.dirN ? ` · direction right ${t.dirOk}/${t.dirN}` : ''}. Weights learn from these results.</div>` : ''; })()}
      ${off}${cs.track.length > 2 ? lineChart([{ n: 'Expected close', c: '#4C7DFF', pts: cs.track.map(t => ({ t: t.ts, v: t.v })), w: 2 }], { fmt: v => Math.round(v).toLocaleString('en-IN') }) : ''}
      ${casPairHtml(index, cs)}
      ${exp ? casIdeasHtml(index, cs) : ''}
      ${strikes}
      <div class="hzcap">Expiring ${index} options settle at the auction close, so their prices (put-call parity) show where the market expects it. Estimate, can change until the auction ends at 3:28–3:30.</div></div>`;
  }
  // ---- CAS strike ideas (expiry day only): expected settlement value vs price now
  function casIdeas(index, cs, snap) {
    const e = cs.est; if (!e || !snap) return null;
    const step = C.INDICES[index].step, v = e.v, sd = Math.max(e.band, step * 0.1);
    const out = [];
    for (const r of snap.rows) {
      if (Math.abs(r.strike - v) > step * 4) continue;
      for (const side of ['CE', 'PE']) {
        const ltp = r[side.toLowerCase()].ltp; if (!(ltp > 0)) continue;
        const call = side === 'CE', val = x => Math.max(0, call ? x - r.strike : r.strike - x);
        const settle = val(v), worst = val(call ? v - sd : v + sd);
        const cost = Math.max(0.5, ltp * 0.02) + settle * 0.00125;          // spread/slippage + STT on exercise (approx.)
        const be = call ? r.strike + ltp + cost : r.strike - ltp - cost;       // close needed to break even
        const chance = C.ncdf((call ? v - be : be - v) / sd);
        const edge = settle - ltp - cost, gain = (settle - ltp) / ltp;
        out.push({ strike: r.strike, side, ltp, settle, worst, cost, chance, edge, gain, itm: C.ncdf((call ? v - r.strike : r.strike - v) / sd) });
      }
    }
    const buys = out.filter(x => x.edge > 0 && x.gain >= 0.05 && x.chance >= 0.6).sort((a, b) => b.edge / b.ltp * b.chance - a.edge / a.ltp * a.chance);
    const avoid = out.filter(x => x.ltp >= 1 && (x.settle < x.ltp * 0.9) && Math.abs(x.strike - v) <= step * 2).sort((a, b) => Math.abs(a.strike - v) - Math.abs(b.strike - v))
      .slice(0, 2).map(x => Object.assign(x, { why: x.itm < 0.3 ? 'expires zero' : 'overpriced' }));
    return { buys: buys.slice(0, 3), avoid, ts: snap.ts, v, sd };
  }
  function casIdeaLog(index, cs, ideas) {
    const b = ideas.buys[0]; if (!b) return;
    const log = store.get('oi.rec.casideas', []), day = C.istDate(Date.now());
    const today = log.filter(x => x.day === day && x.index === index);
    if (today.some(x => x.strike === b.strike && x.side === b.side) || today.length >= 5) return;
    log.push({ day, index, ts: ideas.ts, strike: b.strike, side: b.side, ltp: b.ltp, settleEst: b.settle, worst: b.worst, chance: b.chance, estClose: ideas.v, band: ideas.sd });
    store.set('oi.rec.casideas', log.slice(-500));
    fire('casIdea', index, (st.expiries[index] || [''])[0], `💡 ${index} auction idea: ${fmtK(b.strike)} ${b.side} @ ₹${f2(b.ltp)}`,
      `Expected close ${fmtK(ideas.v)} ± ${fmtK(ideas.sd)} → settles ≈ ₹${f1(b.settle)} (${b.gain >= 0 ? '+' : ''}${Math.round(b.gain * 100)}%), chance in profit ${Math.round(b.chance * 100)}%. Worst case ₹${f1(b.worst)}. Buy as NRML (Flattrade squares off F&O intraday at 3:25).`,
      b.side === 'CE' ? 'bull' : 'bear', b.strike + b.side, 30);
  }
  /** after the official close: fill in what each idea actually settled at */
  function casIdeaSettle(index, official) {
    const log = store.get('oi.rec.casideas', []), day = C.istDate(Date.now()); let ch = false;
    for (const x of log) if (x.day === day && x.index === index && !isFinite(x.settleActual)) {
      x.settleActual = Math.max(0, x.side === 'CE' ? official - x.strike : x.strike - official); x.official = official;
      x.resultPct = (x.settleActual - x.ltp) / x.ltp * 100; ch = true; }
    if (ch) store.set('oi.rec.casideas', log);
  }
  // ---- CAS: best CE and best PE — buy-at price and the price it may reach at the auction close
  function casPair(index, cs, snap, exp) {
    const e = cs.est; if (!e || !snap) return null;
    const step = C.INDICES[index].step, v = e.v, sd = Math.max(e.band, step * 0.1);
    const syn = C.synthetic(snap.rows, snap.spot), ref = isFinite(syn) ? syn : snap.spot;     // live market level the option prices reflect
    const valueAt = (side, K, close) => exp ? Math.max(0, side === 'ce' ? close - K : K - close)                 // expiry: settles at intrinsic
      : C.estPrice(snap.rows, side, K, ref, close);                                                              // otherwise: price if the close lands there
    const out = {};
    for (const side of ['ce', 'pe']) {
      const cands = [];
      for (const r of snap.rows) {
        if (Math.abs(r.strike - v) > step * 4) continue;
        const ltp = r[side].ltp; if (!(ltp >= 1)) continue;
        const goTo = valueAt(side, r.strike, v), worst = valueAt(side, r.strike, side === 'ce' ? v - sd : v + sd);
        const cost = Math.max(0.5, ltp * 0.02) + (exp ? goTo * 0.00125 : 0);
        const buyMax = (goTo - cost) / 1.05;                                         // highest price that still leaves ≥5% after costs
        const be = ltp + cost;                                                        // option value needed to break even
        let chance;
        if (exp) { const beClose = side === 'ce' ? r.strike + be : r.strike - be; chance = C.ncdf((side === 'ce' ? v - beClose : beClose - v) / sd); }
        else chance = goTo > be ? C.ncdf(Math.min(3, (goTo - be) / Math.max(0.5, Math.abs(goTo - worst)))) : 1 - C.ncdf(Math.min(3, (be - goTo) / Math.max(0.5, Math.abs(goTo - worst))));
        const gain = (goTo - ltp) / ltp, edge = goTo - ltp - cost;
        cands.push({ side: side.toUpperCase(), strike: r.strike, ltp, goTo, worst, buyMax, chance, gain, edge, score: edge / ltp * chance });
      }
      cands.sort((a, b) => b.score - a.score);
      let b = cands[0]; if (!b) { out[side] = null; continue; }
      if (!(b.edge > 0)) b = cands.slice().sort((x, y) => Math.abs(x.strike - v) - Math.abs(y.strike - v))[0];   // no edge anywhere: show the strike nearest the expected close
      b.verdict = b.edge > 0 && b.gain >= 0.05 && b.chance >= 0.6 ? (b.ltp <= b.buyMax ? 'Buy now' : 'Buy only at ≤ ₹' + f1(b.buyMax)) : b.goTo < b.ltp * 0.5 ? 'Avoid: likely to lose value' : 'No edge: priced fair';
      b.vcls = /^Buy now/.test(b.verdict) ? 'g' : /^Buy only/.test(b.verdict) ? 'f' : 'x';
      out[side] = b;
    }
    return { v, sd, exp, ce: out.ce, pe: out.pe };
  }
  /** non-expiry days: record + alert a "Buy now" CE/PE from the closing-auction pair */
  function casPairLog(index, b, P) {
    const log = store.get('oi.rec.casideas', []), day = C.istDate(Date.now());
    const today = log.filter(x => x.day === day && x.index === index);
    if (today.some(x => x.strike === b.strike && x.side === b.side) || today.length >= 5) return;
    log.push({ day, index, ts: Date.now(), strike: b.strike, side: b.side, ltp: b.ltp, settleEst: b.goTo, worst: b.worst, chance: b.chance, estClose: P.v, band: P.sd, expiry: false });
    store.set('oi.rec.casideas', log.slice(-500));
    fire('casIdea', index, (st.expiries[index] || [''])[0], `💡 ${index} auction idea: ${fmtK(b.strike)} ${b.side} @ ₹${f2(b.ltp)}`,
      `Expected close ${fmtK(P.v)} ± ${fmtK(P.sd)} → may reach ≈ ₹${f1(b.goTo)} (+${Math.round(b.gain * 100)}%) once the close is known. Buy at or below ₹${f1(b.buyMax)}. Chance in profit ${Math.round(b.chance * 100)}%. Worst case ₹${f1(b.worst)}. Not expiry: sell by 3:40. Buy as NRML.`,
      b.side === 'CE' ? 'bull' : 'bear', b.strike + b.side, 30);
  }
  function casPairText(cs) {
    const P = cs.pair; if (!P) return '';
    const t = x => !x ? '' : `${fmtK(x.strike)} ${x.side} now ₹${f2(x.ltp)}, buy ≤ ₹${f1(Math.max(0, x.buyMax))}, may go to ₹${f1(x.goTo)} (${x.verdict})`;
    return ` CE: ${t(P.ce) || '–'}. PE: ${t(P.pe) || '–'}.`;
  }
  function casPairHtml(index, cs) {
    const P = cs.pair; if (!P) return '';
    const col = x => !x ? '<div class="cpc"><div class="dim">No liquid strike near the expected close.</div></div>' : `<div class="cpc ${x.side.toLowerCase()}">
      <div class="cph"><b>${fmtK(x.strike)} ${x.side}</b></div>
      <div class="cpv"><span>Now</span><b>₹${f2(x.ltp)}</b></div>
      <div class="cpv"><span>Buy at or below</span><b>${x.buyMax > 0 ? '₹' + f1(x.buyMax) : '–'}</b></div>
      <div class="cpv"><span>May reach</span><b class="${x.goTo >= x.ltp ? 'up' : 'dn'}">₹${f1(x.goTo)} (${x.gain >= 0 ? '+' : ''}${Math.round(x.gain * 100)}%)</b></div>
      <div class="cpv"><span>Worst case</span><b>₹${f1(x.worst)}</b></div>
      <div class="cpv"><span>Chance in profit</span><b>${Math.round(x.chance * 100)}%</b></div>
      <div class="vj ${x.vcls}" style="display:block;text-align:center;margin-top:6px">${x.verdict}</div></div>`;
    return `<div class="cid"><div class="fhead" style="margin:0"><b>CE and PE to buy</b><span class="dim" style="font-size:11px">close ≈ ${fmtK(P.v)} ± ${fmtK(P.sd)}</span></div>
      <div class="cpair">${col(P.ce)}${col(P.pe)}</div>
      <div class="ciw">Buy as NRML (Flattrade squares off F&amp;O intraday at 3:25). ${P.exp ? 'Expiry: options settle at the auction close, so "may go to" is the settlement value.' : 'Not expiry: options do not settle today. "May go to" is the estimated price once the close is known (~3:35); sell by 3:40 or carry overnight at your own risk.'}</div>
      <div class="hzcap">"Buy at or below" leaves at least 5% after approx. costs if the close lands as expected. The auction can still surprise until it ends (3:28–3:30).</div></div>`;
  }

  function casIdeasHtml(index, cs) {
    const I = cs.ideas; if (!I) return '';
    const lot = LOT[index];
    const best = I.buys[0];
    const row = (x, tag, col) => `<div class="cir"><div><b>${fmtK(x.strike)} ${x.side}</b> <span class="dim">₹${f2(x.ltp)} → ₹${f1(x.settle)}</span></div><div style="color:${col}">${tag}</div></div>`;
    return `<div class="cid"><div class="fhead" style="margin:0"><b>Strike to buy</b><span class="dim" style="font-size:11px">settles at the auction close</span></div>
      ${best ? `<div class="cib"><div class="cibh"><b>${fmtK(best.strike)} ${best.side}</b><span class="ib">Best pick</span><span class="iv2">₹${f2(best.ltp)}</span></div>
        <div class="cig"><div><span>Settles ≈</span><b>₹${f1(best.settle)} <i class="up">(+${Math.round(best.gain * 100)}%)</i></b></div>
          <div><span>Chance in profit</span><b>${Math.round(best.chance * 100)}%</b></div>
          <div><span>Worst case (close ${fmtK(best.side === 'CE' ? I.v - I.sd : I.v + I.sd)})</span><b>₹${f1(best.worst)} <i class="${best.worst >= best.ltp ? 'up' : 'dn'}">(${best.worst >= best.ltp ? '+' : ''}${Math.round((best.worst / best.ltp - 1) * 100)}%)</i></b></div>
          <div><span>Per lot (${lot})</span><b>₹${fmtK(best.ltp * lot)} → ≈ ₹${fmtK(best.settle * lot)}</b></div></div></div>`
        : `<div class="hzmsg" style="margin-top:6px">No edge right now: options are priced close to their expected settlement. Nothing to buy.</div>`}
      ${I.buys.slice(1).map(x => row(x, `<span class="up">+${Math.round(x.gain * 100)}%</span> · ${Math.round(x.chance * 100)}%`, 'inherit')).join('')}
      ${I.avoid.map(x => row(x, 'Avoid · ' + x.why, x.why === 'expires zero' ? 'var(--ce)' : 'var(--amber)')).join('')}
      <div class="ciw">Buy as NRML, not intraday: Flattrade squares off F&amp;O intraday at 3:25. Sell by 3:40 or hold to settlement (STT applies on exercise).</div>
      <div class="hzcap">Gain = expected settlement − price now, after approx. costs. Shown only when the gap beats costs; most days options are already priced close to it. The auction can still surprise until it ends (3:28–3:30).</div></div>`;
  }

  function casAccuracy() {
    const l = store.get('oi.rec.cas', []).filter(x => isFinite(x.official) && isFinite(x.est325));
    if (!l.length) return null;
    const err = l.map(x => Math.abs(x.est325 - x.official)), dir = l.filter(x => Math.sign(x.est325 - x.spot315) === Math.sign(x.official - x.spot315)).length;
    return { n: l.length, avgErr: err.reduce((a, b) => a + b, 0) / l.length, dirPct: dir / l.length * 100 };
  }

  // =====================================================================================
  // PRICE JUDGE + TRADE PLANS (shared by chain badges, strike checker, alerts and position advice)
  // =====================================================================================
  function judgeCtx(index, useSelected) {
    const d = useSelected ? dataFor(index) : dataNear(index); if (!d) return null;
    const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur;
    const step = C.INDICES[index].step, vf = volFor(index), aiv = atmIv(cur, d.iso);
    let tone = ''; try { const p = predictionFor(index); tone = p ? p.tone : ''; } catch (e) { }
    return { index, iso: d.iso, key: d.key, cur, rows: cur.rows, spot: cur.spot, step, tone,
      atmIv: isFinite(aiv) ? aiv / 100 : (vf ? vf.vol / 100 : 0.13), volPct: vf ? vf.vol : (isFinite(aiv) ? aiv : 13),
      upLevel: nearLevel(index, cur, 'ce'), dnLevel: nearLevel(index, cur, 'pe') };
  }
  function judge(ctx, side, K, ltp) {
    if (!ctx || !(ltp > 0)) return null;
    return C.judgeOption({ side, K, ltp, spot: ctx.spot, iso: ctx.iso, nowMs: Date.now(), atmIv: ctx.atmIv, volPct: ctx.volPct, tone: ctx.tone,
      rows: ctx.rows, upLevel: ctx.upLevel, dnLevel: ctx.dnLevel, step: ctx.step });
  }
  /** which option to buy for a direction, with entry, target exit and stop-loss exit */
  function tradePlan(index, dir, forceStrike, useSelected, extraType) {
    const ctx = judgeCtx(index, !!useSelected); if (!ctx) return null;
    const side = dir === 'up' ? 'ce' : 'pe';
    let K = forceStrike;
    if (!K) {
      const target = side === 'ce' ? ctx.upLevel : ctx.dnLevel;
      const a = C.analyzeStrikes(C.windowRows(ctx.rows, ctx.spot, 12), side, ctx.spot, ctx.iso, Date.now(), st.hilo[ctx.key] || {}, target, { step: ctx.step });
      if (!a.list.length) return null; K = a.list[0].strike;
    }
    const r = ctx.rows.find(x => x.strike === K); if (!r || !(r[side].ltp > 0)) return null;
    const ltp = r[side].ltp, j = judge(ctx, side, K, ltp); if (!j) return null;
    let rs = null; try { rs = rallyStats(ctx, side, K, ltp, j.target, j.tgtLevel); } catch (e) { }
    const S = st.settings, safeOn = S.safe !== false;
    const stop = safeOn ? Math.max(j.stop, ltp * (1 - S.safeStop / 100)) : j.stop;
    const rr = isFinite(j.target) && ltp > stop ? (j.target - ltp) / (ltp - stop) : NaN;
    const plan = { index, dir, side: side.toUpperCase(), strike: K, iso: ctx.iso, ltp, entryMax: ltp * 1.03, target: j.target, stop,
      tgtLevel: j.tgtLevel, stopLevel: j.stopLevel, verdict: j.verdict, rr, ts: Date.now(),
      rally: rs && { count: rs.count, times: rs.times.slice(-3).map(t => hhmm(t.from) + '→' + hhmm(t.at)), need: rs.need, best: rs.best, chance: rs.chance, enough: rs.elapsed >= 30 } };
    if (safeOn) { plan.safe = safeCheck(ctx, plan, extraType); plan.be = ltp * (1 + S.safeBE / 100); }
    return plan;
  }

  // =====================================================================================
  // SAFE MODE — only the strongest setups get a "BUY"; everything else is "No trade"
  // =====================================================================================
  /** losing trades today: Safe-mode plans that hit their stop, or Flattrade positions closed in loss */
  function lossesToday() {
    const today = C.istDate(Date.now());
    const a = REC.plans().filter(x => x.day === today && x.safe === true && x.res === 'stop' && !x.hero).length;
    let b = 0; try { if (FT.ready()) b = (FT.positions.list || []).filter(p => !p.qty && p.rpnl < 0 && parseOpt(p.tsym, p.dname)).length; } catch (e) { }
    return Math.max(a, b);
  }
  function safeCheck(ctx, p, extraType) {
    const S = st.settings, up = p.dir === 'up', now = Date.now(), tp = C.istParts(now), mins = tp.h * 60 + tp.mi;
    const r15 = fut15(), tone = ctx.tone;
    const types = new Set(st.alerts.filter(a => a.index === p.index && now - a.ts < 15 * 60000 && a.tone === (up ? 'bull' : 'bear') && DIRECTIONAL.has(a.type)).map(a => a.type));
    if (extraType) types.add(extraType);
    const ch = p.rally && isFinite(p.rally.chance) ? p.rally.chance * 100 : NaN, losses = lossesToday();
    const exp = isExpiryDay(p.index);
    const checks = [
      { ok: tone === (up ? 'up' : 'dn'), t: `Market read ${up ? 'bullish' : 'bearish'}`, v: tone ? (tone === 'up' ? 'bullish' : tone === 'dn' ? 'bearish' : 'sideways') : 'no read yet' },
      { ok: r15.bias === (up ? 'Bullish' : 'Bearish'), t: 'NIFTY futures agree (15 min)', v: r15.label ? `${r15.label}` : 'no clear buildup' },
      { ok: types.size >= 2, t: '2+ different alerts agree (15 min)', v: `${types.size} agree` },
      { ok: p.verdict === 'Good buy', t: 'Premium is a Good buy', v: p.verdict },
      { ok: ch >= S.safeChance, t: `Chance of target ${S.safeChance}%+`, v: isFinite(ch) ? Math.round(ch) + '%' : 'not known' },
      { ok: p.rr >= S.safeRR, t: `Reward ${S.safeRR}× the risk or more`, v: isFinite(p.rr) ? p.rr.toFixed(1) + '×' : 'no target' },
      { ok: mins >= 9 * 60 + 30 && mins < 15 * 60 + 15 && !(exp && mins >= 14 * 60 + 30), t: 'Good time to enter', v: mins < 9 * 60 + 30 ? 'opening noise (before 9:30)' : exp && mins >= 14 * 60 + 30 ? 'expiry after 2:30 PM' : mins >= 15 * 60 + 15 ? 'closing auction' : 'ok' },
      { ok: losses < S.safeLosses, t: `Under ${S.safeLosses} losses today`, v: `${losses} so far` },
    ];
    return { ok: checks.every(c => c.ok), checks, passed: checks.filter(c => c.ok).length };
  }
  const safeListHtml = sf => `<div class="sfl">${sf.checks.map(c => `<div class="${c.ok ? 'ok' : 'no'}">${c.ok ? '✓' : '✗'} ${c.t}<span>${esc(String(c.v))}</span></div>`).join('')}</div>`;
  function planText(p) {
    if (!p) return '';
    if (p.safe && !p.safe.ok) return `⛔ NO TRADE (Safe mode): ${p.safe.checks.filter(c => !c.ok).map(c => c.t + ' — ' + c.v).join('; ')}.`;
    if (p.hero) return `✅ HERO-ZERO SAFE GO: buy ${fmtK(p.strike)} ${p.side} at or below ₹${f1(p.entryMax)} × ${p.lots} lot${p.lots > 1 ? 's' : ''} (₹${fmtK(p.cost)}). Sell HALF at ₹${f1(p.target)} (2×), trail the rest 30% below its peak. Exit all at ₹${f1(p.stop)} (−50%), after 25 min with no move, or at 3:20 PM.` +
      (p.may ? ` May reach: ${p.may.map(l => `${fmtK(l.L)} → ₹${f1(l.est)} (${pctTxt(l.p)})`).join(', ')}.` : '') + (st.settings.hzPaper !== false ? ' 📝 PAPER-TRADE MODE: watch only.' : '');
    return (p.safe ? '✅ SAFE MODE: all checks passed. ' : '') + `${p.dir === 'up' ? '▲ Market going UP' : '▼ Market going DOWN'} → Buy ${fmtK(p.strike)} ${p.side} at or below ₹${f1(p.entryMax)} (now ₹${f2(p.ltp)}). ` +
      `Exit at ₹${isFinite(p.target) ? f1(p.target) : '–'}${isFinite(p.tgtLevel) ? ` (if ${p.index} reaches ${fmtK(p.tgtLevel)})` : ''}. ` +
      `Stop-loss ₹${f1(p.stop)}${isFinite(p.stopLevel) ? ` (if ${p.index} breaks ${fmtK(p.stopLevel)})` : ''}. Premium: ${p.verdict}.` + (p.be ? ` When it reaches ₹${f1(p.be)}, move the stop to your buy price.` : '') + rallyText(p);
  }
  function rallyText(p) {
    const r = p && p.rally; if (!r) return '';
    return ` Rallied +${Math.round(r.need * 100)}% from a bottom ${r.count}× today${r.times.length ? ` (${r.times.join(', ')})` : ''}.` +
      (isFinite(r.chance) ? ` Chance of reaching the target again before 3:30: ${Math.round(r.chance * 100)}%.` : '');
  }
  function rallyHtml(p) {
    const r = p && p.rally; if (!r) return '';
    const pc = isFinite(r.chance) ? Math.round(r.chance * 100) : null;
    const cc = pc === null ? '' : pc >= 50 ? 'up' : pc >= 30 ? 'am' : 'dn';
    return `<div class="tpr"><div class="tprr"><span>Reached from bottom today</span><b>${r.count}×</b></div>
      <div class="tprt">${r.count ? `Rose +${Math.round(r.need * 100)}% from a low (the gain this trade needs): ${r.times.join(', ')}` : `Has not risen +${Math.round(r.need * 100)}% from a low yet today${r.enough ? '' : ' (still collecting data)'}`}${r.best > 0 ? ` · best rally +${Math.round(r.best * 100)}%` : ''}</div>
      ${pc === null ? '' : `<div class="tprr"><span>Chance of reaching target again</span><b class="${cc}">${pc}%</b></div><div class="pbar"><div class="${cc}" style="width:${pc}%"></div></div>`}</div>`;
  }
  function planHtmlBox(p) {
    if (!p) return '';
    if (p.safe && !p.safe.ok) return `<div class="tplan nt"><div class="tph">⛔ No trade<span class="vj x">${p.safe.passed}/${p.safe.checks.length} checks</span></div>
      <div class="tpn">Safe mode: conditions are not strong enough. Waiting is a decision too.</div>${safeListHtml(p.safe)}
      <div class="tpn">Best candidate was ${fmtK(p.strike)} ${p.side} at ₹${f2(p.ltp)} (${p.dir === 'up' ? 'market up' : 'market down'}).</div></div>`;
    if (p.hero) return heroPlanBox(p);
    return `${p.safe ? `<div class="sfok">✅ Safe mode: all ${p.safe.checks.length} checks passed</div>` : ''}<div class="tplan ${p.dir === 'up' ? 'up' : 'dn'}"><div class="tph">${p.dir === 'up' ? '▲ Market going UP' : '▼ Market going DOWN'} <span class="vj ${vjCls(p.verdict)}">${p.verdict}</span></div>
      <div class="tpg num"><div><span>Buy</span><b>${fmtK(p.strike)} ${p.side}</b></div><div><span>Entry ≤</span><b>₹${f1(p.entryMax)}</b></div>
      <div><span>Exit (target)</span><b class="up">₹${isFinite(p.target) ? f1(p.target) : '–'}</b></div><div><span>Stop-loss</span><b class="dn">₹${f1(p.stop)}</b></div></div>
      <div class="tpn">Now ₹${f2(p.ltp)}${isFinite(p.tgtLevel) ? ` · target if ${p.index} ${fmtK(p.tgtLevel)}` : ''}${isFinite(p.stopLevel) ? ` · stop if ${fmtK(p.stopLevel)} breaks` : ''}</div>${p.be ? `<div class="tpn">🔒 At ₹${f1(p.be)} (+${st.settings.safeBE}%) move the stop to ₹${f1(p.ltp)}: a winner can't become a loss.</div>` : ''}${rallyHtml(p)}${tradeBtn({ i: p.index, k: p.strike, s: p.side, t: 'B', iso: p.iso, p: tick05(p.entryMax), safe: p.safe ? p.safe.ok : null, why: 'alert plan' }, `🛒 Buy ${fmtK(p.strike)} ${p.side}`, 'buy wide')}</div>`;
  }
  const vjCls = v => v === 'Good buy' ? 'g' : v === 'Expensive' ? 'x' : 'f';
  const DIRECTIONAL = new Set(['reversal', 'reversalWarn', 'rangeBreak', 'resShift', 'supShift', 'resForecast', 'supForecast', 'heroSignal', 'futFlip', 'oiDecline', 'zeroFlip', 'strikeDump', 'bigOi']);
  function attachPlan(a) {
    if (!DIRECTIONAL.has(a.type) || (a.tone !== 'bull' && a.tone !== 'bear') || a.index === undefined) return;
    if (!C.marketOpen(Date.now()) || C.istParts(Date.now()).h * 60 + C.istParts(Date.now()).mi >= 15 * 60 + 15) return;   // no new buys during the auction
    let force = null;
    if (a.type === 'heroSignal') {
      if (st.settings.hzSafe !== false) { try { a.plan = heroPlan(a.index, a.tone === 'bull' ? 'CE' : 'PE'); } catch (e) { a.plan = null; } return; }
      const hz = heroFor(a.index); if (hz && hz.picks[0]) force = hz.picks[0].strike;
    }
    try { a.plan = tradePlan(a.index, a.tone === 'bull' ? 'up' : 'down', force, false, a.type); } catch (e) { a.plan = null; }
  }

  // =====================================================================================
  // HERO-ZERO SAFE MODE — fixed budget, max 2 tries, strict entry, fixed exit rules
  // =====================================================================================
  function heroTries(index) { const k = C.istDate(Date.now()) + '|' + index; return (st.hzGo = st.hzGo || store.get('oi.hz.go', {}))[k] || []; }
  function heroPlan(index, side) {
    const e = hzEval(index); if (!e) return null;
    const now = Date.now(), b = e.best, up = e.useSide === 'CE';
    const checks = e.req.concat([{ ok: e.nConf >= e.need, t: `${e.need}+ confirmations (HZ tab)`, v: `${e.nConf} of ${e.conf.length}` }]);
    const safe = { ok: e.go, checks, passed: checks.filter(c => c.ok).length };
    const p = b ? { index, dir: up ? 'up' : 'down', side: e.useSide, strike: b.strike, iso: e.ctx.iso, ltp: b.ltp, entryMax: b.ltp * 1.03, target: b.ltp * 2, stop: b.ltp * 0.5,
      tgtLevel: NaN, stopLevel: NaN, verdict: 'Hero-zero', rr: 2, ts: now, hero: true, lots: e.lots, cost: e.lots * e.lot * b.ltp, reach: b.reach, safe,
      may: e.reach && e.reach.levels.length ? e.reach.levels : null }
      : { index, dir: up ? 'up' : 'down', side: e.useSide, strike: NaN, ltp: NaN, hero: true, safe };
    if (e.go && b) { const tries = heroTries(index); if (!tries.some(t => now - t.ts < 20 * 60000)) { tries.push({ ts: now, strike: b.strike, side: e.useSide }); st.hzGo[C.istDate(now) + '|' + index] = tries; store.set('oi.hz.go', st.hzGo); } }
    return p;
  }
  function heroPlanBox(p) {
    return `<div class="sfok">✅ Hero-zero Safe mode: all ${p.safe.checks.length} checks passed</div><div class="tplan ${p.side === 'CE' ? 'up' : 'dn'}"><div class="tph">🚀 Hero-zero GO <span class="vj g">${p.lots} lot${p.lots > 1 ? 's' : ''} · ₹${fmtK(p.cost)}</span></div>
      <div class="tpg num"><div><span>Buy</span><b>${fmtK(p.strike)} ${p.side}</b></div><div><span>Entry ≤</span><b>₹${f1(p.entryMax)}</b></div>
      <div><span>Sell HALF at (2×)</span><b class="up">₹${f1(p.target)}</b></div><div><span>Loss cap (−50%)</span><b class="dn">₹${f1(p.stop)}</b></div></div>
      <div class="tpn">Then trail the rest: exit if it falls 30% from its peak. No move in 25 min → exit. Last exit 3:20 PM. Reach chance ${Math.round(p.reach * 100)}%.</div>
      ${p.may ? `<div class="tpn">May reach: ${p.may.map(l => `${p.index} ${fmtK(l.L)} → ₹${f1(l.est)} (${l.x.toFixed(1)}×, ${pctTxt(l.p)})`).join(' · ')}</div>` : ''}
      <div class="tpn">Most hero-zero trades lose the small budget. Only use money you are ready to lose fully.</div></div>`;
  }
  /** Hero-zero Safe plan card inside the Hero-zero box (expiry day) */
  function heroSafeHtml(index, hz) {
    if (st.settings.hzSafe === false || !hz || !(hz.state === 'CE' || hz.state === 'PE')) return '';
    const p = heroPlanPeek(index, hz.state);
    if (!p) return '';
    return `<div class="hzsafe"><div class="hzsh">${p.safe.ok ? '✅ Safe GO' : '⛔ No trade yet'} · Hero-zero Safe mode <span>${p.safe.passed}/${p.safe.checks.length}</span></div>
      ${p.safe.ok ? heroPlanBox(p) : safeListHtml(p.safe)}
      <div class="hzcap">Budget ₹${fmtK(st.settings.hzBudget)} per expiry · max ${st.settings.hzTries} tries · ${heroTries(index).length} used today.</div><button class="btn ghost" data-gohz="1" style="margin-top:6px;padding:7px 10px;font-size:12px">Open HZ: strike, entry, reasons, how far it may go →</button></div>`;
  }
  /** HZ: refresh market breadth in the hero window and alert on a speed burst in the signal direction */
  function hzTick(index, expiry) {
    if (!isExpiryDay(index)) return;
    const m = hzMins(); if (m < st.settings.heroStart - 60 || m > 15 * 60 + 20) return;
    fetchHzx(false).catch(() => { });
    let e = null; try { e = hzEval(index); } catch (x) { console.error(x); }
    if (e && e.movers.length) {
      const mv = e.movers[0], match = e.side && mv.side === e.side;
      fire('hzMove', index, expiry, `🔥 ${index} ${fmtK(mv.strike)} ${mv.side} moving: +${mv.g.toFixed(0)}% in ${mv.mins} min`,
        `${moverTxt(mv)}.${match ? ` Same side as the hero-zero trigger (${e.trig.how === 'straddle' ? 'straddle spike' : 'writers exiting'}).` : e.side ? ` Opposite to the ${e.side} trigger: careful.` : ' No trigger yet: open HZ before buying.'}`,
        mv.side === 'CE' ? 'bull' : 'bear', mv.strike + mv.side, 15, match ? 'critical' : null);
    }
    if (e && e.trig.forming && !e.side) fire('hzTrigger', index, expiry, `⏳ ${index} hero-zero forming: ${e.trig.forming} side`, e.trig.txt, e.trig.forming === 'CE' ? 'bull' : 'bear', 'form' + e.trig.forming, 60);
    const sp = hzSpeed(index), hz = heroFor(index); if (!sp.dir || m < st.settings.heroStart) return;
    const side = sp.dir === 'up' ? 'CE' : 'PE', withSignal = hz && hz.state === side;
    fire('hzSpeed', index, expiry, `⚡ ${index} speed burst ${sp.dir === 'up' ? '▲' : '▼'} ${sgn(Math.round(sp.pts), fmtK)} pts in 2 min`,
      `${withSignal ? `In the direction of the ${side} hero-zero signal. ` : ''}Open HZ to see the strike, entry and how far it may go.`, sp.dir === 'up' ? 'bull' : 'bear', sp.dir + Math.floor(Date.now() / 300000), 5, withSignal ? 'critical' : null);
  }
  /** when every Hero-zero Safe check passes, send one GO alert (counts as a try) */
  function heroSafeTick(index, expiry) {
    if (st.settings.hzSafe === false || !isExpiryDay(index)) return;
    const hz = heroFor(index); if (!hz || !(hz.state === 'CE' || hz.state === 'PE')) return;
    const p = heroPlanPeek(index, hz.state); if (!p || !p.safe.ok) return;
    if (heroTries(index).some(t => Date.now() - t.ts < 20 * 60000)) return;
    fire('heroSignal', index, expiry, `🚀 ${index} HERO-ZERO SAFE GO: ${fmtK(p.strike)} ${p.side}`, `All Hero-zero Safe checks passed. Budget ₹${fmtK(st.settings.hzBudget)}.`,
      p.side === 'CE' ? 'bull' : 'bear', 'safego' + p.strike, 20, 'critical');
  }
  /** same as heroPlan but never counts a try (for display) */
  function heroPlanPeek(index, side) {
    const saved = JSON.stringify(st.hzGo || {}); const p = heroPlan(index, side); st.hzGo = JSON.parse(saved); store.set('oi.hz.go', st.hzGo); return p;
  }

  // =====================================================================================
  // HZ — hero-zero workbench: one place to pick the strike, the entry, why, and where it may reach
  // =====================================================================================
  const HZ_HEAVY = ['HDFCBANK', 'RELIANCE', 'ICICIBANK', 'INFY', 'BHARTIARTL', 'TCS', 'LT', 'ITC'];
  const HZ_SPEED = { NIFTY: 25, SENSEX: 80 };            // points in ~2 minutes = a burst
  /** spot ticks for the speed check (live feed every 2 s, chain every minute) */
  function tickPush(index, spot) {
    if (!(spot > 0)) return;
    const T = (st.tick = st.tick || {})[index] = (st.tick || {})[index] || [], now = Date.now();
    if (T.length && now - T[T.length - 1].t < 1500) return;
    T.push({ t: now, s: spot }); while (T.length && now - T[0].t > 12 * 60000) T.shift();
  }
  /** breadth, heavyweights, sister index and Europe (every 3 min in the hero window or while HZ is open) */
  async function fetchHzx(force) {
    const now = Date.now(), x = st.hzx || {};
    if (!force && x.at && now - x.at < 3 * 60000) return x;
    const out = Object.assign({}, x, { at: now });
    try {
      const j = await nseGet('/api/equity-stockIndices?index=' + encodeURIComponent('NIFTY 50'));
      const adv = j.advance || {}, data = (j.data || []).filter(r => r.symbol && r.symbol !== 'NIFTY 50');
      out.adv = +adv.advances || data.filter(r => +r.pChange > 0).length; out.dec = +adv.declines || data.filter(r => +r.pChange < 0).length;
      out.heavy = HZ_HEAVY.map(sy => { const r = data.find(d => d.symbol === sy); return r ? { s: sy, p: +r.pChange, lp: +r.lastPrice } : null; }).filter(Boolean);
    } catch (e) { out.breadthErr = (e && e.msg) || 'breadth not available'; }
    try {
      const j = await nseGet('/api/allIndices'), d = j.data || [];
      const f = re => d.find(r => re.test(r.index || r.indexSymbol || ''));
      const bank = f(/^NIFTY BANK$/i), nf = f(/^NIFTY 50$/i);
      if (bank) out.bank = { lp: +bank.last, pct: +bank.percentChange }; if (nf) out.nifty = { lp: +nf.last, pct: +nf.percentChange };
    } catch (e) { }
    await Promise.all([['dax', '^GDAXI'], ['ftse', '^FTSE']].map(async ([k, sym]) => {
      try {
        const r = await http('GET', `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?range=1d&interval=5m`, { 'User-Agent': UA, 'Accept': 'application/json' });
        const jj = parseJson(r.text), m = jj && jj.chart && jj.chart.result && jj.chart.result[0] && jj.chart.result[0].meta;
        if (m && m.regularMarketPrice > 0) { const prev = m.chartPreviousClose || m.previousClose; out[k] = { lp: m.regularMarketPrice, pct: prev ? (m.regularMarketPrice / prev - 1) * 100 : NaN }; }
      } catch (e) { }
    }));
    // baseline at the start of the hero window, so "since 1:30" moves can be compared
    const tp = C.istParts(now), mins = tp.h * 60 + tp.mi, day = C.istDate(now);
    if (mins >= st.settings.heroStart && (!out.base || out.base.day !== day)) out.base = { at: now, day, heavy: out.heavy, bank: out.bank, nifty: out.nifty, dax: out.dax, ftse: out.ftse, adv: out.adv, dec: out.dec };
    if (out.base && out.base.day !== day) out.base = null;
    st.hzx = out; store.set('oi.hzx', out);
    return out;
  }
  const hzMins = () => { const p = C.istParts(Date.now()); return p.h * 60 + p.mi; };
  const pv = (pt, K, i) => { const a = pt.p[K]; return a && a[i] > 0 ? a[i] : NaN; };
  /** ATM straddle (CE + PE at today's ATM): melting = normal; rising off its low = market waking up */
  function hzStraddle(ctx, P) {
    const K = ctx.rows.reduce((b, r) => Math.abs(r.strike - ctx.spot) < Math.abs(b - ctx.spot) ? r.strike : b, ctx.rows[0].strike);
    const pts = P.filter(x => isFinite(pv(x, K, 0)) && isFinite(pv(x, K, 1))).map(x => ({ m: x.m, v: pv(x, K, 0) + pv(x, K, 1) }));
    const r = ctx.rows.find(x => x.strike === K), now = r ? r.ce.ltp + r.pe.ltp : NaN;
    if (pts.length < 10 || !(now > 0)) return { K, now, ok: null, txt: 'Collecting straddle prices (needs about 10 minutes of data).' };
    const nowM = hzMins(), last60 = pts.filter(x => x.m >= nowM - 60);
    const low = last60.reduce((b, x) => x.v < b.v ? x : b, last60[0] || pts[pts.length - 1]);
    const ago5 = pts.filter(x => x.m <= nowM - 5).slice(-1)[0];
    const fromLow = (now / low.v - 1) * 100, rising = ago5 ? now > ago5.v : false;
    const ok = fromLow >= 8 && rising;
    return { K, now, low: low.v, lowM: low.m, fromLow, rising, ok,
      txt: ok ? `ATM ${fmtK(K)} straddle ₹${f1(now)} is up ${fromLow.toFixed(0)}% from its low ₹${f1(low.v)} at ${hhmm(low.m)}: options are waking up.`
        : `ATM ${fmtK(K)} straddle ₹${f1(now)} (low ₹${f1(low.v)} at ${hhmm(low.m)}, ${fromLow >= 0 ? '+' : ''}${fromLow.toFixed(0)}%): still melting, no burst yet.` };
  }
  /** quiet midday range, then a break of the day's high or low after the hero start time */
  function hzSqueeze(ctx, P, index) {
    if (P.length < 30) return { ok: null, brk: '', txt: 'Collecting the day\'s range…' };
    const S = st.settings, nowM = hzMins();
    const all = P.map(x => x.s), hi = Math.max(...all), lo = Math.min(...all), dr = hi - lo;
    const mid = P.filter(x => x.m >= 12 * 60 && x.m < S.heroStart).map(x => x.s);
    const wr = mid.length >= 20 ? Math.max(...mid) - Math.min(...mid) : NaN;
    const squeeze = isFinite(wr) && dr > 0 && wr <= dr * 0.4;
    const before = P.filter(x => x.m < nowM - 3).map(x => x.s);
    const bHi = before.length ? Math.max(...before) : hi, bLo = before.length ? Math.min(...before) : lo;
    const brk = nowM >= S.heroStart ? (ctx.spot > bHi ? 'up' : ctx.spot < bLo ? 'down' : '') : '';
    return { squeeze, wr, dr, hi: bHi, lo: bLo, brk,
      txt: `${squeeze ? `Squeeze: only ${fmtK(wr)} pts from 12:00 to ${hhmm(S.heroStart)} (day range ${fmtK(dr)}).` : isFinite(wr) ? `Midday range ${fmtK(wr)} pts of a ${fmtK(dr)}-pt day: no squeeze.` : `Day range ${fmtK(dr)} pts.`} ` +
        (brk === 'up' ? `🚀 Broke the day high ${fmtK(bHi)}.` : brk === 'down' ? `🚀 Broke the day low ${fmtK(bLo)}.` : `Day high ${fmtK(bHi)} · low ${fmtK(bLo)}: no break yet.`) };
  }
  /** speed: points moved in the last ~2 minutes (live ticks) */
  function hzSpeed(index) {
    const T = (st.tick || {})[index] || [], now = Date.now(); if (T.length < 2) return { pts: NaN, dir: '', ok: null, txt: 'Waiting for live prices (Flattrade feed gives second-by-second speed).' };
    const cur = T[T.length - 1], ago = T.filter(x => now - x.t >= 110000).slice(-1)[0] || T[0];
    const mins = (cur.t - ago.t) / 60000; if (mins < 0.5) return { pts: NaN, dir: '', ok: null, txt: 'Collecting live prices…' };
    const pts = (cur.s - ago.s) * (2 / Math.max(2, mins)), lim = HZ_SPEED[index] || 25;
    const dir = pts >= lim ? 'up' : pts <= -lim ? 'down' : '';
    return { pts, dir, ok: !!dir, txt: dir ? `⚡ ${index} moved ${sgn(pts, fmtK)} pts in 2 min: a burst ${dir}.` : `${sgn(Math.round(pts), fmtK)} pts in the last 2 min (burst = ${lim}+).` };
  }
  /** traded volume of a strike in the last 5 min vs its afternoon average */
  function hzVolume(P, K, side) {
    const i = side === 'ce' ? 2 : 3, pi = side === 'ce' ? 0 : 1, nowM = hzMins();
    const pts = P.filter(x => x.p[K] && x.p[K][i] > 0 && x.m >= 12 * 60);
    if (pts.length < 15) return { ok: null, txt: 'Collecting volume for this strike…' };
    const last = pts[pts.length - 1], ago = pts.filter(x => x.m <= nowM - 5).slice(-1)[0];
    if (!ago) return { ok: null, txt: 'Collecting volume…' };
    const v5 = last.p[K][i] - ago.p[K][i], span = Math.max(5, last.m - pts[0].m), avg5 = (last.p[K][i] - pts[0].p[K][i]) / span * 5;
    const x = avg5 > 0 ? v5 / avg5 : NaN, priceOk = last.p[K][pi] >= ago.p[K][pi] * 0.97;
    const ok = x >= 3 && priceOk;
    return { ok, x, v5, txt: isFinite(x) ? `Last 5 min volume ${C.fmtQ ? C.fmtQ(v5) : fmtK(v5)} = ${x.toFixed(1)}× its afternoon average${ok ? ', price holding: big buyers in.' : x >= 3 ? ', but price is falling (sellers).' : '.'}` : 'No volume data.' };
  }
  /** heavyweights + breadth, sister index, Europe, all since the hero start (or on the day) */
  function hzMarket(index, up) {
    const x = st.hzx || {}, b = x.base && Date.now() - (x.base.at || 0) >= 10 * 60000 ? x.base : null, out = {};
    const chg = (now, base) => now && isFinite(now.pct) ? (base && isFinite(base.pct) ? now.pct - base.pct : now.pct) : NaN;
    if (x.heavy && x.heavy.length) {
      const moves = x.heavy.map(h => { const bh = b && b.heavy ? b.heavy.find(y => y.s === h.s) : null; return { s: h.s, d: bh ? h.p - bh.p : h.p }; });
      const agree = moves.filter(m => up ? m.d > 0.05 : m.d < -0.05).length, against = moves.filter(m => up ? m.d < -0.05 : m.d > 0.05).length;
      const ad = isFinite(x.adv) && isFinite(x.dec) ? `${x.adv} up / ${x.dec} down` : '';
      out.breadth = { ok: agree >= 5 && (!isFinite(x.adv) || (up ? x.adv > x.dec : x.dec > x.adv)), txt: `Heavyweights ${agree}/${moves.length} moving ${up ? 'up' : 'down'}${b ? ' since ' + hhmm(st.settings.heroStart) : ''}${ad ? ` · NIFTY 50: ${ad}` : ''}. ${moves.slice(0, 5).map(m => `${m.s} ${sgn(m.d, v => v.toFixed(2))}%`).join(', ')}`, agree, against };
    } else out.breadth = { ok: null, txt: x.breadthErr ? 'Breadth not reachable right now.' : 'Loading heavyweights and breadth…' };
    const sis = index === 'NIFTY' ? x.bank : x.nifty, sisName = index === 'NIFTY' ? 'BANKNIFTY' : 'NIFTY';
    const sd = chg(sis, b && (index === 'NIFTY' ? b.bank : b.nifty)), eu = [chg(x.dax, b && b.dax), chg(x.ftse, b && b.ftse)].filter(isFinite);
    const euAvg = eu.length ? eu.reduce((a, v) => a + v, 0) / eu.length : NaN;
    const sOk = isFinite(sd) ? (up ? sd > 0.1 : sd < -0.1) : null, eOk = isFinite(euAvg) ? (up ? euAvg > 0.1 : euAvg < -0.1) : null;
    out.sister = { ok: sOk === null && eOk === null ? null : (sOk === true && eOk !== false) || (eOk === true && sOk !== false),
      txt: `${sisName} ${isFinite(sd) ? sgn(sd, v => v.toFixed(2)) + '%' : '–'} · Europe (DAX/FTSE) ${isFinite(euAvg) ? sgn(euAvg, v => v.toFixed(2)) + '%' : '–'}${b ? ' since ' + hhmm(st.settings.heroStart) : ' today'}.` };
    return out;
  }
  /** strikes worth buying for a hero-zero: most acceleration (gamma) per rupee, liquid, within reach */
  function hzCandidates(ctx, side, index) {
    const S = st.settings, sd = side.toLowerCase(), call = side === 'CE', now = Date.now();
    const T = C.yearsToExpiry(ctx.iso, now), vf = volFor(index), left = C.minsLeft(now);
    const em = vf ? C.expMove(ctx.spot, vf.vol, Math.max(5, left)) : NaN;
    const vols = ctx.rows.map(r => r[sd].vol || 0).filter(v => v > 0).sort((a, b) => a - b), vMed = vols.length ? vols[Math.floor(vols.length / 2)] : 0;
    const out = [];
    for (const r of ctx.rows) {
      const o = r[sd], v = o.ltp; if (!(v >= S.heroMin && v <= S.heroMax)) continue;
      const dist = call ? r.strike - ctx.spot : ctx.spot - r.strike; if (dist <= 0) continue;
      if (isFinite(em) && dist > em * 2) continue;
      const iv = C.impliedVol(v, ctx.spot, r.strike, T, call) || ctx.atmIv, g = C.bs(ctx.spot, r.strike, T, iv, call);
      const delta = Math.abs(g.delta); if (!(delta >= 0.04 && delta <= 0.45)) continue;
      const spread = o.bid > 0 && o.ask > 0 ? (o.ask - o.bid) / v : NaN;
      const liquid = (isFinite(spread) ? spread <= 0.08 : true) && (!vMed || (o.vol || 0) >= vMed * 0.3);
      const reach = reachProb(index, ctx.spot, r.strike);
      const gpr = delta / v;                                    // premium gain per index point, as a share of price
      const sweet = Math.exp(-Math.pow((delta - 0.2) / 0.1, 2));  // delta ~0.15–0.25 accelerates best per rupee
      out.push({ strike: r.strike, ltp: v, delta, gamma: g.gamma, gpr, iv, reach, dist, spread, vol: o.vol || 0, liquid, score: (g.gamma / v) * (0.3 + sweet) * (0.5 + (isFinite(reach) ? reach : 0)) * (liquid ? 1 : 0.4) });
    }
    return out.sort((a, b) => b.score - a.score);
  }
  /** where it may reach: index levels with estimated premium and the chance, plus "if nothing moves" */
  function hzReach(ctx, side, K, ltp, index, road) {
    const sd = side.toLowerCase(), up = side === 'CE', now = Date.now(), vf = volFor(index);
    const nowM = hzMins(), to320 = Math.max(1, 15 * 60 + 20 - nowM), sig = vf ? C.expMove(ctx.spot, vf.vol, to320) : NaN;
    const lv = [];
    const add = (L, why) => { if (!isFinite(L)) return; L = Math.round(L / ctx.step) * ctx.step; if ((up ? L <= ctx.spot : L >= ctx.spot) || lv.some(x => x.L === L)) return;
      const est = C.estPrice(ctx.rows, sd, K, ctx.spot, L), p = isFinite(sig) ? C.touchProb(Math.abs(L - ctx.spot), sig) : NaN;
      if (isFinite(est) && est > 0) lv.push({ L, est, x: est / ltp, p, why }); };
    if (isFinite(sig)) { add(ctx.spot + (up ? 0.5 : -0.5) * sig, 'a normal move'); add(ctx.spot + (up ? 1 : -1) * sig, 'a strong move'); }
    if (road && isFinite(road.end)) add(road.end, road.wall ? `the writers' wall ${fmtK(road.wall)}` : 'end of the open road');
    add(K, 'the strike itself');
    lv.sort((a, b) => up ? a.L - b.L : b.L - a.L);
    // nothing moves: premium at 3:20 with spot unchanged
    const T = C.yearsToExpiry(ctx.iso, now), T320 = Math.max(1e-6, T - to320 / (365 * 24 * 60));
    const iv = C.impliedVol(ltp, ctx.spot, K, T, up) || ctx.atmIv, flat = C.bs(ctx.spot, K, T320, iv, up).price;
    return { levels: lv, sig, flat, to320 };
  }
  // ---------- HZ early triggers: writers exiting (early threshold) OR an ATM straddle spike ----------
  function hzTrigger(index, ctx, P, hz, str) {
    const S = st.settings, early = S.heroEarly || 50;
    const ce = hz && hz.ce ? hz.ce.drop : 0, pe = hz && hz.pe ? hz.pe.drop : 0;
    if (ce >= early && ce - pe >= 20) return { side: 'CE', how: 'writers', txt: `Call writers exiting: near-ATM CE OI change down ${Math.round(ce)}% from today's peak.` };
    if (pe >= early && pe - ce >= 20) return { side: 'PE', how: 'writers', txt: `Put writers exiting: near-ATM PE OI change down ${Math.round(pe)}% from today's peak.` };
    if (str && str.ok) {
      const K = str.K, nowM = hzMins(), win = P.filter(x => x.m >= nowM - 30);
      const leg = i => { const v = win.map(x => pv(x, K, i)).filter(isFinite); const r = ctx.rows.find(x => x.strike === K); const now = r ? (i ? r.pe.ltp : r.ce.ltp) : NaN;
        const lo = v.length ? Math.min(...v) : NaN; return lo > 0 && now > 0 ? (now / lo - 1) * 100 : NaN; };
      const cu = leg(0), pu = leg(1);
      const side = isFinite(cu) && isFinite(pu) ? (cu >= pu ? 'CE' : 'PE') : isFinite(cu) ? 'CE' : 'PE';
      const g = side === 'CE' ? cu : pu;
      if (g >= 15) return { side, how: 'straddle', txt: `ATM straddle spiking (+${str.fromLow.toFixed(0)}% off its low); the ${side} leg is up ${g.toFixed(0)}% in 30 min.` };
    }
    if (ce >= early && pe >= early) return { side: '', how: 'both', txt: `Both sides' OI change falling (CE −${Math.round(ce)}%, PE −${Math.round(pe)}%): wait for one side.` };
    const lean = ce > pe ? 'CE' : pe > ce ? 'PE' : '';
    return { side: '', how: '', txt: `No trigger yet. Writers: CE OI change −${Math.round(ce)}%, PE −${Math.round(pe)}% from peak (trigger at ${early}%).`, lean, forming: Math.max(ce, pe) >= Math.min(40, early - 10) ? lean : '' };
  }
  /** "Moving now": cheap strikes whose premium is already jumping (the 7 → 26 kind of move) */
  function hzMovers(ctx, P, index) {
    const S = st.settings, nowM = hzMins(), out = [];
    const win = P.filter(x => x.m >= nowM - 10); if (win.length < 3) return out;
    for (const r of ctx.rows) for (const [i, sd] of [[0, 'ce'], [1, 'pe']]) {
      const v = r[sd].ltp; if (!(v >= 3 && v <= Math.max(S.heroMax, 40))) continue;
      if (sd === 'ce' ? r.strike < ctx.spot - ctx.step : r.strike > ctx.spot + ctx.step) continue;
      let lo = Infinity, loM = 0; for (const x of win) { const p = pv(x, r.strike, i); if (p > 0 && p < lo) { lo = p; loM = x.m; } }
      if (!(lo >= 1)) continue;
      const g = (v / lo - 1) * 100;
      if (g >= (S.hzMove || 30) && v - lo >= 2) out.push({ strike: r.strike, side: sd.toUpperCase(), lo, loM, v, g, mins: Math.max(1, nowM - loM) });
    }
    return out.sort((a, b) => b.g - a.g).slice(0, 4);
  }
  const moverTxt = m => `${fmtK(m.strike)} ${m.side} ₹${f1(m.lo)} → ₹${f1(m.v)} (+${m.g.toFixed(0)}% in ${m.mins} min)`;
  /** remember when the hero-zero trade started forming, triggered and turned GO (and log the triggered strike) */
  function hzStamp(e) {
    if (!e || !isExpiryDay(e.index)) return null;
    const day = C.istDate(Date.now()), k = day + '|' + e.index, T = (st.hzTimes = st.hzTimes || store.get('oi.hz.times', {}));
    const t = T[k] = T[k] || {}; let ch = false;
    if (!t.forming && (e.trig.side || e.trig.forming)) { t.forming = Date.now(); t.formSide = e.trig.side || e.trig.forming; ch = true; }
    const nm = hzMins(), inWin = nm >= st.settings.heroStart && nm < 15 * 60 + 10;
    if (!t.trigger && inWin && e.trig.side && e.best) { t.trigger = Date.now(); t.how = e.trig.how; t.side = e.trig.side; t.strike = e.best.strike; t.ltp = e.best.ltp; ch = true;
      const log = REC.hero(), cur = e.ctx.cur;
      if (heroAdd(log, { id: Date.now() + 'z' + e.best.strike, day, index: e.index, expiry: e.ctx.iso, strike: e.best.strike, side: e.useSide, src: 'HZ trigger', entry: e.best.ltp, entryTs: Date.now(), spot0: e.ctx.spot,
        vol: (volFor(e.index) || {}).vol, reach: e.best.reach, targets: [{ lbl: '2x', price: e.best.ltp * 2 }, { lbl: '3x', price: e.best.ltp * 3 }, { lbl: '5x', price: e.best.ltp * 5 }], peak: e.best.ltp, peakTs: Date.now() })) REC.setHero(log);
      fire('hzTrigger', e.index, e.ctx.iso, `🎯 ${e.index} hero-zero strike: ${fmtK(e.best.strike)} ${e.useSide} ₹${f2(e.best.ltp)}`,
        `${e.trig.txt} Buy at or below ₹${f1(e.best.ltp * 1.03)}. ${e.go ? 'All checks passed: GO.' : `Not GO yet (${e.nConf}/${e.conf.length} confirmations). Watch HZ.`}`, e.useSide === 'CE' ? 'bull' : 'bear', 'trig' + e.best.strike, 30, e.go ? 'critical' : null); }
    else if (t.trigger && inWin && e.trig.side && e.best && e.trig.side !== (t.side2 || t.side)) {   // the side flipped later in the day
      t.side2 = e.trig.side; t.trigger2 = Date.now(); t.how2 = e.trig.how; t.strike2 = e.best.strike; t.ltp2 = e.best.ltp; ch = true;
      fire('hzTrigger', e.index, e.ctx.iso, `🔁 ${e.index} hero-zero switched to ${e.trig.side}: ${fmtK(e.best.strike)} ${e.useSide} ₹${f2(e.best.ltp)}`, e.trig.txt, e.useSide === 'CE' ? 'bull' : 'bear', 'flip' + e.best.strike, 30); }
    if (!t.go && e.go) { t.go = Date.now(); ch = true; }
    for (const k2 of Object.keys(T)) if (!k2.startsWith(day)) delete T[k2];
    if (ch) store.set('oi.hz.times', T);
    return t;
  }
  function hzTimesTxt(index) {
    const t = (st.hzTimes || store.get('oi.hz.times', {}))[C.istDate(Date.now()) + '|' + index]; if (!t) return '';
    const bits = [];
    if (t.forming) bits.push(`forming ${C.istTime(t.forming)}${t.formSide ? ' (' + t.formSide + ')' : ''}`);
    if (t.trigger) bits.push(`strike given ${C.istTime(t.trigger)} (${t.how === 'straddle' ? 'straddle spike' : 'writers exiting'}: ${fmtK(t.strike)} ${t.side} ₹${f2(t.ltp)})`);
    if (t.trigger2) bits.push(`switched to ${t.side2} ${C.istTime(t.trigger2)} (${fmtK(t.strike2)} ${t.side2} ₹${f2(t.ltp2)})`);
    if (t.go) bits.push(`GO ${C.istTime(t.go)}`);
    return bits.join(' → ');
  }

  // ---------- data source notice (top of the app) ----------
  function srcStripHtml() {
    const now = Date.now();
    return Object.keys(C.INDICES).map(i => {
      const exps = st.expiries[i] || [], key = i + '|' + (exps[0] || ''), lv = st.live[key], h = st.snaps[key] || [];
      const ts = Math.max(lv ? lv.ts : 0, h.length ? h[h.length - 1].ts : 0), src = st.srcUsed[i] || C.INDICES[i].src;
      const live = isLive(src) && lv && now - lv.ts < 15000, age = ts ? Math.round((now - ts) / 1000) : NaN;
      const oi = st.oiSrc && st.oiSrc[i] && st.oiSrc[i] !== src ? ` · OI ${st.oiSrc[i]}` : '';
      const cl = st.errors[i] ? 'err' : !ts ? '' : live || age < 150 ? 'ok' : 'stale';
      const ageTxt = !ts ? 'waiting' : live ? 'live' : age < 90 ? `${age}s ago` : `${Math.round(age / 60)} min ago`;
      return `<span class="src ${cl}"><b>${i}</b> ${esc(src)}${oi} · ${ageTxt}${st.errors[i] ? ' · retrying' : ''}</span>`;
    }).join('');
  }

  // ---------- separate purchases of the same strike (Flattrade trade book, first-in first-out) ----------
  function ftTime(s) { const m = /(\d{1,2}):(\d{2}):(\d{2})/.exec(String(s || '')); if (!m) return 0; const d = C.istDate(Date.now()).split('-').map(Number); return Date.UTC(d[0], d[1] - 1, d[2], +m[1] - 5, +m[2] - 30, +m[3]); }
  function splitBuys(p) {
    const T = (FT.trades && FT.trades.list) || []; if (!T.length || !(p.qty > 0)) return null;
    const fills = T.filter(t => (t.exch + '|' + t.token) === p.k || t.tsym === p.tsym);
    const buys = {}, order = [];
    for (const f of fills.filter(f => f.side === 'B')) { const tt = ftTime(f.ts); const o = buys[f.ord] || (buys[f.ord] = { ord: f.ord, qty: 0, val: 0, ts: tt }); if (!order.includes(f.ord)) order.push(f.ord); o.qty += f.qty; o.val += f.qty * f.prc; if (tt && (!o.ts || tt < o.ts)) o.ts = tt; }
    let sold = fills.filter(f => f.side === 'S').reduce((a, f) => a + f.qty, 0);
    const lots = order.map(k => buys[k]).sort((a, b) => a.ts - b.ts).map(o => ({ ord: o.ord, qty: o.qty, avg: o.val / o.qty, ts: o.ts }));
    for (const l of lots) { const u = Math.min(l.qty, sold); l.qty -= u; sold -= u; }
    const open = lots.filter(l => l.qty > 0);
    const have = open.reduce((a, l) => a + l.qty, 0);
    if (have < p.qty) {                                  // older purchases not in today's trade book (carried from earlier days)
      const rem = p.qty - have, val = p.qty * p.avg - open.reduce((a, l) => a + l.qty * l.avg, 0);
      open.unshift({ ord: 'earlier', qty: rem, avg: val > 0 ? val / rem : p.avg, ts: 0 });
    }
    return open.length >= 2 ? open : null;
  }

  /** the full HZ evaluation for one index: side, strike, entry, checks, reasons, reach */
  function hzEval(index) {
    const S = st.settings, ctx = judgeCtx(index, false); if (!ctx) return null;
    const P = (st.path || {})[ctx.key] || [], hz = heroFor(index), now = Date.now(), nowM = hzMins();
    const sq = hzSqueeze(ctx, P, index), spd = hzSpeed(index), str = hzStraddle(ctx, P), r15 = fut15();
    // strike only when there is a trigger: writers exiting (early threshold) OR an ATM straddle spike
    const trig = hzTrigger(index, ctx, P, hz, str), side = trig.side;
    let lean = '';
    if (!side) { const v = (sq.brk === 'up' ? 1 : sq.brk === 'down' ? -1 : 0) + (spd.dir === 'up' ? 1 : spd.dir === 'down' ? -1 : 0) + (r15.bias === 'Bullish' ? 1 : r15.bias === 'Bearish' ? -1 : 0) + (trig.lean === 'CE' ? 1 : trig.lean === 'PE' ? -1 : 0);
      lean = v > 0 ? 'CE' : v < 0 ? 'PE' : ''; }
    const useSide = side || lean || 'CE', up = useSide === 'CE';
    const movers = hzMovers(ctx, P, index);
    const cands = hzCandidates(ctx, useSide, index);
    for (const c of cands) { const mv = movers.find(m => m.strike === c.strike && m.side === useSide); if (mv) { c.mover = mv; c.score *= 1.6; } }
    cands.sort((a, b) => b.score - a.score);
    const best = side ? cands[0] || null : null;
    // open road from the zero-OI plan
    let road = null;
    try { const view = C.windowRows(C.compare(ctx.cur, null), ctx.spot, S.strikes), pl = C.heroPlan(view, ctx.spot, zeroTester(ctx.key, view), S);
      if (pl.side === useSide && pl.zone) road = { end: pl.zone[1], wall: pl.wall }; } catch (e) { }
    const vol = best ? hzVolume(P, best.strike, useSide.toLowerCase()) : { ok: null, txt: '–' };
    const mk = hzMarket(index, up);
    const mp = ctx.cur.mp, mpOk = isFinite(mp) ? (up ? mp > ctx.spot + ctx.step / 2 : mp < ctx.spot - ctx.step / 2) : null;
    const alert = st.alerts.find(a => a.index === index && now - a.ts < 20 * 60000 && a.tone === (up ? 'bull' : 'bear') && /^(reversal|reversalWarn|rangeBreak)$/.test(a.type));
    const tries = heroTries(index), lot = LOT[index] || 1, lots = best ? Math.floor(S.hzBudget / (best.ltp * 1.03 * lot)) : 0;
    const req = [
      { ok: isExpiryDay(index), t: 'Expiry day', v: isExpiryDay(index) ? 'yes' : 'no (hero-zero is for expiry day)' },
      { ok: nowM >= S.heroStart && nowM < 15 * 60 + 10, t: `Between ${hhmm(S.heroStart)} and 3:10 PM`, v: hhmm(nowM) },
      { ok: !!side, t: 'Trigger: writers exiting or straddle spike', v: side ? (trig.how === 'straddle' ? `straddle spike, ${side} leg` : `${side} writers exiting`) : trig.how === 'both' ? 'both sides falling: wait' : 'not yet' },
      { ok: !!best && best.liquid, t: 'A liquid strike within reach', v: best ? `${fmtK(best.strike)} ${useSide} ₹${f2(best.ltp)}${best.liquid ? '' : ' (thin)'}` : `none priced ₹${S.heroMin}–${S.heroMax}` },
      { ok: !!best && best.reach >= 0.2, t: 'Reach chance 20%+', v: best && isFinite(best.reach) ? Math.round(best.reach * 100) + '%' : '–' },
      { ok: lots >= 1, t: `Budget ₹${fmtK(S.hzBudget)} buys 1+ lot`, v: best ? `${lots} lot${lots === 1 ? '' : 's'}` : '–' },
      { ok: tries.length < S.hzTries, t: `Under ${S.hzTries} tries today`, v: `${tries.length} used` },
    ];
    const conf = [
      { ok: C.futConfirm(useSide, r15.bias) === 'agree', t: 'Futures agree', v: r15.label || 'no clear buildup' },
      { ok: !!alert, t: `Reversal / breakout alert ${up ? 'up' : 'down'}`, v: alert ? `${alert.kind} ${C.istTime(alert.ts)}` : 'none in 20 min' },
      { ok: sq.brk === (up ? 'up' : 'down'), t: `Broke the day ${up ? 'high' : 'low'}`, v: sq.brk ? (sq.brk === (up ? 'up' : 'down') ? 'yes' : 'broke the other way') : 'not yet' },
      { ok: str.ok === true, t: 'ATM straddle waking up', v: isFinite(str.fromLow) ? `${str.fromLow >= 0 ? '+' : ''}${str.fromLow.toFixed(0)}% off its low` : 'collecting' },
      { ok: sq.squeeze === true, t: 'Quiet midday squeeze', v: isFinite(sq.wr) ? `${fmtK(sq.wr)} pts` : '–' },
      { ok: spd.dir === (up ? 'up' : 'down'), t: 'Speed burst', v: isFinite(spd.pts) ? `${sgn(Math.round(spd.pts), fmtK)} pts / 2 min` : 'no live ticks' },
      { ok: vol.ok === true, t: 'Volume surge on the strike', v: isFinite(vol.x) ? `${vol.x.toFixed(1)}×` : 'collecting' },
      { ok: mk.breadth.ok === true, t: 'Heavyweights & breadth agree', v: mk.breadth.agree !== undefined ? `${mk.breadth.agree}/${(st.hzx.heavy || []).length}` : 'loading' },
      { ok: mk.sister.ok === true, t: 'Sister index / Europe agree', v: mk.sister.ok === null ? 'loading' : mk.sister.ok ? 'yes' : 'no' },
      { ok: mpOk === true, t: `Max pain pulls ${up ? 'up' : 'down'}`, v: isFinite(mp) ? `max pain ${fmtK(mp)}` : '–' },
      { ok: movers.some(m => m.side === useSide), t: `${useSide} premiums already jumping`, v: movers.filter(m => m.side === useSide).length ? moverTxt(movers.filter(m => m.side === useSide)[0]) : 'none in 10 min' },
    ];
    const nConf = conf.filter(c => c.ok).length, need = 3;
    const go = req.every(c => c.ok) && nConf >= need;
    const verdict = go ? 'GO' : req.slice(0, 3).every(c => c.ok) ? 'WAIT' : isExpiryDay(index) ? 'WATCH' : 'NO TRADE';
    const reach = best ? hzReach(ctx, useSide, best.strike, best.ltp, index, road) : null;
    // reasons for this strike
    const why = [];
    if (best) {
      why.push(`Trigger: ${trig.txt}`);
      if (best.mover) why.push(`Already moving: ${moverTxt(best.mover)}.`);
      if (nowM >= 14 * 60 + 50) why.push('Late in expiry: premium melts very fast now. Use half the budget and exit quickly.');
      why.push(`Delta ${best.delta.toFixed(2)}: cheap enough to multiply, close enough to wake up when ${index} moves.`);
      why.push(`Best acceleration per rupee${cands.length > 1 ? ` of ${cands.length} strikes priced ₹${S.heroMin}–${S.heroMax}` : ''}: about +${(best.gpr * 100).toFixed(1)}% premium per ${index} point now, and faster as it gets closer (gamma).`);
      why.push(`${fmtK(best.dist)} pts from spot, inside today's expected move; reach chance ${pctTxt(best.reach)} before 3:30 PM.`);
      if (road) why.push(`Inside the open road: ${useSide === 'CE' ? 'call' : 'put'} writers have left up to ${fmtK(road.end)}${road.wall ? `; the next wall is ${fmtK(road.wall)}` : ''}.`);
      why.push(!best.liquid ? 'Thin trading: use a limit order, never market.' : best.vol > 0 || isFinite(best.spread) ? `Liquid: ${best.vol > 0 ? (C.fmtQ ? C.fmtQ(best.vol) : fmtK(best.vol)) + ' traded today' : ''}${isFinite(best.spread) ? `${best.vol > 0 ? ', ' : ''}buy/sell spread ${(best.spread * 100).toFixed(1)}%` : ''}.` : 'Volume not reported by this data source: use a limit order.');
      if (lots) why.push(`${lots} lot${lots > 1 ? 's' : ''} × ${lot} = ₹${fmtK(lots * lot * best.ltp)} of your ₹${fmtK(S.hzBudget)} budget.`);
    }
    const res = { index, ctx, side, lean, useSide, best, cands, road, req, conf, nConf, need, go, verdict, reach, why, lots, lot, sq, spd, str, vol, mk, mp, tries, trig, movers, hz };
    try { hzStamp(res); } catch (x) { console.error(x); }
    return res;
  }
  /** paper-trade results: hero GO plans tracked by the app, money under the Safe rules */
  function hzPaper() {
    const L = REC.plans().filter(x => x.hero && x.res !== 'open' && x.res !== 'nodata');
    const sims = L.map(x => heroRuleSim({ entry: x.entry, peak: x.hi, close: x.out || x.last, index: x.index, done: true })).filter(Boolean);
    const tot = sims.reduce((a, r) => a + r.pnl, 0);
    return { n: L.length, doubled: L.filter(x => x.hi >= x.entry * 2).length, tot, open: REC.plans().filter(x => x.hero && x.res === 'open').length };
  }
  /** your best hero-zero setups from everything recorded */
  function hzBest() {
    const H = REC.hero().filter(e => e.done && e.entry > 0);
    if (H.length < 5) return { n: H.length, rows: [] };
    const step = i => C.INDICES[i] ? C.INDICES[i].step : 50, tm = ts => { const p = C.istParts(ts); return p.h * 60 + p.mi; };
    const grp = (name, f) => { const g = {}; for (const e of H) { const k = f(e); (g[k] = g[k] || []).push(e); }
      return Object.entries(g).map(([k, v]) => ({ name, k, n: v.length, x2: v.filter(e => e.peak >= e.entry * 2).length })).filter(r => r.n >= 2); };
    const rows = [
      ...grp('Premium', e => e.entry < 5 ? 'under ₹5' : e.entry < 10 ? '₹5–10' : e.entry < 20 ? '₹10–20' : '₹20+'),
      ...grp('Distance', e => { const s = Math.abs(e.strike - e.spot0) / step(e.index); return s <= 2 ? '1–2 strikes away' : s <= 4 ? '3–4 strikes away' : '5+ strikes away'; }),
      ...grp('Time', e => { const m = tm(e.entryTs); return m < 14 * 60 ? 'before 2:00' : m < 14 * 60 + 45 ? '2:00–2:45' : 'after 2:45'; }),
    ].sort((a, b) => b.x2 / b.n - a.x2 / a.n);
    return { n: H.length, rows };
  }
  function hzRender() {
    const el = $('hzPage'); if (!el) return;
    const index = st.ui.index, S = st.settings;
    if (C.marketOpen(Date.now()) || st.ui.view === 'hz') fetchHzx(false).then(() => { if (st.ui.view === 'hz') hzPaint(); }).catch(() => { });
    hzPaint();
  }
  function hzPaint() {
    const el = $('hzPage'); if (!el) return;
    const index = st.ui.index, S = st.settings, e = (() => { try { return hzEval(index); } catch (x) { console.error(x); return null; } })();
    const paper = S.hzPaper !== false, pp = hzPaper(), hb = hzBest();
    const chk = (list) => `<div class="sfl">${list.map(c => `<div class="${c.ok ? 'ok' : 'no'}">${c.ok ? '✓' : '✗'} ${c.t}<span>${esc(String(c.v))}</span></div>`).join('')}</div>`;
    const paperBar = `<div class="hzpaper ${paper ? 'on' : ''}"><label><input type="checkbox" id="hzPaperOn" ${paper ? 'checked' : ''}> 📝 Paper-trade mode</label><span>${paper ? 'Watch only, no real money. Every GO is recorded with its result.' : 'Off: GO signals are for real trades.'}</span></div>`;
    if (!e) { el.innerHTML = `${paperBar}<div class="card"><h3>HZ · ${index}</h3><div class="hzmsg">Waiting for ${index} option chain data…</div></div>`; return; }
    const b = e.best, vcls = e.go ? 'go' : e.verdict === 'WAIT' ? 'wait' : 'no', tt = hzTimesTxt(index);
    const head = `<div class="card hzv ${vcls}"><div class="hzvh"><div><div class="hzvt">${e.go ? '✅ GO' : e.verdict === 'WAIT' ? '⏳ WAIT' : e.verdict === 'WATCH' ? '👀 WATCH' : '⛔ NO TRADE'}</div>
        <div class="dim" style="font-size:12px">${index} hero-zero · ${e.side ? e.side + ' side' : e.lean ? 'leaning ' + e.lean : 'no side yet'} · ${C.istTime(Date.now())}</div></div>
        <div class="hzvs"><b>${e.nConf}/${e.conf.length}</b><span>confirmations<br>need ${e.need}</span></div></div>
      ${b ? `<div class="hzpick ${e.useSide === 'CE' ? 'ce' : 'pe'}"><div><span>Strike</span><b>${fmtK(b.strike)} ${e.useSide}</b></div><div><span>Now</span><b>₹${f2(b.ltp)}</b></div>
        <div><span>Entry: buy at or below</span><b class="up">₹${f1(b.ltp * 1.03)}</b></div><div><span>Don't chase above</span><b class="dn">₹${f1(b.ltp * 1.1)}</b></div>
        <div><span>Lots (budget ₹${fmtK(S.hzBudget)})</span><b>${e.lots} × ${e.lot} = ₹${fmtK(e.lots * e.lot * b.ltp)}</b></div><div><span>Reach chance</span><b>${pctTxt(b.reach)}</b></div></div>`
        : e.side ? `<div class="hzmsg">No ${e.useSide} strike priced ₹${S.heroMin}–₹${S.heroMax} within reach right now.</div>` : `<div class="hzmsg">No strike yet. A strike is given only when <b>writers exit</b> one side (OI change down ${S.heroEarly || 50}%+ from its peak) or the <b>ATM straddle spikes</b>.</div>`}
      <div class="hzmsg" style="margin-top:8px">⚙️ ${e.trig.txt}</div>
      ${tt ? `<div class="hzcap">Today: ${tt}</div>` : ''}
      ${e.movers.length ? `<div class="hzmove"><b>🔥 Moving now</b>${e.movers.map(m => `<span class="${m.side === 'CE' ? 'ce' : 'pe'}">${moverTxt(m)}</span>`).join('')}</div>` : ''}
      ${b ? tradeBtn({ i: index, k: b.strike, s: e.useSide, t: 'B', iso: e.ctx.iso, p: tick05(b.ltp * 1.03), l: Math.max(1, e.lots), hero: true, safe: e.go, why: 'HZ ' + e.verdict }, `🛒 Buy ${fmtK(b.strike)} ${e.useSide} (${Math.max(1, e.lots)} lot${e.lots > 1 ? 's' : ''})`, 'buy wide') : ''}
      ${e.go && paper ? '<div class="hzmsg" style="color:var(--amber)">📝 Paper-trade mode: note this GO, don\'t buy. The result is recorded below.</div>' : ''}
      ${!e.go && e.verdict === 'WAIT' ? `<div class="hzmsg">Setup is forming. GO needs every required check and ${e.need}+ confirmations.</div>` : ''}</div>`;
    const why = b ? `<div class="card"><h3>Why this strike</h3><ol class="hzwhy">${e.why.map(w => `<li>${w}</li>`).join('')}</ol>
      ${e.cands.length > 1 ? `<div class="hzcap">Other choices: ${e.cands.slice(1, 4).map(c => `${fmtK(c.strike)} ₹${f2(c.ltp)} (Δ ${c.delta.toFixed(2)}, reach ${pctTxt(c.reach)})`).join(' · ')}</div>` : ''}</div>` : '';
    const R = e.reach;
    const reach = b && R ? `<div class="card"><h3>How far it may go</h3>
      <table class="acct"><tr><th>If ${index} reaches</th><th>Premium</th><th>Return</th><th>Chance</th></tr>${R.levels.map(l => `<tr><td>${fmtK(l.L)}<div class="dim" style="font-size:10.5px;font-weight:400">${l.why}</div></td><td class="num">₹${f1(l.est)}</td><td class="num up">${l.x.toFixed(1)}×</td><td class="num">${pctTxt(l.p)}</td></tr>`).join('')}
      <tr><td>Stays at ${fmtK(e.ctx.spot)}<div class="dim" style="font-size:10.5px;font-weight:400">no move till 3:20</div></td><td class="num">₹${f1(R.flat)}</td><td class="num dn">${(R.flat / b.ltp).toFixed(1)}×</td><td class="num">–</td></tr></table>
      <div class="hzmsg">Likely by 3:20 PM: <b>₹${f1(Math.max(0.05, R.flat))} – ₹${f1((R.levels[0] || { est: b.ltp }).est)}</b>${R.levels.length > 1 ? ` · good case <b>₹${f1(R.levels[1].est)}</b>` : ''}${R.levels.length > 2 ? ` · best case <b>₹${f1(R.levels[R.levels.length - 1].est)}</b>` : ''}.</div>
      <div class="hzcap">Premiums come from today's chain prices at that distance; chances from ${volFor(index) ? volFor(index).src + ' ' + f1(volFor(index).vol) : 'volatility'} and the ${R.to320} min left to 3:20 PM. A late move gives less than shown.</div></div>` : '';
    const rules = b ? `<div class="card"><h3>Exit plan</h3><div class="hzrules">
      <div><b>Sell half at ₹${f1(b.ltp * 2)}</b><span>2×: your money is back, the rest is free</span></div>
      <div><b>Trail the rest 30%</b><span>exit if it falls 30% from its peak</span></div>
      <div><b>Loss cap ₹${f1(b.ltp * 0.5)}</b><span>−50%: exit, this try is done</span></div>
      <div><b>Time stop 25 min</b><span>no real move → exit; expiry premium melts</span></div>
      <div><b>Last exit 3:20 PM</b><span>before the auction and 3:25 square-off</span></div></div></div>` : '';
    const checks = `<div class="card"><h3>Required (all must pass)</h3>${chk(e.req)}<h3 style="margin-top:12px">Confirmations (${e.nConf} of ${e.conf.length}, need ${e.need})</h3>${chk(e.conf)}</div>`;
    const sig = `<div class="card"><h3>Live signals</h3><div class="hzsig">
      <div><b>📈 ATM straddle</b><span>${e.str.txt}</span></div>
      <div><b>🗜 Squeeze & breakout</b><span>${e.sq.txt}</span></div>
      <div><b>⚡ Speed</b><span>${e.spd.txt}</span></div>
      <div><b>📊 Volume on ${b ? fmtK(b.strike) + ' ' + e.useSide : 'strike'}</b><span>${e.vol.txt}</span></div>
      <div><b>🏦 Heavyweights & breadth</b><span>${esc(e.mk.breadth.txt)}</span></div>
      <div><b>🌍 Sister index & Europe</b><span>${e.mk.sister.txt}</span></div>
      <div><b>🧲 Max pain</b><span>${isFinite(e.mp) ? `Max pain ${fmtK(e.mp)} vs spot ${fmtK(e.ctx.spot)}: ${Math.abs(e.mp - e.ctx.spot) < e.ctx.step / 2 ? 'at spot, pins the price' : e.mp > e.ctx.spot ? 'pulls up (helps CE)' : 'pulls down (helps PE)'}.` : '–'}</span></div></div></div>`;
    const paperCard = `<div class="card"><h3>📝 Paper-trade results</h3><div class="hzmsg">${pp.n ? `${pp.n} hero GO${pp.n > 1 ? 's' : ''} tracked · ${pp.doubled} doubled · with the Safe rules and ₹${fmtK(S.hzBudget)} each: <b class="${cls(pp.tot)}">${pp.tot >= 0 ? '+' : '−'}₹${fmtK(Math.abs(pp.tot))}</b>${pp.open ? ` · ${pp.open} open` : ''}.` : 'No hero GO yet. Every GO is recorded automatically with its result.'}</div>
      <div class="hzcap">Use real money only after 3–4 expiries show a profit here.</div></div>`;
    const best = `<div class="card"><h3>🎯 Your best setups</h3>${hb.rows.length ? `<table class="acct"><tr><th>Setup</th><th>Picks</th><th>Doubled</th></tr>${hb.rows.slice(0, 8).map(r => `<tr><td>${r.name}: ${r.k}</td><td class="num">${r.n}</td><td class="num ${r.x2 / r.n >= 0.4 ? 'up' : r.x2 / r.n < 0.2 ? 'dn' : 'am'}">${Math.round(r.x2 / r.n * 100)}%</td></tr>`).join('')}</table>` : `<div class="hzmsg">Builds from your Hero log: ${hb.n} of 5 finished picks so far. Then it shows which premium, distance and time worked best for you.</div>`}</div>`;
    const ask = `<button class="btn ghost" data-ask="${esc(`HZ for ${index}: ${b ? `why ${fmtK(b.strike)} ${e.useSide}? Is it a good buy now and how far can it go?` : 'why is there no hero-zero strike yet? What would trigger one?'}`)}" style="margin:8px 12px;width:calc(100% - 24px)">💬 Ask EV about this</button>`;
    el.innerHTML = paperBar + head + ask + why + reach + rules + checks + sig + paperCard + best;
  }

  // =====================================================================================
  // ASK EV — chat about the app's own data. Claude (with your API key) or offline rules. Read-only, educational.
  // =====================================================================================
  const ASK_EDU = 'For educational purposes only, not investment advice.';
  const ASK_MODELS = [['claude-sonnet-5-5', 'Claude Sonnet (balanced)'], ['claude-haiku-4-5-20251001', 'Claude Haiku (fast, cheapest)'], ['claude-opus-5-5', 'Claude Opus (deepest)']];
  st.ask = { msgs: store.get('oi.ask.msgs', []), busy: false, open: false };
  const askKey = () => store.get('oi.ask.key', '');
  const askMode = () => 'offline';                 // AI setup removed on request: answers come from the app's own data
  function askIndex(q) { return /sensex|bse/i.test(q) ? 'SENSEX' : /nifty|nse/i.test(q) ? 'NIFTY' : st.ui.index; }
  function askStrike(q) { const m = /\b(\d{4,6})\b/.exec(String(q).replace(/,/g, '')); return m ? +m[1] : null; }
  /** today's price path of one strike, every 5 minutes, with its low and high */
  function askStrikePath(index, K) {
    const exps = st.expiries[index] || [], key = index + '|' + (exps[0] || ''), P = (st.path || {})[key] || [];
    const out = [];
    for (const [i, sd] of [[0, 'CE'], [1, 'PE']]) {
      const pts = P.filter(x => x.p[K] && x.p[K][i] > 0).map(x => ({ m: x.m, v: x.p[K][i], s: x.s }));
      if (!pts.length) continue;
      const lo = pts.reduce((a, x) => x.v < a.v ? x : a), hi = pts.reduce((a, x) => x.v > a.v ? x : a);
      const after = pts.filter(x => x.m >= lo.m), hiAfter = after.reduce((a, x) => x.v > a.v ? x : a, after[0]);
      out.push(`${K} ${sd}: low ₹${lo.v} at ${hhmm(lo.m)} (spot ${fmtK(lo.s)}), high ₹${hi.v} at ${hhmm(hi.m)} (spot ${fmtK(hi.s)}), best rise after the low: ₹${lo.v} → ₹${hiAfter.v} by ${hhmm(hiAfter.m)}. Every 5 min: ` +
        pts.filter((x, j) => j % 5 === 0 || j === pts.length - 1).map(x => `${hhmm(x.m)} ₹${x.v}`).join(', '));
    }
    return out.length ? out.join('\n') : `${K}: no price record today (strike outside the recorded range, or the app was not running).`;
  }
  /** everything the assistant may look at, as compact text */
  function askContext(q) {
    const now = Date.now(), L = [], idx = askIndex(q), K = askStrike(q);
    L.push(`Now: ${C.istDate(now)} ${C.istTime(now, true)} IST. Market ${C.marketOpen(now) ? 'OPEN' : 'CLOSED'}. Selected index: ${st.ui.index}.`);
    L.push(`Settings: Safe mode ${st.settings.safe !== false ? 'ON' : 'OFF'} (chance ≥${st.settings.safeChance}%, reward ≥${st.settings.safeRR}×, stop ${st.settings.safeStop}%, breakeven at +${st.settings.safeBE}%, stop after ${st.settings.safeLosses} losses). Hero-zero: window from ${hhmm(st.settings.heroStart)}, strike at ${st.settings.heroEarly || 50}% OI-change fall, budget ₹${st.settings.hzBudget}, ${st.settings.hzTries} tries, paper-trade ${st.settings.hzPaper !== false ? 'ON' : 'OFF'}. Lot sizes: NIFTY ${LOT.NIFTY}, SENSEX ${LOT.SENSEX}.`);
    for (const i of Object.keys(C.INDICES)) {
      const d = dataNear(i); if (!d) { L.push(`${i}: no data yet.`); continue; }
      const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur, f = st.first[d.key];
      L.push(`\n## ${i} (expiry ${d.iso}${isExpiryDay(i) ? ', EXPIRY TODAY' : ''}) source ${st.srcUsed[i] || C.INDICES[i].src}, data at ${C.istTime(cur.ts, true)}`);
      L.push(`Spot ${f2(cur.spot)}${f ? ` (open-time ${f2(f.spot)})` : ''}. PCR ${cur.pcr ? cur.pcr.toFixed(2) : '–'}. Max pain ${fmtK(cur.mp)}. Resistance (max CE OI) ${fmtK(cur.res)}, support (max PE OI) ${fmtK(cur.sup)}.`);
      const v = C.windowRows(cur.rows, cur.spot, 7);
      L.push('Chain (strike | CE ltp, OI, OI chg | PE ltp, OI, OI chg):');
      for (const r of v) L.push(`${r.strike} | ${r.ce.ltp}, ${Q(r.ce.oi)}, ${Q(r.ce.oi - r.ce.poi)} | ${r.pe.ltp}, ${Q(r.pe.oi)}, ${Q(r.pe.oi - r.pe.poi)}`);
      try { const p = predictionFor(i); if (p) L.push(`App market read: ${p.tone === 'up' ? 'bullish' : p.tone === 'dn' ? 'bearish' : 'sideways'}${p.label ? ' (' + p.label + ')' : ''}.`); } catch (e) { }
      for (const dir of ['up', 'down']) { try { const pl = tradePlan(i, dir); if (pl) L.push(`App plan if market goes ${dir.toUpperCase()}: ${planText(pl)}`); } catch (e) { } }
      if (isExpiryDay(i)) { try { const e = hzEval(i); if (e) {
        L.push(`HZ (hero-zero): verdict ${e.verdict}; trigger: ${e.trig.txt}${e.best ? `; strike ${e.best.strike} ${e.useSide} ₹${e.best.ltp} (entry ≤ ₹${f1(e.best.ltp * 1.03)}, lots ${e.lots}, reach ${pctTxt(e.best.reach)})` : '; no strike'}; confirmations ${e.nConf}/${e.conf.length}.`);
        L.push('HZ required: ' + e.req.map(c => `${c.ok ? '✓' : '✗'} ${c.t} (${c.v})`).join('; '));
        L.push('HZ confirmations: ' + e.conf.map(c => `${c.ok ? '✓' : '✗'} ${c.t} (${c.v})`).join('; '));
        if (e.reach && e.reach.levels.length) L.push('HZ may reach: ' + e.reach.levels.map(l => `${i} ${l.L} → ₹${f1(l.est)} (${pctTxt(l.p)})`).join('; ') + `; if flat till 3:20 → ₹${f1(e.reach.flat)}.`);
        if (e.movers.length) L.push('Moving now: ' + e.movers.map(moverTxt).join('; '));
        const tt = hzTimesTxt(i); if (tt) L.push('HZ timeline today: ' + tt);
      } } catch (x) { } }
    }
    const r15 = fut15(); if (r15.label) L.push(`\nNIFTY futures last 15 min: ${r15.label} (${r15.bias}).`);
    try { const vx = vixNow(); if (vx && vx.v) L.push(`India VIX ${f2(vx.v)}${vx.prev ? ` (prev ${f2(vx.prev)})` : ''}.`); } catch (e) { }
    if (K) L.push(`\n## Strike ${K} today (${idx})\n` + askStrikePath(idx, K));
    if (K) { for (const sd of ['CE', 'PE']) { try { L.push('\n' + outlookText(strikeOutlook(idx, K, sd))); } catch (e) { } } }
    try { L.push('\n' + bigText(idx)); } catch (e) { }
    const al = st.alerts.slice(-25);
    if (al.length) { L.push('\n## Alerts today (latest last)'); for (const a of al) L.push(`${C.istTime(a.ts)} ${a.index} [${a.lvl}] ${a.title || a.kind}: ${a.msg}${a.plan ? ' PLAN: ' + planText(a.plan) : ''}`); }
    try { const ps = myPositions(); if (ps.length) { L.push('\n## My open positions'); for (const p of ps) { const a = adviseOne(p);
      L.push(`${p.index} ${p.strike} ${p.side} qty ${p.qty} avg ₹${f2(p.avg)} ltp ₹${f2(p.ltp)}${p.parts ? ` (purchase ${p.part} of ${p.parts}${p.buyTs ? ' at ' + C.istTime(p.buyTs) : ''})` : ''}${a ? ` → ${a.act}: ${a.msg} (P&L ${a.pnlPct.toFixed(1)}%)` : ''}`); } } } catch (e) { }
    try { const day = REC.calls()[C.istDate(now)] || {}; for (const i of Object.keys(C.INDICES)) { const c = day[i]; if (c) L.push(`\nMorning call ${i}: ${c.label} (locked ${C.istTime(c.ts)}), reasons: ${(c.factors || []).map(f => f.txt).join('; ')}${c.rec ? `; strike idea ${c.rec.strike} ${c.rec.side} ₹${c.rec.ltp}` : ''}.`); } } catch (e) { }
    const H = REC.hero().slice(-12); if (H.length) { L.push('\n## Hero log (recent)'); for (const e of H) L.push(`${e.day} ${C.istTime(e.entryTs)} ${e.index} ${e.strike} ${e.side} (${e.src}) entry ₹${e.entry}, peak ₹${e.peak} at ${e.peakTs ? C.istTime(e.peakTs) : '–'}${e.done ? `, closed ₹${e.close}` : ''}`); }
    try { const S = planStats(REC.plans().filter(x => now - x.ts < 30 * 86400e3)); if (S.n) L.push(`\nAlert accuracy (30 days): ${S.n} plans, target ${Math.round(S.tPct)}%, stop ${Math.round(S.sPct)}%, avg ${S.avg.toFixed(0)}%.`); } catch (e) { }
    return L.join('\n').slice(0, 45000);
  }
  const ASK_SYS = `You are "EV", the analysis assistant inside EV Pulse, a personal NIFTY/SENSEX options app. Answer ONLY from the app data provided with each question (option chain, OI, alerts, hero-zero (HZ) evaluation, price paths, positions, records). Quote times (IST) and numbers from the data. If the data needed is missing, say exactly what is missing; never invent prices or times.
When the user asks which strike to buy, trade or "execute", give one specific answer: index, strike and CE/PE, entry price (buy at or below), target, stop-loss, lots, and 2–4 reasons from the data. Prefer the app's own plan or HZ strike; say whether Safe mode passed and, if it did not, say "Safe mode says no trade" before showing the best candidate. Hero-zero ideas follow the app's rules (sell half at 2×, trail 30%, −50% loss cap, 25-min time stop, exit by 3:20 PM).
You cannot place orders yourself; the user places them with the app's Buy/Exit buttons after confirming. Be brief: short paragraphs or bullets, Indian rupee (₹), plain English (or the user's language).
End every answer that mentions a strike, entry, exit or position with this exact line: "${ASK_EDU}"`;
  async function askClaude(q) {
    const key = askKey(); if (!key) return { err: 'AI mode is not set up on this phone.' };
    const hist = st.ask.msgs.filter(m => !m.err).slice(-8, -1).map(m => ({ role: m.role === 'user' ? 'user' : 'assistant', content: m.text }));
    const msgs = hist.concat([{ role: 'user', content: `APP DATA (${C.istTime(Date.now(), true)} IST):\n${askContext(q)}\n\nQUESTION: ${q}` }]);
    while (msgs.length && msgs[0].role !== 'user') msgs.shift();
    const body = JSON.stringify({ model: st.settings.askModel || ASK_MODELS[0][0], max_tokens: 1200, system: ASK_SYS, messages: msgs });
    const r = await http('POST', 'https://api.anthropic.com/v1/messages', { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json', 'anthropic-dangerous-direct-browser-access': 'true' }, body, 95000);
    const j = parseJson(r.text);
    if (j && j.content) return { text: j.content.filter(c => c.type === 'text').map(c => c.text).join('\n').trim() };
    const em = j && j.error ? j.error.message : '';
    if (r.status === 401) return { err: 'The AI key was rejected.' };
    if (/credit/i.test(em)) return { err: 'Your Anthropic account has no credit left. Add credit at console.anthropic.com, or use Offline mode.' };
    if (r.status === 0) return { err: 'No internet connection, so Claude could not be reached. Offline answers still work.' };
    return { err: `Claude did not answer (HTTP ${r.status}${em ? ': ' + em : ''}).` };
  }
  // ---------- per-2-second record of near-ATM strikes (live feed) for "sudden big quantity" checks ----------
  st.tk = {};
  function tkPush(index, snap) {
    if (!snap || !snap.rows || !snap.rows.length) return;
    const step = C.INDICES[index].step, r = {};
    for (const x of snap.rows) if (Math.abs(x.strike - snap.spot) <= step * 12)
      r[x.strike] = [x.ce.ltp || 0, x.ce.oi || 0, x.ce.vol || 0, x.pe.ltp || 0, x.pe.oi || 0, x.pe.vol || 0];
    const B = st.tk[index] = st.tk[index] || [];
    if (B.length && snap.ts - B[B.length - 1].ts < 1500) return;
    B.push({ ts: snap.ts, s: snap.spot, r });
    while (B.length && snap.ts - B[0].ts > 40 * 60000) B.shift();      // keep the last 40 minutes
  }
  setInterval(() => {
    if (!useFT() || !C.marketOpen(Date.now())) return;
    const L = LD();
    for (const index of Object.keys(C.INDICES)) {
      const iso = (st.expiries[index] || [])[0];
      if (!iso || !L.hasChain(index, iso)) continue;
      try { const p = L.chain(index, iso, lastSpot(index)); if (p.rows.length && p.spot) { tkPush(index, { ts: Date.now(), spot: p.spot, rows: p.rows }); burstTick(index); } } catch (e) { console.error(e); }
    }
  }, 2000);
  /** the series to scan: live 2-second points when we have them, otherwise the 1-minute snapshots */
  function tkSeries(index, mins) {
    const now = Date.now(), B = (st.tk[index] || []).filter(x => now - x.ts <= mins * 60000);
    if (B.length >= 10) return { pts: B, every: '2 seconds' };
    const d = dataNear(index); if (!d) return { pts: [], every: '' };
    const step = C.INDICES[index].step;
    const pts = d.h.filter(s => now - s.ts <= mins * 60000).map(s => { const r = {};
      for (const x of s.rows) if (Math.abs(x.strike - s.spot) <= step * 12) r[x.strike] = [x.ce.ltp || 0, x.ce.oi || 0, x.ce.vol || 0, x.pe.ltp || 0, x.pe.oi || 0, x.pe.vol || 0];
      return { ts: s.ts, s: s.spot, r }; });
    return { pts, every: '1 minute' };
  }
  const med = a => { const b = a.filter(isFinite).map(Math.abs).sort((x, y) => x - y); return b.length ? b[Math.floor(b.length / 2)] : 0; };
  /** what a sudden OI jump means for the INDEX: +1 bullish, −1 bearish */
  function bigMeaning(side, dOi, dP, p0, dS, spot) {
    // price hardly moved (under 1%): OI added = writers (the usual case near ATM); OI cut = judge by the index's move, else neutral
    if (p0 > 0 && Math.abs(dP) < 0.01 * p0) {
      if (dOi > 0) return side === 'CE' ? { t: 'Call writing (sellers added): caps the upside', b: -1 } : { t: 'Put writing (sellers added): support below', b: 1 };
      const sm = spot > 0 && isFinite(dS) && Math.abs(dS) >= 0.0003 * spot ? Math.sign(dS) : 0;
      if (!sm) return { t: `${side === 'CE' ? 'Call' : 'Put'} OI exiting (price not moved yet)`, b: 0 };
      dP = side === 'CE' ? sm : -sm;
    }
    const up = dP > 0;
    if (side === 'CE') return dOi > 0 ? (up ? { t: 'Fresh call buying', b: 1 } : { t: 'Call writing (sellers added): caps the upside', b: -1 })
      : (up ? { t: 'Call short covering (writers ran)', b: 1 } : { t: 'Call buyers exiting', b: -1 });
    return dOi > 0 ? (up ? { t: 'Fresh put buying', b: -1 } : { t: 'Put writing (sellers added): support below', b: 1 })
      : (up ? { t: 'Put short covering (writers ran)', b: -1 } : { t: 'Put buyers exiting', b: 1 });
  }
  /**
   * Sudden large quantities: per strike and side, OI or volume jumps far bigger than that contract's usual step.
   * Big = at least 3× its median step AND at least 1.5% of its OI (or 300 lots), merged within 1 minute.
   */
  function bigMoves(index, mins) {
    const { pts, every } = tkSeries(index, mins || 30), lot = LOT[index] || 1, out = [];
    if (pts.length < 4) return { list: out, every, n: pts.length };
    const strikes = Object.keys(pts[pts.length - 1].r).map(Number);
    for (const K of strikes) for (const [side, io, ip, iv] of [['CE', 1, 0, 2], ['PE', 4, 3, 5]]) {
      const ser = pts.filter(x => x.r[K]).map(x => ({ ts: x.ts, s: x.s, oi: x.r[K][io], p: x.r[K][ip], v: x.r[K][iv] }));
      if (ser.length < 4) continue;
      const dOi = [], dV = [];
      for (let i = 1; i < ser.length; i++) { dOi.push(ser[i].oi - ser[i - 1].oi); dV.push(ser[i].v - ser[i - 1].v); }
      const mOi = med(dOi), mV = med(dV);
      let ev = null;
      for (let i = 1; i < ser.length; i++) {
        const a = ser[i - 1], b = ser[i], doi = b.oi - a.oi, dv = b.v - a.v;
        const bigOi = Math.abs(doi) >= Math.max(3 * mOi, 0.015 * Math.max(a.oi, 1), 300 * lot) && a.oi > 0;
        const bigV = dv >= Math.max(4 * mV, 600 * lot) && !bigOi;
        if (!bigOi && !bigV) { if (ev && b.ts - ev.t1 > 60000) { out.push(ev); ev = null; } continue; }
        if (ev && b.ts - ev.t1 <= 60000 && Math.sign(doi) === Math.sign(ev.dOi || doi)) { ev.t1 = b.ts; ev.dOi += doi; ev.dV += dv; ev.p1 = b.p; ev.s1 = b.s; ev.oi1 = b.oi; continue; }
        if (ev) out.push(ev);
        ev = { K, side, t0: a.ts, t1: b.ts, dOi: doi, dV: dv, p0: a.p, p1: b.p, s0: a.s, s1: b.s, oi0: a.oi, oi1: b.oi, kind: bigOi ? 'oi' : 'vol' };
      }
      if (ev) out.push(ev);
    }
    for (const e of out) {
      const m = bigMeaning(e.side, e.dOi, e.p1 - e.p0, e.p0, e.s1 - e.s0, e.s1);
      e.t = e.kind === 'vol' ? 'Heavy trading (volume burst, little OI change)' : m.t; e.b = e.kind === 'vol' ? 0 : m.b;
      e.pct = e.oi0 > 0 ? e.dOi / e.oi0 * 100 : 0; e.lots = Math.round(Math.abs(e.kind === 'vol' ? e.dV : e.dOi) / lot);
    }
    for (const e of st.bursts[index] || []) if (Date.now() - e.t1 <= (mins || 30) * 60000 && !out.some(x => x.K === e.K && x.side === e.side && Math.abs(x.t1 - e.t1) < 60000)) out.push(e);
    out.sort((a, b) => b.t1 - a.t1);
    return { list: out, every, n: pts.length };
  }
  const bigTxt = (e, index) => `${C.istTime(e.t0, true)}${e.t1 - e.t0 > 3000 ? '–' + C.istTime(e.t1, true) : ''} · **${fmtK(e.K)} ${e.side}** ${e.kind === 'vol' ? `volume +${Q(e.dV)}` : `OI ${sQ(e.dOi)} (${e.pct >= 0 ? '+' : ''}${e.pct.toFixed(1)}%)`} ≈ ${e.lots} lots, premium ₹${f2(e.p0)} → ₹${f2(e.p1)}: ${e.t}${e.b ? (e.b > 0 ? ' → bullish for ' : ' → bearish for ') + index : ''}`;

  /**
   * Will this option's premium go up or down? Scores the strike's own buildup, writers around it, the other side,
   * index momentum, futures, sudden big quantities and time decay. Positive = premium likely up.
   */
  function strikeOutlook(index, K, side) {
    const d = dataNear(index); if (!d) return { err: `No ${index} chain data yet.` };
    const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur, sd = side.toLowerCase(), up = side === 'CE', step = C.INDICES[index].step;
    const row = cur.rows.find(r => r.strike === K);
    if (!row || !(row[sd].ltp > 0)) return { err: `${fmtK(K)} ${side} is not in the ${index} ${d.iso} chain the app is tracking (tracked: ${fmtK(cur.rows[0] && cur.rows[0].strike)}–${fmtK(cur.rows.length ? cur.rows[cur.rows.length - 1].strike : NaN)}).` };
    const now = Date.now(), at = mins => { let b = null; for (const s of d.h) if (now - s.ts >= mins * 60000) b = s; return b || d.h[0]; };
    const b15 = at(15), b5 = at(5), r15 = b15.rows.find(r => r.strike === K), r5 = b5.rows.find(r => r.strike === K);
    const o = row[sd], p15 = r15 ? r15[sd].ltp : NaN, p5 = r5 ? r5[sd].ltp : NaN, oi15 = r15 ? r15[sd].oi : NaN;
    const up_ = [], dn_ = [], why = (s, t) => (s > 0 ? up_ : dn_).push({ s, t });
    let score = 0; const add = (s, t) => { score += s; why(s, t); };
    // 1. the strike's own price + OI (last 15 min)
    const dp = o.ltp - p15, doi = o.oi - oi15, since = C.istTime(b15.ts);
    if (isFinite(dp) && isFinite(doi) && oi15 > 0) {
      const pc = doi / oi15 * 100, pp = p15 > 0 ? dp / p15 * 100 : 0;
      if (Math.abs(pc) >= 2 || Math.abs(pp) >= 3) {
        if (dp > 0 && doi < 0) add(2, `Short covering at ${fmtK(K)} ${side}: writers cut OI by ${Math.abs(pc).toFixed(1)}% while the premium rose ${pp.toFixed(0)}% since ${since}.`);
        else if (dp > 0 && doi > 0) add(1, `Long buildup at ${fmtK(K)} ${side}: OI +${pc.toFixed(1)}% with the premium up ${pp.toFixed(0)}% since ${since} (buyers adding).`);
        else if (dp < 0 && doi > 0) add(-2, `Short buildup at ${fmtK(K)} ${side}: writers added OI +${pc.toFixed(1)}% while the premium fell ${Math.abs(pp).toFixed(0)}% since ${since}.`);
        else if (dp < 0 && doi < 0) add(-1, `Long unwinding at ${fmtK(K)} ${side}: OI −${Math.abs(pc).toFixed(1)}% and premium −${Math.abs(pp).toFixed(0)}% since ${since} (buyers leaving).`);
      }
    }
    // 2. premium momentum (5 min)
    if (isFinite(p5) && p5 > 0) { const m = (o.ltp / p5 - 1) * 100;
      if (m >= 8) add(1, `Premium already moving: ₹${f2(p5)} → ₹${f2(o.ltp)} (+${m.toFixed(0)}%) in 5 min.`);
      else if (m <= -8) add(-1, `Premium sliding: ₹${f2(p5)} → ₹${f2(o.ltp)} (${m.toFixed(0)}%) in 5 min.`); }
    // 3. writers' wall in the way, and support behind (same side vs the other side, last 15 min)
    const between = (lo, hi) => cur.rows.filter(r => r.strike >= lo && r.strike <= hi);
    const dO = (r, s) => { const b = b15.rows.find(x => x.strike === r.strike); return b ? r[s].oi - b[s].oi : 0; };
    const ahead = up ? between(cur.spot, Math.max(K, cur.spot) + 2 * step) : between(Math.min(K, cur.spot) - 2 * step, cur.spot);
    const behind = up ? between(cur.spot - 3 * step, cur.spot) : between(cur.spot, cur.spot + 3 * step);
    const wallAdd = ahead.reduce((a, r) => a + dO(r, sd), 0), wallOi = ahead.reduce((a, r) => a + r[sd].oi, 0);
    const other = up ? 'pe' : 'ce', supAdd = behind.reduce((a, r) => a + dO(r, other), 0), supOi = behind.reduce((a, r) => a + r[other].oi, 0);
    const big = ahead.slice().sort((a, b) => b[sd].oi - a[sd].oi)[0];
    if (wallOi > 0 && wallAdd / wallOi > 0.04) add(-2, `${up ? 'Call' : 'Put'} writers are adding in the way: ${sQ(wallAdd)} OI at ${fmtK(ahead[0].strike)}–${fmtK(ahead[ahead.length - 1].strike)} since ${since}${big ? ` (biggest wall ${fmtK(big.strike)}, ${Q(big[sd].oi)})` : ''}.`);
    else if (wallOi > 0 && wallAdd / wallOi < -0.04) add(2, `${up ? 'Call' : 'Put'} writers are leaving the way: ${sQ(wallAdd)} OI at ${fmtK(ahead[0].strike)}–${fmtK(ahead[ahead.length - 1].strike)} since ${since}.`);
    if (supOi > 0 && supAdd / supOi > 0.04) add(1, `${up ? 'Put' : 'Call'} writers adding ${up ? 'below' : 'above'} spot (${sQ(supAdd)} OI): they are defending the ${up ? 'floor' : 'ceiling'}.`);
    else if (supOi > 0 && supAdd / supOi < -0.04) add(-1, `${up ? 'Put' : 'Call'} writers pulling out ${up ? 'below' : 'above'} spot (${sQ(supAdd)} OI): the ${up ? 'floor' : 'ceiling'} is weakening.`);
    // 4. index momentum vs a normal move
    const vf = volFor(index), sig15 = vf ? C.expMove(cur.spot, vf.vol, 15) : NaN, ds = cur.spot - b15.spot;
    if (isFinite(sig15) && sig15 > 0 && Math.abs(ds) > 0.8 * sig15) add((ds > 0) === up ? 1 : -1, `${index} moved ${ds > 0 ? '+' : ''}${f1(ds)} pts in 15 min (bigger than a normal ${f1(sig15)}), ${(ds > 0) === up ? 'helping' : 'against'} this ${side}.`);
    // 5. futures (NIFTY)
    if (index === 'NIFTY') { const r = fut15(); if (r.label && /Bull|Bear/.test(r.bias)) add((r.bias === 'Bullish') === up ? 1 : -1, `NIFTY futures: ${r.label} in the last 15 min (${r.bias.toLowerCase()}).`); }
    // 6. sudden big quantities near this strike (last 30 min)
    const bm = bigMoves(index, 30), near = bm.list.filter(e => e.b && Math.abs(e.K - K) <= 2 * step && now - e.t1 <= 30 * 60000);
    let bs = 0; for (const e of near) bs += (e.b > 0) === up ? 1 : -1;
    if (bs >= 1) add(Math.min(2, bs), `Sudden big orders near ${fmtK(K)} favour this ${side}: ${near.slice(0, 2).map(e => `${C.istTime(e.t0, true)} ${fmtK(e.K)} ${e.side} ${e.t.toLowerCase()} (${e.lots} lots)`).join('; ')}.`);
    else if (bs <= -1) add(Math.max(-2, bs), `Sudden big orders near ${fmtK(K)} go against this ${side}: ${near.slice(0, 2).map(e => `${C.istTime(e.t0, true)} ${fmtK(e.K)} ${e.side} ${e.t.toLowerCase()} (${e.lots} lots)`).join('; ')}.`);
    // 7. the app's own market read
    try { const p = predictionFor(index); if (p && (p.tone === 'up' || p.tone === 'dn')) add((p.tone === 'up') === up ? 1 : -1, `The app's market read is ${p.tone === 'up' ? 'bullish' : 'bearish'}${p.label ? ' (' + p.label + ')' : ''}.`); } catch (e) { }
    // 8. time decay
    const otm = up ? K > cur.spot : K < cur.spot, tp = C.istParts(now), mm = tp.h * 60 + tp.mi;
    if (otm && isExpiryDay(index) && mm >= 13 * 60) add(-1, `Expiry-day decay: ${fmtK(K)} ${side} is out of the money, so the premium melts every minute unless ${index} moves ${up ? 'up' : 'down'} fast.`);
    // levels: where it could go
    const sigDay = vf ? C.expMove(cur.spot, vf.vol, Math.max(5, 15 * 60 + 30 - mm)) : NaN;
    const rnd = v => Math.round(v / step) * step;
    const tgtL0 = up ? (cur.res > cur.spot ? cur.res : cur.spot + (isFinite(sigDay) ? sigDay : 2 * step)) : (cur.sup < cur.spot ? cur.sup : cur.spot - (isFinite(sigDay) ? sigDay : 2 * step));
    const badL0 = up ? (cur.sup < cur.spot ? cur.sup : cur.spot - 2 * step) : (cur.res > cur.spot ? cur.res : cur.spot + 2 * step);
    const tgtL = rnd(tgtL0), badL = rnd(badL0);
    const estT = C.estPrice(cur.rows, sd, K, cur.spot, tgtL), estB = C.estPrice(cur.rows, sd, K, cur.spot, badL);
    const pT = isFinite(sigDay) ? C.touchProb(Math.abs(tgtL - cur.spot), sigDay) : NaN, pB = isFinite(sigDay) ? C.touchProb(Math.abs(badL - cur.spot), sigDay) : NaN;
    const verdict = score >= 3 ? 'UP' : score <= -3 ? 'DOWN' : score >= 1 ? 'leaning UP' : score <= -1 ? 'leaning DOWN' : 'UNCLEAR';
    return { index, K, side, ltp: o.ltp, oi: o.oi, spot: cur.spot, ts: cur.ts, iso: d.iso, score, verdict, up: up_.sort((a, b) => b.s - a.s), dn: dn_.sort((a, b) => a.s - b.s),
      tgtL, estT, pT, badL, estB, pB, near, every: bm.every, src: st.srcUsed[index] || C.INDICES[index].src };
  }
  function outlookText(x) {
    if (x.err) return x.err;
    const icon = /UP/.test(x.verdict) ? '📈' : /DOWN/.test(x.verdict) ? '📉' : '↔️';
    const conf = Math.abs(x.score) >= 5 ? 'strong' : Math.abs(x.score) >= 3 ? 'moderate' : 'weak';
    const L = [`${icon} **${x.index} ${fmtK(x.K)} ${x.side} (${x.iso}): ${x.verdict}** · score ${x.score > 0 ? '+' : ''}${x.score} (${conf})`,
      `Now ₹${f2(x.ltp)} · OI ${Q(x.oi)} · ${x.index} ${f2(x.spot)} · ${x.src} at ${C.istTime(x.ts, true)}`];
    if (x.up.length) L.push(`\n**Why it may go up**\n` + x.up.map(r => `- ${r.t}`).join('\n'));
    if (x.dn.length) L.push(`\n**Why it may go down**\n` + x.dn.map(r => `- ${r.t}`).join('\n'));
    if (!x.up.length && !x.dn.length) L.push('\nNo strong signal either way: price and OI around this strike are quiet.');
    L.push(`\n**Where it could go**\n- If ${x.index} reaches ${fmtK(x.tgtL)}: about **₹${f1(x.estT)}**${isFinite(x.pT) ? ` (chance ${Math.round(x.pT * 100)}% today)` : ''}\n- If ${x.index} goes to ${fmtK(x.badL)}: about **₹${f1(x.estB)}**${isFinite(x.pB) ? ` (chance ${Math.round(x.pB * 100)}%)` : ''}`);
    const inval = x.side === 'CE' ? `${x.index} breaks below ${fmtK(x.badL)}, or call writers add OI at ${fmtK(x.K)}` : `${x.index} breaks above ${fmtK(x.badL)}, or put writers add OI at ${fmtK(x.K)}`;
    L.push(`\n**Changes the view if:** ${inval}.`);
    L.push(`_Checked from the chain every minute and big-order scan every ${x.every || 'minute'}. A guide from the data, not a certainty._`);
    return L.join('\n');
  }
  function bigText(index) {
    const bm = bigMoves(index, 30);
    if (bm.n < 4) return `Not enough ${index} data yet to spot sudden big orders (need a few minutes of chain data${useFT() ? '' : '; with Flattrade or HDFC Sky live data the scan runs every 2 seconds'}).`;
    const L = bm.list.slice(0, 8);
    if (!L.length) return `**${index}: no sudden big orders in the last 30 min** (scanned every ${bm.every}). OI and volume changes are normal size.`;
    const bull = L.filter(e => e.b > 0).length, bear = L.filter(e => e.b < 0).length;
    return `**${index}: sudden big orders, last 30 min** (scanned every ${bm.every})\n` + L.map(e => '- ' + bigTxt(e, index)).join('\n') +
      `\n\nNet: ${bull} bullish, ${bear} bearish${bull > bear + 1 ? ` → **big money leaning bullish**` : bear > bull + 1 ? ` → **big money leaning bearish**` : ' → mixed'}.`;
  }
  // ---------- sudden OI bursts (live, every 2 s): big change within 30 s → critical alert with a strike to buy ----------
  st.bursts = {}; st.burstSeen = {};
  function burstScan(index) {
    const B = st.tk[index] || []; if (B.length < 20) return [];
    const now = B[B.length - 1], lot = LOT[index] || 1, out = [];
    let i30 = B.length - 1; while (i30 > 0 && now.ts - B[i30].ts < 30000) i30--;
    const past = B[i30]; if (now.ts - past.ts < 20000) return [];
    for (const K of Object.keys(now.r).map(Number)) for (const [side, io, ip] of [['CE', 1, 0], ['PE', 4, 3]]) {
      const a = past.r[K], b = now.r[K]; if (!a || !b || !(a[io] > 0)) continue;
      const d = b[io] - a[io];
      // usual 30-second change for this contract over the last 30 min
      const ch = []; for (let j = 15; j < B.length; j += 5) { const x = B[j].r[K], y = B[j - 15].r[K]; if (x && y) ch.push(x[io] - y[io]); }
      const thr = Math.max(4 * med(ch), 0.025 * a[io], 500 * lot);
      if (Math.abs(d) < thr) continue;
      const m = bigMeaning(side, d, b[ip] - a[ip], a[ip], now.s - past.s, now.s);
      out.push({ K, side, t0: past.ts, t1: now.ts, dOi: d, dV: 0, p0: a[ip], p1: b[ip], s0: past.s, s1: now.s, oi0: a[io], oi1: b[io], kind: 'oi', t: m.t, b: m.b,
        pct: d / a[io] * 100, lots: Math.round(Math.abs(d) / lot), burst: true });
    }
    return out;
  }
  function burstTick(index) {
    const L = burstScan(index); if (!L.length) return;
    const keep = st.bursts[index] = st.bursts[index] || [], fresh = [];
    for (const e of L) {
      const k = index + '|' + e.K + e.side + '|' + Math.sign(e.dOi);
      if (st.burstSeen[k] && e.t1 - st.burstSeen[k] < 3 * 60000) continue;      // same contract, same way: once per 3 min
      st.burstSeen[k] = e.t1; keep.push(e); fresh.push(e);
    }
    while (keep.length && Date.now() - keep[0].t1 > 60 * 60000) keep.shift();
    if (!fresh.length) return;
    const net = fresh.reduce((a, e) => a + e.b, 0); if (!net) return;
    const bull = net > 0, dir = bull ? 'up' : 'down', same = fresh.filter(e => e.b === (bull ? 1 : -1));
    const crit = same.length >= 2 || same.some(e => Math.abs(e.pct) >= 4);
    const d = dataNear(index), pk = (() => { try { return pennyScan(index); } catch (x) { return null; } })();
    const pen = pk && (bull ? pk.ce : pk.pe)[0];
    const lines = same.slice(0, 3).map(e => `${fmtK(e.K)} ${e.side} OI ${sQ(e.dOi)} (${e.pct >= 0 ? '+' : ''}${e.pct.toFixed(0)}%) in 30 s, ₹${f2(e.p0)}→₹${f2(e.p1)}: ${e.t.toLowerCase()}`);
    let pl = null; try { pl = tradePlan(index, dir); } catch (x) { }
    const buy = pl && pl.strike ? ` Strike to buy: ${fmtK(pl.strike)} ${pl.side} at or below ₹${f1(pl.entryMax)} (now ₹${f2(pl.ltp)}), target ₹${isFinite(pl.target) ? f1(pl.target) : '–'}, stop ₹${f1(pl.stop)}${pl.safe ? (pl.safe.ok ? ', Safe mode ✓' : `, Safe mode ${pl.safe.passed}/${pl.safe.checks.length}: careful`) : ''}.` : '';
    const msg = `${lines.join('. ')}. Big money ${bull ? 'bullish' : 'bearish'} for ${index} (spot ${f2(same[0].s1)}).` + buy +
      (pen ? ` Penny idea: ${fmtK(pen.K)} ${pen.side} ₹${f2(pen.ltp)}, buy ≤ ₹${f2(pen.entryMax)}; if ${index} ${bull ? 'rises' : 'falls'} ${fmtK(Math.abs(pen.L2 - pen.spot))} pts → ~₹${f1(pen.e2)} (${pen.x2.toFixed(1)}×).` : '');
    fire('bigOi', index, d ? d.iso : '', `🐋 ${index} sudden OI ${bull ? '(bullish)' : '(bearish)'}: ${same.length} strike${same.length > 1 ? 's' : ''}`, msg, bull ? 'bull' : 'bear', dir, 3, crit ? 'critical' : 'important');
  }

  // ---------- PENNY: cheap out-of-the-money strikes that can multiply 2–10× on a sharp move ----------
  st.penny = store.get('oi.penny.log', []);
  function pennyScan(index) {
    const ctx = judgeCtx(index, false); if (!ctx) return null;
    const S = st.settings, lo = S.pennyMin || 0.5, hi = S.pennyMax || 15, now = Date.now(), vf = volFor(index);
    const left = Math.max(10, C.minsLeft(now) || 0), sig = vf ? C.expMove(ctx.spot, vf.vol, left) : NaN;
    if (!(sig > 0)) return { ctx, ce: [], pe: [], sig: NaN };
    const d = dataNear(index), at = mins => { let b = null; for (const s of d.h) if (now - s.ts >= mins * 60000) b = s; return b || d.h[0]; };
    const b15 = at(15), b5 = at(5), sig15 = C.expMove(ctx.spot, vf.vol, 15), ds15 = ctx.spot - b15.spot, ds5 = ctx.spot - b5.spot;
    const mode = ds15 <= -0.8 * sig15 || ds5 <= -0.5 * sig15 ? 'fall' : ds15 >= 0.8 * sig15 || ds5 >= 0.5 * sig15 ? 'rise' : '';
    const bursts = (st.bursts[index] || []).filter(e => now - e.t1 < 15 * 60000), bNet = bursts.reduce((a, e) => a + e.b, 0);
    const P = (st.path || {})[ctx.key] || [];
    const res = { ctx, sig, mode, ds15, ds5, sig15, bNet, ce: [], pe: [] };
    for (const side of ['CE', 'PE']) {
      const sd = side.toLowerCase(), up = side === 'CE', out = [];
      const vols = ctx.rows.map(r => r[sd].vol || 0).filter(v => v > 0).sort((a, b) => a - b), vMed = vols.length ? vols[Math.floor(vols.length / 2)] : 0;
      for (const r of ctx.rows) {
        const o = r[sd], v = o.ltp; if (!(v >= lo && v <= hi)) continue;
        const dist = up ? r.strike - ctx.spot : ctx.spot - r.strike; if (dist <= 0 || dist > 3.5 * sig) continue;
        const L1 = ctx.spot + (up ? 1 : -1) * sig, L2 = ctx.spot + (up ? 2 : -2) * sig;
        const e1 = C.estPrice(ctx.rows, sd, r.strike, ctx.spot, L1), e2 = C.estPrice(ctx.rows, sd, r.strike, ctx.spot, L2), eK = C.estPrice(ctx.rows, sd, r.strike, ctx.spot, r.strike);
        if (!(e1 > 0 && e2 > 0)) continue;
        const x1 = e1 / v, x2 = e2 / v, p1 = C.touchProb(sig, sig), p2 = C.touchProb(2 * sig, sig), pK = C.touchProb(dist, sig);
        const spread = o.bid > 0 && o.ask > 0 ? (o.ask - o.bid) / v : NaN;
        const thin = (isFinite(spread) && spread > 0.15) || (vMed > 0 && (o.vol || 0) < vMed * 0.1) || !(o.vol > 0);
        // fuel: writers leaving this strike / the way, the other side's writers adding behind, momentum, bursts
        const fuel = []; let f = 0;
        const rb = b15.rows.find(x => x.strike === r.strike);
        if (rb && rb[sd].oi > 0) { const c = (o.oi - rb[sd].oi) / rb[sd].oi * 100;
          if (c <= -8) { f += 2; fuel.push(`${side} writers leaving ${fmtK(r.strike)} (OI ${c.toFixed(0)}% in 15 min)`); }
          else if (c >= 15) { f -= 1; fuel.push(`writers adding at ${fmtK(r.strike)} (OI +${c.toFixed(0)}%): a wall`); } }
        if (mode === (up ? 'rise' : 'fall')) { f += 2; fuel.push(`${index} ${up ? 'rising' : 'falling'} fast (${ds15 >= 0 ? '+' : ''}${f1(ds15)} pts in 15 min)`); }
        else if (mode) f -= 1;
        if (bNet && (bNet > 0) === up) { f += Math.min(2, Math.abs(bNet)); fuel.push(`sudden big OI ${up ? 'bullish' : 'bearish'} (${Math.abs(bNet)} burst${Math.abs(bNet) > 1 ? 's' : ''} in 15 min)`); }
        const pts = P.filter(x => x.p[r.strike] && x.p[r.strike][up ? 0 : 1] > 0).map(x => x.p[r.strike][up ? 0 : 1]);
        let dayLo = Math.min(v, ...(pts.length ? pts : [v])), dayHi = Math.max(v, ...(pts.length ? pts : [v]));
        const p5 = b5.rows.find(x => x.strike === r.strike), mv = p5 && p5[sd].ltp > 0 ? (v / p5[sd].ltp - 1) * 100 : 0;
        if (mv >= 25) { f += 1; fuel.push(`moving now: +${mv.toFixed(0)}% in 5 min`); }
        // expected multiple if the move comes; weighted by the chance it comes
        const ev = p1 * x1 + p2 * Math.max(0, x2 - x1);
        const score = ev * (thin ? 0.4 : 1) * (1 + 0.15 * Math.max(-3, Math.min(5, f)));
        out.push({ index, K: r.strike, side, ltp: v, spot: ctx.spot, dist, L1, L2, e1, e2, eK, x1, x2, p1, p2, pK, thin, spread, vol: o.vol || 0, oi: o.oi || 0, fuel, f, mv, dayLo, dayHi, ev, score,
          entryMax: tick05(v * 1.05), stop: tick05(Math.max(0.05, v * 0.5)), iso: ctx.iso });
      }
      res[sd] = out.filter(x => x.x2 >= 2).sort((a, b) => b.score - a.score).slice(0, 5);
    }
    return res;
  }
  /** record the top pick per side (max 3 a day each) and follow its peak, so the section shows its real track record */
  function pennyTrack(index, R) {
    if (!R || !C.marketOpen(Date.now())) return;
    const now = Date.now(), day = C.istDate(now), L = st.penny; let ch = false;
    const live = (K, sd) => { const r = R.ctx.rows.find(x => x.strike === K); return r ? r[sd.toLowerCase()].ltp : NaN; };
    for (const e of L) if (e.day === day && e.index === index && !e.done) {
      const v = live(e.K, e.side); if (!(v > 0)) continue;
      e.last = v; if (v > e.peak) { e.peak = v; e.peakTs = now; ch = true; }
      const tp = C.istParts(now); if (tp.h * 60 + tp.mi >= 15 * 60 + 25) { e.done = true; e.close = v; ch = true; }
    }
    for (const side of ['CE', 'PE']) {
      const top = R[side.toLowerCase()][0]; if (!top || top.thin || top.score < 0.6) continue;
      const mine = L.filter(e => e.day === day && e.index === index && e.side === side);
      if (mine.length >= 3 || mine.some(e => e.K === top.K) || mine.some(e => now - e.ts < 20 * 60000)) continue;
      L.push({ id: now + index + top.K + side, day, ts: now, index, iso: top.iso, K: top.K, side, entry: top.ltp, x2: +top.x2.toFixed(1), peak: top.ltp, peakTs: now, last: top.ltp, mode: R.mode, f: top.f });
      ch = true;
    }
    while (L.length > 300) L.shift();
    if (ch) store.set('oi.penny.log', L);
  }
  function pennyStats() {
    const L = st.penny.filter(e => e.entry > 0), n = L.length, hit = k => L.filter(e => e.peak / e.entry >= k).length;
    return { n, x2: hit(2), x5: hit(5), x10: hit(10), days: new Set(L.map(e => e.day)).size };
  }
  function pennyCard(c) {
    const up = c.side === 'CE', mv = up ? 'rises' : 'falls';
    return `<div class="pn ${up ? 'ce' : 'pe'}${c.thin ? ' thin' : ''}">
      <div class="pnh"><b>${c.index} ${fmtK(c.K)} ${c.side}</b><span class="pnp">₹${f2(c.ltp)}</span>${c.mv >= 25 ? '<span class="pnm">🔥 moving</span>' : ''}${c.thin ? '<span class="pnt">thin: wide spread</span>' : ''}</div>
      <div class="png num">
        <div><span>If ${c.index} ${mv} ${fmtK(Math.abs(c.L1 - c.spot))} pts</span><b>₹${f1(c.e1)} <i class="up">${c.x1.toFixed(1)}×</i></b><em>chance ${pctTxt(c.p1)}</em></div>
        <div><span>Big move ${fmtK(Math.abs(c.L2 - c.spot))} pts</span><b>₹${f1(c.e2)} <i class="up">${c.x2.toFixed(1)}×</i></b><em>chance ${pctTxt(c.p2)}</em></div>
        <div><span>Today low / high</span><b>₹${f2(c.dayLo)} / ₹${f2(c.dayHi)}</b><em>${c.dayLo > 0 ? (c.dayHi / c.dayLo).toFixed(1) + '× range' : ''}</em></div>
      </div>
      ${c.fuel.length ? `<div class="pnf">${c.fuel.map(x => `<span>${esc(x)}</span>`).join('')}</div>` : ''}
      <div class="pnr">Buy ≤ <b>₹${f2(c.entryMax)}</b> · stop ₹${f2(c.stop)} (−50%) · sell half at <b>₹${f2(c.ltp * 2)}</b> (2×) · trail the rest</div>
      ${tradeBtn({ i: c.index, k: c.K, s: c.side, t: 'B', iso: c.iso, p: c.entryMax, l: 1, hero: true, why: 'Penny' }, `🛒 Buy ${fmtK(c.K)} ${c.side}`, 'buy wide')}</div>`;
  }
  function pennyPaint() {
    const el = $('pennyPage'); if (!el) return;
    const S = st.settings, hi = S.pennyMax || 15;
    const chips = `<div class="pnchips">Price up to ${[5, 10, 15, 25].map(v => `<button class="chip ${v === hi ? 'on' : ''}" data-pmax="${v}">₹${v}</button>`).join('')}</div>`;
    let h = `<div class="card"><h3>💰 Penny strikes</h3><div class="hzcap">Cheap out-of-the-money options (₹${S.pennyMin || 0.5}–₹${hi}) that can multiply 2–10× if the market makes a sharp move today. Ranked by how much they gain on a 1σ / 2σ move, the chance of that move, liquidity, and live signals (writers leaving, sudden big OI, momentum).</div>${chips}</div>`;
    for (const index of Object.keys(C.INDICES)) {
      let R = null; try { R = pennyScan(index); pennyTrack(index, R); } catch (e) { console.error(e); }
      if (!R) { h += `<div class="card"><h3>${index}</h3><div class="hzmsg">Waiting for ${index} chain data…</div></div>`; continue; }
      const m = R.mode, banner = m ? `<div class="pnmode ${m}">${m === 'fall' ? '📉 Market falling now' : '📈 Market rising now'}: ${index} ${R.ds15 >= 0 ? '+' : ''}${f1(R.ds15)} pts in 15 min (normal ±${f1(R.sig15)}). ${m === 'fall' ? 'PUT' : 'CALL'} pennies are live.</div>` : '';
      const order = m === 'fall' ? ['pe', 'ce'] : ['ce', 'pe'];
      h += `<div class="card"><div class="fhead"><h3>${index} · ${R.ctx.iso}</h3><span class="dim" style="font-size:11px">${fmtK(R.ctx.spot)} · 1σ to close ±${isFinite(R.sig) ? fmtK(Math.round(R.sig)) : '–'} pts</span></div>${banner}`;
      for (const sd of order) {
        const L = R[sd], up = sd === 'ce';
        h += `<div class="pnsec"><b>${up ? '📈 If the market rises: CALL pennies' : '📉 If the market falls: PUT pennies'}</b></div>`;
        h += L.length ? L.slice(0, 4).map(pennyCard).join('') : `<div class="hzmsg">No ${up ? 'CE' : 'PE'} priced ₹${S.pennyMin || 0.5}–₹${hi} can reach 2× on a big move today.</div>`;
      }
      h += '</div>';
    }
    const ps = pennyStats(), today = C.istDate(Date.now()), rec = st.penny.slice().reverse().slice(0, 12);
    h += `<div class="card"><h3>📒 Penny record (real results)</h3>
      ${ps.n ? `<div class="hzmsg">Since tracking started: <b>${ps.n}</b> picks over ${ps.days} day${ps.days > 1 ? 's' : ''} · reached 2×: <b>${ps.x2}</b> (${Math.round(ps.x2 / ps.n * 100)}%) · 5×: <b>${ps.x5}</b> · 10×: <b>${ps.x10}</b></div>` : '<div class="hzmsg">No picks recorded yet. The top pick per side is recorded automatically (up to 3 a day) and followed to 3:25 PM.</div>'}
      ${rec.length ? `<table class="acct"><tr><th>When</th><th>Strike</th><th>Entry</th><th>Peak</th><th>Best</th></tr>${rec.map(e => `<tr><td>${e.day === today ? '' : e.day.slice(5) + ' '}${C.istTime(e.ts)}</td><td>${e.index === 'SENSEX' ? 'SX ' : ''}${fmtK(e.K)} ${e.side}</td><td class="num">₹${f2(e.entry)}</td><td class="num">₹${f2(e.peak)}<div class="dim" style="font-size:10px">${C.istTime(e.peakTs)}</div></td><td class="num ${e.peak / e.entry >= 2 ? 'up' : ''}">${(e.peak / e.entry).toFixed(1)}×</td></tr>`).join('')}</table>` : ''}
      <div class="hzcap">Most penny options expire near zero; the big multiples come only on sharp-move days. Use a small fixed amount you can lose fully. For educational purposes only.</div></div>`;
    el.innerHTML = h;
  }
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-pmax]'); if (!b) return; st.settings.pennyMax = +b.dataset.pmax; saveSettings(); pennyPaint(); });
  // =====================================================================================
  // PER-SECOND RECORDER — every second, NIFTY + SENSEX option chain (near ATM), spot, futures, VIX → files on the phone.
  // Minute blocks are sealed with a SHA-256 chain; gaps are written down with their reason. Retention: settings.recKeep days.
  // =====================================================================================
  const RHEAD = 'time,kind,strike,ce_ltp,ce_oi,ce_vol,ce_bid,ce_ask,pe_ltp,pe_oi,pe_vol,pe_bid,pe_ask,spot,fut,vix\n';
  const memFiles = {};                                                    // browser preview only
  if (!(Bridge && Bridge.recAppend)) window.__recMem = memFiles;
  const RB = {
    append: (n, t) => Bridge && Bridge.recAppend ? String(Bridge.recAppend(n, t)) : ((memFiles[n] = (memFiles[n] || '') + t), 'ok|' + memFiles[n].length),
    list: () => { try { return Bridge && Bridge.recList ? JSON.parse(Bridge.recList()) : Object.keys(memFiles).map(n => ({ n, size: memFiles[n].length, t: Date.now() })); } catch (e) { return []; } },
    read: (n, max) => Bridge && Bridge.recRead ? String(Bridge.recRead(n, max || 2e6)) : (memFiles[n] || '').slice(0, max || 2e6),
    verify: n => { try { return Bridge && Bridge.recVerify ? JSON.parse(Bridge.recVerify(n)) : jsVerify(memFiles[n] || ''); } catch (e) { return { ok: false, why: String(e) }; } },
    sha: s => Bridge && Bridge.sha256 ? String(Bridge.sha256(s)) : (window.__sha ? window.__sha(s) : ''),
  };
  function jsVerify(text) {                                              // same rule as the phone's check (preview/testing)
    let prev = '', blk = '', blocks = 0, rows = 0;
    for (const line of text.split('\n')) {
      if (!line) continue;
      if (line.startsWith('#BLOCK,')) { const p = line.split(','); if (RB.sha(prev + blk) !== p[3]) return { ok: false, blocks, rows, badAt: p[1] }; prev = p[3]; blk = ''; blocks++; }
      else if (!line.startsWith('#GAP') && !line.startsWith('time,')) { blk += line + '\n'; rows++; }
    }
    return { ok: true, blocks, rows, badAt: '', tail: blk ? 'last block not sealed yet' : '' };
  }
  const recName = (day, index) => `EVPulse_ticks_${day}_${index}.csv.gz`;
  const minName = day => `EVPulse_1min_${day}.csv`, momName = day => `EVPulse_moments_${day}.csv`;
  st.rec = Object.assign({ day: '', prev: {}, started: {}, last: {}, lastTs: {}, rows: {}, gapFrom: {}, gapWhy: {}, gaps: [], errs: '' }, store.get('oi.rec.state', {}));
  st.recBuf = {}; st.recLastRow = {};
  const recOn = () => st.settings.recOn !== false;
  function recSave() { const R = st.rec; store.set('oi.rec.state', { day: R.day, prev: R.prev, started: R.started, lastTs: R.lastTs, rows: R.rows, gaps: R.gaps.slice(-200) }); }
  const n2s = v => v === undefined || v === null || !isFinite(v) ? '' : (Math.round(v * 100) / 100).toString();
  function recWhy() {
    const L = LD();
    if (!wantFT()) return 'data source is NSE/BSE website (no per-second data): pick Flattrade or HDFC Sky';
    if (!L.ready()) return `${L === HS ? 'HDFC Sky' : 'Flattrade'} not logged in`;
    if (L.wsState !== 'open') return 'live feed disconnected';
    if (L.lastTick && Date.now() - L.lastTick > 10000) return 'live feed silent (no ticks)';
    return 'no chain yet';
  }
  function recTick() {
    if (!recOn()) return;
    const now = Date.now(), day = C.istDate(now), R = st.rec, open = C.marketOpen(now);
    if (R.day !== day) { recFlushAll(true); Object.assign(R, { day, prev: {}, started: {}, lastTs: {}, rows: {}, gapFrom: {}, gapWhy: {}, gaps: [] }); st.recBuf = {}; st.recLastRow = {}; recSave();
      try { const keep = st.settings.recKeep || 30, d = new Date(now - keep * 86400e3 + 5.5 * 3600e3).toISOString().slice(0, 10); if (Bridge && Bridge.recPrune) Bridge.recPrune(d); } catch (e) { } }
    if (!open) { recFlushAll(false); return; }
    const sec = Math.floor(now / 1000) * 1000, t = C.istTime(sec, true), L = LD();
    for (const index of Object.keys(C.INDICES)) {
      const iso = (st.expiries[index] || [])[0];
      let p = null;
      if (useFT() && iso && L.hasChain(index, iso) && !(L.lastTick && now - L.lastTick > 10000)) { try { p = L.chain(index, iso, lastSpot(index)); } catch (e) { p = null; } }
      if (!p || !p.rows.length || !p.spot) {                           // a gap: remember when and why it started
        if (!R.gapFrom[index]) { R.gapFrom[index] = R.lastTs[index] && now - R.lastTs[index] < 60000 ? R.lastTs[index] + 1000 : sec; R.gapWhy[index] = recWhy(); }
        continue;
      }
      const buf = st.recBuf[index] = st.recBuf[index] || [];
      const lastTs = R.lastTs[index] || 0;
      if (R.gapFrom[index] || (lastTs && sec - lastTs > 5000 && C.istDate(lastTs) === day)) {
        const from = R.gapFrom[index] || lastTs + 1000, why = R.gapWhy[index] || 'app was closed or the phone was asleep';
        if (sec - from >= 2000) { const g = { index, from, to: sec - 1000, why }; R.gaps.push(g); buf.push(`#GAP,${C.istTime(g.from, true)},${C.istTime(g.to, true)},${why.replace(/,/g, ';')}`); }
        R.gapFrom[index] = 0; R.gapWhy[index] = '';
      }
      if (sec === lastTs) continue;
      const key = (index === 'NIFTY' && L.futQuote) ? L.futQuote() : null, vx = (() => { try { return vixNow(); } catch (e) { return null; } })();
      const full = !lastTs || Math.floor(sec / 60000) !== Math.floor(lastTs / 60000);   // every new minute: all strikes (a keyframe)
      const memo = st.recLastRow[index] = st.recLastRow[index] || {};
      buf.push(`${t},I,,,,,,,,,,,,${n2s(p.spot)},${key ? n2s(key.ltp) : ''},${vx && vx.v ? n2s(vx.v) : ''}`);
      const step = C.INDICES[index].step;
      for (const r of p.rows) {
        if (Math.abs(r.strike - p.spot) > step * 15) continue;
        const body = [r.ce.ltp, r.ce.oi, r.ce.vol, r.ce.bid, r.ce.ask, r.pe.ltp, r.pe.oi, r.pe.vol, r.pe.bid, r.pe.ask].map(n2s).join(',');
        if (!full && memo[r.strike] === body) continue;
        memo[r.strike] = body; buf.push(`${t},S,${r.strike},${body}`);
      }
      R.lastTs[index] = sec; R.rows[index] = (R.rows[index] || 0) + 1;
      if (full && lastTs) recFlush(index, lastTs);
    }
  }
  /** seal the buffered rows of the minute that just ended: hash chain + one gzip write */
  function recFlush(index, ts) {
    const R = st.rec, buf = st.recBuf[index] || []; if (!buf.length) return;
    // the first line of the current (new) minute stays in the buffer: rows of the next minute begin at its index-row
    let cut = buf.length; const curMin = C.istTime(R.lastTs[index], true).slice(0, 5);
    for (let i = 0; i < buf.length; i++) if (!buf[i].startsWith('#') && buf[i].slice(0, 5) === curMin && buf[i].split(',')[1] === 'I') { cut = i; break; }
    const rows = buf.slice(0, cut), rest = buf.slice(cut); if (!rows.length) return;
    const data = rows.filter(l => !l.startsWith('#GAP')), gaps = rows.filter(l => l.startsWith('#GAP'));
    const block = data.map(l => l + '\n').join(''), h = RB.sha((R.prev[index] || '') + block);
    const name = recName(R.day, index), head = R.started[index] ? '' : RHEAD;
    const text = head + gaps.map(l => l + '\n').join('') + block + `#BLOCK,${C.istTime(ts, true).slice(0, 5)},${data.length},${h}\n`;
    const res = RB.append(name, text);
    if (/^ok/.test(res)) { R.prev[index] = h; R.started[index] = 1; st.recBuf[index] = rest; R.errs = ''; recSave(); }
    else R.errs = res;
    recMinute(index, ts);
  }
  function recFlushAll(endOfDay) { for (const index of Object.keys(C.INDICES)) if ((st.recBuf[index] || []).length && (endOfDay || Date.now() - (st.rec.lastTs[index] || 0) > 90000)) {
    const buf = st.recBuf[index]; const R = st.rec, data = buf.filter(l => !l.startsWith('#GAP')), gaps = buf.filter(l => l.startsWith('#GAP')); if (!data.length) continue;
    const block = data.map(l => l + '\n').join(''), h = RB.sha((R.prev[index] || '') + block);
    if (/^ok/.test(RB.append(recName(R.day, index), (R.started[index] ? '' : RHEAD) + gaps.map(l => l + '\n').join('') + block + `#BLOCK,${C.istTime(R.lastTs[index], true).slice(0, 5)},${data.length},${h}\n`))) { R.prev[index] = h; R.started[index] = 1; st.recBuf[index] = []; recSave(); } } }
  setInterval(() => { try { recTick(); } catch (e) { st.rec.errs = String(e); } }, 1000);

  // ---- 1-minute summary row (OI change + price) for Excel
  st.recMinStarted = store.get('oi.rec.minday', '');
  function recMinute(index, ts) {
    const R = st.rec, x = (() => { try { return oipResult(index, '1'); } catch (e) { return null; } })(); if (!x) return;
    const head = st.recMinStarted === R.day ? '' : 'time,index,spot,fut,vix,ce_oi_near,pe_oi_near,ce_oi_chg_1m,pe_oi_chg_1m,atm,atm_ce,atm_pe,verdict_1m,score_1m,verdict_5m,score_5m,strongest\n';
    const x5 = (() => { try { return oipResult(index, '5'); } catch (e) { return null; } })(), q = index === 'NIFTY' && LD().futQuote ? LD().futQuote() : null, vx = (() => { try { return vixNow(); } catch (e) { return null; } })();
    const line = [C.istTime(ts, true).slice(0, 5), index, n2s(x.spot), q ? n2s(q.ltp) : '', vx && vx.v ? n2s(vx.v) : '', x.ceOi, x.peOi, x.dCe, x.dPe, x.atm, n2s(x.atmCe), n2s(x.atmPe),
      x.verdict, x.score, x5 ? x5.verdict : '', x5 ? x5.score : '', x.top ? `${x.top.K} ${x.top.side} ${x.top.kind}` : ''].join(',') + '\n';
    if (/^ok/.test(RB.append(minName(R.day), head + line))) { st.recMinStarted = R.day; store.set('oi.rec.minday', R.day); }
  }

  // =====================================================================================
  // OI CHANGE + PRICE RESULT — reads every near-ATM strike's OI change together with its price change
  // =====================================================================================
  const OIP_WIN = [['1', '1 min'], ['5', '5 min'], ['15', '15 min'], ['open', 'Since 9:15']];
  function oipBase(index, win) {
    const now = Date.now();
    if (win === '1') { const B = st.tk[index] || []; for (let i = B.length - 1; i >= 0; i--) if (now - B[i].ts >= 60000) return { ts: B[i].ts, get: (K, s) => { const r = B[i].r[K]; return r ? (s === 'ce' ? { ltp: r[0], oi: r[1] } : { ltp: r[3], oi: r[4] }) : null; } }; }
    const d = dataNear(index); if (!d || !d.h.length) return null;
    let b = d.h[0];
    if (win !== 'open') { const m = win === '1' ? 1 : +win; for (const s of d.h) if (now - s.ts >= m * 60000) b = s; }
    else b = st.first[d.key] || d.h[0];
    return { ts: b.ts, get: (K, s) => { const r = b.rows.find(x => x.strike === K); return r ? r[s] : null; } };
  }
  /** for the index: +1 = bullish meaning, −1 = bearish, per buildup type and side */
  const OIP_MEAN = { CE: { 'Short covering': 1, 'Long buildup': 1, 'Short buildup': -1, 'Long unwinding': -1 }, PE: { 'Short covering': -1, 'Long buildup': -1, 'Short buildup': 1, 'Long unwinding': 1 } };
  function oipKind(dp, doi) { if (dp > 0 && doi < 0) return 'Short covering'; if (dp > 0 && doi > 0) return 'Long buildup'; if (dp < 0 && doi > 0) return 'Short buildup'; if (dp < 0 && doi < 0) return 'Long unwinding'; return ''; }
  st.oipSince = store.get('oi.oip.since', {});
  function oipResult(index, win) {
    const d = dataNear(index); if (!d) return null;
    const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur, base = oipBase(index, win); if (!base) return null;
    const step = C.INDICES[index].step, atm = Math.round(cur.spot / step) * step, rows = cur.rows.filter(r => Math.abs(r.strike - atm) <= step * 5);
    let score = 0, w = 0, top = null, dCe = 0, dPe = 0, ceOi = 0, peOi = 0; const kinds = {};
    for (const r of rows) for (const side of ['CE', 'PE']) {
      const sd = side.toLowerCase(), o = r[sd], b = base.get(r.strike, sd); if (!b || !(b.oi > 0) || !(o.oi > 0)) continue;
      const doi = o.oi - b.oi, dp = o.ltp - b.ltp, k = oipKind(dp, doi);
      if (sd === 'ce') { dCe += doi; ceOi += o.oi; } else { dPe += doi; peOi += o.oi; }
      if (!k || Math.abs(doi) / b.oi < 0.003) continue;
      const m = OIP_MEAN[side][k], wt = Math.abs(doi); score += m * wt; w += wt;
      kinds[side + ' ' + k] = (kinds[side + ' ' + k] || 0) + wt;
      if (!top || wt > top.wt) top = { K: r.strike, side, kind: k, wt, doi, dp, pct: doi / b.oi * 100, pp: b.ltp > 0 ? dp / b.ltp * 100 : 0, m };
    }
    const s = w ? Math.round(score / w * 100) : 0, verdict = s >= 25 ? 'Bullish' : s <= -25 ? 'Bearish' : 'Sideways';
    const key = index + '|' + win, prev = st.oipSince[key];
    if (!prev || prev.v !== verdict || C.istDate(prev.ts) !== C.istDate(Date.now())) { st.oipSince[key] = { v: verdict, ts: Date.now() }; store.set('oi.oip.since', st.oipSince);
      if (prev && prev.v !== verdict && win === '5' && C.marketOpen(Date.now()) && C.istDate(prev.ts) === C.istDate(Date.now())) momentAdd({ index, kind: 'Verdict change', txt: `5-min OI + price read turned ${prev.v} → ${verdict} (score ${s})`, b: verdict === 'Bullish' ? 1 : verdict === 'Bearish' ? -1 : 0, spot: cur.spot }); }
    const main = Object.entries(kinds).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([k, v]) => ({ k, share: w ? v / w * 100 : 0 }));
    const atmR = cur.rows.find(r => r.strike === atm);
    return { index, win, spot: cur.spot, ts: cur.ts, baseTs: base.ts, score: s, verdict, top, main, since: st.oipSince[key].ts, dCe, dPe, ceOi, peOi, atm, atmCe: atmR ? atmR.ce.ltp : NaN, atmPe: atmR ? atmR.pe.ltp : NaN };
  }
  function oipCard(index) {
    const win = st.ui.oipWin || '5', x = oipResult(index, win);
    const chips = `<div class="toggle">${OIP_WIN.map(([k, n]) => `<button class="chip ${k === win ? 'on' : ''}" data-oipw="${k}">${n}</button>`).join('')}</div>`;
    if (!x) return `<div class="card"><h3>OI + price · ${index}</h3>${chips}<div class="hzmsg">Waiting for data${win === '1' ? ' (1 min needs Flattrade or HDFC Sky live data)' : ''}…</div></div>`;
    const cl = x.verdict === 'Bullish' ? 'up' : x.verdict === 'Bearish' ? 'dn' : '';
    const t = x.top, tTxt = t ? `<b>${fmtK(t.K)} ${t.side}</b>: ${t.kind.toLowerCase()} (OI ${t.pct >= 0 ? '+' : ''}${t.pct.toFixed(1)}%, price ${t.pp >= 0 ? '+' : ''}${t.pp.toFixed(0)}%)` : '–';
    return `<div class="card oip"><div class="fhead"><h3>OI + price · ${index}</h3><span class="dim" style="font-size:11px">vs ${C.istTime(x.baseTs, true)}</span></div>${chips}
      <div class="oipv ${cl}"><b>${x.verdict === 'Bullish' ? '📈' : x.verdict === 'Bearish' ? '📉' : '↔️'} ${x.verdict}</b><span>score ${x.score > 0 ? '+' : ''}${x.score} · held since ${C.istTime(x.since)}</span></div>
      <div class="hzmsg">${x.main.length ? x.main.map(m => `${m.k} (${Math.round(m.share)}% of the OI change)`).join(' · ') : 'OI and prices hardly changed in this window.'}</div>
      <div class="hzmsg">Strongest strike: ${tTxt}</div>
      <div class="hzcap">Near-ATM ±5 strikes. CE OI ${sQ(x.dCe)} · PE OI ${sQ(x.dPe)}. Call short covering / long buildup and put writing count as bullish; call writing, put buying and put short covering as bearish.</div></div>`;
  }
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-oipw]'); if (!b) return; st.ui.oipWin = b.dataset.oipw; saveUi(); render(); });

  // ---- moments: the exact second something important happened
  st.moments = store.get('oi.moments', { day: '', list: [] });
  function momentAdd(m) {
    const day = C.istDate(Date.now()); if (st.moments.day !== day) st.moments = { day, list: [] };
    const L = st.moments.list, ts = m.ts || Date.now();
    if (L.some(x => x.index === m.index && x.txt === m.txt && ts - x.ts < 120000)) return;
    L.push(Object.assign({ ts }, m)); while (L.length > 400) L.shift(); store.set('oi.moments', st.moments);
    const head = st.rec.momStarted === day ? '' : 'time,index,kind,meaning,spot,detail\n';
    if (/^ok/.test(RB.append(momName(day), head + [C.istTime(ts, true), m.index, m.kind, m.b > 0 ? 'bullish' : m.b < 0 ? 'bearish' : '', n2s(m.spot), '"' + String(m.txt).replace(/"/g, "'") + '"'].join(',') + '\n'))) st.rec.momStarted = day;
  }
  // bursts and premium spikes become moments
  setInterval(() => {
    if (!C.marketOpen(Date.now())) return;
    for (const index of Object.keys(C.INDICES)) {
      for (const e of st.bursts[index] || []) if (!e.mom) { e.mom = 1; momentAdd({ ts: e.t1, index, kind: 'Sudden OI', txt: `${fmtK(e.K)} ${e.side} OI ${sQ(e.dOi)} (${e.pct >= 0 ? '+' : ''}${e.pct.toFixed(1)}%) in 30 s, ₹${f2(e.p0)}→₹${f2(e.p1)}: ${e.t}`, b: e.b, spot: e.s1 }); }
      const B = st.tk[index] || []; if (B.length < 50) continue;
      const now = B[B.length - 1]; let j = B.length - 1; while (j > 0 && now.ts - B[j].ts < 90000) j--; const old = B[j];
      for (const K of Object.keys(now.r)) for (const [side, ip] of [['CE', 0], ['PE', 3]]) {
        const a = old.r[K], b = now.r[K]; if (!a || !b || !(a[ip] >= 2)) continue;
        const g = (b[ip] / a[ip] - 1) * 100; if (Math.abs(g) < 30 || Math.abs(b[ip] - a[ip]) < 2) continue;
        const k = 'spk|' + index + K + side + (g > 0 ? '+' : '-'); if (st.cool[k] && Date.now() - st.cool[k] < 10 * 60000) continue; st.cool[k] = Date.now();
        momentAdd({ ts: now.ts, index, kind: 'Premium spike', txt: `${fmtK(+K)} ${side} ₹${f2(a[ip])} → ₹${f2(b[ip])} (${g >= 0 ? '+' : ''}${g.toFixed(0)}% in 90 s)`, b: (g > 0) === (side === 'CE') ? 1 : -1, spot: now.s });
      }
    }
  }, 5000);

  // =====================================================================================
  // AUDIT — did each signal's direction come true 5 / 15 / 30 minutes later? (from the per-minute spot record)
  // =====================================================================================
  function spotAt(index, ts) {
    const exps = st.expiries[index] || [], P = (st.path || {})[index + '|' + (exps[0] || '')] || []; if (!P.length) return NaN;
    const tp = C.istParts(ts), m = tp.h * 60 + tp.mi; let best = null;
    for (const x of P) { if (x.m >= m) { best = x; break; } }
    return best && best.m - m <= 2 ? best.s : NaN;
  }
  function auditRows(day) {
    day = day || C.istDate(Date.now());
    const sig = [];
    for (const a of st.alerts) if (C.istDate(a.ts) === day && (a.tone === 'bull' || a.tone === 'bear') && a.type !== 'posAdvice' && !/position/i.test(a.kind || '')) sig.push({ ts: a.ts, index: a.index, src: 'Alert', what: a.kind || a.title, b: a.tone === 'bull' ? 1 : -1 });
    if (st.moments.day === day) for (const m of st.moments.list) if (m.b && m.kind !== 'Sudden OI') sig.push({ ts: m.ts, index: m.index, src: 'Moment', what: m.kind, b: m.b, txt: m.txt });
    const now = Date.now();
    return sig.sort((a, b) => a.ts - b.ts).map(x => {
      const s0 = spotAt(x.index, x.ts), out = Object.assign({}, x, { s0 });
      for (const h of [5, 15, 30]) {
        const t = x.ts + h * 60000; if (t > now - 60000) { out['r' + h] = null; continue; }
        const s = spotAt(x.index, t), mv = s - s0, need = s0 * 0.0002;
        out['s' + h] = s; out['r' + h] = !isFinite(mv) ? null : Math.abs(mv) < need ? 0 : Math.sign(mv) === x.b ? 1 : -1;
      }
      return out;
    });
  }
  function auditStats(rows) {
    const by = {};
    for (const r of rows) { const k = r.what; const b = by[k] = by[k] || { n: 0, ok: 0, done: 0 };
      b.n++; if (r.r15 !== null && r.r15 !== undefined) { b.done++; if (r.r15 === 1) b.ok++; } }
    const all = rows.filter(r => r.r15 !== null && r.r15 !== undefined);
    return { by, n: rows.length, done: all.length, ok: all.filter(r => r.r15 === 1).length };
  }
  function auditCsv() {
    const rows = [['Date', 'Time (IST)', 'Index', 'Source', 'Signal', 'Direction', 'Spot at signal', 'Spot +5 min', 'Result +5', 'Spot +15 min', 'Result +15', 'Spot +30 min', 'Result +30', 'Detail']];
    const R = x => x === 1 ? 'RIGHT' : x === -1 ? 'WRONG' : x === 0 ? 'FLAT' : 'pending';
    for (const r of auditRows()) rows.push([C.istDate(r.ts), C.istTime(r.ts, true), r.index, r.src, r.what, r.b > 0 ? 'UP' : 'DOWN', r.s0, r.s5, R(r.r5), r.s15, R(r.r15), r.s30, R(r.r30), r.txt || '']);
    return rows;
  }
  EXPORTS.audit = ['Signal audit (right / wrong)', 'Signal_Audit', auditCsv];
  EXPORTS.moments = ['Moments log', 'Moments', () => [['Date', 'Time (IST)', 'Index', 'Kind', 'Meaning', 'Spot', 'Detail'], ...(st.moments.list || []).map(m => [st.moments.day, C.istTime(m.ts, true), m.index, m.kind, m.b > 0 ? 'bullish' : m.b < 0 ? 'bearish' : '', m.spot, m.txt])]];

  // =====================================================================================
  // DAILY → DATA / AUDIT tab
  // =====================================================================================
  function recFiles() { return RB.list().filter(f => /^EVPulse_/.test(f.n)).sort((a, b) => b.n.localeCompare(a.n)); }
  const mb = n => n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : n >= 1024 ? Math.round(n / 1024) + ' KB' : n + ' B';
  function dataView() {
    const R = st.rec, today = C.istDate(Date.now()), on = recOn(), open = C.marketOpen(Date.now());
    const live = Object.keys(C.INDICES).map(i => R.lastTs[i] && Date.now() - R.lastTs[i] < 5000);
    const state = !on ? '<b class="dn">Off</b>' : !open ? 'Waiting for market hours (9:15–3:30)' : live.some(Boolean) ? '<b class="up">● Recording every second</b>' : `<b class="dn">Not recording: ${esc(recWhy())}</b>`;
    const files = recFiles(), todays = files.filter(f => f.n.includes(today)), size = todays.reduce((a, f) => a + f.size, 0);
    const gaps = (R.day === today ? R.gaps : []).slice(-6).reverse();
    const recCard = `<div class="card"><div class="fhead"><h3>⏺ Per-second recorder</h3><label class="exp" style="margin:0;font-size:12px"><input type="checkbox" id="recOn" ${on ? 'checked' : ''}> On</label></div>
      <div class="hzmsg">${state}</div>
      <div class="hzmsg">Today: ${Object.keys(C.INDICES).map(i => `<b>${i}</b> ${R.day === today ? (R.rows[i] || 0).toLocaleString('en-IN') : 0} seconds${R.lastTs[i] && R.day === today ? ` (last ${C.istTime(R.lastTs[i], true)})` : ''}`).join(' · ')} · files ${mb(size)}</div>
      ${gaps.length ? `<div class="hzmsg"><b>Gaps today</b>${gaps.map(g => `<br>${g.index} ${C.istTime(g.from, true)} – ${C.istTime(g.to, true)}: ${esc(g.why)}`).join('')}</div>` : (R.day === today && Object.values(R.rows).some(Boolean) ? '<div class="hzmsg up">No gaps today ✓</div>' : '')}
      ${R.errs ? `<div class="hzmsg dn">${esc(R.errs)}</div>` : ''}
      <div class="hzcap">Each second: spot, NIFTY futures, India VIX and, for 31 strikes around ATM, CE/PE price, OI, volume, bid, ask. Unchanged strikes are written once a minute (each minute starts with all strikes). Each minute is sealed with a SHA-256 chain, so any later edit is caught by <b>Verify</b>. Kept ${st.settings.recKeep || 30} days. Needs Flattrade or HDFC Sky live data and the app running (set battery to Unrestricted).</div>
      <div class="field" style="margin-top:8px"><label>Keep recordings for (days)</label><input id="recKeep" type="number" min="3" max="365" value="${st.settings.recKeep || 30}"></div></div>`;
    const res = `<div class="dsec">OI change + price: the result</div>${Object.keys(C.INDICES).map(oipCard).join('')}`;
    const ml = st.moments.day === today ? st.moments.list.slice().reverse().slice(0, 25) : [];
    const mom = `<div class="card"><div class="fhead"><h3>⚡ Moments today</h3><span class="dim" style="font-size:11px">${ml.length} logged</span></div>
      ${ml.length ? `<div class="momlist">${ml.map(m => `<div class="mom ${m.b > 0 ? 'up' : m.b < 0 ? 'dn' : ''}"><span class="num">${C.istTime(m.ts, true)}</span><b>${m.index} · ${esc(m.kind)}</b><i>${esc(m.txt)}</i></div>`).join('')}</div>` : '<div class="hzmsg">Nothing yet. Sudden OI, premium spikes (30%+ in 90 s) and changes of the 5-min OI + price read are logged here to the second.</div>'}</div>`;
    const ar = auditRows(), as = auditStats(ar), R1 = x => x === 1 ? '<b class="up">✓</b>' : x === -1 ? '<b class="dn">✗</b>' : x === 0 ? '<span class="dim">flat</span>' : '<span class="dim">…</span>';
    const aud = `<div class="card"><div class="fhead"><h3>🧾 Audit: were the signals right?</h3><span class="dim" style="font-size:11px">today</span></div>
      ${as.done ? `<div class="hzmsg">After 15 min: <b>${as.ok} of ${as.done} right (${Math.round(as.ok / as.done * 100)}%)</b>${as.n > as.done ? ` · ${as.n - as.done} still pending` : ''}</div>
        <div class="hzmsg">${Object.entries(as.by).filter(([, b]) => b.done).sort((a, b) => b[1].done - a[1].done).map(([k, b]) => `${esc(k)}: ${b.ok}/${b.done}`).join(' · ')}</div>` : `<div class="hzmsg">${as.n ? `${as.n} signals so far; results appear 15 minutes after each one.` : 'No directional signals yet today.'}</div>`}
      ${ar.length ? `<table class="acct aud"><tr><th>Signal</th><th>Way</th><th>+5</th><th>+15</th><th>+30</th></tr>${ar.slice(-15).reverse().map(r => `<tr><td><span class="dim">${C.istTime(r.ts)}</span> ${r.index === 'SENSEX' ? 'SX · ' : ''}${esc(r.what)}</td><td class="${r.b > 0 ? 'up' : 'dn'}">${r.b > 0 ? '↑' : '↓'}</td><td>${R1(r.r5)}</td><td>${R1(r.r15)}</td><td>${R1(r.r30)}</td></tr>`).join('')}</table>` : ''}
      <div class="hzcap">Right = the index moved the signalled way (by at least 0.02%) after 5, 15 and 30 minutes, checked from the recorded spot. Kept for every day so the hit rate builds up.</div></div>`;
    const fl = files.slice(0, 16);
    const dl = `<div class="card"><h3>⬇ Recorded files</h3>
      ${fl.length ? `<div class="reclist">${fl.map(f => `<div class="recf"><div><b>${esc(f.n.replace(/^EVPulse_/, ''))}</b><span>${mb(f.size)}</span></div><span class="recb">${/ticks_/.test(f.n) ? `<button class="chip" data-recv="${esc(f.n)}">Verify</button>` : ''}<button class="chip" data-recx="${esc(f.n)}">Download</button></span>${st.recVer && st.recVer[f.n] ? `<div class="recv ${st.recVer[f.n].ok ? 'up' : 'dn'}">${st.recVer[f.n].ok ? `✓ Verified: ${st.recVer[f.n].blocks} sealed minutes, ${st.recVer[f.n].rows.toLocaleString('en-IN')} rows, untouched` : `✗ Changed or damaged at minute ${esc(st.recVer[f.n].badAt || '?')}${st.recVer[f.n].why ? ': ' + esc(st.recVer[f.n].why) : ''}`}${st.recVer[f.n].fileHash ? `<br><span class="dim">File SHA-256 ${st.recVer[f.n].fileHash.slice(0, 16)}…</span>` : ''}</div>` : ''}</div>`).join('')}</div>` : '<div class="hzmsg">No recordings yet.</div>'}
      <div class="dlgrid" style="margin-top:8px"><button class="dlb" data-dl="audit"><b>Signal audit</b><span>.csv</span></button><button class="dlb" data-dl="moments"><b>Moments log</b><span>.csv</span></button></div>
      <div class="hzcap">ticks_…csv.gz = every second (open with any unzip app, then Excel; one file per index per day). 1min_…csv = one row a minute with the OI change + price result. Files go to Downloads → EV Pulse → Recorder.</div></div>`;
    return recCard + res + mom + aud + dl;
  }
  document.addEventListener('click', e => {
    const t = e.target; if (!t.closest) return;
    const x = t.closest('[data-recx]'); if (x) { const n = x.dataset.recx;
      const r = Bridge && Bridge.recExport ? String(Bridge.recExport(n)) : (() => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([memFiles[n] || ''])); a.download = n; document.body.appendChild(a); a.click(); a.remove(); return 'ok|Downloads/' + n; })();
      toast(r.startsWith('ok|') ? 'Saved: ' + r.slice(3) : r.slice(r.indexOf('|') + 1)); return; }
    const v = t.closest('[data-recv]'); if (v) { st.recVer = st.recVer || {}; st.recVer[v.dataset.recv] = RB.verify(v.dataset.recv); render(); }
  });
  document.addEventListener('change', e => {
    if (e.target && e.target.id === 'recOn') { st.settings.recOn = e.target.checked; saveSettings(); toast(e.target.checked ? 'Recorder on' : 'Recorder off'); render(); }
    if (e.target && e.target.id === 'recKeep') { const v = Math.max(3, Math.min(365, +e.target.value || 30)); st.settings.recKeep = v; saveSettings(); toast(`Recordings kept ${v} days`); }
  });
  // =====================================================================================
  // OI CHANGE MONITOR + PENDING OI (Home, refreshed every second)
  // =====================================================================================
  st.oiMonPrev = {}; st.oiPeakLive = {};
  function monRows(index) {
    const iso = (st.expiries[index] || [])[0], d = dataNear(index); if (!iso || !d) return null;
    const L = LD();
    if (useFT() && L.hasChain(index, iso)) { try { const p = L.chain(index, iso, lastSpot(index)); if (p.rows.length && p.spot) return { index, iso, key: d.key, spot: p.spot, rows: p.rows, ts: Date.now(), live: true }; } catch (e) { } }
    const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur;
    return { index, iso, key: d.key, spot: cur.spot, rows: cur.rows, ts: cur.ts, live: false };
  }
  /** OI of each strike about 60 s ago (2-second record when live, else the snapshot a minute back) */
  function monAgo(index, secs) {
    const now = Date.now(), B = st.tk[index] || [];
    for (let i = B.length - 1; i >= 0; i--) if (now - B[i].ts >= secs * 1000) { const p = B[i]; return { ts: p.ts, get: (K, sd) => { const r = p.r[K]; return r ? r[sd === 'ce' ? 1 : 4] : NaN; } }; }
    const d = dataNear(index); if (!d) return null;
    let b = null; for (const s of d.h) if (now - s.ts >= secs * 1000) b = s; if (!b) return null;
    return { ts: b.ts, get: (K, sd) => { const r = b.rows.find(x => x.strike === K); return r ? r[sd].oi : NaN; } };
  }
  function monPeak(m) {                                   // highest OI seen today per strike (live, every second)
    const day = C.istDate(Date.now()), P = st.oiPeakLive[m.key] = (st.oiPeakLive[m.key] && st.oiPeakLive[m.key].day === day) ? st.oiPeakLive[m.key] : { day, k: {} };
    const pk = st.peaks[m.key] || {};
    for (const r of m.rows) {
      const x = P.k[r.strike] || (P.k[r.strike] = [0, 0]), q = pk[r.strike];
      x[0] = Math.max(x[0], r.ce.oi || 0, q && isFinite(q[0]) ? r.ce.poi + q[0] : 0);
      x[1] = Math.max(x[1], r.pe.oi || 0, q && isFinite(q[1]) ? r.pe.poi + q[1] : 0);
    }
    return P.k;
  }
  const mq = v => !isFinite(v) ? '–' : (v > 0 ? '+' : '') + Q(v);
  function oiMonHtml(index) {
    const m = monRows(index);
    if (!m) return `<div class="card oimon"><h3>📡 OI change monitor</h3><div class="hzmsg">Waiting for ${index} chain data…</div></div>`;
    const step = C.INDICES[index].step, atm = Math.round(m.spot / step) * step, ago = monAgo(index, 60), prev = st.oiMonPrev[index] = st.oiMonPrev[index] || {};
    let ce = 0, pe = 0, ce1 = 0, pe1 = 0, ceOi = 0, peOi = 0, top = null;
    for (const r of m.rows) {
      ce += r.ce.oi - r.ce.poi; pe += r.pe.oi - r.pe.poi; ceOi += r.ce.oi; peOi += r.pe.oi;
      if (ago) for (const sd of ['ce', 'pe']) { const a = ago.get(r.strike, sd); if (!isFinite(a)) continue; const d1 = r[sd].oi - a; if (sd === 'ce') ce1 += d1; else pe1 += d1;
        if (Math.abs(r.strike - atm) <= step * 8 && (!top || Math.abs(d1) > Math.abs(top.d))) top = { K: r.strike, sd, d: d1, a }; }
    }
    const net = pe - ce, bias = net > 0.1 * Math.max(Math.abs(ce), Math.abs(pe), 1) ? ['Put writers stronger', 'up'] : net < -0.1 * Math.max(Math.abs(ce), Math.abs(pe), 1) ? ['Call writers stronger', 'dn'] : ['Balanced', ''];
    const pcr = ceOi > 0 ? peOi / ceOi : NaN;
    const rows = m.rows.filter(r => Math.abs(r.strike - atm) <= step * 6);
    const cell = (r, sd) => { const a = ago ? ago.get(r.strike, sd) : NaN, d1 = r[sd].oi - a, k = r.strike + sd, old = prev[k], now = r[sd].oi; prev[k] = now;
      return { day: now - r[sd].poi, d1, fl: old !== undefined && old !== now ? (now > old ? ' flu' : ' fld') : '' }; };
    const body = rows.map(r => { const c = cell(r, 'ce'), p = cell(r, 'pe'), hot = top && top.K === r.strike;
      return `<tr class="${r.strike === atm ? 'atm' : ''}"><td class="${cls(c.day)}">${mq(c.day)}</td><td class="m1 ${cls(c.d1)}${c.fl}">${mq(c.d1)}</td><td class="sk">${hot ? '🔥' : ''}${fmtK(r.strike)}</td><td class="m1 ${cls(p.d1)}${p.fl}">${mq(p.d1)}</td><td class="${cls(p.day)}">${mq(p.day)}</td></tr>`; }).join('');
    const tTxt = top && Math.abs(top.d) > 0 ? (() => { const sd = top.sd.toUpperCase(), up = top.d > 0;
      const what = sd === 'CE' ? (up ? 'call writers adding (resistance building)' : 'call writers exiting (resistance weakening)') : (up ? 'put writers adding (support building)' : 'put writers exiting (support weakening)');
      return `Biggest move in the last minute: <b>${fmtK(top.K)} ${sd} ${mq(top.d)}</b>${top.a > 0 ? ` (${(top.d / top.a * 100).toFixed(1)}%)` : ''}: ${what}.`; })() : 'No OI change in the last minute.';
    return `<div class="card oimon"><div class="fhead"><h3>📡 OI change monitor · ${index}</h3><span class="omlive ${m.live ? 'on' : ''}">${m.live ? '● live' : '● 1 min'} ${C.istTime(m.ts, true)}</span></div>
      <div class="omt num">
        <div><span>CE OI today</span><b class="${cls(-ce)}">${mq(ce)}</b><em>1 min ${mq(ce1)}</em></div>
        <div><span>PE OI today</span><b class="${cls(pe)}">${mq(pe)}</b><em>1 min ${mq(pe1)}</em></div>
        <div><span>Net (PE − CE)</span><b class="${bias[1]}">${mq(net)}</b><em>${bias[0]}</em></div>
        <div><span>PCR now</span><b>${isFinite(pcr) ? pcr.toFixed(2) : '–'}</b><em>${isFinite(pcr) ? (pcr > 1.2 ? 'bullish lean' : pcr < 0.8 ? 'bearish lean' : 'neutral') : ''}</em></div></div>
      <div class="hzmsg">${tTxt}</div>
      <table class="omtab num"><tr><th>CE today</th><th>CE 1 min</th><th>Strike</th><th>PE 1 min</th><th>PE today</th></tr>${body}</table>
      <div class="hzcap">"Today" = change vs previous close; "1 min" = change in the last 60 seconds. Rising CE OI caps the upside, rising PE OI supports. ${m.live ? 'Refreshes every second.' : 'Refreshes each minute: pick Flattrade or HDFC Sky in Settings for every-second updates.'}</div></div>`;
  }
  function pendHtml(index) {
    const m = monRows(index); if (!m) return '';
    const step = C.INDICES[index].step, atm = Math.round(m.spot / step) * step, pk = monPeak(m), lot = LOT[index] || 1;
    const rows = m.rows.filter(r => Math.abs(r.strike - atm) <= step * 8);
    const max = Math.max(1, ...rows.map(r => Math.max(r.ce.oi || 0, r.pe.oi || 0)));
    let tc = 0, tp = 0, tcx = 0, tpx = 0;
    for (const r of m.rows) { const p = pk[r.strike] || [0, 0]; tc += r.ce.oi || 0; tp += r.pe.oi || 0; tcx += Math.max(0, p[0] - (r.ce.oi || 0)); tpx += Math.max(0, p[1] - (r.pe.oi || 0)); }
    const wallC = rows.filter(r => r.strike >= m.spot).sort((a, b) => b.ce.oi - a.ce.oi)[0], wallP = rows.filter(r => r.strike <= m.spot).sort((a, b) => b.pe.oi - a.pe.oi)[0];
    const body = rows.map(r => { const p = pk[r.strike] || [0, 0];
      const side = (o, peak, sd) => { const ex = peak > 0 ? Math.max(0, (peak - o.oi) / peak * 100) : 0;
        const w = (o.oi / max * 100).toFixed(1), pk_ = Math.min(99.5, peak / max * 100).toFixed(1);
        return `<div class="pdb ${sd}"><i style="width:${w}%"></i><s style="${sd === 'ce' ? 'right' : 'left'}:${pk_}%"></s></div><div class="pdv"><b>${Q(o.oi)}</b>${ex >= 1 ? `<span class="dn">−${ex.toFixed(0)}% from peak</span>` : '<span class="dim">at peak</span>'}</div>`; };
      return `<div class="pdr ${r.strike === atm ? 'atm' : ''}"><div class="pdc">${side(r.ce, p[0], 'ce')}</div><div class="pdk">${fmtK(r.strike)}</div><div class="pdc">${side(r.pe, p[1], 'pe')}</div></div>`; }).join('');
    const exp = isExpiryDay(index);
    return `<div class="card pend"><div class="fhead"><h3>📦 Pending OI · ${index}</h3><span class="dim" style="font-size:11px">${m.iso}${exp ? ' · expiry today' : ''}</span></div>
      <div class="omt num">
        <div><span>CE pending</span><b>${Q(tc)}</b><em>≈ ${fmtK(Math.round(tc / lot))} lots · exited ${Q(tcx)}</em></div>
        <div><span>PE pending</span><b>${Q(tp)}</b><em>≈ ${fmtK(Math.round(tp / lot))} lots · exited ${Q(tpx)}</em></div>
        <div><span>Biggest CE wall</span><b class="dn">${wallC ? fmtK(wallC.strike) : '–'}</b><em>${wallC ? Q(wallC.ce.oi) + ' open' : ''}</em></div>
        <div><span>Biggest PE wall</span><b class="up">${wallP ? fmtK(wallP.strike) : '–'}</b><em>${wallP ? Q(wallP.pe.oi) + ' open' : ''}</em></div></div>
      <div class="pdh"><span>CALLS pending</span><span>Strike</span><span>PUTS pending</span></div>${body}
      <div class="hzcap">Pending OI = contracts still open right now at each strike. The bar is the open OI; the white mark is today's peak, so the gap is what has already been closed. ${exp ? '<b>Expiry today: all pending OI settles at the 3:30 close</b>, so writers defend their biggest walls hardest near the end.' : 'Big pending walls near spot act as resistance (calls) and support (puts).'}</div></div>`;
  }
  // =====================================================================================
  // WALLS: strikes whose OI is falling, and which resistance / support is most likely to break
  // =====================================================================================
  st.wallLog = store.get('oi.rec.walls', []);
  function wallScan(index) {
    const m = monRows(index); if (!m || !m.rows.length) return null;
    const step = C.INDICES[index].step, pk = monPeak(m), a15 = monAgo(index, 900), a5 = monAgo(index, 300), now = Date.now();
    const vf = volFor(index), left = Math.max(5, C.minsLeft(now) || 0), sig = vf ? C.expMove(m.spot, vf.vol, left) : NaN, sig15 = vf ? C.expMove(m.spot, vf.vol, 15) : NaN;
    const d = dataNear(index); let b15 = null; if (d) for (const s of d.h) if (now - s.ts >= 900000) b15 = s; if (!b15 && d) b15 = d.h[0];
    const ds15 = b15 ? m.spot - b15.spot : 0;
    const near = m.rows.filter(r => Math.abs(r.strike - m.spot) <= step * 10);
    // 1. strikes whose OI is falling
    const dec = [];
    for (const r of near) for (const sd of ['ce', 'pe']) {
      const o = r[sd].oi; if (!(o > 0)) continue;
      const o15 = a15 ? a15.get(r.strike, sd) : NaN, o5 = a5 ? a5.get(r.strike, sd) : NaN, p = (pk[r.strike] || [0, 0])[sd === 'ce' ? 0 : 1];
      const c15 = o15 > 0 ? (o - o15) / o15 : 0, c5 = o5 > 0 ? (o - o5) / o5 : 0, fromPk = p > 0 ? (p - o) / p : 0;
      if (c15 <= -0.03 || c5 <= -0.02 || fromPk >= 0.1) dec.push({ K: r.strike, side: sd.toUpperCase(), oi: o, d15: o15 > 0 ? o - o15 : NaN, c15, c5, fromPk, ltp: r[sd].ltp });
    }
    dec.sort((x, y) => Math.min(x.c15, -x.fromPk) - Math.min(y.c15, -y.fromPk));
    // 2. walls and their break chance
    const sideSum = (lo, hi, sd) => { let a = 0, b = 0; for (const r of m.rows) if (r.strike >= lo && r.strike <= hi) { const o15 = a15 ? a15.get(r.strike, sd) : NaN; if (o15 > 0) { a += r[sd].oi - o15; b += o15; } } return b > 0 ? a / b : 0; };
    const fq = index === 'NIFTY' ? fut15() : null;
    const judge = (r, type) => {
      const up = type === 'R', sd = up ? 'ce' : 'pe', o = r[sd].oi, p = (pk[r.strike] || [0, 0])[up ? 0 : 1], o15 = a15 ? a15.get(r.strike, sd) : NaN;
      const dist = Math.abs(r.strike - m.spot), pTouch = isFinite(sig) && sig > 0 ? C.touchProb(dist, sig) : NaN;
      const why = []; let s = 0;
      const ero = p > 0 ? (p - o) / p : 0; if (ero >= 0.05) { s += 3 * ero; why.push(`${up ? 'call' : 'put'} writers left ${Math.round(ero * 100)}% from today's peak`); }
      const c15 = o15 > 0 ? (o - o15) / o15 : 0;
      if (c15 >= 0.03) { s -= Math.min(1.5, 2 * c15); why.push(`fresh ${up ? 'call' : 'put'} writing +${Math.round(c15 * 100)}% in 15 min (strengthening)`); }
      else if (c15 <= -0.03) { s += Math.min(1.5, 2 * -c15); why.push(`OI ${Math.round(c15 * 100)}% in 15 min`); }
      const opp = up ? sideSum(m.spot - 2 * step, m.spot, 'pe') : sideSum(m.spot, m.spot + 2 * step, 'ce');
      if (opp >= 0.03) { s += Math.min(1, opp * 6); why.push(`${up ? 'put writers adding below spot (pushing up)' : 'call writers adding above spot (pushing down)'}`); }
      else if (opp <= -0.03) { s -= Math.min(0.8, -opp * 5); why.push(`${up ? 'put writers leaving below (less push up)' : 'call writers leaving above (less push down)'}`); }
      if (isFinite(sig15) && sig15 > 0) { const mo = (up ? ds15 : -ds15) / sig15; if (Math.abs(mo) >= 0.5) { s += Math.max(-1, Math.min(1, mo * 0.6)); why.push(`${index} ${mo > 0 ? 'moving toward' : 'moving away from'} it (${ds15 >= 0 ? '+' : ''}${f1(ds15)} pts in 15 min)`); } }
      const pb = b15 && b15.rows.find(x => x.strike === r.strike), pp = pb && pb[sd].ltp > 0 ? r[sd].ltp / pb[sd].ltp - 1 : 0;
      if (pp >= 0.1 && c15 < 0) { s += 0.6; why.push(`${fmtK(r.strike)} ${sd.toUpperCase()} premium +${Math.round(pp * 100)}% while OI falls (short covering)`); }
      if (fq && fq.label && /Bull|Bear/.test(fq.bias)) { const ok = (fq.bias === 'Bullish') === up; s += ok ? 0.3 : -0.3; if (ok) why.push(`futures ${fq.label.toLowerCase()}`); }
      const f = 1 / (1 + Math.exp(-1.4 * s)), pBreak = isFinite(pTouch) ? pTouch * (0.25 + 0.75 * f) : NaN;
      return { K: r.strike, type, oi: o, peak: p, ero, c15, dist, pTouch, pBreak, s, why, f, label: !isFinite(pBreak) ? '–' : pBreak >= 0.55 ? 'Likely to break' : pBreak >= 0.35 ? 'Under pressure' : f >= 0.75 ? 'Weak, but far' : f <= 0.35 ? 'Strong, holding' : 'Holding' };
    };
    // walls = the nearest strikes holding a big share of open OI (≥ 60% of the largest on that side, using today's peak so a melting wall still counts)
    const pick = (list, sd) => { const ix = sd === 'ce' ? 0 : 1, sz = r => Math.max(r[sd].oi, (pk[r.strike] || [0, 0])[ix]), mx = Math.max(1, ...list.map(sz));
      return list.filter(r => sz(r) >= 0.6 * mx).slice(0, 2); };
    const res = pick(near.filter(r => r.strike > m.spot && r.ce.oi > 0).sort((a, b) => a.strike - b.strike), 'ce').map(r => judge(r, 'R'));
    const sup = pick(near.filter(r => r.strike < m.spot && r.pe.oi > 0).sort((a, b) => b.strike - a.strike), 'pe').map(r => judge(r, 'S'));
    const all = [...res, ...sup].filter(w => isFinite(w.pBreak)).sort((a, b) => b.pBreak - a.pBreak);
    return { index, m, dec: dec.slice(0, 6), res, sup, top: all[0] || null, sig, ds15 };
  }
  /** remember the strongest break call (≥55%) and check later whether the index crossed it */
  function wallTrack(index, W) {
    const now = Date.now(), day = C.istDate(now), L = st.wallLog; let ch = false;
    const P = (st.path || {})[W.m.key] || [];
    for (const e of L) if (e.day === day && e.index === index && !e.hit) {
      const t = C.istParts(e.ts), m0 = t.h * 60 + t.mi;
      if (P.some(x => x.m >= m0 && (e.type === 'R' ? x.s > e.K : x.s < e.K)) || (e.type === 'R' ? W.m.spot > e.K : W.m.spot < e.K)) { e.hit = true; e.hitTs = now; ch = true; }
    }
    const t = W.top; if (t && C.marketOpen(now) && t.pBreak >= 0.55 && !L.some(e => e.day === day && e.index === index && e.K === t.K && e.type === t.type)) {
      L.push({ day, ts: now, index, K: t.K, type: t.type, p: +t.pBreak.toFixed(2), spot: +W.m.spot.toFixed(2), hit: false }); ch = true; }
    while (L.length > 400) L.shift();
    if (ch) store.set('oi.rec.walls', L);
  }
  function wallStats(index) {
    const today = C.istDate(Date.now()), L = st.wallLog.filter(e => e.index === index && (e.day < today || e.hit));
    return { n: L.length, hit: L.filter(e => e.hit).length };
  }
  function wallHtml(index) {
    let W = null; try { W = wallScan(index); if (W) wallTrack(index, W); } catch (e) { console.error(e); }
    if (!W) return '';
    const card = w => { const pc = isFinite(w.pBreak) ? Math.round(w.pBreak * 100) : null, cl = w.pBreak >= 0.55 ? 'brk' : w.pBreak >= 0.35 ? 'prs' : 'hld';
      return `<div class="wl ${w.type === 'R' ? 'r' : 's'} ${cl}"><div class="wlh"><b>${w.type === 'R' ? '🟥 Resistance' : '🟩 Support'} ${fmtK(w.K)}</b><span class="wlp">${pc !== null ? pc + '%' : '–'}</span></div>
        <div class="wlbar"><i style="width:${pc || 0}%"></i></div>
        <div class="wls"><b>${w.label}</b> · ${fmtK(Math.round(w.dist))} pts away · reach chance ${pctTxt(w.pTouch)} · ${Q(w.oi)} open${w.ero >= 0.05 ? ` (−${Math.round(w.ero * 100)}% from peak)` : ''}</div>
        ${w.why.length ? `<ul class="wlw">${w.why.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '<div class="wls dim">No change around this wall yet.</div>'}</div>`; };
    const t = W.top, st_ = wallStats(index);
    const topTxt = t && t.pBreak < 0.35 ? `<div class="wltop">All walls holding for now. Weakest: <b>${t.type === 'R' ? 'resistance' : 'support'} ${fmtK(t.K)}</b> (${Math.round(t.pBreak * 100)}%)${t.why.length ? ': ' + esc(t.why[0]) : ''}.</div>`
      : t ? `<div class="wltop ${t.type === 'R' ? 'up' : 'dn'}">Most likely to break: <b>${t.type === 'R' ? 'resistance' : 'support'} ${fmtK(t.K)}</b> (${Math.round(t.pBreak * 100)}%) → ${t.type === 'R' ? `if it breaks, ${index} can run toward ${fmtK((W.res.find(x => x.K > t.K) || {}).K || t.K + C.INDICES[index].step * 2)}; CE buyers benefit` : `if it breaks, ${index} can slide toward ${fmtK((W.sup.find(x => x.K < t.K) || {}).K || t.K - C.INDICES[index].step * 2)}; PE buyers benefit`}.</div>` : '';
    const dec = W.dec.length ? `<div class="wdec">${W.dec.map(x => `<div class="${x.side === 'CE' ? 'ce' : 'pe'}"><b>${fmtK(x.K)} ${x.side}</b><span>${isFinite(x.d15) && x.d15 < 0 ? `${Q(x.d15)} (${Math.round(x.c15 * 100)}%) in 15 min` : ''}${x.fromPk >= 0.1 ? ` · −${Math.round(x.fromPk * 100)}% from peak` : ''}</span><em>${x.side === 'CE' ? 'call writers leaving: upside opening' : 'put writers leaving: downside opening'}</em></div>`).join('')}</div>`
      : '<div class="hzmsg">No strike near spot is losing OI right now.</div>';
    return `<div class="card walls"><div class="fhead"><h3>🧱 Which wall will break? · ${index}</h3><span class="dim" style="font-size:11px">${fmtK(Math.round(W.m.spot))} · ±${isFinite(W.sig) ? fmtK(Math.round(W.sig)) : '–'} pts left today</span></div>
      ${topTxt}
      <div class="wgrid">${W.res.map(card).join('')}${W.sup.map(card).join('')}</div>
      <div class="dsec" style="margin:12px 0 4px">⬇ Strikes with OI decreasing</div>${dec}
      <div class="hzcap">Break chance = chance ${index} reaches the wall today (from volatility) × how weak the wall is (writers leaving it, fresh writing, pressure from the other side, momentum, premium at the wall${index === 'NIFTY' ? ', futures' : ''}). ${st_.n ? `Track record: ${st_.hit} of ${st_.n} "likely to break" calls broke.` : 'Calls of 55%+ are recorded and checked against the actual move.'} A guide, not a certainty.</div></div>`;
  }
  function oiMonPaint() {
    const a = $('oiMon'), b = $('oiPend'); if (!a || !b) return;
    try { a.innerHTML = oiMonHtml(st.ui.index); b.innerHTML = pendHtml(st.ui.index); const w = $('oiWalls'); if (w) w.innerHTML = wallHtml(st.ui.index); } catch (e) { console.error(e); }
  }
  setInterval(() => { if (st.ui.view === 'home' && document.visibilityState === 'visible' && !st.busy) oiMonPaint(); }, 1000);
  /** offline answers from the app's own rules (no internet) */
  function askOffline(q) {
    const idx = askIndex(q), K = askStrike(q), s = String(q).toLowerCase();
    const sideQ = /\b(ce|calls?)\b/.test(s) ? 'CE' : /\b(pe|puts?)\b/.test(s) ? 'PE' : null;
    const atmK = () => { const d = dataNear(idx); if (!d) return null; const st_ = C.INDICES[idx].step; return Math.round(d.cur.spot / st_) * st_; };
    if (/(sudden|big|large|huge|block|bulk|heavy|unusual|whale)\b.*(quantit|order|oi|buy|sell|volume|trade|position|money)|dump|dumped|big money|smart money/.test(s) && !K)
      return bigText(idx) + (/(both|all|nifty.*sensex|sensex.*nifty)/.test(s) ? '\n\n' + bigText(idx === 'NIFTY' ? 'SENSEX' : 'NIFTY') : '');
    if (/(oi|open interest).*(price|result|change)|buildup|build-up|short covering|result now/.test(s) && !K) {
      const out = [];
      for (const i of /sensex|nifty/.test(s) ? [idx] : Object.keys(C.INDICES)) for (const w of ['1', '5', '15']) { const x = oipResult(i, w); if (!x) continue;
        out.push(`- **${i} · last ${w} min: ${x.verdict}** (score ${x.score > 0 ? '+' : ''}${x.score}, since ${C.istTime(x.since)})${x.main.length ? ': ' + x.main.map(m => `${m.k} ${Math.round(m.share)}%`).join(', ') : ''}${x.top ? `. Strongest: ${fmtK(x.top.K)} ${x.top.side} ${x.top.kind.toLowerCase()} (OI ${x.top.pct >= 0 ? '+' : ''}${x.top.pct.toFixed(1)}%, price ${x.top.pp >= 0 ? '+' : ''}${x.top.pp.toFixed(0)}%)` : ''}`); }
      return out.length ? `**OI change + price result**\n${out.join('\n')}\n\n_${ASK_EDU}_` : 'Not enough data yet for the OI + price result.';
    }
    if (/(break|broken|breakout|breakdown|crack)/.test(s) && /(resistance|support|wall|level)/.test(s) || /which (resistance|support)/.test(s) || /oi (decreas|falling|reduc)/.test(s)) {
      const out = [];
      for (const i of /sensex|nifty/.test(s) ? [idx] : Object.keys(C.INDICES)) { const W = wallScan(i); if (!W) continue;
        if (W.top && W.top.pBreak < 0.35) out.push(`**${i}: all walls holding for now.** Weakest: ${W.top.type === 'R' ? 'resistance' : 'support'} ${fmtK(W.top.K)} (${Math.round(W.top.pBreak * 100)}%)${W.top.why.length ? ': ' + W.top.why.join('; ') : ''}.`);
        else if (W.top) out.push(`**${i}: most likely to break is ${W.top.type === 'R' ? 'resistance' : 'support'} ${fmtK(W.top.K)} (${Math.round(W.top.pBreak * 100)}%)**${W.top.why.length ? ': ' + W.top.why.join('; ') : ''}.`);
        for (const w of [...W.res, ...W.sup]) if (w !== W.top) out.push(`- ${w.type === 'R' ? 'Resistance' : 'Support'} ${fmtK(w.K)}: ${w.label} (${isFinite(w.pBreak) ? Math.round(w.pBreak * 100) + '%' : '–'})`);
        if (W.dec.length) out.push(`- OI falling at: ${W.dec.slice(0, 4).map(x => `${fmtK(x.K)} ${x.side}${isFinite(x.d15) && x.d15 < 0 ? ' ' + Q(x.d15) : ''}`).join(', ')}`); }
      return out.length ? out.join('\n') + `\n\n_${ASK_EDU}_` : 'Not enough chain data yet to judge the walls.';
    }
    if (/penny|pennies|cheap|lottery|10x|10 x|multibag|x times|2-10/.test(s)) {
      const out = [];
      for (const i of /sensex|nifty/.test(s) ? [idx] : Object.keys(C.INDICES)) { const R = pennyScan(i); if (!R) continue;
        for (const sd of R.mode === 'fall' ? ['pe', 'ce'] : ['ce', 'pe']) for (const c of R[sd].slice(0, 2))
          out.push(`- **${i} ${fmtK(c.K)} ${c.side}** ₹${f2(c.ltp)}: ${i} ${c.side === 'CE' ? '+' : '−'}${fmtK(Math.round(Math.abs(c.L1 - c.spot)))} pts → ₹${f1(c.e1)} (${c.x1.toFixed(1)}×, ${pctTxt(c.p1)}); big move → ₹${f1(c.e2)} (${c.x2.toFixed(1)}×, ${pctTxt(c.p2)})${c.fuel.length ? '. ' + c.fuel[0] : ''}${c.thin ? ' (thin)' : ''}`);
        if (R.mode) out.unshift(`**${i} is ${R.mode === 'fall' ? 'falling' : 'rising'} fast now (${R.ds15 >= 0 ? '+' : ''}${f1(R.ds15)} pts in 15 min).**`); }
      return out.length ? `**Penny strikes now** (full list in the Penny tab)\n${out.join('\n')}\n\nBuy ≤ 5% above the price, stop at −50%, sell half at 2×.\n\n_${ASK_EDU}_` : 'No penny strikes in range right now.';
    }
    const KK = K || (/\batm\b/.test(s) ? atmK() : null);
    const dirQ = /(go|move|goes|going|will|rise|raise|up|down|fall|drop|increase|decrease|outlook|view|direction|bull|bear|target|reach|chance|analy|check)/.test(s);
    if (KK && dirQ && !/why.*(not|n't|miss|no )/.test(s) && !/hold|my position|exit|book/.test(s)) {
      const sides = sideQ ? [sideQ] : ['CE', 'PE'];
      const res = sides.map(sd => strikeOutlook(idx, KK, sd));
      let txt = res.map(outlookText).join('\n\n———\n\n');
      if (!sideQ && res.every(r => !r.err)) { const b = res.slice().sort((a, c) => Math.abs(c.score) - Math.abs(a.score))[0];
        txt = `You didn't say CE or PE, so here are both. Stronger signal: **${fmtK(b.K)} ${b.side} ${b.verdict}**.\n\n` + txt; }
      return txt + `\n\n_${ASK_EDU}_`;
    }
    if (/(which|what|suggest|give|best).*(strike|buy|trade)|strike.*(buy|execute|take)|\bexecute\b|what (to|should i) buy/.test(s)) {
      const out = [];
      if (isExpiryDay(idx)) { const e = hzEval(idx);
        if (e && e.best) out.push(`**Hero-zero (${idx}, ${e.verdict})**: buy **${fmtK(e.best.strike)} ${e.useSide}** at or below **₹${f1(e.best.ltp * 1.03)}** (now ₹${f2(e.best.ltp)}), ${e.lots} lot(s). Sell half at ₹${f1(e.best.ltp * 2)}, loss cap ₹${f1(e.best.ltp * 0.5)}, exit by 3:20 PM.\n- ${e.why.slice(0, 3).join('\n- ')}`);
        else if (e) out.push(`**Hero-zero (${idx})**: no strike yet. ${e.trig.txt}`); }
      const pls = ['up', 'down'].map(d => { try { return tradePlan(idx, d); } catch (x) { return null; } }).filter(Boolean);
      const ok = pls.find(p => !p.safe || p.safe.ok);
      if (ok) out.push(`**${idx} ${ok.dir === 'up' ? 'up' : 'down'} trade**: buy **${fmtK(ok.strike)} ${ok.side}** at or below **₹${f1(ok.entryMax)}** (now ₹${f2(ok.ltp)}). Target ₹${isFinite(ok.target) ? f1(ok.target) : '–'}, stop-loss ₹${f1(ok.stop)}. Premium: ${ok.verdict}.${ok.safe ? ' Safe mode: all checks passed.' : ''}`);
      else if (pls.length) { const b = pls.sort((a, c) => (c.safe ? c.safe.passed : 0) - (a.safe ? a.safe.passed : 0))[0];
        out.push(`**Safe mode says no trade** for regular ${idx} trades right now (${b.safe.passed}/${b.safe.checks.length} checks). Failing: ${b.safe.checks.filter(c => !c.ok).map(c => `${c.t} (${c.v})`).join('; ')}.\nBest candidate: ${fmtK(b.strike)} ${b.side} at ₹${f2(b.ltp)}, target ₹${isFinite(b.target) ? f1(b.target) : '–'}, stop ₹${f1(b.stop)}.`); }
      if (!out.length) out.push(`No ${idx} chain data yet, so I can't suggest a strike.`);
      return out.join('\n\n') + `\n\n_${ASK_EDU}_`;
    }
    if (K) return `**${idx} ${fmtK(K)} today**\n${askStrikePath(idx, K).replace(/\. Every 5 min:.*$/gm, '.')}\n\n${isExpiryDay(idx) ? `HZ timeline: ${hzTimesTxt(idx) || 'no hero-zero trigger recorded today'}.` : ''}`;
    if (/hold|position|exit|book/.test(s)) { const ps = myPositions(); if (!ps.length) return 'No open NIFTY / SENSEX option positions found (log in to Flattrade for today, or add trades in the Journal).';
      return ps.map(p => { const a = adviseOne(p); return `**${p.index} ${fmtK(p.strike)} ${p.side}**${p.parts ? ` (purchase ${p.part} of ${p.parts})` : ''}: avg ₹${f2(p.avg)}, now ₹${f2(p.ltp)} → **${a ? a.act : '–'}**. ${a ? a.msg : ''}`; }).join('\n\n') + `\n\n_${ASK_EDU}_`; }
    if (/alert/.test(s)) { const a = st.alerts[st.alerts.length - 1]; if (!a) return 'No alerts yet today.';
      return `**${C.istTime(a.ts)} · ${a.title || a.kind}**\n${a.msg}${a.plan ? '\n\n' + planText(a.plan) + `\n\n_${ASK_EDU}_` : ''}`; }
    if (/morning|call|predict/.test(s)) { const day = REC.calls()[C.istDate(Date.now())] || {}, c = day[idx], eod = (REC.eod() || {})[C.istDate(Date.now())];
      if (!c) return 'No morning call recorded today yet (it locks automatically from 9:00).';
      const d = dataNear(idx), chg = d && c.prevClose > 0 ? (d.cur.spot / c.prevClose - 1) * 100 : NaN;
      return `**${idx} morning call: ${c.label}** (locked ${C.istTime(c.ts)}${c.late ? ', late' : ''}, confidence ${c.conf || '–'}).\nReasons: ${(c.factors || []).slice(0, 4).map(f => f.txt).join('; ')}.\n${isFinite(chg) ? `So far ${idx} is ${chg >= 0 ? '+' : ''}${chg.toFixed(2)}% from yesterday's close.` : ''}${c.rec ? `\nMorning strike idea: ${fmtK(c.rec.strike)} ${c.rec.side} at ₹${f2(c.rec.ltp)}.` : ''}\n\n_${ASK_EDU}_`; }
    if (/hero|setup|zero|hz/.test(s)) { const e = isExpiryDay(idx) ? hzEval(idx) : null, hb = hzBest();
      return (e ? `**${idx} HZ: ${e.verdict}.** ${e.trig.txt}${e.best ? ` Strike ${fmtK(e.best.strike)} ${e.useSide} ₹${f2(e.best.ltp)}.` : ''}\n\n` : `${idx} is not on expiry today.\n\n`) +
        (hb.rows.length ? 'Your best setups: ' + hb.rows.slice(0, 4).map(r => `${r.name} ${r.k}: ${Math.round(r.x2 / r.n * 100)}% doubled (${r.n})`).join('; ') : `Best-setup report needs 5 finished hero picks (${hb.n} so far).`); }
    return 'I can answer: **will a strike go up or down** (e.g. "Will 25100 CE go up?"), **sudden big orders** ("Any big orders in NIFTY?"), **which strike to buy**, **why a strike moved or was not shown** (type the strike number), **should I hold my positions**, **explain the last alert**, **morning call**, **hero-zero / best setup**. Try one of the buttons below.';
  }
  function askMd(t) {
    t = String(t || '').split('\n').filter(l => l.replace(/[_*\s]/g, '') !== ASK_EDU.replace(/\s/g, '')).join('\n').replace(/\n{3,}/g, '\n\n').trim();
    let h = esc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|\s)_(.+?)_(?=\s|$)/g, '$1<i>$2</i>');
    h = h.split('\n').map(l => /^\s*[-•]\s+/.test(l) ? `<li>${l.replace(/^\s*[-•]\s+/, '')}</li>` : l).join('\n').replace(/(<li>.*?<\/li>\n?)+/gs, m => `<ul>${m.replace(/\n/g, '')}</ul>`);
    return h.replace(/\n/g, '<br>');
  }
  // ---------------- interactive chat: follow-up memory, thinking steps, line-by-line answers, cards, live answers, watches ----------------
  st.ask.ctx = store.get('oi.ask.ctx', {});                 // last index / strike / side talked about
  st.ask.watch = store.get('oi.ask.watch', []);
  const GLOSS = {
    'pcr': '**PCR (put-call ratio)** = total put OI ÷ total call OI. Above about 1.2: put writers are confident (support, bullish lean). Below about 0.8: call writers dominate (resistance, bearish lean). Watch its *change* through the day more than the level.',
    'max pain': '**Max pain** is the strike where option buyers lose the most at expiry. On expiry day the index often drifts towards it, especially in the last hours, but a strong trend overrides it.',
    'short covering': '**Short covering**: price up + OI down. Writers who sold the option are buying it back in a hurry, which pushes the premium up fast. On calls it is bullish; on puts it is bearish.',
    'long buildup': '**Long buildup**: price up + OI up. Fresh buyers are adding positions. On calls bullish, on puts bearish.',
    'short buildup': '**Short buildup (writing)**: price down + OI up. Sellers are adding. Call writing caps the upside (bearish); put writing builds support (bullish).',
    'long unwinding': '**Long unwinding**: price down + OI down. Buyers are leaving. On calls bearish, on puts bullish.',
    'oi': '**OI (open interest)** = number of option contracts still open. Rising OI = new positions; falling OI = positions being closed. Read it together with price (see short covering, long buildup).',
    'iv': '**IV (implied volatility)** = how much movement the option price is "expecting". High IV makes options expensive; when IV falls (after events), premiums drop even if the index doesn\'t move.',
    'theta': '**Theta (time decay)**: how much premium an option loses per day just from time passing. Out-of-the-money options on expiry day lose the most, fast.',
    'delta': '**Delta**: how many rupees the option moves for a 1-point index move. ATM ≈ 0.5, far OTM pennies ≈ 0.05–0.15, which is why they need a big move.',
    'hero zero': '**Hero-zero**: buying a cheap OTM option on expiry day, hoping for a sharp move that multiplies it (hero), knowing it often goes to zero. The HZ tab only says GO when writers exit or the straddle spikes and the checks pass.',
    'straddle': '**ATM straddle** = ATM CE + ATM PE price. When it jumps, the market expects a big move soon: a key hero-zero trigger.',
    'vix': '**India VIX** = the market\'s fear gauge, from NIFTY option prices. Rising VIX = bigger moves and costlier options; falling VIX = calm, premiums shrink.',
    'penny': '**Penny strikes** = options priced ₹0.5–₹15 far from the money. They can go 2–10× on a sharp move but usually expire near zero. Use a small fixed amount.',
    'closing auction': '**Closing auction**: stocks stop at 3:15, the official close comes from an auction (3:20–3:30), published about 3:35. The exchange\'s indicative auction value is the best guide to the final close.',
  };
  function askGloss(s) {
    const m = /(what\s+(is|are|does|do)|meaning of|explain|define|means?)\s+(an?\s+|the\s+)?([a-z\s-]{2,20})\??$/.exec(s) || /^([a-z\s-]{2,18})\?$/.exec(s);
    if (!m) return null;
    const term = (m[4] || m[1] || '').trim().replace(/s$/, '').replace(/-/g, ' ');
    const k = Object.keys(GLOSS).find(g => term === g || term.includes(g) || (g === 'oi' && /open interest/.test(term)) || (g === 'hero zero' && /hero ?zero|hz/.test(term)));
    return k ? GLOSS[k] : null;
  }
  /** turn a short follow-up into a full question using what we talked about last */
  function askResolve(q) {
    const s = String(q).toLowerCase().trim(), c = st.ask.ctx || {};
    if (!c.K) return q;
    const hasK = askStrike(s), sideOnly = /^(and |what about |how about |check |then )?(the )?(ce|pe|call|put)s?\??$/.test(s);
    const idxOnly = /^(and |what about |how about )?(nifty|sensex)\??$/.test(s);
    if (sideOnly) { const sd = /pe|put/.test(s) ? 'PE' : 'CE'; return `Will ${c.index} ${c.K} ${sd} go up?`; }
    if (idxOnly) return `${/sensex/.test(s) ? 'SENSEX' : 'NIFTY'} ATM ${c.side || 'CE'} outlook: will the ATM ${c.side || 'CE'} go up?`;
    if (hasK && /^(and |what about |how about |check |then )?\d{4,6}( (ce|pe|call|put))?\??$/.test(s)) { const sd = /pe|put/.test(s) ? 'PE' : /ce|call/.test(s) ? 'CE' : (c.side || ''); return `Will ${c.index} ${hasK}${sd ? ' ' + sd : ''} go up?`; }
    if (!hasK && /^(why|reason|reasons|how so|explain( it)?|where (can|will|could) it go|target|targets|how far|chance|chances|and now|now\??|update|again|refresh)\??$/.test(s)) return `Will ${c.index} ${c.K}${c.side ? ' ' + c.side : ''} go up?`;
    if (!hasK && /\b(it|this|that)\b/.test(s) && /(go|up|down|rise|fall|buy|hold|reach)/.test(s)) return `${q} (${c.index} ${c.K}${c.side ? ' ' + c.side : ''})`.replace(/\b(it|this|that)\b/, `${c.K}${c.side ? ' ' + c.side : ''}`);
    return q;
  }
  function askMeta(q) {
    const s = String(q).toLowerCase(), idx = askIndex(q);
    let K = askStrike(q); const side = /\b(ce|calls?)\b/.test(s) ? 'CE' : /\b(pe|puts?)\b/.test(s) ? 'PE' : null;
    if (!K && /\batm\b/.test(s)) { const d = dataNear(idx); if (d) { const stp = C.INDICES[idx].step; K = Math.round(d.cur.spot / stp) * stp; } }
    const dir = /(go|move|will|rise|up|down|fall|drop|outlook|view|direction|target|reach|chance|analy|check)/.test(s);
    if (K && dir && !/why.*(not|n't|miss)|hold|my position/.test(s)) return { kind: 'outlook', index: idx, K, side, sides: side ? [side] : ['CE', 'PE'] };
    if (/(sudden|big|large|huge|block|bulk|unusual).*(order|oi|quantit|money)|dump/.test(s)) return { kind: 'big', index: idx };
    if (/penny|pennies|cheap|10x/.test(s)) return { kind: 'penny', index: idx };
    if (/hold|position|exit|book/.test(s)) return { kind: 'pos' };
    return { kind: 'other', index: idx };
  }
  /** today's premium path of one contract (from the per-minute record) as a tiny chart */
  function askSpark(index, K, side) {
    const exps = st.expiries[index] || [], P = (st.path || {})[index + '|' + (exps[0] || '')] || [], i = side === 'PE' ? 1 : 0;
    const pts = P.filter(x => x.p[K] && x.p[K][i] > 0).map(x => ({ m: x.m, v: x.p[K][i] }));
    if (pts.length < 3) return '';
    const W = 260, H = 46, lo = Math.min(...pts.map(p => p.v)), hi = Math.max(...pts.map(p => p.v)), m0 = pts[0].m, m1 = pts[pts.length - 1].m || m0 + 1;
    const xy = p => [((p.m - m0) / Math.max(1, m1 - m0) * (W - 4) + 2).toFixed(1), (H - 4 - (p.v - lo) / Math.max(0.01, hi - lo) * (H - 8)).toFixed(1)];
    const d = pts.map((p, j) => (j ? 'L' : 'M') + xy(p).join(',')).join(' '), last = xy(pts[pts.length - 1]);
    const up = pts[pts.length - 1].v >= pts[0].v;
    return `<div class="aspark"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><path d="${d}" fill="none" stroke="${up ? 'var(--pe)' : 'var(--ce)'}" stroke-width="2"/><circle cx="${last[0]}" cy="${last[1]}" r="3" fill="${up ? 'var(--pe)' : 'var(--ce)'}"/></svg>
      <div class="asl"><span>${hhmm(m0)} ₹${f2(pts[0].v)}</span><span>low ₹${f2(lo)} · high ₹${f2(hi)}</span><span>now ₹${f2(pts[pts.length - 1].v)}</span></div></div>`;
  }
  function askCards(m) {
    if (!m || m.kind !== 'outlook') return '';
    let h = '';
    for (const sd of m.sides) {
      const x = strikeOutlook(m.index, m.K, sd); if (x.err) continue;
      const cl = /UP/.test(x.verdict) ? 'up' : /DOWN/.test(x.verdict) ? 'dn' : '';
      h += `<div class="acard ${sd === 'CE' ? 'ce' : 'pe'}"><div class="ach"><b>${m.index} ${fmtK(m.K)} ${sd}</b><span class="abadge ${cl}">${x.verdict}</span><span class="dim">₹${f2(x.ltp)}</span></div>
        <div class="ameter"><i style="left:${Math.max(2, Math.min(98, 50 + x.score * 5))}%"></i><span>DOWN</span><span>UP</span></div>
        ${askSpark(m.index, m.K, sd)}
        <div class="aact">${tradeBtn({ i: m.index, k: m.K, s: sd, t: 'B', p: tick05(x.ltp * 1.02), why: 'Ask EV' }, '🛒 Buy', 'buy')}<button class="chip" data-achain="${m.index}|${m.K}">📊 Chain</button><button class="chip" data-awatch="${m.index}|${m.K}|${sd}|${x.ltp}">🔔 Alert me</button></div></div>`;
    }
    return h;
  }
  function askFollow(m) {
    if (!m) return [];
    if (m.kind === 'outlook') { const other = m.side === 'PE' ? 'CE' : 'PE', stp = C.INDICES[m.index].step;
      return [m.side ? `Check ${other} too` : null, 'Where could it go?', `What about ${m.K + stp}`, `What about ${m.K - stp}`, 'Any big orders?', 'What is short covering?'].filter(Boolean); }
    if (m.kind === 'big') return ['Will the ATM CE go up?', 'Will the ATM PE go up?', 'Show penny strikes', 'OI change and price result now'];
    if (m.kind === 'penny') return ['Any big orders?', 'Will the ATM PE go up?', 'What is a penny strike?'];
    if (m.kind === 'pos') return ['Any big orders?', 'OI change and price result now', 'Which strike should I buy now?'];
    return ['Will the ATM CE go up?', 'Any big orders?', 'Show penny strikes', 'Which strike should I buy now?'];
  }
  const askThink = m => m && m.kind === 'outlook' ? [`Reading the ${m.index} chain…`, `Checking OI change and price at ${fmtK(m.K)}…`, 'Scanning sudden big orders…', 'Weighing it up…']
    : m && m.kind === 'big' ? ['Scanning every strike, last 30 min…', 'Comparing each OI jump with its normal size…'] : ['Looking at today\'s data…'];
  function askLinkify(h) {   // tap any "25,150 CE" in an answer to analyse it
    return h.replace(/(?<![\d,])(\d{2},\d{3}|\d{5})\s(CE|PE)\b/g, (all, k, sd) => `<a class="aslink" data-ask="Will ${k.replace(/,/g, '')} ${sd} go up?">${all}</a>`);
  }
  function askTicker() {
    return Object.keys(C.INDICES).map(i => { const d = dataNear(i); if (!d) return `<span>${i} –</span>`; const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur, f = st.first[d.key];
      const ch = f ? cur.spot - f.spot : NaN; return `<span class="tk"><b>${i}</b> ${fmtK(Math.round(cur.spot))} <em style="color:${ch > 0 ? 'var(--pe)' : ch < 0 ? 'var(--ce)' : 'var(--muted)'}">${isFinite(ch) ? (ch >= 0 ? '▲' : '▼') + Math.abs(Math.round(ch)) : ''}</em></span>`; }).join('') +
      `<span class="tkdot ${useFT() ? 'on' : ''}">${useFT() ? '● live' : '● 1 min'}</span>`;
  }
  function askWelcome() {
    const rows = Object.keys(C.INDICES).map(i => { let x = null, b = null; try { x = oipResult(i, '5'); b = bigMoves(i, 30); } catch (e) { }
      return `<div class="awr"><b>${i}</b><span class="${x ? (x.verdict === 'Bullish' ? 'up' : x.verdict === 'Bearish' ? 'dn' : '') : ''}">${x ? x.verdict : 'waiting'}</span><span class="dim">${b ? b.list.length + ' big order' + (b.list.length === 1 ? '' : 's') + ' (30 min)' : ''}</span></div>`; }).join('');
    return `<div class="aa"><div class="ah">🤖 EV · ${C.istTime(Date.now())}</div>Hi! I read the live option chain for you. Ask in plain words, e.g. <b>"Will 25100 CE go up?"</b>, then follow up with <b>"PE?"</b>, <b>"what about 25200"</b> or <b>"where could it go?"</b>. Tap 🎤 to speak.
      <div class="awel">${rows}</div><div class="hzcap">OI + price read for the last 5 minutes.</div></div>`;
  }
  function askRender() {
    const el = $('askMsgs'); if (!el) return;
    $('askMode').innerHTML = askTicker();
    $('askCtx').innerHTML = st.ask.ctx && st.ask.ctx.K ? `💭 Talking about <b>${st.ask.ctx.index} ${fmtK(st.ask.ctx.K)}${st.ask.ctx.side ? ' ' + st.ask.ctx.side : ''}</b>: just type "${st.ask.ctx.side === 'PE' ? 'CE' : 'PE'}?", "what about ${st.ask.ctx.K + C.INDICES[st.ask.ctx.index].step}" or "why?" · <a data-actx="1">clear</a>`
      : `📎 Uses today's app data: ${Object.keys(C.INDICES).map(i => `<b>${i}</b> ${st.srcUsed[i] || '–'}`).join(', ')}, ${st.alerts.length} alerts, positions. Read-only.`;
    const keepBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    el.innerHTML = (st.ask.msgs.length ? '' : askWelcome()) + st.ask.msgs.map((m, i) => {
      if (m.role === 'user') return `<div class="aq">${esc(m.text)}</div>`;
      if (m.role === 'note') return `<div class="anote">${askMd(m.text)}</div>`;
      const lines = String(m.text || '').split('\n'), shown = m.shown === undefined ? lines.length : m.shown, done = shown >= lines.length;
      const body = askLinkify(askMd(lines.slice(0, shown).join('\n')));
      const live = m.live ? `<button class="alive ${m.liveOn ? 'on' : ''}" data-alive="${i}">${m.liveOn ? `🔴 LIVE · ${C.istTime(m.upd || m.ts, true)}` : '⏸ Make live'}</button>` : '';
      return `<div class="aa${m.err ? ' err' : ''}"><div class="ah">${m.err ? '⚠️' : '🤖'} EV · ${C.istTime(m.ts)}${live}</div>${body}${done ? (m.cards || '') : '<span class="acur">▍</span>'}
        ${done && !m.err ? `<div class="aedu">${ASK_EDU}</div><div class="atools"><button data-acopy="${i}">📋 Copy</button><button data-ashare="${i}">↗ Share</button></div>` : ''}</div>`;
    }).join('') + (st.ask.busy ? `<div class="aa"><div class="ah">🤖 EV</div><div class="athink">${esc(st.ask.think || 'Thinking…')}</div><span class="adots"><i></i><i></i><i></i></span></div>` : '');
    const last = [...st.ask.msgs].reverse().find(m => m.role === 'ai' && !m.err), f = last && last.follow ? last.follow : askFollow(null);
    $('askChips').innerHTML = f.map(t => `<button class="chip" data-ask="${esc(t)}">${esc(t)}</button>`).join('');
    if (keepBottom || st.ask.busy || st.ask.typing) el.scrollTop = el.scrollHeight;
  }
  async function askSend(q) {
    q = String(q || '').trim(); if (!q || st.ask.busy) return;
    const rq = askResolve(q), meta = askMeta(rq), s = q.toLowerCase().trim();
    st.ask.msgs.push({ role: 'user', text: q, ts: Date.now() }); st.ask.busy = true;
    const steps = askThink(meta); st.ask.think = steps[0]; askRender();
    for (let i = 1; i < steps.length; i++) { await sleep(320); st.ask.think = steps[i]; askRender(); }
    await sleep(260);
    let text, err = false;
    try {
      if (/^(stop watching|clear watch|stop alerts?|unwatch)/.test(s)) { text = st.ask.watch.length ? `Stopped watching ${st.ask.watch.length} strike(s).` : 'Nothing was being watched.'; st.ask.watch = []; store.set('oi.ask.watch', []); }
      else if (/^(hi|hello|hey|hai|good (morning|afternoon|evening)|namaste)\b/.test(s)) text = `Hello 👋 Here's the market right now:\n` + Object.keys(C.INDICES).map(i => { const x = oipResult(i, '5'); return x ? `- **${i}** ${fmtK(Math.round(x.spot))}: ${x.verdict} on OI + price (5 min)` : `- ${i}: waiting for data`; }).join('\n') + '\n\nAsk me about any strike.';
      else if (/^(thanks|thank you|thx|ok|okay|super|great|good)\b/.test(s)) text = 'You\'re welcome! Ask anytime. I keep reading the chain every second.';
      else { const g = askGloss(s); text = g || askOffline(rq);
        // focused follow-ups: keep only the part asked about
        if (!g && meta.kind === 'outlook') {
          const L = text.split('\n'), sec = h => { const i = L.findIndex(l => l.startsWith('**' + h)); if (i < 0) return []; let j = i + 1; while (j < L.length && !/^\*\*(Why|Where|Changes)/.test(L[j]) && !/^_/.test(L[j]) && !/^———/.test(L[j])) j++; return L.slice(i, j); };
          const head = L.filter(l => /^(📈|📉|↔️)/.test(l));
          if (/^(where|target|how far|chance)/.test(s)) text = [...head, '', ...sec('Where it could go'), ...sec('Changes the view')].join('\n') + `\n\n_${ASK_EDU}_`;
          else if (/^(why|reason|how so|explain)/.test(s)) text = [...head, '', ...sec('Why it may go up'), ...sec('Why it may go down')].join('\n') + `\n\n_${ASK_EDU}_`;
        } }
    } catch (e) { text = 'Something went wrong: ' + ((e && e.message) || e); err = true; }
    if (meta.kind === 'outlook') { st.ask.ctx = { index: meta.index, K: meta.K, side: meta.side }; store.set('oi.ask.ctx', st.ask.ctx); }
    const msg = { role: 'ai', text, err, ts: Date.now(), q: rq, meta, follow: askFollow(meta), cards: err ? '' : askCards(meta), live: meta.kind === 'outlook' || meta.kind === 'big', liveOn: false, shown: 0 };
    st.ask.busy = false; st.ask.msgs.push(msg); st.ask.typing = true;
    const n = String(text).split('\n').length;
    while (msg.shown < n) { msg.shown = Math.min(n, msg.shown + (n > 24 ? 2 : 1)); askRender(); await sleep(70); }
    delete msg.shown; st.ask.typing = false;
    st.ask.msgs = st.ask.msgs.slice(-40); askSave(); askRender();
  }
  function askSave() { store.set('oi.ask.msgs', st.ask.msgs.map(m => Object.assign({}, m, { cards: undefined, liveOn: false, shown: undefined }))); }
  // live answers: refresh the text and cards every 5 s while the chat is open
  setInterval(() => {
    if (!st.ask.open || st.ask.busy || st.ask.typing) return;
    let ch = false;
    for (const m of st.ask.msgs) if (m.liveOn && m.q) { try { m.text = askOffline(m.q); m.cards = askCards(m.meta); m.upd = Date.now(); ch = true; } catch (e) { } }
    $('askMode') && ($('askMode').innerHTML = askTicker());
    if (ch) askRender();
  }, 5000);
  // watches: tell me when this premium moves 15% or the verdict flips
  setInterval(() => {
    if (!st.ask.watch.length) return;
    let ch = false;
    for (const w of st.ask.watch) {
      const x = (() => { try { return strikeOutlook(w.index, w.K, w.side); } catch (e) { return null; } })(); if (!x || x.err) continue;
      const g = (x.ltp / w.p0 - 1) * 100, flip = w.v && x.verdict.replace('leaning ', '') !== w.v.replace('leaning ', '') && /UP|DOWN/.test(x.verdict);
      if (Math.abs(g) >= 15 || flip) {
        const t = `🔔 ${w.index} ${fmtK(w.K)} ${w.side}: ${Math.abs(g) >= 15 ? `₹${f2(w.p0)} → ₹${f2(x.ltp)} (${g >= 0 ? '+' : ''}${g.toFixed(0)}%)` : ''}${flip ? ` view changed ${w.v} → ${x.verdict}` : ''}`;
        st.ask.msgs.push({ role: 'note', text: t + `. Tap to see why: ${fmtK(w.K)} ${w.side}`, ts: Date.now() });
        deliver({ ts: Date.now(), index: w.index, type: 'premJump', kind: 'Watch', lvl: 'important', tone: (g > 0) === (w.side === 'CE') ? 'bull' : 'bear', title: `Ask EV watch · ${w.index} ${fmtK(w.K)} ${w.side}`, msg: t });
        w.p0 = x.ltp; w.v = x.verdict; ch = true;
      } else if (!w.v) { w.v = x.verdict; ch = true; }
    }
    if (ch) { store.set('oi.ask.watch', st.ask.watch); askSave(); if (st.ask.open) askRender(); }
  }, 3000);
  window.__voice = (text, err) => { if (err) return toast(err); if (!text) return toast('Didn\'t catch that, try again'); if (!st.ask.open) askOpen(); askSend(text); };
  document.addEventListener('click', e => {
    const t = e.target; if (!t.closest) return;
    const lv = t.closest('[data-alive]'); if (lv) { const m = st.ask.msgs[+lv.dataset.alive]; if (m) { m.liveOn = !m.liveOn; m.upd = Date.now(); if (m.liveOn) { try { m.text = askOffline(m.q); m.cards = askCards(m.meta); } catch (x) { } } askRender(); toast(m && m.liveOn ? 'Live: this answer refreshes every 5 seconds' : 'Live off'); } return; }
    const cp = t.closest('[data-acopy]'); if (cp) { const m = st.ask.msgs[+cp.dataset.acopy]; try { navigator.clipboard.writeText(m.text.replace(/\*\*/g, '') + '\n' + ASK_EDU); toast('Copied'); } catch (x) { toast('Copy not available'); } return; }
    const sh = t.closest('[data-ashare]'); if (sh) { const m = st.ask.msgs[+sh.dataset.ashare]; const txt = m.text.replace(/\*\*/g, '') + '\n\n' + ASK_EDU + '\n(EV Pulse)';
      if (Bridge && Bridge.shareText) Bridge.shareText('EV Pulse · Ask EV', txt); else { try { navigator.clipboard.writeText(txt); toast('Copied to share'); } catch (x) { } } return; }
    const ch = t.closest('[data-achain]'); if (ch) { const [i, k] = ch.dataset.achain.split('|'); askClose(); st.ui.index = i; saveUi(); go('chain'); setTimeout(() => { const tr = document.querySelector(`#chainTbl tr[data-k="${k}"]`); if (tr) tr.scrollIntoView({ block: 'center' }); }, 300); return; }
    const wt = t.closest('[data-awatch]'); if (wt) { const [i, k, sd, p] = wt.dataset.awatch.split('|');
      st.ask.watch = st.ask.watch.filter(w => !(w.index === i && w.K === +k && w.side === sd)).concat([{ index: i, K: +k, side: sd, p0: +p, ts: Date.now() }]).slice(-6);
      store.set('oi.ask.watch', st.ask.watch); st.ask.msgs.push({ role: 'note', text: `🔔 Watching **${i} ${fmtK(+k)} ${sd}** from ₹${f2(+p)}: I'll alert you if it moves 15% or my view changes. (${st.ask.watch.length} watched · say "stop watching" to clear)`, ts: Date.now() }); askSave(); askRender(); return; }
    if (t.closest('[data-actx]')) { st.ask.ctx = {}; store.set('oi.ask.ctx', {}); askRender(); return; }
    if (t.closest('#askMic')) { if (Bridge && Bridge.voice) Bridge.voice(); else toast('Voice works in the Android app'); return; }
  });
  function askOpen(q) { st.ask.open = true; $('askPanel').classList.add('on'); askRender(); if (q) askSend(q); else setTimeout(() => $('askIn').focus(), 200); }
  function askClose() { st.ask.open = false; $('askPanel').classList.remove('on'); }
  document.addEventListener('click', e => {
    const t = e.target; if (!t.closest) return;
    if (t.closest('#askFab')) return askOpen();
    if (t.closest('#askClose')) return askClose();
    if (t.closest('#askSend')) { const v = $('askIn').value; $('askIn').value = ''; return askSend(v); }
    const c = t.closest('[data-ask]'); if (c) { e.stopPropagation(); return askOpen(c.dataset.ask); }
    if (t.closest('#askClear')) { st.ask.msgs = []; store.set('oi.ask.msgs', []); askRender(); toast('Chat cleared'); }
  });
  document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target && e.target.id === 'askIn') { const v = e.target.value; e.target.value = ''; askSend(v); } });


  // =====================================================================================
  // TRADING — you pick the strike, check the order, tap Confirm; the order goes to your Flattrade account.
  // Nothing is ever placed without that tap.
  // =====================================================================================
  const tick05 = v => Math.max(0.05, Math.round(v * 20) / 20);
  /** a Buy / Exit button for any strike; the order sheet opens on tap */
  function tradeBtn(o, label, cls_) {
    return `<button class="tbtn ${cls_ || (o.t === 'S' ? 'sell' : 'buy')}" data-trade="${esc(JSON.stringify(o))}">${label}</button>`;
  }
  st.tr = { o: null, busy: false, last: null };
  function trLtp(o) {
    const d = dataNear(o.i); if (!d) return NaN;
    const lv = st.live[d.key], cur = lv && lv.ts > d.cur.ts ? lv : d.cur;
    const r = cur.rows.find(x => x.strike === o.k); return r ? r[o.s.toLowerCase()].ltp : NaN;
  }
  function trOpen(o) {
    const S = st.settings, d = dataNear(o.i);
    st.tr.o = Object.assign({ lots: o.l || 1, type: S.trType || 'LMT', prd: o.prd || S.trPrd || 'I', iso: o.iso || (d ? d.iso : '') }, o);
    if (!st.tr.o.p) st.tr.o.p = trLtp(st.tr.o);
    st.tr.o.p = tick05(st.tr.o.p || 0.05);
    st.tr.busy = false; st.tr.last = null;
    $('trSheet').classList.add('on'); trRender();
  }
  function trClose() { $('trSheet').classList.remove('on'); st.tr.o = null; }
  function trRender() {
    const o = st.tr.o, el = $('trBody'); if (!o || !el) return;
    const S = st.settings, lot = o.q ? 1 : (LOT[o.i] || 1), qty = o.q ? o.q : o.lots * lot, ltp = trLtp(o), buy = o.t === 'B';
    const price = o.type === 'MKT' ? ltp : o.p, cost = isFinite(price) ? price * qty : NaN;
    const warn = [];
    if (!FT.ready()) warn.push('Not logged in to Flattrade today: log in from Settings first.');
    if (S.trOn !== true) warn.push('Trading is switched off. Turn it on in Settings → 🛒 Trading.');
    if (!o.q && o.lots > (S.trMaxLots || 10)) warn.push(`More than your limit of ${S.trMaxLots || 10} lots per order.`);
    if (buy && o.safe === false) warn.push('Safe mode said NO TRADE for this setup.');
    if (buy && o.hero && S.hzPaper !== false) warn.push('Hero-zero paper-trade mode is ON: this would be a real order.');
    const mm = hzMins(); if (buy && mm >= 15 * 60 + 15) warn.push('After 3:15 PM: closing auction; intraday positions are squared off at 3:25.');
    if (o.type === 'MKT') warn.push('Market order: fills at whatever price is available. Cheap options can jump.');
    if (o.type === 'LMT' && isFinite(ltp) && buy && o.p > ltp * 1.1) warn.push(`Limit ₹${f2(o.p)} is over 10% above the price now (₹${f2(ltp)}).`);
    const blocked = !FT.ready() || S.trOn !== true || (!o.q && o.lots > (S.trMaxLots || 10)) || st.tr.busy;
    const res = st.tr.last;
    el.innerHTML = `<div class="trh ${buy ? 'b' : 's'}">${buy ? 'BUY' : 'SELL'} <b>${o.i} ${fmtK(o.k)} ${o.s}</b><span>${o.iso ? fmtExpLong(o.iso) : ''}</span></div>
      <div class="trltp">Now <b>₹${f2(ltp)}</b>${o.why ? ` · ${esc(o.why)}` : ''}</div>
      ${o.q ? `<div class="trrow"><span>Quantity</span><b>${qty}</b></div>`
        : `<div class="trrow"><span>Lots (${lot} each)</span><div class="step"><button data-tr="lots-">−</button><b>${o.lots}</b><button data-tr="lots+">+</button></div></div>
      ${buy ? `<div class="trcap"><span>Use capital</span>${[['25', '25%'], ['50', '50%'], ['100', 'All']].map(([k, n]) => `<button class="chip ${o.cap === k ? 'on' : ''}" data-tr="cap:${k}">${n}</button>`).join('')}</div>
      <div class="hzcap" style="margin:2px 2px 6px">${FT.funds && FT.funds.at ? `Available to trade: <b>₹${fmtK(FT.funds.avail)}</b> (Flattrade, ${C.istTime(FT.funds.at)})${isFinite(cost) && FT.funds.avail > 0 ? ` · this order uses <b>${Math.round(cost / FT.funds.avail * 100)}%</b>` : ''}` : 'Tap a button to read your available funds from Flattrade.'}${o.capNote ? ` · ${o.capNote}` : ''}</div>` : ''}
      <div class="trrow"><span>Quantity</span><b>${qty}</b></div>`}
      <div class="trrow"><span>Order type</span><div class="seg2">${[['LMT', 'Limit'], ['MKT', 'Market']].map(([k, n]) => `<button class="${o.type === k ? 'on' : ''}" data-tr="type:${k}">${n}</button>`).join('')}</div></div>
      ${o.type === 'LMT' ? `<div class="trrow"><span>Limit price ₹</span><div class="step"><button data-tr="p-">−</button><input id="trPrice" type="number" step="0.05" inputmode="decimal" value="${o.p.toFixed(2)}"><button data-tr="p+">+</button></div></div>` : ''}
      <div class="trrow"><span>Product</span><div class="seg2">${[['I', 'Intraday (MIS)'], ['M', 'Normal (NRML)']].map(([k, n]) => `<button class="${o.prd === k ? 'on' : ''}" data-tr="prd:${k}">${n}</button>`).join('')}</div></div>
      <div class="trrow tot"><span>${buy ? 'Approx. cost' : 'Approx. value'}</span><b>₹${isFinite(cost) ? fmtK(cost) : '–'}</b></div>
      ${warn.length ? `<div class="trwarn">${warn.map(w => `<div>⚠️ ${w}</div>`).join('')}</div>` : ''}
      ${res ? `<div class="trres ${res.ok ? 'ok' : 'bad'}">${res.ok ? `✅ Order sent to Flattrade${res.note ? ' · ' + esc(res.note) : ''} · no. ${esc(res.no)}${res.status ? ` · <b>${esc(res.status)}</b>${res.why ? ' · ' + esc(res.why) : ''}` : ' · checking status…'}` : `❌ ${esc(res.err)}`}</div>` : ''}
      <button class="btn trgo ${buy ? 'b' : 's'}" id="trGo" ${blocked || (res && res.ok) ? 'disabled' : ''}>${st.tr.busy ? 'Placing…' : res && res.ok ? 'Done' : `Confirm ${buy ? 'BUY' : 'SELL'} ${qty} × ${o.type === 'MKT' ? 'MARKET' : '₹' + f2(o.p)}`}</button>
      <div class="hzcap">The order goes to your Flattrade account only when you tap Confirm. You are responsible for every order. Analysis is for educational purposes only.</div>`;
  }
  /** lots that fit a share of the available funds (with a small buffer for charges and price movement) */
  async function trCapital(o) {
    try { if (!FT.funds || Date.now() - FT.funds.at > 30000) await FT.limits(); } catch (e) { o.capNote = (e && e.msg) || 'funds not available'; return; }
    const price = o.type === 'MKT' ? trLtp(o) * 1.02 : o.p, lot = LOT[o.i] || 1;
    const money = FT.funds.avail * (+o.cap / 100) * 0.985 - 50;
    let lots = Math.floor(money / (price * lot));
    if (lots < 1) { o.capNote = `not enough for 1 lot (needs ₹${fmtK(price * lot)})`; o.lots = 1; return; }
    const cap = st.settings.trMaxLots || 10;
    o.capNote = `${o.cap === '100' ? 'all' : o.cap + '% of'} capital = ${lots} lot${lots > 1 ? 's' : ''}` + (lots > cap ? `; your limit is ${cap} lots per order (Settings → 🛒 Trading)` : '');
    o.lots = lots;
  }
  /** exchanges reject single option orders above the freeze quantity: send big orders in parts */
  async function placeSplit(base, index, lot) {
    const fz = (st.settings.trFreeze || {})[index] || (index === 'SENSEX' ? 1000 : 1800);
    const chunk = Math.max(lot, Math.floor(fz / lot) * lot), parts = [];
    for (let left = base.qty; left > 0; left -= chunk) parts.push(Math.min(chunk, left));
    if (parts.length === 1) return FT.placeOrder(base);
    const nos = [], errs = [];
    for (const q of parts) { const r = await FT.placeOrder(Object.assign({}, base, { qty: q })); if (r.ok) nos.push(r.no); else errs.push(r.err); }
    return nos.length ? { ok: true, no: nos[nos.length - 1], nos, parts: parts.length, note: `sent as ${parts.length} orders of up to ${chunk} qty (freeze limit)${errs.length ? `; ${errs.length} failed: ${errs[0]}` : ''}` }
      : { ok: false, err: errs[0] || 'orders failed' };
  }
  /** before exiting a managed position, cancel its stop-loss and target so they can't sell again later */
  async function mgCancelFor(pid, why) {
    const m = st.mg && st.mg[pid]; if (!m) return;
    for (const k of ['slNo', 'tgtNo']) if (m[k]) { try { const r = await FT.cancelOrder(m[k]); mgLog(m, `${k === 'slNo' ? 'Stop' : 'Target'} order cancelled (${why})${r.ok ? '' : ': ' + r.err}`); } catch (e) { } m[k] = null; m[k === 'slNo' ? 'slSent' : 'tgSent'] = null; }
    m.trail.on = false; mgSave();
  }
  /** ⚡ instant exit: one tap, no confirm screen (only when switched on in Settings) */
  async function exitNow(o) {
    if (st.settings.trOn !== true || !FT.ready()) return toast('Trading is off or Flattrade is not logged in');
    const ltp = trLtp(o) || o.p, slip = (st.settings.trSlip || 3) / 100, px = tick05(ltp * (1 - slip));
    toast(`⚡ Exiting ${o.q} × ${o.i} ${fmtK(o.k)} ${o.s}…`);
    try {
      const c = await FT.contract(o.i, (dataNear(o.i) || {}).iso, o.k, o.s);
      if (o.pid) await mgCancelFor(o.pid, 'instant exit');
      const r = await placeSplit({ exch: c.exch, tsym: c.tsym, qty: o.q, prc: px, prctyp: 'LMT', prd: o.prd || st.settings.trPrd || 'I', trantype: 'S' }, o.i, c.ls || LOT[o.i] || 1);
      const rec = store.get('oi.rec.orders', []); rec.push({ ts: Date.now(), day: C.istDate(Date.now()), i: o.i, k: o.k, s: o.s, t: 'S', qty: o.q, prc: px, type: 'LMT', prd: o.prd, tsym: c.tsym, ok: r.ok, no: r.no || '', err: r.err || '', from: 'instant exit' }); store.set('oi.rec.orders', rec.slice(-500));
      if (!r.ok) return toast('❌ Exit failed: ' + r.err);
      toast(`✅ Exit sent at ₹${f2(px)} (limit ${st.settings.trSlip || 3}% below ₹${f2(ltp)})${r.note ? ' · ' + r.note : ''}`);
      setTimeout(async () => { try { const ob = await FT.orderBook(), x = ob.list.find(y => y.no === r.no); if (x) toast(`Exit ${x.status.toLowerCase()}${x.avg ? ' @ ₹' + f2(x.avg) : ''}${x.why ? ' · ' + x.why : ''}`); await FT.loadPositions(); } catch (e) { } render(); }, 2500);
    } catch (e) { toast('❌ ' + ((e && e.msg) || e)); }
  }
  async function trGo() {
    const o = st.tr.o; if (!o || st.tr.busy) return;
    const S = st.settings; if (S.trOn !== true || !FT.ready()) return trRender();
    st.tr.busy = true; trRender();
    try {
      const c = await FT.contract(o.i, o.iso, o.k, o.s);
      const lot = c.ls || LOT[o.i] || 1, qty = o.q ? o.q : o.lots * lot;
      if (o.t === 'S' && o.pid) await mgCancelFor(o.pid, 'exit');
      const r = await placeSplit({ exch: c.exch, tsym: c.tsym, qty, prc: tick05(o.p), prctyp: o.type, prd: o.prd, trantype: o.t }, o.i, lot);
      st.tr.last = r;
      const rec = store.get('oi.rec.orders', []); rec.push({ ts: Date.now(), day: C.istDate(Date.now()), i: o.i, k: o.k, s: o.s, t: o.t, qty, prc: o.type === 'MKT' ? 0 : tick05(o.p), type: o.type, prd: o.prd, tsym: c.tsym, ok: r.ok, no: r.no || '', err: r.err || '', from: o.why || '' });
      store.set('oi.rec.orders', rec.slice(-500));
      if (r.ok) { toast(`Order sent: ${o.t === 'B' ? 'BUY' : 'SELL'} ${c.tsym}`); for (const ms of [1500, 4000, 9000]) setTimeout(() => trStatus(r.no), ms); }
    } catch (e) { st.tr.last = { ok: false, err: (e && e.msg) || String(e) }; }
    st.tr.busy = false; trRender();
  }
  async function trStatus(no) {
    try {
      const ob = await FT.orderBook(), x = ob.list.find(y => y.no === no);
      if (x && st.tr.last && st.tr.last.no === no) { st.tr.last.status = x.status; st.tr.last.why = /REJECT/.test(x.status) ? (/IP/i.test(x.why) ? x.why + ' (orders must come from your registered static IP)' : x.why) : x.avg ? `filled at ₹${f2(x.avg)}` : ''; trRender(); }
      if (x && /COMPLETE/.test(x.status)) { try { await FT.loadPositions(); } catch (e) { } }
      if (st.ui.view === 'pos') render();
    } catch (e) { }
  }
  /** today's orders on the Positions page, with Cancel for open ones */
  function ordersHtml() {
    if (!FT.ready()) return '';
    const L = (FT.orders && FT.orders.list) || [];
    return `<div class="card"><div class="fhead"><h3>Orders today</h3><button class="chip" id="ordRefresh">Refresh</button></div>
      ${L.length ? L.slice().reverse().slice(0, 15).map(x => { const open = /OPEN|PENDING|TRIGGER/.test(x.status);
        return `<div class="ordr"><div><b class="${x.side === 'B' ? 'up' : 'dn'}">${x.side === 'B' ? 'BUY' : 'SELL'}</b> ${esc(x.tsym)} · ${x.fill || 0}/${x.qty} · ${x.type === 'MKT' ? 'MKT' : '₹' + f2(x.prc)}${x.avg ? ` · avg ₹${f2(x.avg)}` : ''}</div>
          <div class="dim">${esc(x.status)}${x.why ? ' · ' + esc(x.why) : ''} · ${esc((x.ts.match(/\d{1,2}:\d{2}:\d{2}/) || [''])[0])}${open ? ` <button class="chip" data-cancel="${esc(x.no)}">Cancel</button>` : ''}</div></div>`; }).join('')
        : `<div class="hzmsg dim">${FT.orders && FT.orders.at ? 'No orders today.' : 'Tap Refresh to load today\'s orders.'}</div>`}</div>`;
  }
  document.addEventListener('click', async e => {
    const t = e.target; if (!t.closest) return;
    const xn = t.closest('[data-exitnow]'); if (xn) { e.stopPropagation(); let o = null; try { o = JSON.parse(xn.dataset.exitnow); } catch (x) { } if (o) { xn.disabled = true; xn.textContent = '⚡ Exiting…'; await exitNow(o); } return; }
    const b = t.closest('[data-trade]');
    if (b) { e.stopPropagation(); let o = null; try { o = JSON.parse(b.dataset.trade); } catch (x) { } if (!o) return;
      if (!FT.configured()) return toast('Set up Flattrade in Settings to place orders');
      return trOpen(o); }
    if (t.closest('#trClose') || t.id === 'trSheet') return trClose();
    if (t.closest('#trGo')) return trGo();
    const a = t.closest('[data-tr]'); if (a && st.tr.o) { const o = st.tr.o, v = a.dataset.tr, step = o.p >= 100 ? 1 : o.p >= 20 ? 0.5 : 0.05;
      if (v === 'lots+') o.lots = Math.min(o.lots + 1, 99); else if (v === 'lots-') o.lots = Math.max(1, o.lots - 1);
      else if (v === 'p+') o.p = tick05(o.p + step); else if (v === 'p-') o.p = tick05(o.p - step);
      else if (v.startsWith('type:')) o.type = v.slice(5); else if (v.startsWith('prd:')) o.prd = v.slice(4);
      else if (v.startsWith('cap:')) { o.cap = v.slice(4); o.capNote = 'reading funds…'; trRender(); await trCapital(o); }
      if (v === 'lots+' || v === 'lots-') { o.cap = null; o.capNote = ''; }
      st.tr.last = null; return trRender(); }
    const cn = t.closest('[data-cancel]'); if (cn) { if (!confirm('Cancel this order?')) return; const r = await FT.cancelOrder(cn.dataset.cancel); toast(r.ok ? 'Cancel sent' : r.err); setTimeout(async () => { try { await FT.orderBook(); } catch (x) { } render(); }, 1200); return; }
    if (t.closest('#ordRefresh')) { try { await FT.orderBook(); } catch (x) { toast((x && x.msg) || 'Could not load orders'); } render(); }
  });
  document.addEventListener('change', e => { if (e.target && e.target.id === 'trPrice' && st.tr.o) { const v = parseFloat(e.target.value); if (v > 0) st.tr.o.p = tick05(v); st.tr.last = null; trRender(); } });
  function tradeSettings() {
    const el = $('trSet'); if (!el) return; const S = st.settings;
    el.innerHTML = `<label class="exp" style="font-size:13px;color:var(--text)"><input type="checkbox" id="trOn" ${S.trOn === true ? 'checked' : ''}> Allow placing orders from EV Pulse</label>
      <div class="grid2"><div class="field"><label>Max lots per order</label><input id="trMax" type="number" step="1" inputmode="numeric" value="${S.trMaxLots || 10}"></div>
      <div class="field"><label>Default product</label><select id="trPrd"><option value="I" ${(S.trPrd || 'I') === 'I' ? 'selected' : ''}>Intraday (MIS)</option><option value="M" ${S.trPrd === 'M' ? 'selected' : ''}>Normal (NRML)</option></select></div></div>
      <label class="exp" style="font-size:13px;color:var(--text);margin-top:10px"><input type="checkbox" id="trInstant" ${S.trInstant === true ? 'checked' : ''}> ⚡ Instant exit: one tap, no confirm screen</label>
      <div class="grid2"><div class="field"><label>Instant exit price: below current by (%)</label><input id="trSlip" type="number" step="0.5" inputmode="decimal" value="${S.trSlip || 3}"></div>
      <div class="field"><label>Split orders above (qty) NIFTY / SENSEX</label><div class="row2" style="gap:6px"><input id="trFzN" type="number" step="1" value="${(S.trFreeze || {}).NIFTY || 1800}"><input id="trFzS" type="number" step="1" value="${(S.trFreeze || {}).SENSEX || 1000}"></div></div></div>
      <div class="help">Large orders are sent in parts below the exchange freeze quantity (check the current limit with Flattrade). Instant exit cancels the position's stop-loss and target orders first, then sells with a limit a little below the price so it fills at once.</div>
      <div class="help">Buy buttons appear on suggested strikes, the HZ page, alert plans and every Chain strike (tap a row); Exit buttons on your positions. Each order opens a confirm screen first. Flattrade accepts API orders only from your registered static IP.</div>`;
  }
  document.addEventListener('change', e => {
    const id = e.target && e.target.id;
    if (id === 'trOn') { if (e.target.checked && !confirm('Allow EV Pulse to send orders to your Flattrade account when you tap Confirm?')) { e.target.checked = false; return; } st.settings.trOn = e.target.checked; saveSettings(); toast(e.target.checked ? 'Trading on: orders need your Confirm tap' : 'Trading off'); }
    if (id === 'trMax') { st.settings.trMaxLots = Math.max(1, Math.min(99, parseInt(e.target.value) || 10)); saveSettings(); }
    if (id === 'trPrd') { st.settings.trPrd = e.target.value; saveSettings(); }
    if (id === 'trInstant') { if (e.target.checked && !confirm('Instant exit sells with ONE tap, without a confirm screen. Turn on?')) { e.target.checked = false; return; } st.settings.trInstant = e.target.checked; saveSettings(); }
    if (id === 'trSlip') { st.settings.trSlip = Math.max(0.5, Math.min(20, parseFloat(e.target.value) || 3)); saveSettings(); }
    if (id === 'trFzN' || id === 'trFzS') { st.settings.trFreeze = Object.assign({}, st.settings.trFreeze, { [id === 'trFzN' ? 'NIFTY' : 'SENSEX']: Math.max(1, parseInt(e.target.value) || 1) }); saveSettings(); }
  });

  // =====================================================================================
  // MANAGE A POSITION — stop-loss and target as real Flattrade orders, moved from here.
  // Floating (trailing) stop: the app raises the stop as the price rises (never lowers it) and updates Flattrade.
  // =====================================================================================
  st.mg = store.get('oi.mg', {});                   // per position id: { sl, tgt, trail:{on,mode,val}, be, auto, slNo, tgtNo, slAt, tgtAt, log:[] }
  const mgSave = () => store.set('oi.mg', st.mg);
  let mgCur = null, mgTimer = null;
  function mgPos(id) { try { return myPositions().find(p => p.id === id) || null; } catch (e) { return null; } }
  function mgGet(p) {
    const m = st.mg[p.id] = st.mg[p.id] || { sl: tick05(p.avg * (1 - (st.settings.safeStop || 20) / 100)), tgt: tick05(p.avg * 1.6), trail: { on: false, mode: 'pct', val: 10 }, be: true, auto: true, tgtOn: false, log: [] };
    m.peak = Math.max(m.peak || 0, p.ltp || 0, p.avg); return m;
  }
  function mgLog(m, t) { m.log = (m.log || []).concat([{ ts: Date.now(), t }]).slice(-8); }
  /** auto-scaling stop: the bigger the gain, the tighter the stop; tighter still in the closing auction */
  const MG_STEPS = [[10, 10], [5, 15], [2, 20], [0, 30]];             // [gain multiple ≥, % below the high]
  function mgCasNow(p) { const m = hzMins(); return m >= 15 * 60 + 15 && isExpiryDay(p.index); }
  function mgScalePct(p, m) {
    const x = (m.peak || p.ltp) / p.avg; let pct = 30;
    for (const [mult, pc] of MG_STEPS) if (x >= mult) { pct = pc; break; }
    if (m.cas !== false && mgCasNow(p)) pct = Math.min(pct, 10);
    return pct;
  }
  function mgOpen(id) { const p = mgPos(id); if (!p) return toast('Position not found'); mgCur = id; mgGet(p); $('mgSheet').classList.add('on'); mgRender(); }
  function mgClose() { $('mgSheet').classList.remove('on'); mgCur = null; }
  function mgRender() {
    const el = $('mgBody'); if (!el || !mgCur) return;
    const p = mgPos(mgCur); if (!p) { el.innerHTML = '<div class="hzmsg">This position is closed.</div>'; return; }
    const m = mgGet(p), qty = Math.abs(p.qty), pnl = (p.ltp - p.avg) * qty, pct = (p.ltp / p.avg - 1) * 100;
    const lo = tick05(Math.min(m.sl, p.ltp, p.avg) * 0.7), hi = tick05(Math.max(m.tgt, p.ltp, m.peak) * 1.15), span = hi - lo || 1;
    const x = v => Math.max(0, Math.min(100, (v - lo) / span * 100));
    const slRisk = (m.sl - p.avg) * qty, tgtGain = (m.tgt - p.avg) * qty;
    const st_ = (no, at) => no ? `<span class="mgok">● at Flattrade · #${esc(String(no).slice(-6))}${at ? ' · ' + C.istTime(at) : ''}</span>` : '<span class="mgno">○ not placed yet</span>';
    const scl = m.trail.on && m.trail.mode === 'scale', curPct = scl ? mgScalePct(p, m) : null, mult = (m.peak || p.ltp) / p.avg;
    const trailTxt = !m.trail.on ? 'Fixed stop. Turn on floating to let it follow the price up.'
      : scl ? `⚡ Auto-scale ON: now <b>${curPct}%</b> below the high ₹${f2(m.peak)} (gain ${mult.toFixed(1)}×)${m.cas !== false && mgCasNow(p) ? ' · closing-auction mode' : ''}. Moves up only, checked every 2 seconds.`
      : `Floating ON: stays ${m.trail.mode === 'pct' ? m.trail.val + '%' : '₹' + m.trail.val} below the highest price (₹${f2(m.peak)}). Moves up only.`;
    const steps = scl ? `<table class="acct mgsteps"><tr><th>Gain</th><th>Stop</th><th>e.g. bought ₹5: high → stop</th></tr>${MG_STEPS.map(([mx, pc]) => { const lbl = mx ? `${mx}× or more` : 'under 2×', on = !(m.cas !== false && mgCasNow(p)) && pc === curPct;
        return `<tr class="${on ? 'on' : ''}"><td>${lbl}</td><td class="num">${pc}% below</td><td class="num">₹${mx ? 5 * mx : 8} → ₹${f1((mx ? 5 * mx : 8) * (1 - pc / 100))}</td></tr>`; }).join('')}
      <tr class="${m.cas !== false && mgCasNow(p) ? 'on' : ''}"><td>Auction (3:15+)</td><td class="num">10% below</td><td class="num">₹88 → ₹79.2</td></tr></table>
      <label class="exp" style="font-size:12px;color:var(--text);margin-top:6px"><input type="checkbox" id="mgCas" ${m.cas !== false ? 'checked' : ''}> 10% in the closing auction (expiry, 3:15 PM on)</label>` : '';
    el.innerHTML = `<div class="mghead"><div><b>${p.index} ${fmtK(p.strike)} ${p.side}</b><span>${qty} qty · avg ₹${f2(p.avg)}${p.parts ? ` · purchase ${p.part}/${p.parts}` : ''}</span></div>
        <div class="r"><b>₹${f2(p.ltp)}</b><span class="${cls(pnl)}">${pnl >= 0 ? '+' : '−'}₹${fmtK(Math.abs(pnl))} (${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%)</span></div></div>
      <div class="ladder"><div class="lbar"><i class="lrisk" style="left:${x(m.sl)}%;width:${Math.max(0, x(p.avg) - x(m.sl))}%"></i><i class="lgain" style="left:${x(p.avg)}%;width:${Math.max(0, x(m.tgt) - x(p.avg))}%"></i></div>
        <span class="lm sl" style="left:${x(m.sl)}%">SL<br>₹${f1(m.sl)}</span><span class="lm en" style="left:${x(p.avg)}%">Buy<br>₹${f1(p.avg)}</span>
        <span class="lm lt" style="left:${x(p.ltp)}%">Now<br>₹${f1(p.ltp)}</span>${m.tgtOn ? `<span class="lm tg" style="left:${x(m.tgt)}%">Target<br>₹${f1(m.tgt)}</span>` : ''}${m.trail.on ? `<span class="lm pk" style="left:${x(m.peak)}%">High<br>₹${f1(m.peak)}</span>` : ''}</div>
      <div class="mgsec"><div class="mgt"><b>🛑 Stop-loss</b>${st_(m.slNo, m.slAt)}</div>
        <input type="range" class="mgr sl" id="mgSl" min="${lo}" max="${tick05(p.ltp - 0.05)}" step="0.05" value="${Math.min(m.sl, p.ltp - 0.05)}">
        <div class="mgv"><button data-mg="sl-">−</button><b>₹${f2(m.sl)}</b><button data-mg="sl+">+</button><span class="${cls(slRisk)}">${slRisk >= 0 ? 'locks +' : 'risk −'}₹${fmtK(Math.abs(slRisk))}</span></div>
        <div class="mgchips"><span>Floating</span>${[['off', 'Off'], ['scale:0', '⚡ Auto-scale'], ['pct:10', '10%'], ['pct:20', '20%'], ['rs:2', '₹2'], ['rs:5', '₹5']].map(([k, n]) => { const on = k === 'off' ? !m.trail.on : m.trail.on && k === m.trail.mode + ':' + m.trail.val; return `<button class="chip ${on ? 'on' : ''}" data-mg="trail:${k}">${n}</button>`; }).join('')}</div>
        <div class="hzcap">${trailTxt}</div>${steps}
        <label class="exp" style="font-size:12px;color:var(--text);margin-top:6px"><input type="checkbox" id="mgBe" ${m.be ? 'checked' : ''}> Move stop to my buy price once +${st.settings.safeBE || 15}% (no-loss)</label></div>
      <div class="mgsec"><div class="mgt"><b>🎯 Target (sell order)</b>${m.tgtOn ? st_(m.tgtNo, m.tgtAt) : '<span class="mgno">off</span>'}</div>
        <label class="exp" style="font-size:12px;color:var(--text)"><input type="checkbox" id="mgTgtOn" ${m.tgtOn ? 'checked' : ''}> Keep a target order at Flattrade</label>
        ${m.tgtOn ? `<input type="range" class="mgr tg" id="mgTgt" min="${tick05(p.ltp + 0.05)}" max="${hi}" step="0.05" value="${Math.max(m.tgt, p.ltp + 0.05)}">
        <div class="mgv"><button data-mg="tg-">−</button><b>₹${f2(m.tgt)}</b><button data-mg="tg+">+</button><span class="up">gain +₹${fmtK(Math.max(0, tgtGain))}</span></div>
        <div class="hzcap">When the target fills, the app cancels the stop-loss (and the other way round).</div>` : ''}</div>
      <div class="mgsec"><label class="exp" style="font-size:12px;color:var(--text)"><input type="checkbox" id="mgAuto" ${m.auto ? 'checked' : ''}> Update Flattrade automatically when I change a level</label>
        ${m.auto ? '' : `<button class="btn" id="mgSync" style="margin-top:8px">Update Flattrade now</button>`}
        ${m.log && m.log.length ? `<div class="mglog">${m.log.slice().reverse().map(l => `<div>${C.istTime(l.ts, true)} · ${esc(l.t)}</div>`).join('')}</div>` : ''}</div>
      <div class="prb">${st.settings.trInstant === true ? `<button class="tbtn sell" data-exitnow="${esc(JSON.stringify({ i: p.index, k: p.strike, s: p.side, q: qty, p: p.ltp, prd: p.prd, pid: p.id }))}">⚡ Exit all now (${qty})</button>` : tradeBtn({ i: p.index, k: p.strike, s: p.side, t: 'S', q: qty, p: tick05(p.ltp), prd: p.prd, pid: p.id, why: 'exit now' }, `Exit all now (${qty})`, 'sell')}${qty / (LOT[p.index] || 1) >= 2 ? tradeBtn({ i: p.index, k: p.strike, s: p.side, t: 'S', q: Math.floor(qty / (LOT[p.index] || 1) / 2) * (LOT[p.index] || 1), p: tick05(p.ltp), why: 'exit half' }, 'Exit half', 'sell ghost') : ''}</div>
      ${p.prd === 'I' && isExpiryDay(p.index) ? '<div class="trwarn">⚠️ Intraday (MIS) position: Flattrade squares it off at 3:25 PM, before the closing-auction spike finishes. Use Normal (NRML) for trades you want to hold through the auction.</div>' : ''}
      <div class="hzcap">${st.settings.trOn === true ? '' : '⚠️ Trading is off in Settings → 🛒 Trading, so nothing is sent to Flattrade. '}Floating stops and target/stop pairing run while EV Pulse is open (it keeps running in the background). The stop-loss order itself stays at Flattrade even if the phone is off.</div>`;
  }
  /** send the stop and target to Flattrade: place if new, modify if they already exist */
  async function mgSync(id, why) {
    const p = mgPos(id), m = st.mg[id]; if (!p || !m) return;
    if (st.settings.trOn !== true || !FT.ready()) { mgLog(m, 'not sent: trading is off or Flattrade not logged in'); mgSave(); return mgRender(); }
    let c; try { c = await FT.contract(p.index, (dataNear(p.index) || {}).iso, p.strike, p.side); } catch (e) { mgLog(m, (e && e.msg) || 'contract not found'); mgSave(); return mgRender(); }
    const qty = Math.abs(p.qty), slLmt = tick05(m.sl * (m.fast ? 0.92 : 0.97));        // wider limit in fast moves so the stop actually fills
    const one = async (kind, no, o) => {
      const sig = `${o.trgprc || ''}|${o.prc}|${o.qty}`;
      if (no && m[kind + 'Sent'] === sig) return;                       // nothing changed since the last update
      const r = no ? await FT.modifyOrder(Object.assign({ no }, o)) : await FT.placeOrder(o);
      if (r.ok) { m[kind + 'Sent'] = sig; if (kind === 'sl') { m.slNo = r.no || no; m.slAt = Date.now(); } else { m.tgtNo = r.no || no; m.tgtAt = Date.now(); } mgLog(m, `${kind === 'sl' ? 'Stop' : 'Target'} ${no ? 'moved' : 'placed'} at ₹${f2(kind === 'sl' ? m.sl : m.tgt)}${why ? ' (' + why + ')' : ''}`); }
      else mgLog(m, `${kind === 'sl' ? 'Stop' : 'Target'} failed: ${r.err}`);
    };
    await one('sl', m.slNo, { exch: c.exch, tsym: c.tsym, qty, prc: slLmt, trgprc: tick05(m.sl), prctyp: 'SL-LMT', prd: p.prd || st.settings.trPrd || 'I', trantype: 'S' });
    if (m.tgtOn) await one('tg', m.tgtNo, { exch: c.exch, tsym: c.tsym, qty, prc: tick05(m.tgt), prctyp: 'LMT', prd: p.prd || st.settings.trPrd || 'I', trantype: 'S' });
    else if (m.tgtNo) { const r = await FT.cancelOrder(m.tgtNo); if (r.ok) { mgLog(m, 'Target order cancelled'); m.tgtNo = null; } }
    mgSave(); if (mgCur === id) mgRender();
  }
  function mgChanged(id, why) { const m = st.mg[id]; mgSave(); mgRender(); if (m && m.auto) { clearTimeout(mgTimer); mgTimer = setTimeout(() => mgSync(id, why), 900); } }
  /** every few seconds: raise floating stops, move to cost, and pair the two exit orders */
  async function mgTick() {
    if (!Object.keys(st.mg).length) return;
    let list = []; try { list = myPositions(); } catch (e) { return; }
    for (const p of list) {
      const m = st.mg[p.id]; if (!m || !(p.ltp > 0)) continue;
      m.peak = Math.max(m.peak || 0, p.ltp);
      let ns = m.sl;
      if (m.trail.on) ns = Math.max(ns, m.trail.mode === 'scale' ? m.peak * (1 - mgScalePct(p, m) / 100) : m.trail.mode === 'pct' ? m.peak * (1 - m.trail.val / 100) : m.peak - m.trail.val);
      if (m.be && m.peak >= p.avg * (1 + (st.settings.safeBE || 15) / 100)) ns = Math.max(ns, p.avg);
      ns = tick05(Math.min(ns, p.ltp - 0.1));
      const minStep = Math.max(0.5, m.sl * 0.01);
      const fast = m.lastLtp > 0 && p.ltp >= m.lastLtp * 1.05;               // price jumped 5%+ since the last check: update quickly
      m.lastLtp = p.ltp; if (fast) m.fastUntil = Date.now() + 60000; m.fast = (m.fastUntil || 0) > Date.now();
      if (ns >= m.sl + minStep && (!m.trailAt || Date.now() - m.trailAt > (m.fast ? 3000 : 10000))) { m.sl = ns; m.trailAt = Date.now(); mgLog(m, `${m.trail.mode === 'scale' ? 'Auto-scale' : 'Floating'} stop raised to ₹${f2(ns)}${m.fast ? ' (fast move)' : ''}`); if (m.auto && m.slNo) mgSync(p.id, 'floating'); }
    }
    // pairing: one exit filled → cancel the other
    const ids = Object.keys(st.mg).filter(k => st.mg[k].slNo || st.mg[k].tgtNo); if (!ids.length || !FT.ready()) return mgSave();
    try {
      const ob = await FT.orderBook();
      for (const k of ids) { const m = st.mg[k], f = no => ob.list.find(x => x.no === no);
        const s = f(m.slNo), t = f(m.tgtNo);
        if (s && /COMPLETE/.test(s.status) && m.tgtNo && t && /OPEN|PENDING/.test(t.status)) { await FT.cancelOrder(m.tgtNo); mgLog(m, 'Stop filled → target cancelled'); m.tgtNo = null; }
        if (t && /COMPLETE/.test(t.status) && m.slNo && s && /OPEN|PENDING|TRIGGER/.test(s.status)) { await FT.cancelOrder(m.slNo); mgLog(m, 'Target filled → stop cancelled'); m.slNo = null; }
        if (s && /REJECT|CANCEL/.test(s.status) && !(t && /COMPLETE/.test(t.status))) { mgLog(m, `Stop order ${s.status.toLowerCase()}${s.why ? ': ' + s.why : ''}`); m.slNo = null; }
      }
    } catch (e) { }
    mgSave(); if (mgCur) mgRender();
  }
  let mgBusy = false;
  setInterval(() => { if (!mgBusy && C.marketOpen(Date.now()) && Object.keys(st.mg).length) { mgBusy = true; mgTick().catch(() => { }).finally(() => { mgBusy = false; }); } }, 2000);
  document.addEventListener('click', e => {
    const t = e.target; if (!t.closest) return;
    const o = t.closest('[data-manage]'); if (o) { e.stopPropagation(); return mgOpen(o.dataset.manage); }
    if (t.closest('#mgClose') || t.id === 'mgSheet') return mgClose();
    if (t.closest('#mgSync') && mgCur) return mgSync(mgCur, 'manual');
    const a = t.closest('[data-mg]'); if (!a || !mgCur) return;
    const p = mgPos(mgCur), m = st.mg[mgCur], v = a.dataset.mg, step = m.sl >= 100 ? 1 : 0.5;
    if (v === 'sl+') m.sl = tick05(Math.min(m.sl + step, p.ltp - 0.05)); else if (v === 'sl-') m.sl = tick05(Math.max(0.05, m.sl - step));
    else if (v === 'tg+') m.tgt = tick05(m.tgt + step); else if (v === 'tg-') m.tgt = tick05(Math.max(p.ltp + 0.05, m.tgt - step));
    else if (v.startsWith('trail:')) { const k = v.slice(6); if (k === 'off') m.trail.on = false; else { const [md, val] = k.split(':'); m.trail = { on: true, mode: md, val: +val }; m.trailAt = 0; } }
    mgChanged(mgCur, v.startsWith('trail') ? 'floating setting' : 'you moved it');
  });
  document.addEventListener('input', e => { if (!mgCur || !e.target) return; const m = st.mg[mgCur]; if (!m) return;
    if (e.target.id === 'mgSl') { m.sl = tick05(+e.target.value); const b = e.target.nextElementSibling && e.target.nextElementSibling.querySelector('b'); if (b) b.textContent = '₹' + f2(m.sl); }
    if (e.target.id === 'mgTgt') { m.tgt = tick05(+e.target.value); const b = e.target.nextElementSibling && e.target.nextElementSibling.querySelector('b'); if (b) b.textContent = '₹' + f2(m.tgt); } });
  document.addEventListener('change', e => { if (!mgCur || !e.target) return; const m = st.mg[mgCur]; if (!m) return; const id = e.target.id;
    if (id === 'mgSl' || id === 'mgTgt') mgChanged(mgCur, 'you moved it');
    if (id === 'mgBe') { m.be = e.target.checked; mgChanged(mgCur, 'no-loss rule'); }
    if (id === 'mgTgtOn') { m.tgtOn = e.target.checked; mgChanged(mgCur, 'target ' + (m.tgtOn ? 'on' : 'off')); }
    if (id === 'mgAuto') { m.auto = e.target.checked; mgSave(); mgRender(); }
    if (id === 'mgCas') { m.cas = e.target.checked; mgChanged(mgCur, 'auction setting'); } });

  // ---- strike checker (Chain tab): enter a strike and see if it is worth buying, profit potential, target and stop
  function checkerHtml() {
    const c = st.chk = st.chk || { side: 'CE' };
    const ctx = judgeCtx(st.ui.index, true);
    let out = '';
    if (c.ran && ctx) {
      const K = +c.strike, side = c.side.toLowerCase(), r = ctx.rows.find(x => x.strike === K);
      if (!r) out = `<div class="hzmsg dn">${fmtK(K)} is not in the ${st.ui.index} chain for this expiry. Strikes go in steps of ${ctx.step}.</div>`;
      else if (!(r[side].ltp > 0)) out = `<div class="hzmsg dn">No price for ${fmtK(K)} ${c.side} right now.</div>`;
      else {
        const ltp = r[side].ltp, j = judge(ctx, side, K, ltp), buy = parseFloat(c.buy);
        const em = C.expMove(ctx.spot, ctx.volPct, Math.min(375, j.mte));
        const lvls = [...new Set([ctx.upLevel, ctx.dnLevel, Math.round((ctx.spot + em) / ctx.step) * ctx.step, Math.round((ctx.spot - em) / ctx.step) * ctx.step])].filter(isFinite).sort((a, b) => b - a);
        const scen = lvls.map(L => { const p = C.estPrice(ctx.rows, side, K, ctx.spot, L), base = buy > 0 ? buy : ltp;
          return `<div>${fmtK(L)}${L === ctx.upLevel ? ' <span class="dim">wall ↑</span>' : L === ctx.dnLevel ? ' <span class="dim">wall ↓</span>' : ''}</div><div><b>₹${f1(p)}</b></div><div class="${p >= base ? 'up' : 'dn'}">${p >= base ? '+' : ''}${Math.round((p / base - 1) * 100)}%</div>`; }).join('');
        out = `<div class="chkr">
          <div class="fhead" style="margin:0"><b style="font-size:16px">${fmtK(K)} ${c.side} · ₹${f2(ltp)}</b><span class="vj ${vjCls(j.verdict)}" style="font-size:12.5px">${j.verdict}</span></div>
          <div class="tpg num"><div><span>Breakeven at expiry</span><b>${fmtK(j.be)}</b></div><div><span>Chance it is touched</span><b>${pctTxt(j.beProb)}</b></div>
            <div><span>IV / ATM IV</span><b>${isFinite(j.iv) ? (j.iv * 100).toFixed(1) : '–'}% / ${(ctx.atmIv * 100).toFixed(1)}%</b></div><div><span>Decay per ${j.lastDay ? 'hour' : 'day'}</span><b class="dn">₹${f1(j.decay)} (${isFinite(j.decayPct) ? j.decayPct.toFixed(1) : '–'}%)</b></div>
            <div><span>Exit target</span><b class="up">₹${isFinite(j.target) ? f1(j.target) : '–'}</b></div><div><span>Stop-loss</span><b class="dn">₹${f1(j.stop)}</b></div></div>
          ${buy > 0 ? `<div class="zverdict ${ltp >= buy ? 'up' : 'dn'}" style="margin-top:8px">Your buy ₹${f2(buy)} → now ₹${f2(ltp)}: <b>${ltp >= buy ? '+' : ''}${Math.round((ltp / buy - 1) * 100)}%</b> (₹${fmtK((ltp - buy) * LOT[st.ui.index])} per lot)</div>` : ''}
          <div class="ptab num" style="margin-top:8px"><div class="pth">If ${st.ui.index} goes to</div><div class="pth">Est. price</div><div class="pth">${buy > 0 ? 'vs your buy' : 'vs now'}</div>${scen}</div>
          <div class="flist">${j.reasons.map(t => `<div class="fr"><span class="fi">•</span><span>${t}</span></div>`).join('')}</div>
          <div class="hzcap">Estimates use today's chain prices for the same distance from spot. Guide only.</div></div>`;
      }
    }
    return `<div class="card chk"><div class="fhead"><h3>Check a strike</h3><span class="dim" style="font-size:11px">${st.ui.index} · ${ctx ? fmtExp(ctx.iso) : ''}</span></div>
      <div class="chkin"><input id="chkK" type="number" inputmode="numeric" placeholder="Strike, e.g. ${ctx ? fmtK(Math.round(ctx.spot / ctx.step) * ctx.step).replace(/,/g, '') : '25000'}" value="${c.strike || ''}">
        <div class="seg2" id="chkSide">${['CE', 'PE'].map(x => `<button class="${c.side === x ? 'on ' + x.toLowerCase() : ''}" data-v="${x}">${x}</button>`).join('')}</div></div>
      <div class="chkin"><input id="chkBuy" type="number" step="0.05" inputmode="decimal" placeholder="Your buy price (optional)" value="${c.buy || ''}"><button class="btn" id="chkGo" style="margin:0;width:auto;padding:10px 18px">Check</button></div>
      ${out}</div>`;
  }
  function checkerBind() {
    $('chkBox').addEventListener('click', e => {
      const c = st.chk = st.chk || { side: 'CE' };
      const sb = e.target.closest('#chkSide [data-v]');
      if (sb) { c.strike = $('chkK').value; c.buy = $('chkBuy').value; c.side = sb.dataset.v; if (c.ran) c.ran = true; $('chkBox').innerHTML = checkerHtml(); return; }
      if (e.target.closest('#chkGo')) { c.strike = $('chkK').value; c.buy = $('chkBuy').value; if (!(+c.strike > 0)) { toast('Enter a strike price'); return; } c.ran = true; $('chkBox').innerHTML = checkerHtml(); }
    });
  }

  // =====================================================================================
  // MY POSITIONS: Flattrade positions (read-only) + open journal trades, with hold / exit / book-profit advice
  // =====================================================================================
  st.posPeak = store.get('oi.pos.peak', {});        // highest price seen since entry, per position
  st.hzx = store.get('oi.hzx', null) || {};
  if (!store.get('oi.mig.hz1', false)) { if (st.settings.heroStart === 13 * 60 + 30) st.settings.heroStart = 12 * 60 + 30; store.set('oi.settings', st.settings); store.set('oi.mig.hz1', true); }
  st.posFirst = store.get('oi.pos.first', {});        // first time a position was seen (hero time stop)
  st.posHalf = store.get('oi.pos.half', {});
  st.posLow = store.get('oi.pos.low', {});          // lowest price seen since entry, per position
  st.posFlash = store.get('oi.pos.flash', {});      // last flash message kind per position
  st.posAdv = store.get('oi.pos.adv', {});          // last advice per position (to alert on change)
  /** NIFTY06OCT26C25000 / SENSEX26O0882000CE / "NIFTY 06OCT26 25000 CE" → {index, side, strike} */
  function parseOpt(tsym, dname) {
    const s = (dname || '') + ' ' + (tsym || '');
    const index = /^SENSEX/i.test(tsym) || /SENSEX/i.test(dname) ? 'SENSEX' : /^NIFTY(?!NXT|BANK|FIN|MID)/i.test(tsym) || /^NIFTY\s/i.test(dname) ? 'NIFTY' : null;
    if (!index) return null;
    let m = /\b(\d{4,6})(?:\.0+)?\s*(CE|PE)\b/i.exec(dname)
      || /^SENSEX(?:\d{2}[1-9OND]\d{2}|\d{2}[A-Z]{3})(\d{4,6})(CE|PE)$/i.exec(tsym)
      || /(\d{4,6})(CE|PE)$/i.exec(tsym);
    if (m) return { index, strike: +m[1], side: m[2].toUpperCase() };
    m = /[A-Z]\d{2}[A-Z]{3}\d{2}([CP])(\d{4,6})$/i.exec(tsym);
    if (m) return { index, strike: +m[2], side: m[1].toUpperCase() === 'C' ? 'CE' : 'PE' };
    return null;
  }
  function myPositions() {
    const out = [];
    if (FT.ready()) for (const p of FT.positions.list) {
      if (!p.qty) continue;
      const o = parseOpt(p.tsym, p.dname); if (!o) continue;
      const live = FT.liveLtp(p.k), ltp = isFinite(live) ? live : p.lp;
      let parts = null; try { parts = splitBuys(p); } catch (e) { }
      if (parts) parts.forEach((pt, i) => {
        const pid = 'ft:' + p.k + ':' + (pt.ord || i);
        if (pt.ts && !st.posFirst[pid]) st.posFirst[pid] = pt.ts;
        out.push(Object.assign({ id: pid, src: 'Flattrade', prd: p.prd, qty: pt.qty, avg: pt.avg, ltp, name: p.tsym, part: i + 1, parts: parts.length, buyTs: pt.ts || 0, group: 'ft:' + p.k }, o));
      });
      else out.push(Object.assign({ id: 'ft:' + p.k, src: 'Flattrade', prd: p.prd, qty: p.qty, avg: p.avg, ltp, name: p.tsym }, o));
    }
    if (HS.ready()) for (const p of HS.positions.list) {          // HDFC Sky positions: shown and advised, orders stay with you in the HDFC Sky app
      if (!p.qty) continue;
      const o = parseOpt(p.tsym, p.dname); if (!o) continue;
      const live = HS.liveLtp(p.k), ltp = isFinite(live) ? live : p.lp;
      out.push(Object.assign({ id: 'hs:' + p.k, src: 'HDFC Sky', prd: p.prd, qty: p.qty, avg: p.avg, ltp, name: p.tsym }, o));
    }
    for (const t of REC.trades()) if (!isFinite(t.sell) && C.istDate(t.ts) === C.istDate(Date.now())) {
      const d = dataNear(t.index); const r = d && d.cur.rows.find(x => x.strike === t.strike);
      const lv = d && st.live[d.key] && st.live[d.key].rows.find(x => x.strike === t.strike);
      const ltp = (lv || r) ? (lv || r)[t.side.toLowerCase()].ltp : NaN;
      out.push({ id: 'j:' + t.id, src: 'Journal', index: t.index, strike: t.strike, side: t.side, qty: t.lots * t.lotSize, avg: t.buy, ltp, name: `${t.index} ${fmtK(t.strike)} ${t.side}` });
    }
    return out;
  }
  /** advice for one position */
  function adviseOne(p) {
    const ctx = judgeCtx(p.index, false); if (!ctx || !(p.ltp > 0) || !(p.avg > 0)) return null;
    const long = p.qty > 0, side = p.side.toLowerCase(), wantUp = side === 'ce';
    const pk = st.posPeak[p.id] = Math.max(st.posPeak[p.id] || 0, p.ltp, long ? p.avg : 0);
    const j = judge(ctx, side, p.strike, p.avg) || {};
    const S = st.settings, safeOn = S.safe !== false;
    let stop = long ? Math.max(j.stop || p.avg * 0.65, p.avg * 0.65) : p.avg * 1.3;
    let beOn = false;
    if (long && safeOn) { stop = Math.max(stop, p.avg * (1 - S.safeStop / 100)); if (pk >= p.avg * (1 + S.safeBE / 100)) { stop = Math.max(stop, p.avg); beOn = true; } }
    const first = st.posFirst[p.id] = st.posFirst[p.id] || Date.now();
    const target = long ? j.target : p.avg * 0.5;
    const pnlPct = long ? (p.ltp - p.avg) / p.avg * 100 : (p.avg - p.ltp) / p.avg * 100;
    const pnl = (long ? p.ltp - p.avg : p.avg - p.ltp) * Math.abs(p.qty);
    // what the data says right now
    const r15 = fut15(), tone = ctx.tone;
    const recent = st.alerts.filter(a => Date.now() - a.ts < 20 * 60000 && a.index === p.index && /reversal|reversalWarn|rangeBreak|resShift|supShift/.test(a.type));
    const against = recent.find(a => (wantUp ? a.tone === 'bear' : a.tone === 'bull'));
    const support = (tone === (wantUp ? 'up' : 'dn')) || (r15.bias === (wantUp ? 'Bullish' : 'Bearish'));
    const dataAgainst = !!against || (tone === (wantUp ? 'dn' : 'up') && r15.bias === (wantUp ? 'Bearish' : 'Bullish'));
    const why = [tone ? `Market read: ${tone === 'up' ? 'bullish' : tone === 'dn' ? 'bearish' : 'sideways'}` : '', r15.label ? `futures 15 min: ${r15.label}` : '', against ? `${against.kind} at ${C.istTime(against.ts)}` : ''].filter(Boolean).join(' · ');
    const p_ = C.istParts(Date.now()), mins = p_.h * 60 + p_.mi, expiryToday = isExpiryDay(p.index);
    let act, msg, lvl = 'hold';
    const mg = st.mg && st.mg[p.id];
    if (long && mg && mg.slNo && mg.trail && mg.trail.on) {          // the user's own floating stop at Flattrade is in charge
      const pnlPct = (p.ltp - p.avg) / p.avg * 100, pnl = (p.ltp - p.avg) * Math.abs(p.qty), lock = (mg.sl - p.avg) * Math.abs(p.qty);
      const txt = `Your ${mg.trail.mode === 'scale' ? 'auto-scale' : 'floating'} stop at ₹${f2(mg.sl)} is at Flattrade and rises with the price. ${lock >= 0 ? `It locks at least +₹${fmtK(lock)}.` : `Risk if hit: −₹${fmtK(-lock)}.`}`;
      return { act: 'HOLD', lvl: 'hold', msg: txt, why: 'managed by your stop', stop: mg.sl, target: mg.tgtOn ? mg.tgt : NaN, pnl, pnlPct, peak: Math.max(pk, mg.peak || 0),
        flash: { kind: pnlPct > 0 ? 'ride' : 'calm', head: pnlPct > 0 ? 'Let it run. Your stop is following it up.' : 'Stop is set. Let the trade play out.', text: txt, low: 0 } };
    }
    // hero-zero position (expiry day, cheap premium): fixed hero rules
    const isHero = long && S.hzSafe !== false && expiryToday && p.avg <= Math.max(S.heroMax, 20) && mins >= S.heroStart - 15;
    if (isHero) {
      const half = st.posHalf[p.id] = st.posHalf[p.id] || pk >= p.avg * 2;
      const trail = pk * 0.7, minsIn = (Date.now() - first) / 60000;
      let fk = 'calm', head = 'Hero-zero: stay disciplined.';
      if (mins >= 15 * 60 + 20) { act = 'EXIT'; lvl = 'exit'; msg = 'Hero-zero last exit time (3:20 PM). Exit everything before the auction and the 3:25 square-off.'; }
      else if (p.ltp <= p.avg * 0.5) { act = 'EXIT'; lvl = 'exit'; msg = `Loss cap hit: ₹${f2(p.ltp)} is half your price. Exit; the budget for this try is used.`; }
      else if (half && p.ltp <= trail) { act = 'EXIT'; lvl = 'exit'; msg = `Fell 30% from its peak ₹${f1(pk)}. Exit the rest and keep the profit.`; }
      else if (half) { act = 'BOOK HALF'; lvl = 'book'; fk = 'greed'; head = 'Doubled! Sell half now.'; msg = `It reached 2× (peak ₹${f1(pk)}). Sell HALF: your money is back, the rest is a free trade. Exit the rest below ₹${f1(trail)}.`; }
      else if (minsIn >= 25 && pk < p.avg * 1.3) { act = 'EXIT'; lvl = 'exit'; msg = `No real move in ${Math.round(minsIn)} min. Expiry premium melts fast: exit (time stop).`; }
      else { act = 'HOLD'; head = 'Give it time, rules are set.'; msg = `Hero-zero: sell half at ₹${f1(p.avg * 2)} (2×). Loss cap ₹${f1(p.avg * 0.5)}. Time stop ${hhmm(Math.floor((first + 25 * 60000 - Date.now()) / 60000) + mins)} if nothing moves.`; }
      const pnlPct = (p.ltp - p.avg) / p.avg * 100, pnl = (p.ltp - p.avg) * Math.abs(p.qty);
      return { act, lvl, msg, why: 'Hero-zero Safe rules', stop: p.avg * 0.5, target: p.avg * 2, pnl, pnlPct, peak: pk,
        flash: { kind: lvl === 'exit' ? 'exit' : fk, head: lvl === 'exit' ? 'Follow the rule. Exit.' : head, text: msg, low: 0 } };
    }
    if (!long) {
      if (p.ltp >= stop) { act = 'EXIT'; lvl = 'exit'; msg = `Premium ₹${f2(p.ltp)} is 30%+ above your sell price. Short options can lose fast: exit.`; }
      else if (pnlPct > 0 && dataAgainst) { act = 'BOOK PROFIT'; lvl = 'book'; msg = `You are in profit, but the data has turned against a short ${p.side}. Book profit.`; }
      else { act = 'HOLD'; msg = `Short ${p.side}: you gain as the premium falls. Stop-loss ₹${f1(stop)}.`; }
    } else if (p.ltp <= stop) { act = 'EXIT'; lvl = 'exit'; msg = beOn ? `It was ${S.safeBE}%+ up and has come back to your buy price. Exit at cost: no loss.` : `Stop-loss hit: ₹${f2(p.ltp)} is at or below ₹${f1(stop)}. Exit to protect capital.`; }
    else if (pnlPct < 0) {
      if (dataAgainst) { act = 'EXIT'; lvl = 'exit'; msg = `Price is against you and the data has also turned against your ${p.side}. Exit or reduce.`; }
      else if (expiryToday && mins >= 14 * 60 + 45 && j.beProb < 0.25) { act = 'EXIT'; lvl = 'exit'; msg = `Expiry afternoon: time decay is fast and the move has not come. Exit if no move soon.`; }
      else { act = 'HOLD'; msg = `Price is against you, but the data ${support ? 'still supports' : 'has not turned against'} your ${p.side}. Hold with stop-loss ₹${f1(stop)}.`; }
    } else {
      const dd = pk > 0 ? (pk - p.ltp) / pk * 100 : 0;
      const trail = Math.max(p.avg, pk * 0.95);
      if (dd >= 5 && pk > p.avg * 1.05) { act = 'BOOK PROFIT'; lvl = 'book'; msg = `Don't be greedy: price is ${dd.toFixed(1)}% below its peak ₹${f1(pk)}. Book profit or exit at least half.`; }
      else if (dataAgainst) { act = 'BOOK PROFIT'; lvl = 'book'; msg = `Don't be greedy: reversal risk (${against ? against.kind : 'data turned'}). Book profit now.`; }
      else if (isFinite(target) && p.ltp >= target) { act = 'BOOK PROFIT'; lvl = 'book'; msg = `Target ₹${f1(target)} reached. Book profit, or trail the stop at ₹${f1(trail)}.`; }
      else { act = 'HOLD'; msg = `In profit and the data supports it. Hold; trail the stop at ₹${f1(trail)} (5% below the peak).`; }
    }
    const flash = posFlash(p, { long, pnlPct, pk, stop, target, dataAgainst, support, against, r15, wantUp, expiryToday, mins, act });
    return { act, lvl, msg, why, stop, target, pnl, pnlPct, peak: pk, low: flash.low, flash };
  }
  /** flash message on the position card: keep calm and hold when the data is with you, don't be greedy when profit is at risk */
  const FLASH_LINES = {
    turn: ['Patience is paying off. Stay with it.', 'The market is coming back your way. Hold steady.', 'This is why you trust the data. Hold.'],
    calm: ['Stay calm. The data is still on your side.', 'Do not panic-sell a good trade. Let the data play out.', 'A dip is not a reversal. Hold your nerve.'],
    ride: ['Let your profit run. The data still supports you.', 'Trend is your friend right now. Trail and ride.'],
    greed: ["Don't be greedy. Take the money.", 'Profit on paper is not profit. Book it.', 'Pigs get slaughtered. Lock in your gain.'],
    exit: ['Protect your capital. There is always another trade.', 'Accept the small loss. Live to trade tomorrow.'],
  };
  const flashSeen = {};
  /** a message flashes for its first 5 seconds on screen (re-renders don't restart it); greed and exit keep blinking */
  function flashNew(k) { const t = flashSeen[k] || (flashSeen[k] = Date.now()); return Date.now() - t < 5000; }
  function posFlash(p, x) {
    const low = st.posLow[p.id] = Math.min(st.posLow[p.id] || Infinity, p.ltp, x.long ? p.avg : Infinity);
    const pick = k => { const L = FLASH_LINES[k]; let h = 0; for (const c of p.id + k + C.istDate(Date.now())) h = (h * 31 + c.charCodeAt(0)) >>> 0; return L[h % L.length]; };
    const side = p.side, f2_ = v => f2(v);
    if (!x.long) return { kind: '', low };
    if (x.act === 'EXIT') return { kind: 'exit', low, head: pick('exit'), text: '' };
    // in profit: is there a chance it falls back?
    if (x.pnlPct > 0) {
      const dd = x.pk > 0 ? (x.pk - p.ltp) / x.pk * 100 : 0;
      const risks = [];
      if (x.dataAgainst) risks.push(x.against ? `${x.against.kind} at ${C.istTime(x.against.ts)}` : 'market read has turned against your ' + side);
      if (dd >= 3 && x.pk > p.avg * 1.03) risks.push(`price is ${dd.toFixed(1)}% off its peak ₹${f1(x.pk)}`);
      if (isFinite(x.target) && p.ltp >= x.target * 0.9) risks.push(`near the target ₹${f1(x.target)}`);
      if (x.r15 && x.r15.bias === (x.wantUp ? 'Bearish' : 'Bullish')) risks.push(`futures 15 min: ${x.r15.label}`);
      if (x.expiryToday && x.mins >= 14 * 60 + 30) risks.push('expiry afternoon, premium melts fast');
      if (risks.length) return { kind: 'greed', low, head: pick('greed'), text: `You are up ${x.pnlPct.toFixed(1)}%, but ${risks.join(' · ')}. Exit or book at least half now.` };
      return { kind: 'ride', low, head: pick('ride'), text: `Up ${x.pnlPct.toFixed(1)}% and the data agrees. Trail your stop at ₹${f1(Math.max(p.avg, x.pk * 0.95))}.` };
    }
    // in loss but the data still backs the trade
    if (x.act === 'HOLD' && !x.dataAgainst) {
      const bounce = low > 0 ? (p.ltp - low) / low * 100 : 0;
      if (low < p.avg * 0.95 && bounce >= 8) return { kind: 'turn', low, head: pick('turn'), text: `It went against you down to ₹${f2_(low)}, and has now bounced ${bounce.toFixed(0)}% to ₹${f2_(p.ltp)}. The data ${x.support ? 'supports' : 'has not turned against'} your ${side}. Hold, stop-loss ₹${f1(x.stop)}.` };
      return { kind: 'calm', low, head: pick('calm'), text: `The price is against you for now, but the data ${x.support ? 'supports' : 'has not turned against'} your ${side}. Hold, stop-loss ₹${f1(x.stop)}.` };
    }
    return { kind: '', low };
  }
  function adviseAll(alert) {
    const list = myPositions(); let ch = false;
    for (const p of list) {
      p.adv = adviseOne(p); if (!p.adv) continue;
      const prev = st.posAdv[p.id];
      if (alert && C.marketOpen(Date.now()) && prev !== p.adv.act) {
        const crit = p.adv.lvl === 'exit';
        fire('posAdvice', p.index, (st.expiries[p.index] || [''])[0], `${p.adv.act === 'EXIT' ? '⛔' : /^BOOK/.test(p.adv.act) ? '💰' : '✋'} ${p.adv.act}: ${fmtK(p.strike)} ${p.side}`,
          `${p.adv.msg} Now ₹${f2(p.ltp)} vs your ₹${f2(p.avg)} (${p.adv.pnlPct >= 0 ? '+' : ''}${p.adv.pnlPct.toFixed(1)}%).`, p.adv.lvl === 'hold' ? '' : (p.side === 'CE' ? 'bear' : 'bull'), p.id + p.adv.act, 3, crit ? 'critical' : null);
        st.posAdv[p.id] = p.adv.act; ch = true;
      }
      const fk = p.adv.flash && p.adv.flash.kind;
      if (alert && C.marketOpen(Date.now()) && fk && st.posFlash[p.id] !== fk) {
        if (fk === 'turn' || (fk === 'greed' && p.adv.act === 'HOLD'))
          fire('posAdvice', p.index, (st.expiries[p.index] || [''])[0], `${fk === 'turn' ? '💪 Hold' : "💰 Don't be greedy"}: ${fmtK(p.strike)} ${p.side}`,
            `${p.adv.flash.head} ${p.adv.flash.text}`, '', p.id + 'f' + fk, 10);
        st.posFlash[p.id] = fk; store.set('oi.pos.flash', st.posFlash);
      }
    }
    store.set('oi.pos.peak', st.posPeak); store.set('oi.pos.low', st.posLow); store.set('oi.pos.first', st.posFirst); store.set('oi.pos.half', st.posHalf); if (ch) store.set('oi.pos.adv', st.posAdv);
    return list;
  }
  function posStatus() {
    if (!FT.configured() && !HS.configured()) return { msg: 'No broker set up. Add Flattrade or HDFC Sky in Settings to see your positions here.' };
    if (!FT.ready() && !HS.ready()) return { msg: `Not logged in today. Log in from Settings → ${FT.configured() ? 'Flattrade' : 'HDFC Sky'} (once a day) and your positions appear here.` };
    const P = { list: [...(FT.ready() ? FT.positions.list || [] : []), ...(HS.ready() ? HS.positions.list || [] : [])],
      at: Math.max(FT.ready() ? FT.positions.at : 0, HS.ready() ? HS.positions.at : 0),
      err: [FT.ready() && FT.positions.err ? 'Flattrade: ' + FT.positions.err : '', HS.ready() && HS.positions.err ? 'HDFC Sky: ' + HS.positions.err : ''].filter(Boolean).join(' · ') }, all = P.list;
    const open = all.filter(p => p.qty), closed = all.filter(p => !p.qty);
    const other = open.filter(p => !parseOpt(p.tsym, p.dname));
    const rp = closed.reduce((a, p) => a + (p.rpnl || 0), 0);
    const bits = [];
    bits.push(P.at ? `Updated ${C.istTime(P.at)}` : 'Loading…');
    if (closed.length) bits.push(`${closed.length} closed today (${rp >= 0 ? '+' : '−'}₹${fmtK(Math.abs(rp))} booked)`);
    if (other.length) bits.push(`${other.length} other open (${other.slice(0, 3).map(p => esc(p.tsym)).join(', ')}) not tracked`);
    return { info: bits.join(' · '), err: P.err };
  }
  /** small summary on Home; tap opens the Positions page */
  function posMiniHtml() {
    const list = adviseAll(false); if (!list.length) return '';
    const tot = list.reduce((a, p) => a + (p.adv ? p.adv.pnl : 0), 0);
    const act = list.filter(p => p.adv && p.adv.lvl !== 'hold');
    return `<div class="card posmini" data-gopos="1"><div style="flex:1"><h3 style="margin:0">My positions</h3><div class="pmt">${list.length} open${act.length ? ` · <span class="dn">${act.length} need action (${act.map(p => p.adv.act).join(', ')})</span>` : ' · all on hold'} · tap to view</div></div><b class="${cls(tot)}">${tot >= 0 ? '+' : '−'}₹${fmtK(Math.abs(tot))}</b></div>`;
  }
  function posBadge() {
    const b = $('posBadge'); if (!b) return;
    let L = []; try { L = myPositions(); } catch (e) { }
    const n = L.length, urgent = L.some(p => (st.posAdv || {})[p.id] === 'EXIT');
    b.hidden = !n; b.textContent = n; b.style.background = urgent ? 'var(--ce)' : 'var(--acc)';
  }
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('[data-gopos]')) go('pos'); if (e.target.closest && e.target.closest('[data-gohz]')) go('hz'); });
  document.addEventListener('change', e => { if (e.target && e.target.id === 'hzPaperOn') { st.settings.hzPaper = e.target.checked; saveSettings(); render(); } });
  function positionsHtml() {
    const list = adviseAll(false), ps = posStatus();
    const head = r => `<div class="fhead"><h3>My positions</h3>${r}</div>`;
    const btn = FT.ready() || HS.ready() ? `<button class="btn ghost" id="posRefresh" style="margin-top:6px;padding:6px 10px;font-size:12px">Refresh positions</button>` : '';
    const foot = `${ps.info ? `<div class="hzcap">${ps.info}</div>` : ''}${btn}`;
    const err = ps.err ? `<div class="hzmsg dn">${esc(ps.err)}</div>` : '';
    const brokers = [FT.ready() ? 'Flattrade' : '', HS.ready() ? 'HDFC Sky' : ''].filter(Boolean).join(' + ') || 'Flattrade / HDFC Sky';
    if (!list.length) {
      if (!FT.configured() && !HS.configured() && !REC.trades().length && st.ui.view !== 'pos') return '';
      return `<div class="card">${head(`<span class="dim" style="font-size:11px">${brokers}</span>`)}${err}<div class="hzmsg">${ps.msg || 'No open NIFTY / SENSEX option positions right now.'}</div>${foot}</div>`;
    }
    const tot = list.reduce((a, p) => a + (p.adv ? p.adv.pnl : 0), 0);
    return `<div class="card pos"><button class="askw" style="float:right;margin:0 0 0 8px" data-ask="Look at my open positions. For each purchase: hold, book profit or exit, and why?">💬 Ask EV</button><div class="fhead"><h3>My positions</h3><span class="${cls(tot)}" style="font-weight:800">${tot >= 0 ? '+' : '−'}₹${fmtK(Math.abs(tot))}</span></div>${err}
      ${list.map(p => { const a = p.adv;
        return `<div class="pr ${a ? a.lvl : ''}"><div class="prh"><b>${p.index} ${fmtK(p.strike)} ${p.side}</b><span class="dim">${p.qty > 0 ? 'Buy' : 'Sell'} ${Math.abs(p.qty)} · ${p.src}${p.parts ? ` · purchase ${p.part} of ${p.parts}${p.buyTs ? ' at ' + C.istTime(p.buyTs) : ' (earlier)'}` : ''}</span>${a ? `<span class="pa ${a.lvl}">${a.act}</span>` : ''}</div>
        <div class="prg num"><div><span>Avg</span><b>₹${f2(p.avg)}</b></div><div><span>LTP</span><b>₹${f2(p.ltp)}</b></div><div><span>P&amp;L</span><b class="${a ? cls(a.pnl) : ''}">${a ? (a.pnl >= 0 ? '+' : '−') + '₹' + fmtK(Math.abs(a.pnl)) + ` (${a.pnlPct >= 0 ? '+' : ''}${a.pnlPct.toFixed(1)}%)` : '–'}</b></div></div>
        ${a && a.flash && a.flash.kind ? `<div class="pflash ${a.flash.kind}${flashNew(p.id + a.flash.kind) ? ' new' : ''}"><b>${{ turn: '💪', calm: '🧘', ride: '🚀', greed: '💰', exit: '⛔' }[a.flash.kind]} ${a.flash.head}</b>${a.flash.text ? `<span>${a.flash.text}</span>` : ''}</div>` : ''}
        ${p.src === 'Flattrade' && p.qty > 0 && st.settings.trInstant === true ? `<button class="tbtn sell wide" data-exitnow="${esc(JSON.stringify({ i: p.index, k: p.strike, s: p.side, q: Math.abs(p.qty), p: p.ltp, prd: p.prd, pid: p.id }))}">⚡ Exit now · ${Math.abs(p.qty)} at ~₹${f2(p.ltp * (1 - (st.settings.trSlip || 3) / 100))}</button>` : ''}
        ${p.src === 'Flattrade' && p.qty > 0 ? `<button class="tbtn mgbtn wide" data-manage="${esc(p.id)}">🎯 Manage stop-loss / target${(st.mg[p.id] || {}).slNo ? ` · SL ₹${f1(st.mg[p.id].sl)} at Flattrade` : ''}${(st.mg[p.id] || {}).trail && st.mg[p.id].trail.on ? ' · floating' : ''}</button><div class="prb">${tradeBtn({ i: p.index, k: p.strike, s: p.side, t: 'S', q: Math.abs(p.qty), p: tick05(p.ltp), prd: p.prd, pid: p.id, why: 'exit' + (p.parts ? ` purchase ${p.part}` : '') }, `Exit ${Math.abs(p.qty)}`, 'sell')}${Math.abs(p.qty) / (LOT[p.index] || 1) >= 2 ? tradeBtn({ i: p.index, k: p.strike, s: p.side, t: 'S', q: Math.floor(Math.abs(p.qty) / (LOT[p.index] || 1) / 2) * (LOT[p.index] || 1), p: tick05(p.ltp), prd: p.prd, why: 'exit half' }, 'Exit half', 'sell ghost') : ''}${tradeBtn({ i: p.index, k: p.strike, s: p.side, t: 'B', p: tick05(p.ltp), why: 'add more' }, 'Buy more', 'buy ghost')}</div>` : ''}
        ${p.src === 'HDFC Sky' && p.qty > 0 ? `<div class="hzcap">HDFC Sky position: exit or change it in the HDFC Sky app (orders from EV Pulse go to Flattrade only).</div>` : ''}
        ${a ? `${a.flash && a.flash.text ? '' : `<div class="prm">${a.msg}</div>`}<div class="prs num">Stop ₹${f1(a.stop)}${isFinite(a.target) ? ` · Target ₹${f1(a.target)}` : ''} · Peak ₹${f1(a.peak)}${a.why ? ` · ${esc(a.why)}` : ''}</div>` : '<div class="prs">Waiting for chain data…</div>'}</div>`; }).join('')}
      ${ps.msg ? `<div class="hzmsg">${ps.msg}</div>` : ''}${foot}
      <div class="hzcap">Orders go to Flattrade only when you tap Confirm. Advice is a guide based on the app's data, for educational purposes only.</div></div>${ordersHtml()}`;
  }

  document.addEventListener('click', async e => {
    if (!(e.target && e.target.id === 'posRefresh')) return;
    e.target.disabled = true; e.target.textContent = 'Refreshing…';
    if (FT.ready()) { try { await FT.loadPositions(); } catch (x) { } }
    if (HS.ready()) { try { await HS.loadPositions(); } catch (x) { } }
    render();
    const ps = posStatus(); toast(ps.err ? ps.err : `Positions updated: ${myPositions().length} open`);
  });
  function notify(title, text) {
    if (Bridge && Bridge.notify) Bridge.notify(title, text);
    else toast(title + ': ' + text);
  }

  // ------------------------------------------------------------------ helpers
  const Q = C.fmtQ;
  const sQ = x => (x > 0 ? '+' : '') + Q(x);
  const f1 = x => (isFinite(x) ? x.toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '–');
  const f2 = x => (isFinite(x) ? x.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '–');
  const sgn = (x, f) => (x > 0 ? '+' : x < 0 ? '−' : '') + f(Math.abs(x));
  const cls = x => (x > 0 ? 'up' : x < 0 ? 'dn' : '');
  const fmtK = x => (isFinite(x) ? Math.round(x).toLocaleString('en-IN') : '–');
  const MONS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function fmtExp(e) { const [y, m, d] = e.split('-').map(Number); return `${d} ${MONS[m - 1]}`; }
  function fmtExpLong(e) { const [y, m, d] = e.split('-').map(Number); const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(Date.UTC(y, m - 1, d)).getUTCDay()]; return `${fmtExp(e)} ${String(y).slice(2)} · ${wd}`; }
  function ago(ms) { const s = Math.round((Date.now() - ms) / 1000); return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)}m ago` : C.istTime(ms); }
  const hhmm = m => `${Math.floor(m / 60) % 12 || 12}:${String(m % 60).padStart(2, '0')} ${m >= 720 ? 'PM' : 'AM'}`;
  let toastT; function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2600); }
  function setSpin(on) { $('refresh').classList.toggle('spin', on); }
  const curKey = () => st.ui.index + '|' + st.sel[st.ui.index];

  function current() {
    const key = curKey(), h = st.snaps[key] || [];
    if (!h.length) return null;
    const lv = st.live[key];
    const cur = lv && lv.ts > h[h.length - 1].ts ? lv : h[h.length - 1];
    const base = C.baseline(h, st.first[key], st.ui.win);
    return { key, h, cur, base, rows: C.compare(cur, base), series: st.series[key] || [] };
  }

  // ------------------------------------------------------------------- render
  // ---- alert setup: everything ON by default; Android-only permissions need one tap each
  function setupMissing() {
    if (!Bridge) return [];
    const out = [];
    if (Bridge.notifOk && !Bridge.notifOk()) out.push(['notif', 'Allow notifications', 'Needed for any alert on the phone screen']);
    if (Bridge.canFullScreen && !Bridge.canFullScreen()) out.push(['fs', 'Allow full-screen alerts', 'Critical alerts pop up over the lock screen']);
    if (Bridge.overlayOk && !Bridge.overlayOk()) out.push(['ovl', 'Allow display over other apps', 'Critical alerts pop up on screen even when EV Pulse is minimized']);
    if (Bridge.batteryOk && !Bridge.batteryOk()) out.push(['bat', 'Allow running in background', 'So the phone doesn\'t stop the app and alerts keep coming']);
    return out;
  }
  function setupHtml() {
    const m = setupMissing(); if (!m.length) return '';
    return `<div class="card setup"><div class="fhead"><h3>⚠ Finish alert setup</h3><span class="dim" style="font-size:11px">${m.length} step${m.length > 1 ? 's' : ''} left</span></div>
      <div class="hzmsg">Alerts, alarm and background tracking are already ON. Android needs your OK for these:</div>
      ${m.map(([k, t, d]) => `<button class="sbtn" data-setup="${k}"><b>${t}</b><span>${d}</span></button>`).join('')}
      <div class="hzcap">On Xiaomi, Realme, Vivo, Oppo, Samsung: also set the app's battery usage to "No restrictions" in Settings → Background.</div></div>`;
  }
  function render() {
    renderTop();
    const su = $('setupCard'); if (su) su.innerHTML = setupHtml();
    const su2 = $('setupCard2'); if (su2) su2.innerHTML = setupHtml();
    const d = current();
    const dataView = ['home', 'chain', 'oi', 'trends', 'hz'].includes(st.ui.view);
    $('dataHead').style.display = dataView ? '' : 'none';
    $('pickers').style.display = (st.ui.view === 'settings' || st.ui.view === 'daily' || st.ui.view === 'pos' || st.ui.view === 'penny') ? 'none' : '';
    renderBanner(d);
    if (dataView) renderMetrics(d);
    if (st.ui.view === 'home') { oiMonPaint(); const ce = $('casCard'); if (ce) ce.innerHTML = casCardHtml(st.ui.index); const oh = $('oipHome'); if (oh) { try { oh.innerHTML = oipCard(st.ui.index); } catch (e) { } } const pc = $('posCard'); if (pc) pc.innerHTML = posMiniHtml(); renderFut(); renderVix(); renderSR(d); renderHero(); renderZero(d); renderAtm(d); }
    if (st.ui.view === 'chain') renderChain(d);
    if (st.ui.view === 'oi') renderOI(d);
    if (st.ui.view === 'trends') renderTrends(d);
    if (st.ui.view === 'alerts') renderAlerts();
    if (st.ui.view === 'hz') hzPaint();
    if (st.ui.view === 'penny') pennyPaint();
    if (st.ui.view === 'pos') { const pf = $('posFull'); if (pf) pf.innerHTML = positionsHtml(true); }
    posBadge();
    if (st.ui.view === 'daily') renderDaily();
    if (st.ui.view === 'settings') renderSettings();
    const b = $('badge'); b.hidden = !st.unseen; b.textContent = st.unseen > 99 ? '99+' : st.unseen;
    document.documentElement.style.setProperty('--top-h', $('top').offsetHeight + 'px');
  }

  function renderTop() {
    const pill = $('pill'), txt = $('pillText');
    pill.className = 'pill';
    if (st.errors[st.ui.index] && !current()) { pill.classList.add('err'); txt.textContent = 'ERROR'; }
    else if (C.marketOpen(Date.now())) { pill.classList.add(st.errors[st.ui.index] ? 'err' : 'live'); txt.textContent = st.errors[st.ui.index] ? 'RETRYING' : 'LIVE'; }
    else txt.textContent = 'CLOSED';
    for (const b of $('idxSeg').children) b.classList.toggle('on', b.dataset.i === st.ui.index);
    const sel = $('expSel'), exps = st.expiries[st.ui.index] || [];
    const want = exps.map(e => `<option value="${e}">${fmtExpLong(e)}</option>`).join('') || '<option>Loading…</option>';
    if (sel.dataset.h !== want) { sel.innerHTML = want; sel.dataset.h = want; }
    if (st.sel[st.ui.index]) sel.value = st.sel[st.ui.index];
    for (const c of $('winChips').querySelectorAll('.chip')) c.classList.toggle('on', c.dataset.w === st.ui.win);
    const ss = $('srcStrip'); if (ss) { const h = srcStripHtml(); if (ss.dataset.h !== h) { ss.innerHTML = h; ss.dataset.h = h; } }
  }

  function renderBanner(d) {
    let h = '';
    const err = st.errors[st.ui.index];
    if (wantFT() && !LD().ready() && st.ui.view !== 'settings')
      h = `<div class="banner">${LD() === HS ? 'HDFC Sky' : 'Flattrade'} live data is on, but you're not logged in today. Showing ${C.INDICES[st.ui.index].src} data. <button ${LD() === HS ? 'data-hslogin' : 'data-ftlogin'}="1">Log in</button></div>`;
    else if (useFT() && st.ftErr && !isLive(st.srcUsed[st.ui.index]))
      h = `<div class="banner">${esc(st.ftErr)} Showing ${C.INDICES[st.ui.index].src} data for now. <button data-go="settings">Check</button></div>`;
    else if (err) h = `<div class="banner err">${esc(err)}${d ? ` Showing data from ${C.istTime(d.cur.ts)}.` : ''} <button data-go="settings">Data check</button></div>`;
    else if (d && st.ui.win !== 'prev' && st.ui.win !== 'open' && d.base && d.cur.ts - d.base.ts < (+st.ui.win - 1) * 60000)
      h = `<div class="banner">Only ${Math.max(1, Math.round((d.cur.ts - d.base.ts) / 60000))} min of history so far, so changes are vs ${C.istTime(d.base.ts)}.</div>`;
    $('banner').innerHTML = h;
  }

  function renderMetrics(d) {
    if (!d) { $('metrics').innerHTML = ''; return; }
    const { cur, base, series } = d;
    const firstSpot = series.length ? series[0].spot : cur.spot;
    const pcrBase = base ? base.pcr : (series.length ? series[0].pcr : cur.pcr);
    const sp = cur.spot - firstSpot;
    $('metrics').innerHTML = [
      `<div class="m"><div class="k">Spot · ${isLive(st.srcUsed[st.ui.index]) ? 'live' : C.INDICES[st.ui.index].src}</div><div class="v num">${f2(cur.spot)}</div><div class="d num ${cls(sp)}">${sgn(sp, f1)} today</div></div>`,
      `<div class="m"><div class="k">PCR</div><div class="v num">${isFinite(cur.pcr) ? cur.pcr.toFixed(2) : '–'}</div><div class="d num ${cls(cur.pcr - pcrBase)}">${sgn(cur.pcr - pcrBase, x => x.toFixed(2))}</div></div>`,
      `<div class="m mp"><div class="k">Max pain</div><div class="v num">${fmtK(cur.mp)}</div><div class="d num">${sgn(cur.mp - cur.spot, fmtK)} vs spot</div></div>`,
    ].join('');
  }

  // ------- futures card
  function renderFut() {
    const el = $('futCard'), s = st.fut.series;
    if (!s.length) { el.innerHTML = st.fut.err ? `<div class="card fut"><div class="fhead"><h3>NIFTY futures</h3></div><div class="hzmsg dn">${esc(st.fut.err)}</div></div>` : ''; return; }
    const cur = (useFT() && st.fut.liveCur) || s[s.length - 1], base = futBase(st.ui.win), r = C.futBuildup(cur, base), r15 = fut15();
    const prem = cur.ltp - cur.spot;
    const tag = x => x.label ? `<span class="fb ${x.bias === 'Bullish' ? 'bull' : 'bear'}">${x.label} · ${x.bias}</span>` : '<span class="fb">No clear buildup</span>';
    const exp = st.fut.meta ? fmtExp(st.fut.meta.iso) : '';
    el.innerHTML = `<div class="card fut">
      <div class="fhead"><h3>NIFTY futures <span class="dim">· ${exp}</span></h3>${tag(r)}</div>
      <div class="fgrid num">
        <div><div class="k">Price</div><div class="v">${f2(cur.ltp)}</div><div class="d ${cls(r.dp)}">${isFinite(r.dp) ? sgn(r.dp, f1) : '–'}</div></div>
        <div><div class="k">Premium</div><div class="v ${cls(prem)}">${isFinite(prem) ? sgn(prem, f1) : '–'}</div><div class="d">vs spot</div></div>
        <div><div class="k">OI</div><div class="v">${Q(cur.oi)}</div><div class="d ${cls(r.doi)}">${isFinite(r.doi) ? sQ(r.doi) : '–'}</div></div>
      </div>
      <div class="fnote">Change ${base ? base.label : ''} · last 15 min: ${tag(r15)}${st.ui.index === 'SENSEX' ? '<br>Used for SENSEX too: SENSEX futures trade too thinly to read.' : ''}</div>
    </div>`;
  }

  // ------- hero-zero box
  function heroBar(label, side, s, S) {
    const pct = Math.min(100, s.drop || 0);
    const hit = s.hit;
    return `<div class="hzrow"><div class="hzl ${side}">${label}</div>
      <div class="hzbar"><div class="hzfill ${side} ${hit ? 'hit' : ''}" style="width:${pct.toFixed(0)}%"></div><div class="hzmark" style="left:${S.heroDrop}%"></div></div>
      <div class="hzv num">${isFinite(s.peak) && s.peak > 0 ? `${sQ(s.now)} <span>/ ${sQ(s.peak)}</span>` : (isFinite(s.now) ? sQ(s.now) : '–')}</div></div>`;
  }
  function renderHero() {
    const el = $('hero'), S = st.settings, index = st.ui.index;
    const hz = heroFor(index);
    if (!hz) { el.innerHTML = ''; return; }
    const exp = (st.expiries[index] || [])[0];
    let head = '', body = '';
    const bars = `${heroBar('CE', 'ce', hz.ce, S)}${heroBar('PE', 'pe', hz.pe, S)}
      <div class="hzcap">Total OI change of ATM ±5 strikes · bar = fall from today's peak · strike given at ${S.heroEarly || 50}% · line = strong signal ${S.heroDrop}%${hz.since ? ` · watching since ${C.istTime(hz.since)}` : ''}</div>`;
    if (hz.state === 'not-expiry') {
      head = `<span class="hzst idle">Not expiry day</span>`;
      body = `<div class="hzmsg">Activates on ${index} expiry day (${fmtExpLong(exp)}) after ${hhmm(S.heroStart)}.</div>`;
    } else if (hz.state === 'before') {
      head = `<span class="hzst idle">Expiry day · starts ${hhmm(S.heroStart)}</span>`;
      body = `<div class="hzmsg">Tracking OI change peaks from now. Signal shows after ${hhmm(S.heroStart)}.</div>${bars}`;
    } else {
      let e = null; try { e = hzEval(index); } catch (x) { console.error(x); }
      const trig = e ? e.trig : { side: '', txt: '' }, side = trig.side;
      head = `<span class="hzst ${side === 'CE' ? 'ce' : side === 'PE' ? 'pe' : 'idle'}">${side ? side + ' side' : trig.forming ? 'Forming ' + trig.forming : hz.state === 'both' ? 'Both falling' : 'Watching'}</span>`;
      const big = side ? `${side === 'CE' ? '▲ CE side: call' : '▼ PE side: put'} writers ${trig.how === 'straddle' ? 'quiet, straddle spiking' : 'exiting'}`
        : trig.forming ? `⏳ Forming on the ${trig.forming} side` : trig.how === 'both' ? 'Both sides falling: wait' : 'No side yet';
      const oiRow = (lbl, k, x) => x && isFinite(x.peak) ? `<span class="k ${k}">${lbl} OI chg</span><span>${Q(x.peak)} at ${x.peakTs ? C.istTime(x.peakTs) : '–'} → <b>${Q(x.now)}</b> now</span><span class="d ${x.drop >= (S.heroEarly || 50) ? 'up' : ''}">−${Math.round(x.drop)}%</span>` : '';
      const oi = `<div class="hzoi">${oiRow('CE', 'ce', hz.ce)}${oiRow('PE', 'pe', hz.pe)}</div>`;
      const b = e && e.best;
      const follow = b ? `<div class="hzfollow ${e.useSide === 'CE' ? 'ce' : 'pe'}"><div class="l"><span>Follow this strike</span><b>${fmtK(b.strike)} ${e.useSide}</b><span>now ₹${f2(b.ltp)} · reach ${pctTxt(b.reach)}</span></div>
          <div class="r">Buy at or below<b>₹${f1(b.ltp * 1.03)}</b>${e.go ? '<span class="up">✅ GO</span>' : `<span class="dim">${e.nConf}/${e.conf.length} confirmations</span>`}</div></div>${tradeBtn({ i: index, k: b.strike, s: e.useSide, t: 'B', iso: e.ctx.iso, p: tick05(b.ltp * 1.03), l: Math.max(1, e.lots), hero: true, safe: e.go, why: 'Hero-zero' }, `🛒 Buy ${fmtK(b.strike)} ${e.useSide}`, 'buy wide')}`
        : `<div class="hzmsg dim">No strike yet: a strike is given when writers exit one side (${S.heroEarly || 50}%+ fall) or the ATM straddle spikes.</div>`;
      const tt = hzTimesTxt(index), mv = e && e.movers.length ? `<div class="hzmove"><b>🔥 Moving now</b>${e.movers.slice(0, 3).map(m => `<span class="${m.side === 'CE' ? 'ce' : 'pe'}">${moverTxt(m)}</span>`).join('')}</div>` : '';
      const fut = (() => { if (!side) return ''; const r15 = fut15(), conf = C.futConfirm(side, r15.bias);
        return conf === 'agree' ? `<div class="hzconf ok">✅ Futures agree · ${r15.label}</div>` : conf === 'disagree' ? `<div class="hzconf bad">⚠️ Futures disagree · ${r15.label}</div>` : ''; })();
      body = `<div class="hzbig">${big}</div><div class="hzmsg">${trig.txt}</div>${oi}${follow}${fut}${mv}${tt ? `<div class="hzcap">Today: ${tt}</div>` : ''}
        <div class="row2" style="gap:6px;margin:6px 0"><button class="btn ghost" data-gohz="1" style="margin:0;padding:7px 10px;font-size:12px">Open HZ →</button><button class="btn ghost" data-ask="Explain the ${index} hero-zero situation now. Which strike should I buy, at what entry, and why?" style="margin:0;padding:7px 10px;font-size:12px">💬 Ask EV</button></div>${bars}`;
    }
    el.innerHTML = `<div class="card hz"><div class="hzhead"><h3>Hero-zero</h3>${head}</div>${body}
      <div class="hzfoot">Guide only. Most hero-zero trades expire worthless.</div></div>`;
  }

  // ------- chain table: OI | OI chg | LTP | Strike | LTP | OI chg | OI
  /**
   * "Zero OI change" test for a strike side (i: 0 = CE, 1 = PE): OI change exactly 0, or (vs prev close)
   * fallen >= heroDrop% from that strike's peak today. Same rule as the amber cells.
   */
  function zeroTester(key, view) {
    const pk = st.peaks[key] || {}, drop = st.settings.heroDrop;
    const top = [0, 0];
    for (const r of view) { const p = pk[r.strike]; if (p) { top[0] = Math.max(top[0], p[0]); top[1] = Math.max(top[1], p[1]); } }
    const hasChg = [view.some(r => r.ce.doi !== 0), view.some(r => r.pe.doi !== 0)];
    const t = (r, i) => {
      if (!hasChg[i]) return false;   // no OI-change data on this side (e.g. after hours)
      const x = i ? r.pe : r.ce;
      if (x.oi > 0 && Math.round(x.doi) === 0) return true;
      if (st.ui.win !== 'prev') return false;
      const peak = pk[r.strike] ? pk[r.strike][i] : 0;
      return peak > 0 && peak >= top[i] * 0.05 && (peak - x.doi) / peak * 100 >= drop;
    };
    t.hasData = hasChg[0] || hasChg[1];
    return t;
  }

  // ------- Home: zero OI change above vs below spot
  function renderZero(d) {
    const el = $('zeroCard');
    if (!d) { el.innerHTML = ''; return; }
    const { cur, rows, key } = d;
    const view = C.windowRows(rows, cur.spot, st.settings.strikes);
    const z = zeroTester(key, view);
    const up = view.filter(r => r.strike > cur.spot), dn = view.filter(r => r.strike < cur.spot);
    const cnt = (list, i) => list.filter(r => z(r, i)).length;
    const a = { ce: cnt(up, 0), pe: cnt(up, 1) }, b = { ce: cnt(dn, 0), pe: cnt(dn, 1) };
    const ta = a.ce + a.pe, tb = b.ce + b.pe;
    const strikesOf = (list, i) => list.filter(r => z(r, i)).map(r => fmtK(r.strike));
    const tip = (list, i) => { const k = strikesOf(list, i); return k.length ? k.slice(0, 6).join(', ') + (k.length > 6 ? ' …' : '') : '—'; };
    let verdict, vcls = '';
    if (!z.hasData) verdict = 'No OI-change data right now (market closed or data not published yet).';
    else if (ta === 0 && tb === 0) verdict = 'No strike has zero OI change: writers are active on both sides.';
    else if (ta > tb) { verdict = `More zero OI change <b>above spot</b> (${ta} vs ${tb}). Writers are inactive or exiting above the price.` + (a.ce >= a.pe ? ' Call writers above are fading: resistance is weakening.' : ''); vcls = 'up'; }
    else if (tb > ta) { verdict = `More zero OI change <b>below spot</b> (${tb} vs ${ta}). Writers are inactive or exiting below the price.` + (b.pe >= b.ce ? ' Put writers below are fading: support is weakening.' : ''); vcls = 'dn'; }
    else verdict = `Equal on both sides (${ta} each): no clear lean.`;
    const total = Math.max(1, ta + tb);
    el.innerHTML = `<div class="card zc">
      <div class="fhead"><h3>Zero OI change</h3><span class="dim" style="font-size:11px">±${st.settings.strikes} strikes · vs ${winLabel()}</span></div>
      <div class="zgrid num">
        <div class="zcol"><div class="zt">▲ Above spot</div><div class="zbig">${ta}</div>
          <div class="zrow"><span class="ce">CE</span><b>${a.ce}</b></div><div class="zst">${tip(up, 0)}</div>
          <div class="zrow"><span class="pe">PE</span><b>${a.pe}</b></div><div class="zst">${tip(up, 1)}</div></div>
        <div class="zcol"><div class="zt">▼ Below spot</div><div class="zbig">${tb}</div>
          <div class="zrow"><span class="ce">CE</span><b>${b.ce}</b></div><div class="zst">${tip(dn, 0)}</div>
          <div class="zrow"><span class="pe">PE</span><b>${b.pe}</b></div><div class="zst">${tip(dn, 1)}</div></div>
      </div>
      <div class="zsplit"><div style="width:${(ta / total * 100).toFixed(0)}%" class="za"></div><div style="width:${(tb / total * 100).toFixed(0)}%" class="zb"></div></div>
      <div class="zlab"><span>Above ${ta}</span><span>Below ${tb}</span></div>
      <div class="zverdict ${vcls}">${verdict}</div>
      ${planHtml(view, cur.spot, z)}
      <div class="hzcap">Zero = OI change is 0, or has fallen ${st.settings.heroDrop}%+ from that strike's peak today (the amber cells in Chain).</div>
    </div>`;
  }

  function planHtml(view, spot, z) {
    if (!z.hasData) return '';
    const pl = C.heroPlan(view, spot, z, st.settings);
    if (!pl.side) return `<div class="plan"><div class="ph"><b>Hero-zero plan</b></div><div class="pmsg">${pl.why}</div></div>`;
    const sc = pl.side === 'CE' ? 'ce' : 'pe', dir = pl.side === 'CE' ? 'up' : 'down';
    try { const e = isExpiryDay(st.ui.index) ? hzEval(st.ui.index) : null;
      if (e && e.best && e.useSide === pl.side) { const sd = sc, row = view.find(r => r.strike === e.best.strike) || { [sd]: { ltp: e.best.ltp } };
        pl.buy = Object.assign({}, pl.buy || {}, { strike: e.best.strike, ltp: e.best.ltp, [sd]: { ltp: e.best.ltp } });
        pl.targets = pl.targets.map(t => { const est = C.estPrice(view, sd, e.best.strike, spot, t.level); return { level: t.level, est, x: est / e.best.ltp }; }); } } catch (x) { }
    const buy = pl.buy ? `<div class="pbuy ${sc}"><div><div class="pk">Strike to watch (same as HZ)</div><div class="pv">${fmtK(pl.buy.strike)} ${pl.side}</div></div><div><div class="pk">Now</div><div class="pv">₹${f2(pl.buy.ltp)}</div></div></div>`
      : `<div class="pmsg">No ${pl.side} strike in the open road is priced ₹${st.settings.heroMin}–₹${st.settings.heroMax} right now.</div>`;
    const tg = pl.targets.length ? `<div class="ptab num"><div class="pth">If ${st.ui.index} reaches</div><div class="pth">Est. price</div><div class="pth">Return</div>` +
      pl.targets.map(t => `<div>${fmtK(t.level)}${t.level === pl.wall ? ' <span class="dim">(wall)</span>' : ''}<br><span class="reach">reach ${pctTxt(reachProb(st.ui.index, spot, t.level))}</span></div><div><b>₹${isFinite(t.est) ? f1(t.est) : '–'}</b></div><div class="${t.x >= 1 ? 'up' : 'dn'}">${isFinite(t.x) ? t.x.toFixed(1) + 'x' : '–'}</div>`).join('') + '</div>' : '';
    return `<div class="plan">
      <div class="ph"><b>Hero-zero plan</b><span class="hzst ${sc}">${pl.side} side</span></div>
      <div class="pmsg">Open road <b>${dir}</b>: ${pl.count} ${pl.side} strikes have zero OI change. Spike zone <b>${fmtK(pl.zone[0])} → ${fmtK(pl.zone[1])}</b>${pl.wall ? `, where writers are still adding at <b>${fmtK(pl.wall)}</b> (expect the move to slow there)` : ''}.</div>
      ${buy}${tg}
      <div class="pnote">Estimates use today's chain prices: they show what the option could be worth <i>if</i> spot gets there. If the move doesn't come, a hero-zero option can expire at ₹0. Guide only, not advice.</div>
    </div>`;
  }

  // ------- Daily Trade
  function dataFor(index) {
    const exps = st.expiries[index] || [], iso = st.sel[index] || exps[0];
    if (!iso) return null;
    const key = index + '|' + iso, h = st.snaps[key] || [];
    if (!h.length) return null;
    const lv = st.live[key], cur = lv && lv.ts > h[h.length - 1].ts ? lv : h[h.length - 1];
    let b = C.baseline(h, st.first[key], '15'); if (b && (b === cur || cur.ts - b.ts < 4 * 60000)) b = null;
    return { index, iso, key, h, cur, b, series: st.series[key] || [] };
  }
  /** GIFT Nifty: automatic from NSE (marketStatus → giftnifty), or the value you typed; the newer one wins */
  function giftGet() {
    const today = C.istDate(Date.now());
    const m = store.get('oi.gift', null), a = store.get('oi.giftauto', null);
    const mm = m && C.istDate(m.ts) === today ? Object.assign({ src: 'manual' }, m) : null;
    const aa = a && C.istDate(a.ts) === today ? Object.assign({ src: 'auto' }, a) : null;
    return mm && aa ? (mm.ts > aa.ts ? mm : aa) : mm || aa;
  }
  async function fetchGift(force) {
    const a = store.get('oi.giftauto', null), p = C.istParts(Date.now()), mins = p.h * 60 + p.mi;
    if (useFT()) { try { await FT.findGift(); const q = FT.giftQuote();          // live from Flattrade if they ever list it
      if (q) { store.set('oi.giftauto', { from: 'Flattrade', v: q.v, ts: Date.now(), chg: q.prev > 0 ? q.v - q.prev : NaN, pct: q.prev > 0 ? (q.v / q.prev - 1) * 100 : NaN }); st.giftErr = null; return; } } catch (e) { } }
    const every = mins < 9 * 60 + 15 ? 1 : 15;                         // every minute before the open (NSE blocks faster polling), 15 min after
    if (!force && a && Date.now() - a.ts < every * 60000) return;
    try {
      const j = await nseGet('/api/marketStatus'), g = j && j.giftnifty;
      const v = g ? parseFloat(String(g.LASTPRICE).replace(/,/g, '')) : NaN;
      if (v > 1000) { store.set('oi.giftauto', { v, ts: Date.now(), chg: parseFloat(g.DAYCHANGE), pct: parseFloat(g.PERCHANGE), exp: g.EXPIRYDATE || '', at: g.TIMESTMP || '' }); st.giftErr = null; }
      else st.giftErr = 'NSE did not include GIFT Nifty this time.';
    } catch (e) { st.giftErr = 'Could not reach NSE for GIFT Nifty.'; }
  }
  function futLast() { const s = st.fut.series; return (useFT() && st.fut.liveCur) || (s.length ? s[s.length - 1] : null); }
  function predictionFor(index) {
    const d = dataFor(index); if (!d) return null;
    const { cur, key, b } = d;
    const prevRows = C.compare(cur, null);
    const view = C.windowRows(prevRows, cur.spot, st.settings.strikes);
    const z = zeroTester(key, view);
    const zeroAbove = view.filter(r => r.strike > cur.spot && (z(r, 0) || z(r, 1))).length;
    const zeroBelow = view.filter(r => r.strike < cur.spot && (z(r, 0) || z(r, 1))).length;
    const R = C.srSide(cur, b, 'ce'), S = C.srSide(cur, b, 'pe');
    const fl = futLast(), fb = futBase('prev');
    const futDay = fl && fb ? C.futBuildup(fl, fb) : null;
    const g = giftGet();
    const giftGap = g && fl ? g.v - fl.ltp : NaN;
    const giftPct = g && fl ? giftGap / fl.ltp * 100 : NaN;
    const p = C.predict({ pcr: cur.pcr, spot: cur.spot, mp: cur.mp, step: C.INDICES[index].step, R, S,
      zeroAbove: z.hasData ? zeroAbove : NaN, zeroBelow: z.hasData ? zeroBelow : NaN,
      futDay, fut15: fut15(), giftGap, giftPct, news: NEWS.mood() });
    return Object.assign(p, { d, R, S, zeroAbove, zeroBelow, futDay, g, giftGap, giftPct });
  }
  function predCard(index) {
    const p = predictionFor(index);
    if (!p) return `<div class="card"><h3>${index}</h3><div class="hzmsg">${loadingMsg() || 'No data yet.'}</div></div>`;
    const { cur } = p.d, pct = Math.max(-1, Math.min(1, p.r));
    const nS = nearLevel(index, cur, 'pe'), nR = nearLevel(index, cur, 'ce');
    const lo = Math.min(nS, cur.spot), hi = Math.max(nR, cur.spot);
    const em = (() => { const vf = volFor(index); return vf ? C.expMove(cur.spot, vf.vol, 375) : NaN; })();
    const watch = p.tone === 'up' ? `A move above <b>${fmtK(nR)}</b> (nearest strong call writing) can extend toward ${fmtK(nR + (isFinite(em) ? Math.round(em / C.INDICES[index].step) * C.INDICES[index].step : 2 * C.INDICES[index].step))}.`
      : p.tone === 'dn' ? `A break below <b>${fmtK(nS)}</b> (nearest strong put writing) can extend toward ${fmtK(nS - (isFinite(em) ? Math.round(em / C.INDICES[index].step) * C.INDICES[index].step : 2 * C.INDICES[index].step))}.`
      : `Expect trading between <b>${fmtK(nS)}</b> and <b>${fmtK(nR)}</b> until one side breaks.`;
    const ic = v => v > 0.15 ? '<span class="fi up">▲</span>' : v < -0.15 ? '<span class="fi dn">▼</span>' : '<span class="fi">●</span>';
    return `<div class="card pred">
      <div class="fhead"><h3>${index} <span class="dim">· ${f2(cur.spot)}</span></h3><span class="pl ${p.tone === 'up' ? 'bull' : p.tone === 'dn' ? 'bear' : ''}">${p.label}</span></div>
      <div class="pmeter"><div class="pmid"></div><div class="pdot ${p.tone}" style="left:${(50 + pct * 50).toFixed(1)}%"></div></div>
      <div class="plab"><span>Bearish</span><span>Sideways</span><span>Bullish</span></div>
      <div class="pgrid num">
        <div><div class="k">Expected range</div><div class="v">${fmtK(lo)} – ${fmtK(hi)}</div></div>
        <div><div class="k">Confidence</div><div class="v">${p.conf}</div></div>
        <div><div class="k">Score</div><div class="v ${p.tone}">${p.score >= 0 ? '+' : ''}${p.score.toFixed(1)} / ${p.max.toFixed(1)}</div></div>
      </div>
      <div class="zverdict ${p.tone}">${watch}</div>
      <div class="flist">${p.factors.map(f => `<div class="fr">${ic(f.val)}<span>${f.txt}</span></div>`).join('')}</div>
      ${ideasHtml(index, p.tone)}
    </div>`;
  }
  function renderDaily() {
    const el = $('daily'), dt = st.ui.dtab || 'plan';
    if (dt !== 'plan') {
      const p0 = C.istParts(Date.now());
      el.innerHTML = `<div class="dhead"><div class="dt">Daily Trade</div><div class="dd">${p0.d} ${MONS[p0.mo - 1]} ${p0.y} · ${C.istTime(Date.now())} IST</div></div>${dailyTabs()}` +
        (dt === 'data' ? dataView() : dt === 'call' ? callView() : dt === 'acc' ? accView() : dt === 'hero' ? heroView() : journalView());
      return;
    }
    const g = giftGet(), fl = futLast();
    const gap = g && fl ? g.v - fl.ltp : NaN;
    const now = Date.now(), p = C.istParts(now);
    const giftCard = `<div class="card">
      <div class="fhead"><h3>GIFT Nifty</h3><span style="display:flex;gap:6px;align-items:center"><span class="dim" style="font-size:11px">${g ? (g.src === 'auto' ? `⚡ auto from ${g.from || 'NSE'} · ` : '✍️ typed · ') + C.istTime(g.ts, true) : 'loading…'}</span><button class="chip" id="giftRefresh">↻</button></span></div>
      ${g ? `<div class="gbig num"><b>${f2(g.v)}</b>${g.src === 'auto' && isFinite(g.chg) ? `<span class="${cls(g.chg)}">${sgn(g.chg, f1)} (${sgn(g.pct, x => x.toFixed(2))}%) on the day</span>` : ''}</div>` : `<div class="hzmsg">${esc(st.giftErr || 'Fetching GIFT Nifty from NSE…')}</div>`}
      <details class="gman"><summary>Type a value instead (optional)</summary>
        <div class="gift" style="margin-top:8px"><input id="giftIn" type="number" inputmode="decimal" placeholder="e.g. 25120"><button class="btn" id="giftSave" style="margin:0;width:auto;padding:10px 16px">Use</button></div>
        <div class="hzcap">Only needed if the automatic value fails. The newer of the two is used.</div></details>
      <div class="hzmsg" style="margin-top:8px">${g && fl ? `vs NIFTY futures ${f2(fl.ltp)}: <b class="${cls(gap)}">${sgn(gap, fmtK)} pts (${sgn(gap / fl.ltp * 100, x => x.toFixed(2))}%)</b>, ` +
        (gap / fl.ltp * 100 > 0.3 ? 'gap-up cue for the open.' : gap / fl.ltp * 100 < -0.3 ? 'gap-down cue for the open.' : 'flat open likely.') : 'GIFT Nifty trades almost round the clock and hints at how NIFTY may open. The app reads it from NSE every minute before 9:15 (tap ↻ for now).'}</div>
    </div>`;
    const tab = st.ui.newsTab || 'All';
    const items = NEWS.items.filter(x => tab === 'All' || x.scope === tab);
    const mood = NEWS.mood();
    const imp = x => x.impact > 0 ? '<span class="nb up">Positive for market</span>' : x.impact < 0 ? '<span class="nb dn">Negative for market</span>' : '<span class="nb">Neutral</span>';
    const newsCard = `<div class="card">
      <div class="fhead"><h3>Market-moving news</h3><button class="chip" id="newsRefresh">Refresh</button></div>
      <div class="toggle" id="newsTabs">${['All', 'India', 'World'].map(t => `<button class="chip ${t === tab ? 'on' : ''}" data-nt="${t}">${t}</button>`).join('')}</div>
      ${mood.n ? `<div class="hzmsg">Last 24 h: <b class="up">${mood.pos} positive</b> · <b class="dn">${mood.neg} negative</b> · ${mood.n - mood.pos - mood.neg} neutral</div>` : ''}
      ${NEWS.err && !items.length ? `<div class="hzmsg dn">${esc(NEWS.err)}</div>` : ''}
      ${!items.length && !NEWS.err ? '<div class="hzmsg">Loading headlines…</div>' : ''}
      <div class="nlist">${items.slice(0, 20).map((x, i) => `<div class="ni" data-ni="${NEWS.items.indexOf(x)}">
        <div class="nt">${imp(x)}<span class="ntop">${esc(x.topic)} · ${x.scope}</span></div>
        <div class="nh">${esc(x.title)}</div>
        ${x.society ? `<div class="ns">👥 ${esc(x.society)}</div>` : ''}
        <div class="nm">${esc(x.src)}${x.ts ? ' · ' + ago(x.ts) : ''}</div></div>`).join('')}</div>
      <div class="hzcap">Headlines from Google News. Market impact and impact on society are read from the headline by a built-in rulebook (e.g. rate cut → EMIs may fall). Tap a headline to read the full story.</div>
    </div>`;
    el.innerHTML = `<div class="dhead"><div class="dt">Daily Trade Plan</div><div class="dd">${p.d} ${MONS[p.mo - 1]} ${p.y} · ${C.istTime(now)} IST · ${C.marketOpen(now) ? 'market open' : 'market closed'}</div></div>
      ${dailyTabs()}${predCard('NIFTY')}${predCard('SENSEX')}${giftCard}${newsCard}
      <div class="help" style="padding:0 16px 16px">The prediction combines option chain (PCR, support/resistance shifts, zero OI, max pain), NIFTY futures buildup, GIFT Nifty and news mood. It is a probability-based guide, not a certainty or investment advice.</div>`;
  }

  // ------- Home: support & resistance tracker
  function renderSR(d) {
    const el = $('srCard');
    if (!d) { el.innerHTML = ''; return; }
    const { cur, h, key, series } = d;
    let b = C.baseline(h, st.first[key], '15');
    if (b && (b === cur || cur.ts - b.ts < 4 * 60000)) b = null;
    const mins = b ? Math.round((cur.ts - b.ts) / 60000) : 0;
    const R = C.srSide(cur, b, 'ce'), S = C.srSide(cur, b, 'pe');
    if (!R || !S) { el.innerHTML = ''; return; }
    const winTxt = b ? `last ${mins} min` : 'today';
    const badge = x => {
      if (x.state === 'Shift') return `<span class="sb ${x.dir}">${x.conf === 'Likely' ? 'Likely' : 'May'} shift ${x.dir === 'up' ? '↑' : '↓'} ${fmtK(x.target)}</span>`;
      if (x.state === 'Weakening') return `<span class="sb weak">Weakening ${x.dir === 'up' ? '↑' : '↓'}</span>`;
      if (x.state === 'Flat') return `<span class="sb">No fresh writing</span>`;
      return `<span class="sb hold">Holding</span>`;
    };
    const why = (x) => {
      const who = x.side === 'ce' ? 'Call' : 'Put', name = x.side === 'ce' ? 'Resistance' : 'Support';
      const rc = x.recentOk ? x.recent : x.today;
      if (x.state === 'Shift') return `${who} writers are adding faster at <b>${fmtK(x.target)}</b> (${sQ(x.ch.move)} ${winTxt}, OI now ${Math.round(x.ch.share * 100)}% of ${fmtK(x.level)})` +
        (rc < 0 ? ` while ${fmtK(x.level)} is unwinding (${sQ(rc)}).` : ` than at ${fmtK(x.level)} (${sQ(rc)}).`) +
        ` ${name} may shift <b>${x.dir}</b> to ${fmtK(x.target)}.`;
      if (x.state === 'Weakening') return `${who} writers are exiting ${fmtK(x.level)} (${sQ(rc)} ${winTxt}). ${name} may shift <b>${x.dir}</b>` + (x.target ? ` toward ${fmtK(x.target)}.` : '.');
      if (x.state === 'Flat') return `No new ${who.toLowerCase()} writing at ${fmtK(x.level)} ${winTxt}. Watch for a shift.`;
      return `${who} writers still adding at ${fmtK(x.level)} (${sQ(rc)} ${winTxt}). ${name} is holding.`;
    };
    const lvl = (x, title) => `<div class="srb ${x.side}">
        <div class="srh"><div><div class="srt">${title}</div><div class="srv">${fmtK(x.level)}</div></div>${badge(x)}</div>
        <div class="srg num">
          <div><div class="k">${x.side === 'ce' ? 'Call' : 'Put'} OI</div><div class="v">${Q(x.oi)}</div></div>
          <div><div class="k">OI chg today</div><div class="v ${cls(x.today)}">${sQ(x.today)}</div></div>
          <div><div class="k">Last ${b ? mins + ' min' : '15 min'}</div><div class="v ${x.recentOk ? cls(x.recent) : ''}">${x.recentOk ? sQ(x.recent) : '—'}</div></div>
        </div>
        <div class="srw">${why(x)}</div>
        ${x.next ? `<div class="srn">2nd strongest ${x.side === 'ce' ? 'resistance' : 'support'}: <b>${fmtK(x.next.strike)}</b> · OI ${Q(x.next.oi)}${isFinite(x.next.recent) ? ` · ${sQ(x.next.recent)} ${winTxt}` : ` · ${sQ(x.next.today)} today`}</div>` : ''}
      </div>`;
    // range bar
    const lo = Math.min(S.level, cur.spot), hi = Math.max(R.level, cur.spot), span = Math.max(1, hi - lo);
    const pos = v => ((v - lo) / span * 100).toFixed(1);
    const range = `<div class="srr"><div class="srline"></div>
        <div class="srm pe" style="left:${pos(S.level)}%"><span>S ${fmtK(S.level)}</span></div>
        <div class="srm sp" style="left:${pos(cur.spot)}%"><span>${f1(cur.spot)}</span></div>
        <div class="srm ce" style="left:${pos(R.level)}%"><span>R ${fmtK(R.level)}</span></div></div>
      <div class="srd num"><span class="pe">${fmtK(cur.spot - S.level)} pts above support</span><span class="ce">${fmtK(R.level - cur.spot)} pts to resistance</span></div>`;
    const hr = C.srHistory(series, 'res').slice(-2).map(x => `${C.istTime(x.ts)} R ${fmtK(x.from)}→${fmtK(x.to)}`)
      .concat(C.srHistory(series, 'sup').slice(-2).map(x => `${C.istTime(x.ts)} S ${fmtK(x.from)}→${fmtK(x.to)}`)).sort();
    el.innerHTML = `<div class="card src">
      <div class="fhead"><h3>Support &amp; Resistance</h3><span class="dim" style="font-size:11px">from option OI · ${winTxt}</span></div>
      ${lvl(R, 'Resistance (max Call OI)')}
      ${range}
      ${lvl(S, 'Support (max Put OI)')}
      ${hr.length ? `<div class="srhist">Moves today: ${hr.join(' · ')}</div>` : '<div class="srhist">No support/resistance shift yet today.</div>'}
      <div class="hzcap">Shift forecast: a strike with ≥75% of the level's OI and building faster can take over; writers exiting the level weaken it. Guide only.</div>
    </div>`;
  }

  // ------- Home: ATM CE vs PE OI-change comparison
  function renderAtm(d) {
    const el = $('atmCard');
    if (!d) { el.innerHTML = ''; return; }
    const { cur, h, key } = d;
    const prev = C.compare(cur, null);                 // OI change vs previous close
    const atm = prev[C.atmIndex(prev, cur.spot)];
    if (!atm) { el.innerHTML = ''; return; }
    const at = (mins) => {                              // OI change at this strike N minutes ago
      const b = C.baseline(h, st.first[key], String(mins));
      if (!b || b === cur || cur.ts - b.ts < (mins - 1) * 60000) return null;
      const r = b.rows.find(x => x.strike === atm.strike);
      return r ? { ce: r.ce.oi - r.ce.poi, pe: r.pe.oi - r.pe.poi } : null;
    };
    const m5 = at(5), m15 = at(15);
    const ce = atm.ce.doi, pe = atm.pe.doi;
    const mv = (b, side) => b ? (side === 'ce' ? ce - b.ce : pe - b.pe) : NaN;
    const cell = v => isFinite(v) ? `<b class="${cls(v)}">${sQ(v)}</b>` : '<span class="dim">—</span>';
    const mx = Math.max(1, Math.abs(ce), Math.abs(pe));
    const bar = (v, c) => `<div class="abar"><div class="${c} ${v < 0 ? 'neg' : ''}" style="width:${(Math.abs(v) / mx * 100).toFixed(0)}%"></div></div>`;
    const d5 = [mv(m5, 'ce'), mv(m5, 'pe')], d15 = [mv(m15, 'ce'), mv(m15, 'pe')];
    const pick = isFinite(d5[0]) ? d5 : isFinite(d15[0]) ? d15 : null, plab = isFinite(d5[0]) ? '5 min' : '15 min';
    let verdict = '', vcls = '';
    if (pick) {
      const [c5, p5] = pick;
      if (p5 > 0 && p5 > c5) { verdict = `Put writing at ATM is growing faster (last ${plab}): support building, bullish tilt.`; vcls = 'up'; }
      else if (c5 > 0 && c5 > p5) { verdict = `Call writing at ATM is growing faster (last ${plab}): resistance building, bearish tilt.`; vcls = 'dn'; }
      else if (c5 < 0 && p5 >= c5) { verdict = `Call writers at ATM are exiting (last ${plab}): upside can open up.`; vcls = 'up'; }
      else if (p5 < 0 && c5 >= p5) { verdict = `Put writers at ATM are exiting (last ${plab}): downside can open up.`; vcls = 'dn'; }
      else verdict = `Little change at ATM in the last ${plab}.`;
    } else {
      verdict = pe > ce ? 'Today so far: more put writing than call writing at ATM.' : ce > pe ? 'Today so far: more call writing than put writing at ATM.' : 'ATM OI change is balanced.';
      verdict += ' (5/15-min moves appear once the app has tracked a few minutes.)';
    }
    el.innerHTML = `<div class="card atc">
      <div class="fhead"><h3>ATM ${fmtK(atm.strike)} · CE vs PE</h3><span class="dim" style="font-size:11px">spot ${f2(cur.spot)}</span></div>
      <div class="atgrid num">
        <div></div><div class="ah ce">CE</div><div class="ah pe">PE</div>
        <div class="al">OI</div><div>${Q(atm.ce.oi)}</div><div>${Q(atm.pe.oi)}</div>
        <div class="al">OI chg today</div><div>${cell(ce)}</div><div>${cell(pe)}</div>
        <div class="al">OI chg %</div><div>${cell2(atm.ce.doiPct)}</div><div>${cell2(atm.pe.doiPct)}</div>
        <div class="al">Last 5 min</div><div>${cell(d5[0])}</div><div>${cell(d5[1])}</div>
        <div class="al">Last 15 min</div><div>${cell(d15[0])}</div><div>${cell(d15[1])}</div>
        <div class="al">LTP</div><div>${f2(atm.ce.ltp)}</div><div>${f2(atm.pe.ltp)}</div>
      </div>
      <div class="acmp"><span class="ce">CE</span>${bar(ce, 'ce')}<span class="num">${sQ(ce)}</span></div>
      <div class="acmp"><span class="pe">PE</span>${bar(pe, 'pe')}<span class="num">${sQ(pe)}</span></div>
      <div class="zverdict ${vcls}">${verdict}</div>
    </div>`;
  }
  const cell2 = v => isFinite(v) ? `<b class="${cls(v)}">${sgn(v, x => x.toFixed(1))}%</b>` : '<span class="dim">—</span>';

  function renderChain(d) {
    const tbl = $('chainTbl');
    if (!d) { tbl.innerHTML = ''; $('chainSub').innerHTML = loadingMsg(); return; }
    const { cur, rows, key } = d;
    const view = C.windowRows(rows, cur.spot, st.settings.strikes);
    let maxOi = 1; for (const r of view) maxOi = Math.max(maxOi, r.ce.oi, r.pe.oi);
    const atm = view[C.atmIndex(view, cur.spot)];
    const zeroish = zeroTester(key, view);
    const jc = judgeCtx(st.ui.index, true), J = {};
    if (jc) for (const r of view) for (const sd of ['ce', 'pe']) { try { J[sd + r.strike] = judge(jc, sd, r.strike, r[sd].ltp); } catch (e) { } }
    st.chainJ = J;
    // the strike to buy right now for the market read (bullish → CE, bearish → PE); sideways → breakout candidates only
    const tone = jc ? jc.tone : '';
    let picks = [];
    try {
      if (tone === 'up' || tone === 'dn') { const pl = tradePlan(st.ui.index, tone === 'up' ? 'up' : 'down', null, true); if (pl) picks = [Object.assign(pl, { main: true })]; }
      else if (jc) { for (const dd of ['up', 'down']) { const pl = tradePlan(st.ui.index, dd, null, true); if (pl) picks.push(Object.assign(pl, { main: false })); } }
    } catch (e) { }
    const pickOf = (sd, r) => picks.find(p => p.strike === r.strike && p.side === sd.toUpperCase());
    const tag = (sd, r) => { const p = pickOf(sd, r); return p ? `<span class="bt ${p.main ? 'main' : 'alt'} ${sd}">${p.main ? 'BUY' : (p.dir === 'up' ? 'if ↑' : 'if ↓')}</span>` : ''; };
    const pj = (sd, r) => { const j = J[sd + r.strike]; return j ? ' pjc ' + vjCls(j.verdict) : ''; };
    const head = `<colgroup><col style="width:14.5%"><col style="width:14%"><col style="width:13.5%"><col style="width:16%"><col style="width:13.5%"><col style="width:14%"><col style="width:14.5%"></colgroup>
      <thead><tr><th class="ceh"><span class="side">CALLS</span>OI</th><th class="ceh">OI chg</th><th class="ceh">LTP</th><th class="s">Strike</th><th class="pe peh"><span class="side">PUTS</span>LTP</th><th class="pe peh">OI chg</th><th class="pe peh">OI</th></tr></thead>`;
    let body = '', spotDone = false;
    for (const r of view) {
      if (!spotDone && r.strike > cur.spot) { body += spotRow(cur.spot); spotDone = true; }
      const isAtm = r === atm, open = st.openRow === r.strike;
      const wc = (r.ce.oi / maxOi * 100).toFixed(1), wp = (r.pe.oi / maxOi * 100).toFixed(1);
      body += `<tr data-k="${r.strike}" class="${isAtm ? 'atm ' : ''}${r.strike < cur.spot ? 'itm-ce' : 'itm-pe'}">
        <td class="oice ${r.strike === cur.res ? 'maxoi' : ''}" style="--w:${wc}%">${Q(r.ce.oi)}</td>
        <td class="chg ${zeroish(r, 0) ? 'zero' : cls(r.ce.doi)}">${sQ(r.ce.doi)}</td>
        <td class="${pj('ce', r)}${pickOf('ce', r) ? ' pick' + (pickOf('ce', r).main ? ' main' : '') : ''}">${tag('ce', r)}${f2(r.ce.ltp)}</td>
        <td class="s">${fmtK(r.strike)}</td>
        <td class="pe${pj('pe', r)}${pickOf('pe', r) ? ' pick' + (pickOf('pe', r).main ? ' main' : '') : ''}">${f2(r.pe.ltp)}${tag('pe', r)}</td>
        <td class="pe chg ${zeroish(r, 1) ? 'zero' : cls(r.pe.doi)}">${sQ(r.pe.doi)}</td>
        <td class="pe oipe ${r.strike === cur.sup ? 'maxoi' : ''}" style="--w:${wp}%">${Q(r.pe.oi)}</td></tr>`;
      if (open) body += detailRow(r);
    }
    if (!spotDone) body += spotRow(cur.spot);
    tbl.innerHTML = head + '<tbody>' + body + '</tbody>';
    const pb = $('pickBox');
    if (pb) {
      const m = picks.find(p => p.main), dirTxt = tone === 'up' ? 'Bullish' : tone === 'dn' ? 'Bearish' : 'Sideways';
      pb.innerHTML = !picks.length ? '' : m
        ? `<div class="pickb ${m.dir === 'up' ? 'up' : 'dn'}" data-goto="${m.strike}"><div class="pkh"><span>Market read: <b>${dirTxt}</b></span><span class="vj ${vjCls(m.verdict)}">${m.verdict}</span></div>
            <div class="pkm">${m.dir === 'up' ? '▲' : '▼'} Buy <b>${fmtK(m.strike)} ${m.side}</b> at or below <b>₹${f1(m.entryMax)}</b> <span class="dim">(now ₹${f2(m.ltp)})</span></div>
            <div class="pks num">Exit ₹${isFinite(m.target) ? f1(m.target) : '–'}${isFinite(m.tgtLevel) ? ` (${st.ui.index} ${fmtK(m.tgtLevel)})` : ''} · Stop ₹${f1(m.stop)}${isFinite(m.stopLevel) ? ` (${fmtK(m.stopLevel)} breaks)` : ''} · tap to find it</div></div>`
        : `<div class="pickb side"><div class="pkh"><span>Market read: <b>Sideways</b></span><span class="dim" style="font-size:11px">no buy now</span></div>
            <div class="pkm">Wait for a break. ${picks.map(p => `${p.dir === 'up' ? 'If it breaks ↑' : 'If it breaks ↓'}: <b>${fmtK(p.strike)} ${p.side}</b> ₹${f2(p.ltp)}`).join(' · ')}</div></div>`;
    }
    const cb = $('chkBox'); if (cb && !cb.contains(document.activeElement)) cb.innerHTML = checkerHtml();
    $('chainSub').innerHTML = subLine(d);
    if (st.scrolledFor !== key) {
      st.scrolledFor = key;
      const a = tbl.querySelector('tr.atm');
      if (a) setTimeout(() => { const y = a.getBoundingClientRect().top + window.scrollY - window.innerHeight / 2; window.scrollTo(0, Math.max(0, y)); }, 30);
    }
  }
  const subLine = d => `${srcLabel()} · updated ${C.istTime(d.cur.ts, true)} (${ago(d.cur.ts)}) · OI chg vs <b>${winLabel()}</b>`;
  function srcLabel() { const s = st.srcUsed[st.ui.index] || C.INDICES[st.ui.index].src; const o = st.oiSrc[st.ui.index];
    return isLive(s) ? `<b class="up">⚡ ${s} live</b>` + (o === 'none' ? ' · <b class="dn">no OI in feed</b>' : o ? ` · OI from ${o}` : '') : s; }
  function spotRow(spot) { return `<tr class="spot"><td colspan="7"><div class="sl"><span>Spot ${f2(spot)}</span></div></td></tr>`; }
  function buTag(b) { if (!b) return '<span class="bu" style="color:var(--muted);background:var(--panel2)">No clear buildup</span>'; return `<span class="bu ${/Long buildup|Short covering/.test(b) ? 'g' : 'r'}">${b}</span>`; }
  function detailRow(r) {
    const side = (sd, name) => {
      const x = r[sd];
      return `<div><h4 class="${sd}h">${name} ${fmtK(r.strike)}</h4>${buTag(x.bu)}
        <div class="kv"><span>OI</span><b>${Q(x.oi)}</b></div>
        <div class="kv"><span>OI chg</span><b class="${cls(x.doi)}">${sQ(x.doi)} (${sgn(x.doiPct, v => v.toFixed(1))}%)</b></div>
        <div class="kv"><span>LTP</span><b>${f2(x.ltp)}</b></div>
        <div class="kv"><span>LTP chg</span><b class="${cls(x.dltp)}">${sgn(x.dltp, f2)}</b></div>
        <div class="kv"><span>IV</span><b>${x.iv ? x.iv.toFixed(1) : '–'}</b></div>${(() => { const j = (st.chainJ || {})[sd + r.strike]; return j ? `<div class="kv"><span>To buy</span><b class="vj ${vjCls(j.verdict)}">${j.verdict}</b></div>
        <div class="kv"><span>Target / stop</span><b>₹${isFinite(j.target) ? f1(j.target) : '–'} / ₹${f1(j.stop)}</b></div><div class="jr">${j.reasons.slice(0, 2).join('. ')}.</div>` : ''; })()}</div>`;
    };
    const tb = sd => tradeBtn({ i: st.ui.index, k: r.strike, s: sd.toUpperCase(), t: 'B', iso: st.sel[st.ui.index], p: r[sd].ltp, why: 'from Chain' }, `🛒 Buy ${fmtK(r.strike)} ${sd.toUpperCase()}`);
    return `<tr class="detail"><td colspan="7"><div class="dgrid">${side('ce', 'CALL')}${side('pe', 'PUT')}</div><div class="dgrid" style="margin-top:6px">${tb('ce')}${tb('pe')}</div></td></tr>`;
  }
  const winLabel = () => (WINDOWS.find(w => w[0] === st.ui.win) || [])[1].replace(/^9:15$/, 'since 9:15').toLowerCase();
  function loadingMsg() {
    if (st.errors[st.ui.index]) return '';
    return st.busy || !st.lastOk ? `Fetching option chain from ${C.INDICES[st.ui.index].src}…` : 'No data for this expiry yet.';
  }

  function renderOI(d) {
    for (const b of $('oiToggle').children) b.classList.toggle('on', b.dataset.m === st.ui.oiMode);
    if (!d) { $('bf').innerHTML = `<div class="sub" style="grid-column:1/-1">${loadingMsg()}</div>`; $('lean').innerHTML = ''; $('leanNote').textContent = ''; return; }
    const { cur, rows } = d, m = st.ui.oiMode;
    const view = C.windowRows(rows, cur.spot, st.settings.strikes);
    const val = (r, sd) => (m === 'oi' ? r[sd].oi : r[sd].doi);
    let mx = 1; for (const r of view) mx = Math.max(mx, Math.abs(val(r, 'ce')), Math.abs(val(r, 'pe')));
    const atm = view[C.atmIndex(view, cur.spot)];
    let h = '';
    for (const r of view) {
      const c = val(r, 'ce'), p = val(r, 'pe');
      const kc = r === atm ? 'atm' : (r.strike === cur.mp ? 'mp' : '');
      h += `<div class="vl">${m === 'oi' ? Q(c) : sQ(c)}</div>
            <div class="l"><div class="bar ${c < 0 ? 'neg' : ''}" style="width:${(Math.abs(c) / mx * 100).toFixed(1)}%"></div></div>
            <div class="k ${kc}">${fmtK(r.strike)}</div>
            <div class="r"><div class="bar ${p < 0 ? 'neg' : ''}" style="width:${(Math.abs(p) / mx * 100).toFixed(1)}%"></div></div>
            <div class="vr">${m === 'oi' ? Q(p) : sQ(p)}</div>`;
    }
    $('bf').innerHTML = h;
    let dce = 0, dpe = 0; for (const r of view) { dce += r.ce.doi; dpe += r.pe.doi; }
    $('lean').innerHTML = `<div><div class="k">Call OI chg near ATM</div><div class="v num" style="color:var(--ce)">${sQ(dce)}</div></div>
                           <div><div class="k">Put OI chg near ATM</div><div class="v num" style="color:var(--pe)">${sQ(dpe)}</div></div>`;
    $('leanNote').innerHTML = (dce === 0 && dpe === 0) ? '' :
      (dpe > dce ? 'Put writers more active than call writers: supportive / bullish tilt.' : 'Call writers more active than put writers: capping / bearish tilt.')
      + ` Change vs ${winLabel()}. ${m === 'doi' ? 'Hollow bars = OI reduced.' : 'Blue = ATM, amber outline = max pain.'}`;
  }

  // ------- trend charts (hand-drawn SVG)
  function lineChart(series, opt) {
    const W = 360, H = opt.h || 170, pl = 46, pr = 8, pt = 10, pb = 20;
    const xs = series[0].pts.map(p => p.t);
    if (xs.length < 2) return '';
    const t0 = xs[0], t1 = xs[xs.length - 1] || t0 + 1;
    let lo = Infinity, hi = -Infinity;
    for (const s of series) for (const p of s.pts) if (isFinite(p.v)) { lo = Math.min(lo, p.v); hi = Math.max(hi, p.v); }
    (opt.bands || []).forEach(b => { lo = Math.min(lo, b.v); hi = Math.max(hi, b.v); });
    if (!isFinite(lo)) return '';
    if (hi - lo < 1e-9) { hi += 1; lo -= 1; }
    const padv = (hi - lo) * 0.08; lo -= padv; hi += padv;
    const X = t => pl + (t - t0) / (t1 - t0 || 1) * (W - pl - pr);
    const Y = v => pt + (1 - (v - lo) / (hi - lo)) * (H - pt - pb);
    let g = '';
    for (let i = 0; i <= 3; i++) {
      const v = lo + (hi - lo) * i / 3, y = Y(v).toFixed(1);
      g += `<line x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}" stroke="#262D37" stroke-width="1"/><text x="${pl - 6}" y="${+y + 3}" text-anchor="end">${opt.fmt(v)}</text>`;
    }
    for (const b of (opt.bands || [])) g += `<line x1="${pl}" x2="${W - pr}" y1="${Y(b.v).toFixed(1)}" y2="${Y(b.v).toFixed(1)}" stroke="${b.c}" stroke-dasharray="4 4" stroke-width="1.2"/>`;
    const tl = [t0, (t0 + t1) / 2, t1];
    tl.forEach((t, i) => { g += `<text x="${X(t).toFixed(1)}" y="${H - 5}" text-anchor="${['start', 'middle', 'end'][i]}">${C.istTime(t)}</text>`; });
    for (const s of series) {
      const d = s.pts.filter(p => isFinite(p.v)).map((p, i) => `${i ? 'L' : 'M'}${X(p.t).toFixed(1)},${Y(p.v).toFixed(1)}`).join('');
      g += `<path d="${d}" fill="none" stroke="${s.c}" stroke-width="${s.w || 2}" ${s.dash ? 'stroke-dasharray="5 4"' : ''} stroke-linejoin="round" stroke-linecap="round"/>`;
    }
    const keys = series.map(s => `<span><i style="background:${s.c}"></i>${s.n}</span>`).join('');
    return `<svg class="chart" viewBox="0 0 ${W} ${H}">${g}</svg><div class="keys">${keys}</div>`;
  }
  function renderTrends(d) {
    const el = $('trends');
    if (!d || d.series.length < 2) { el.innerHTML = `<div class="empty">Trends appear after a few updates.<br>History builds up through the day.</div>`; return; }
    const s = d.series, pts = f => s.map(x => ({ t: x.ts, v: f(x) }));
    const S = st.settings;
    el.innerHTML =
      `<div class="card"><h3>Near-ATM OI change</h3><div class="cap">ATM ±5 strikes total, the hero-zero input. A side falling toward zero = writers exiting.</div>${lineChart(
        [{ n: 'CE OI chg', c: '#F2555A', pts: pts(x => x.nce) }, { n: 'PE OI chg', c: '#2FB37A', pts: pts(x => x.npe) }],
        { fmt: Q, bands: [{ v: 0, c: '#5D6674' }] })}</div>` +
      `<div class="card"><h3>PCR</h3><div class="cap">Put OI ÷ Call OI · dashed lines = your alert levels</div>${lineChart(
        [{ n: 'PCR', c: '#4C7DFF', pts: pts(x => x.pcr) }],
        { fmt: v => v.toFixed(2), bands: [{ v: S.pcrHigh, c: '#2FB37A' }, { v: S.pcrLow, c: '#F2555A' }] })}</div>` +
      `<div class="card"><h3>Spot vs key levels</h3><div class="cap">Where OI says the floor and ceiling are</div>${lineChart(
        [{ n: 'Spot', c: '#E6EAF0', pts: pts(x => x.spot), w: 2.2 },
         { n: 'Resistance', c: '#F2555A', pts: pts(x => x.res), w: 1.6 },
         { n: 'Support', c: '#2FB37A', pts: pts(x => x.sup), w: 1.6 },
         { n: 'Max pain', c: '#F5A524', pts: pts(x => x.mp), w: 1.6, dash: 1 }],
        { fmt: v => Math.round(v).toLocaleString('en-IN'), h: 200 })}</div>` + futTrends();
  }
  function futTrends() {
    const s = st.fut.series;
    if (s.length < 2) return '';
    const pts = f => s.map(x => ({ t: x.ts, v: f(x) }));
    const vxs = st.vix.series, ivS = st.iv.SENSEX || [];
    const vixChart = vxs.length > 1 ? `<div class="card"><h3>India VIX &amp; SENSEX IV</h3><div class="cap">Rising = fear and premiums rising; falling = premiums melting</div>${lineChart(
        [{ n: 'India VIX', c: '#F2555A', pts: vxs.map(x => ({ t: x.ts, v: x.v })), w: 2.2 }].concat(ivS.length > 1 ? [{ n: 'SENSEX ATM IV', c: '#4C7DFF', pts: ivS.map(x => ({ t: x.ts, v: x.v })), w: 1.6 }] : []),
        { fmt: v => v.toFixed(1) })}</div>` : '';
    return vixChart + `<div class="card"><h3>NIFTY futures vs spot</h3><div class="cap">Futures above spot and widening = buyers in control</div>${lineChart(
        [{ n: 'Futures', c: '#4C7DFF', pts: pts(x => x.ltp), w: 2.2 }, { n: 'Spot', c: '#E6EAF0', pts: pts(x => x.spot), w: 1.6 }],
        { fmt: v => Math.round(v).toLocaleString('en-IN') })}</div>` +
      `<div class="card"><h3>NIFTY futures OI</h3><div class="cap">Rising OI + rising price = long buildup; rising OI + falling price = short buildup</div>${lineChart(
        [{ n: 'Futures OI', c: '#F5A524', pts: pts(x => x.oi) }], { fmt: Q })}</div>`;
  }

  // =====================================================================================
  // RECORD SCREENS (Daily tab sub-tabs) + strike ideas
  // =====================================================================================
  function ideaRows(a, n, lbl) {
    return a.list.slice(0, n).map((x, i) => `<div class="idea ${i === 0 ? 'best' : ''}">
      <div class="ih"><b>${fmtK(x.strike)} ${x.side}</b>${i === 0 ? `<span class="ib">${lbl || 'Best pick'}</span>` : ''}<span class="iv2">₹${f2(x.ltp)}</span></div>
      <div class="ig num">
        <div><span>IV</span><b>${isFinite(x.iv) ? (x.iv * 100).toFixed(1) + '%' : '–'}</b></div>
        <div><span>Delta</span><b>${x.delta.toFixed(2)}</b></div>
        <div><span>Decay/${x.thetaUnit}</span><b class="dn">₹${Math.abs(x.theta).toFixed(1)}</b><i>${isFinite(x.thetaPct) ? x.thetaPct.toFixed(1) + '%' : ''}</i></div>
        <div><span>Day H / L</span><b>${isFinite(x.hi) ? f1(x.hi) + ' / ' + f1(x.lo) : '–'}</b></div>
      </div>
      ${isFinite(x.est) ? `<div class="it">If ${fmtK(a.target)} comes: <b>₹${f1(x.est)}</b> <span class="${x.mult >= 1 ? 'up' : 'dn'}">(${x.mult.toFixed(1)}x)</span>${isFinite(a.reach) ? ` · chance today ${pctTxt(a.reach)}` : ''}</div>` : ''}
    </div>`).join('');
  }
  function ideasHtml(index, tone) {
    if (!tone) {
      const up = strikeIdeas(index, 'up'), dn = strikeIdeas(index, 'dn');
      if (!up || !up.list.length) return '';
      return `<div class="ideas"><div class="ph"><b>Strike to buy</b><span class="dim" style="font-size:11px">sideways: wait for a break</span></div>
        <div class="pmsg">No clear direction, so no buy now. If spot breaks out, these are the best strikes:</div>
        ${ideaRows(up, 1, 'If it breaks up')}${dn && dn.list.length ? ideaRows(dn, 1, 'If it breaks down') : ''}</div>`;
    }
    const a = strikeIdeas(index, tone); if (!a || !a.list.length) return '';
    return `<div class="ideas"><div class="ph"><b>Strike to buy · ${a.side}</b><span class="dim" style="font-size:11px">expiry ${fmtExp(a.iso)} · ATM IV ${isFinite(a.atmIv) ? (a.atmIv * 100).toFixed(1) + '%' : '–'}</span></div>
      ${ideaRows(a, 3)}
      <div class="pnote">Ranked on delta (0.25–0.55 best), time decay as % of premium, IV vs ATM (avoid costly strikes), OI liquidity, payoff if spot reaches ${fmtK(a.target)} (${a.side === 'CE' ? 'resistance' : 'support'}), and price vs today's high/low. Decay is per hour on expiry day. Guide only.</div></div>`;
  }

  function dailyTabs() {
    const t = st.ui.dtab || 'plan';
    return `<div class="dtabs">${[['plan', 'Plan'], ['data', 'Data / Audit'], ['call', 'Morning call'], ['acc', 'Accuracy'], ['hero', 'Hero log'], ['journal', 'Journal']].map(([k, n]) => `<button class="${t === k ? 'on' : ''}" data-dt="${k}">${n}</button>`).join('')}</div>`;
  }
  const pctS = v => isFinite(v) ? `<b class="${cls(v)}">${v >= 0 ? '+' : '−'}${Math.abs(v).toFixed(2)}%</b>` : '<span class="dim">–</span>';

  function callView() {
    const today = C.istDate(Date.now()), calls = REC.calls(), day = calls[today] || {};
    const g = st.glob ? st.glob.q : {};
    const inv = { usVix: 1, indiaVix: 1, crude: 1, dxy: 1, inr: 1 };     // rising = bad for Indian market → red
    const gl = GLOBAL.filter(x => x[0] !== 'NIFTY' && x[0] !== 'SENSEX').map(([k, , n]) => `<div class="gr"><span>${n}</span><span class="num">${g[k] ? f2(g[k].price) : '–'}</span>${inv[k] && g[k] && isFinite(g[k].pct) ? `<b class="${cls(-g[k].pct)}">${g[k].pct >= 0 ? '+' : '−'}${Math.abs(g[k].pct).toFixed(2)}%</b>` : pctS(g[k] && g[k].pct)}</div>`).join('');
    const gift = giftGet(), fl = futLast();
    const callCard = index => {
      const c = day[index];
      const live = c ? null : morningFor(index);
      const x = c || live;
      if (!x || !x.factors.length) return `<div class="card"><h3>${index}</h3><div class="hzmsg">Waiting for overseas data / GIFT Nifty.</div></div>`;
      const res = c && c.grade ? `<div class="grade ${c.grade === 'Right' ? 'ok' : 'bad'}">${c.grade === 'Right' ? '✓ Call was right' : '✗ Call was wrong'} · closed ${f2(c.close)} (${pctS(c.chgPct)})</div>` : '';
      const rec = c && c.rec ? `<div class="pbuy ${c.rec.side === 'CE' ? 'ce' : 'pe'}"><div><div class="pk">Strike idea at lock</div><div class="pv">${fmtK(c.rec.strike)} ${c.rec.side}</div></div><div><div class="pk">At lock</div><div class="pv">₹${f2(c.rec.ltp)}</div></div>${isFinite(c.rec.hi) ? `<div><div class="pk">Day high</div><div class="pv up">₹${f2(c.rec.hi)}</div></div>` : ''}${isFinite(c.rec.close) ? `<div><div class="pk">Close</div><div class="pv">₹${f2(c.rec.close)}</div></div>` : ''}</div>` : '';
      return `<div class="card pred">
        <div class="fhead"><h3>${index}</h3><span class="pl ${x.tone === 'up' ? 'bull' : x.tone === 'dn' ? 'bear' : ''}">${x.label}</span></div>
        <div class="hzmsg">${c ? `🔒 Locked ${C.istTime(c.ts)}${c.late ? ' (late)' : ''} · ${c.conf} confidence · prev close ${f2(c.prevClose)}` : `Live read (not locked) · ${x.conf} confidence`}</div>
        ${res}
        ${(() => { const rg = c ? c.range : (() => { const pc = prevCloseFor(index), vf = volFor(index); return pc > 0 && vf ? [pc - pc * vf.vol / 100 / Math.sqrt(252), pc + pc * vf.vol / 100 / Math.sqrt(252)] : null; })();
          return rg ? `<div class="zverdict">Expected range today (${c ? (c.volSrc || 'India VIX') + ' ' + f1(c.vol) : (volFor(index) || {}).src || 'VIX'}): <b>${fmtK(rg[0])} – ${fmtK(rg[1])}</b>${c && c.inRange ? ` · close was <b class="${c.inRange === 'Inside' ? 'up' : 'dn'}">${c.inRange.toLowerCase()}</b>` : ''}</div>` : ''; })()}
        ${x.risk ? `<div class="hzconf bad">⚠️ ${x.risk}</div>` : ''}
        <div class="flist">${x.factors.map(f => `<div class="fr"><span class="fi ${f.val > 0.15 ? 'up' : f.val < -0.15 ? 'dn' : ''}">${f.val > 0.15 ? '▲' : f.val < -0.15 ? '▼' : '●'}</span><span>${f.txt}</span></div>`).join('')}</div>
        ${rec}${!c && x.tone ? ideasHtml(index, x.tone) : ''}
      </div>`;
    };
    // scorecard
    const all = []; for (const d of Object.keys(calls).sort().reverse()) for (const index of Object.keys(calls[d]).filter(k => k !== 'VIX')) all.push(Object.assign({ d, index }, calls[d][index]));
    const graded = all.filter(c => c.grade), right = graded.filter(c => c.grade === 'Right').length;
    const byConf = ['High', 'Medium', 'Low'].map(k => { const g2 = graded.filter(c => c.conf === k); return g2.length ? `${k}: ${Math.round(g2.filter(c => c.grade === 'Right').length / g2.length * 100)}% (${g2.length})` : ''; }).filter(Boolean).join(' · ');
    const score = `<div class="card"><div class="fhead"><h3>Scorecard</h3></div>
      ${graded.length ? `<div class="sgrid num"><div><div class="k">Hit rate</div><div class="v ${right / graded.length >= 0.5 ? 'up' : 'dn'}">${Math.round(right / graded.length * 100)}%</div></div><div><div class="k">Right</div><div class="v">${right} / ${graded.length}</div></div><div><div class="k">Days</div><div class="v">${Object.keys(calls).length}</div></div></div><div class="hzcap">${byConf}</div>${(() => {
        const vb = ['Very calm', 'Normal', 'Nervous', 'Fear'].map(b => { const g2 = graded.filter(c => C.vixBand(c.vix) === b); return g2.length ? `${b}: ${Math.round(g2.filter(c => c.grade === 'Right').length / g2.length * 100)}% (${g2.length})` : ''; }).filter(Boolean).join(' · ');
        const rg = all.filter(c => c.inRange), vo = Object.keys(calls).map(d => calls[d].VIX).filter(v => v && v.grade);
        return (vb ? `<div class="hzcap">By India VIX · ${vb}</div>` : '') + (rg.length ? `<div class="hzcap">Close inside VIX range: ${Math.round(rg.filter(c => c.inRange === 'Inside').length / rg.length * 100)}% (${rg.length})</div>` : '') +
          (vo.length ? `<div class="hzcap">VIX outlook right: ${Math.round(vo.filter(v => v.grade === 'Right').length / vo.length * 100)}% (${vo.length})</div>` : ''); })()}` : '<div class="hzmsg">Calls are graded at 3:31 PM against the close. Results build up here day by day.</div>'}
      <div class="tbl">${all.slice(0, 30).map(c => `<div class="tr"><span>${c.d.slice(5)} ${c.index === 'NIFTY' ? 'NF' : 'SX'}</span><span class="${c.tone === 'up' ? 'up' : c.tone === 'dn' ? 'dn' : ''}">${c.label.replace('Flat / sideways', 'Flat')}</span><span>${isFinite(c.chgPct) ? pctS(c.chgPct) : '<span class="dim">open</span>'}</span><span>${c.grade ? (c.grade === 'Right' ? '<b class="up">✓</b>' : '<b class="dn">✗</b>') : ''}</span></div>`).join('')}</div>
    </div>`;
    return `<div class="card">
        <div class="fhead"><h3>Overseas markets</h3><button class="chip" id="globRefresh">Refresh</button></div>
        <div class="glist">${gl}</div>
        <div class="gr"><span>GIFT Nifty (${gift ? (gift.src === 'auto' ? 'auto, NSE' : 'typed') : 'NSE'})</span><span class="num">${gift ? f2(gift.v) : '–'}</span>${gift && fl ? pctS((gift.v - fl.ltp) / fl.ltp * 100) : '<span class="dim">loading</span>'}</div>
        <div class="hzcap">${st.glob ? 'Updated ' + C.istTime(st.glob.at) + ' IST · Yahoo Finance' : st.globErr || 'Loading…'}. % = change vs previous close.</div>
      </div>
      ${vixCardHtml(true)}
      ${callCard('NIFTY')}${callCard('SENSEX')}
      ${!(day.NIFTY && day.SENSEX) ? `<div style="padding:0 8px 10px"><button class="btn" id="lockCall">🔒 Lock today's call now</button><div class="help" style="padding:0 8px">Locks automatically at 9:00 AM (later if the app was not running, marked late). Results are graded at the close and saved to Downloads by themselves. Calls locked after 9:15 are marked late.</div></div>` : ''}
      ${score}${auditCard(['calls', 'score', 'vix', 'hero'])}`;
  }

  function heroView() {
    const log = REC.hero().slice().reverse(), today = C.istDate(Date.now());
    const n = log.length, first = log.filter(e => e.targets[0] && e.targets[0].hitTs).length, two = log.filter(e => e.targets.some(t => t.lbl === '2x' && t.hitTs)).length;
    const card = e => `<div class="hl ${e.side === 'CE' ? 'ce' : 'pe'}">
      <div class="hlh"><b>${fmtK(e.strike)} ${e.side}</b><span class="dim">${e.index} · ${e.src}</span><span class="hlx ${e.peak / e.entry >= 2 ? 'up' : ''}">${(e.peak / e.entry).toFixed(1)}x peak</span></div>
      ${isFinite(e.vol) ? `<div class="hlm dim">${e.index === 'NIFTY' ? 'India VIX' : 'Vol'} ${f1(e.vol)} at prediction · reach chance ${pctTxt(e.reach)}${isFinite(e.volTrend) ? ` · vol since 1 PM ${sgn(e.volTrend, x => x.toFixed(1))}%` : ''}</div>` : ''}
      <div class="hlm">Predicted <b>${e.day === today ? '' : e.day.slice(5) + ' '}${C.istTime(e.entryTs)}</b> at ₹${f2(e.entry)} (spot ${fmtK(e.spot0)})${isFinite(e.last) && !e.done ? ` · now ₹${f2(e.last)}` : ''}${e.done ? ` · closed ₹${f2(e.close)}` : ''}</div>
      <div class="hlt">${e.targets.map(t => `<span class="tg ${t.hitTs ? 'hit' : ''}">${t.lbl} ₹${f1(t.price)}${t.hitTs ? ` ✓ ${C.istTime(t.hitTs)} @ ₹${f1(t.hitLtp)}` : ''}</span>`).join('')}</div>
      <div class="hlm dim">Peak ₹${f2(e.peak)} at ${C.istTime(e.peakTs)}</div>${heroRuleHtml(e)}</div>`;
    const sims = log.map(heroRuleSim).filter(Boolean), tot = sims.reduce((a, x) => a + x.pnl, 0);
    const simCard = sims.length ? `<div class="card"><h3>With Hero-zero Safe rules</h3><div class="hzmsg">Budget ₹${fmtK(st.settings.hzBudget)} per pick, half sold at 2×, rest trailed 30%, −50% loss cap: <b class="${cls(tot)}">${tot >= 0 ? '+' : '−'}₹${fmtK(Math.abs(tot))}</b> over ${sims.length} picks (${sims.filter(x => x.pnl > 0).length} won, ${sims.filter(x => x.pnl <= 0).length} lost).</div><div class="hzcap">Estimate from each pick's recorded peak and close; the real result depends on your exact exits. Charges not included.</div></div>` : '';
    return `${simCard}<div class="card"><div class="fhead"><h3>Hero-zero outcome log</h3><button class="chip" data-dl="hero">⬇ Download</button></div>
      ${n ? `<div class="sgrid num"><div><div class="k">Predictions</div><div class="v">${n}</div></div><div><div class="k">Hit 1st target</div><div class="v up">${Math.round(first / n * 100)}%</div></div><div><div class="k">Doubled</div><div class="v up">${Math.round(two / n * 100)}%</div></div></div>` : ''}
      <div class="hzcap">Every strike the app suggests on expiry day (Hero signal picks and the Hero plan "strike to watch") is recorded with the time and price. When it reaches the predicted price, 2x, 3x or 5x, the time and price are stamped and you get an alert.</div></div>
      ${auditCard(['hero', 'calls', 'score'])}
      ${n ? log.slice(0, 60).map(card).join('') : '<div class="empty">No hero-zero predictions recorded yet.<br>They start on expiry day after ' + hhmm(st.settings.heroStart) + '.</div>'}`;
  }

  /** what a hero pick would have made with the Safe rules and the budget (estimate from peak and close) */
  function heroRuleSim(e) {
    if (!(e.entry > 0) || !e.done) return null;
    const lot = LOT[e.index] || 1, lots = Math.floor(st.settings.hzBudget / (e.entry * lot)); if (lots < 1) return { lots: 0, pnl: 0, txt: `Budget too small for 1 lot (₹${fmtK(e.entry * lot)})` };
    const q = lots * lot, pk = e.peak || e.entry, cl = isFinite(e.close) ? e.close : 0;
    if (pk >= e.entry * 2) { const rest = cl >= pk * 0.7 ? cl : pk * 0.7, pnl = q / 2 * e.entry * 2 + q / 2 * rest - q * e.entry;
      return { lots, pnl, txt: `Doubled: half sold at ₹${f1(e.entry * 2)}, rest out at ~₹${f1(rest)}` }; }
    const out = Math.max(e.entry * 0.5, Math.min(cl, e.entry)), pnl = (out - e.entry) * q;
    return { lots, pnl, txt: out <= e.entry * 0.5 ? 'Loss cap (−50%)' : 'Time stop / exit' };
  }
  function heroRuleHtml(e) {
    const r = heroRuleSim(e); if (!r) return '';
    return `<div class="hlm">🛡 Safe rules${r.lots ? ` (${r.lots} lot${r.lots > 1 ? 's' : ''})` : ''}: ${r.txt}${r.lots ? ` · <b class="${cls(r.pnl)}">${r.pnl >= 0 ? '+' : '−'}₹${fmtK(Math.abs(r.pnl))}</b>` : ''}</div>`;
  }
  const REASONS = ['Hero-zero', 'S/R break', 'Reversal', 'Morning call', 'Futures', 'OI shift', 'Other'];
  const MOODS = ['Calm', 'Confident', 'FOMO', 'Revenge', 'Unsure'];
  /** Accuracy tab: every trade plan the alerts suggested, and whether it hit target or stop-loss first */
  function accView() {
    const per = st.ui.accPer || '30';
    const all = REC.plans(), now = Date.now(), today = C.istDate(now);
    const sf = st.ui.accSafe || 'safe';
    const list = all.filter(x => per === 'all' ? true : per === 'today' ? x.day === today : now - x.ts <= (+per) * 86400e3)
      .filter(x => sf === 'all' ? true : sf === 'safe' ? x.safe === true : sf === 'blocked' ? x.safe === false : x.hero);
    const S = planStats(list);
    const pc = v => isFinite(v) ? Math.round(v) + '%' : '–';
    const rateCls = (st_, min) => st_.n < min ? 'dim' : st_.tPct >= 55 ? 'up' : st_.tPct < 35 ? 'dn' : 'am';
    const group = (keyFn, nameFn) => { const g = {}; for (const x of list) (g[keyFn(x)] = g[keyFn(x)] || []).push(x);
      return Object.entries(g).map(([k, v]) => ({ k, name: nameFn(k, v), s: planStats(v) })).filter(r => r.s.n + r.s.open > 0).sort((a, b) => b.s.n - a.s.n); };
    const table = (rows, head) => rows.length ? `<table class="acct"><tr><th>${head}</th><th>Plans</th><th>Target</th><th>Stop</th><th>Avg</th></tr>${rows.map(r =>
      `<tr><td>${esc(r.name)}</td><td class="num">${r.s.n}${r.s.open ? `<span class="dim"> +${r.s.open}</span>` : ''}</td><td class="num ${rateCls(r.s, 5)}">${pc(r.s.tPct)}</td><td class="num">${pc(r.s.sPct)}</td><td class="num ${cls(r.s.avg)}">${isFinite(r.s.avg) ? (r.s.avg >= 0 ? '+' : '') + r.s.avg.toFixed(0) + '%' : '–'}</td></tr>`).join('')}</table>` : '<div class="hzmsg dim">Nothing yet.</div>';
    const byType = group(x => x.type, (k, v) => (ALERT[k] || {}).name || v[0].kind);
    const byVerdict = group(x => x.verdict || '–', k => k);
    const band = c => c === null ? 'No estimate' : c < 0.3 ? 'Under 30%' : c < 0.5 ? '30–49%' : c < 0.7 ? '50–69%' : '70% +';
    const byChance = group(x => band(x.chance), k => k).map(r => { const v = list.filter(x => band(x.chance) === r.k && x.chance !== null && x.res !== 'open' && x.res !== 'nodata');
      r.pred = v.length ? v.reduce((a, x) => a + x.chance, 0) / v.length * 100 : NaN; return r; })
      .sort((a, b) => ['Under 30%', '30–49%', '50–69%', '70% +', 'No estimate'].indexOf(a.k) - ['Under 30%', '30–49%', '50–69%', '70% +', 'No estimate'].indexOf(b.k));
    const chanceTbl = byChance.length ? `<table class="acct"><tr><th>App said</th><th>Plans</th><th>Avg said</th><th>Actually hit</th></tr>${byChance.map(r =>
      `<tr><td>${r.name}</td><td class="num">${r.s.n}</td><td class="num">${pc(r.pred)}</td><td class="num ${r.s.n >= 5 ? (Math.abs(r.s.tPct - r.pred) <= 12 ? 'up' : 'dn') : 'dim'}">${pc(r.s.tPct)}</td></tr>`).join('')}</table>` : '';
    const chip = x => ({ be: '<span class="acc n">= Breakeven</span>', target: '<span class="acc t">✓ Target</span>', stop: '<span class="acc s">✗ Stop</span>', neither: '<span class="acc n">– Neither</span>', open: '<span class="acc o">● Open</span>', nodata: '<span class="acc n">No data</span>' })[x.res];
    const recent = list.slice().sort((a, b) => b.ts - a.ts).slice(0, 25).map(x => { const pct = planPct(x);
      return `<div class="accr"><div class="accrh"><b>${x.index} ${fmtK(x.strike)} ${x.side}</b>${chip(x)}<span class="num ${cls(pct)}">${isFinite(pct) ? (pct >= 0 ? '+' : '') + pct.toFixed(0) + '%' : ''}</span></div>
        <div class="accrm">${x.day === today ? '' : x.day.slice(5) + ' '}${C.istTime(x.ts)} · ${esc(x.kind)}${x.also.length ? ' +' + x.also.length : ''} · ${x.verdict} · ₹${f1(x.entry)} → target ${x.target ? '₹' + f1(x.target) : '–'} / stop ₹${f1(x.stop)}${x.resTs ? ` · ${minsBetween(x.ts, x.resTs)} min` : ''} · high ₹${f1(x.hi)}${x.chance !== null ? ` · said ${Math.round(x.chance * 100)}%` : ''}</div></div>`; }).join('');
    return `<div class="card"><div class="fhead"><h3>Alert accuracy</h3><span class="dim" style="font-size:11px">target vs stop-loss</span></div>
      <div class="toggle">${[['safe', 'Safe passes'], ['blocked', 'Blocked'], ['hero', 'Hero-zero'], ['all', 'Every plan']].map(([k, n]) => `<button class="chip ${sf === k ? 'on' : ''}" data-as="${k}">${n}</button>`).join('')}</div>
      <div class="toggle" id="accPer">${[['today', 'Today'], ['7', '7 days'], ['30', '30 days'], ['all', 'All']].map(([k, n]) => `<button class="chip ${per === k ? 'on' : ''}" data-ap="${k}">${n}</button>`).join('')}</div>
      <div class="accsum"><div><span>Plans</span><b>${S.n}</b>${S.open ? `<i>${S.open} open</i>` : ''}</div><div><span>Target hit</span><b class="${rateCls(S, 10)}">${pc(S.tPct)}</b><i>${S.t}</i></div>
        <div><span>Stop hit</span><b>${pc(S.sPct)}</b><i>${S.sl}</i></div><div><span>Avg result</span><b class="${cls(S.avg)}">${isFinite(S.avg) ? (S.avg >= 0 ? '+' : '') + S.avg.toFixed(0) + '%' : '–'}</b><i>${S.nei} neither</i></div></div>
      <div class="hzmsg">${S.n ? `If you had bought 1 lot of every plan: <b class="${cls(S.rs)}">${S.rs >= 0 ? '+' : '−'}₹${fmtK(Math.abs(S.rs))}</b> (before charges).` : 'Every alert that suggests a strike is now tracked: target hit, stop-loss hit, or neither by 3:25 PM. Results build up from the next market day.'}</div>
      ${sf === 'blocked' && S.n ? `<div class="hzcap">These are trades Safe mode said NOT to take. If they mostly lost, Safe mode saved you that money.</div>` : ''}
      ${S.n && S.n < 30 ? '<div class="hzcap">Small sample. Judge a rule only after 20–30 plans; a few days can be lucky or unlucky.</div>' : ''}</div>
    <div class="card"><h3>By alert type</h3>${table(byType, 'Alert')}<div class="hzcap">Green: target hit 55%+ · amber: 35–55% · red: under 35%. Grey until 5 plans. "+n" = still open.</div></div>
    <div class="card"><h3>Is the premium judge right?</h3>${table(byVerdict, 'Verdict')}<div class="hzcap">"Good buy" should beat "Fair", and "Expensive" should do worst. If not, the judge needs re-tuning.</div></div>
    <div class="card"><h3>Is the "chance" figure honest?</h3>${chanceTbl || '<div class="hzmsg dim">Nothing yet.</div>'}<div class="hzcap">If the app says 60% and targets hit about 60% of the time, the number can be trusted. Green: within 12 points.</div></div>
    <div class="card"><h3>Recent plans</h3>${recent || '<div class="hzmsg dim">No plans yet.</div>'}</div>
    ${auditCard(['plans', 'alerts', 'hero'])}`;
  }
  function journalView() {
    const list = REC.trades(), today = C.istDate(Date.now()), month = today.slice(0, 7);
    const sToday = journalStats(list.filter(t => C.istDate(t.ts) === today)), sMonth = journalStats(list.filter(t => C.istDate(t.ts).startsWith(month))), sAll = journalStats(list);
    const j = st.jform = st.jform || { index: st.ui.index, side: 'CE', reasons: [], mood: '' };
    const rupee = v => isFinite(v) ? `<b class="${cls(v)}">${v < 0 ? '−' : ''}₹${Math.abs(Math.round(v)).toLocaleString('en-IN')}</b>` : '<span class="dim">–</span>';
    const by = REASONS.map(r => { const s = journalStats(list.filter(t => (t.reasons || []).includes(r))); return s.n ? `<div class="tr"><span>${r}</span><span>${s.n} trades</span><span>${Math.round(s.win)}% win</span><span>${rupee(s.pnl)}</span></div>` : ''; }).join('');
    const form = `<div class="card"><h3>Add a trade</h3>
      <div class="jrow"><div class="seg2" data-jf="index">${['NIFTY', 'SENSEX'].map(x => `<button class="${j.index === x ? 'on' : ''}" data-v="${x}">${x}</button>`).join('')}</div>
        <div class="seg2" data-jf="side">${['CE', 'PE'].map(x => `<button class="${j.side === x ? 'on ' + x.toLowerCase() : ''}" data-v="${x}">${x}</button>`).join('')}</div></div>
      <div class="grid3">
        <div class="field"><label>Strike</label><input id="jStrike" type="number" inputmode="numeric" value="${j.strike || ''}"></div>
        <div class="field"><label>Buy ₹</label><input id="jBuy" type="number" step="0.05" inputmode="decimal" value="${j.buy || ''}"></div>
        <div class="field"><label>Sell ₹ (optional)</label><input id="jSell" type="number" step="0.05" inputmode="decimal" value="${j.sell || ''}"></div>
        <div class="field"><label>Lots</label><input id="jLots" type="number" inputmode="numeric" value="${j.lots || 1}"></div>
        <div class="field"><label>Lot size</label><input id="jLot" type="number" inputmode="numeric" value="${j.lotSize || LOT[j.index]}"></div>
      </div>
      <div class="field"><label>Why did you take it?</label><div class="chipset" data-jf="reasons">${REASONS.map(r => `<button class="chip ${j.reasons.includes(r) ? 'on' : ''}" data-v="${r}">${r}</button>`).join('')}</div></div>
      <div class="field"><label>Mood</label><div class="chipset" data-jf="mood">${MOODS.map(r => `<button class="chip ${j.mood === r ? 'on' : ''}" data-v="${r}">${r}</button>`).join('')}</div></div>
      <div class="field"><label>Note</label><input id="jNote" placeholder="e.g. entered after resistance shift alert" value="${esc(j.note || '')}"></div>
      <button class="btn" id="jSave">Save trade</button>
      <div class="hzcap">The app also saves the market picture at entry: PCR, futures buildup and hero-zero state.</div></div>`;
    const item = (t, i) => { const pnl = tradePnl(t); return `<div class="jt">
      <div class="jth"><b>${t.index} ${fmtK(t.strike)} ${t.side}</b><span class="dim">${C.istDate(t.ts).slice(5)} ${C.istTime(t.ts)}</span>${rupee(pnl)}</div>
      <div class="jtm">Buy ₹${f2(t.buy)} → ${isFinite(t.sell) ? 'Sell ₹' + f2(t.sell) : '<b class="amber">open</b>'} · ${t.lots} lot × ${t.lotSize}${t.reasons && t.reasons.length ? ' · ' + t.reasons.join(', ') : ''}${t.mood ? ' · ' + t.mood : ''}</div>
      ${t.ctx ? `<div class="jtm dim">At entry: PCR ${isFinite(t.ctx.pcr) ? t.ctx.pcr.toFixed(2) : '–'} · Futures ${t.ctx.fut || '–'} · Hero ${t.ctx.hero || '–'}</div>` : ''}
      ${t.note ? `<div class="jtm">📝 ${esc(t.note)}</div>` : ''}
      <div class="jta">${!isFinite(t.sell) ? `<input type="number" step="0.05" inputmode="decimal" placeholder="Exit ₹" data-exit="${t.id}"><button class="chip" data-close="${t.id}">Close</button>` : ''}<button class="chip" data-del="${t.id}">Delete</button></div>
    </div>`; };
    return `<div class="card"><div class="fhead"><h3>Trade journal</h3><button class="chip" data-dl="trades">⬇ Download</button></div>
      <div class="sgrid num"><div><div class="k">Today</div><div class="v">${rupee(sToday.pnl)}</div><div class="d">${sToday.n} closed${sToday.open ? ' · ' + sToday.open + ' open' : ''}</div></div>
        <div><div class="k">This month</div><div class="v">${rupee(sMonth.pnl)}</div><div class="d">${sMonth.n} trades</div></div>
        <div><div class="k">Win rate</div><div class="v">${isFinite(sAll.win) ? Math.round(sAll.win) + '%' : '–'}</div><div class="d">avg W ${isFinite(sAll.avgW) ? '₹' + Math.round(sAll.avgW).toLocaleString('en-IN') : '–'} · L ${isFinite(sAll.avgL) ? '₹' + Math.round(-sAll.avgL).toLocaleString('en-IN') : '–'}</div></div></div>
      ${by ? `<div class="hzcap" style="margin-top:8px">By reason</div><div class="tbl">${by}</div>` : ''}</div>
      ${form}
      ${list.slice().reverse().slice(0, 80).map(item).join('') || ''}`;
  }

  function journalBind(el) {
    el.addEventListener('click', e => {
      const j = st.jform; if (!j) return;
      const keep = () => { j.strike = $('jStrike') && $('jStrike').value; j.buy = $('jBuy') && $('jBuy').value; j.sell = $('jSell') && $('jSell').value; j.lots = $('jLots') && $('jLots').value; j.lotSize = $('jLot') && $('jLot').value; j.note = $('jNote') && $('jNote').value; };
      const f = e.target.closest('[data-jf] [data-v]');
      if (f) { keep(); const k = f.parentElement.dataset.jf, v = f.dataset.v;
        if (k === 'reasons') j.reasons = j.reasons.includes(v) ? j.reasons.filter(x => x !== v) : j.reasons.concat(v);
        else if (k === 'mood') j.mood = j.mood === v ? '' : v;
        else { j[k] = v; if (k === 'index') j.lotSize = LOT[v]; }
        render(); return; }
      if (e.target.closest('#jSave')) {
        keep();
        const t = { id: Date.now(), ts: Date.now(), index: j.index, side: j.side, strike: parseFloat(j.strike), buy: parseFloat(j.buy), sell: parseFloat(j.sell),
          lots: parseInt(j.lots) || 1, lotSize: parseInt(j.lotSize) || LOT[j.index], reasons: j.reasons.slice(), mood: j.mood, note: (j.note || '').trim() };
        if (!(t.strike > 0) || !(t.buy > 0)) { toast('Enter strike and buy price'); return; }
        if (!isFinite(t.sell)) delete t.sell;
        const d = dataNear(t.index), hz = heroFor(t.index), r15 = fut15();
        t.ctx = { pcr: d ? d.cur.pcr : NaN, fut: r15.label || '', hero: hz ? hz.state : '', spot: d ? d.cur.spot : NaN };
        const list = REC.trades(); list.push(t); REC.setTrades(list);
        st.jform = { index: j.index, side: j.side, reasons: [], mood: '' }; toast('Trade saved'); render(); return;
      }
      const c = e.target.closest('[data-close]');
      if (c) { const id = +c.dataset.close, inp = el.querySelector(`[data-exit="${id}"]`), v = parseFloat(inp && inp.value);
        if (!(v >= 0)) { toast('Enter the exit price'); return; }
        const list = REC.trades(), t = list.find(x => x.id === id); if (t) { t.sell = v; t.closeTs = Date.now(); REC.setTrades(list); toast('Trade closed'); render(); } return; }
      const dl = e.target.closest('[data-del]');
      if (dl) { if (!confirm('Delete this trade?')) return; REC.setTrades(REC.trades().filter(x => x.id !== +dl.dataset.del)); render(); }
    });
  }

  // ---------- Alerts tab (history with what happened 15 / 30 min later)
  function renderAlerts() {
    st.unseen = 0;
    const icon = { reversalWarn: '⚠️', reversal: '🔄', heroSignal: '🚀', heroWatch: '👀', rangeBreak: '💥', resShift: '🟥', supShift: '🟩', resForecast: '🟥', supForecast: '🟩', oiDecline: '📉', strikeDump: '⚠️', bigOi: '🐋', zeroFlip: '0️⃣', futFlip: '📊', premJump: '🎯', timeRemind: '⏰', pcr: '⚖️', oiSpike: '⚡', maxPain: '🎓' };
    const f = st.ui.afilt || 'all';
    const list = st.alerts.slice().reverse().filter(a => f === 'all' || a.lvl === f);
    const mv = (v, a) => isFinite(v) ? `<span class="${cls(v)}">${sgn(v, fmtK)}</span>` : '<span class="dim">…</span>';
    $('alertFilt').innerHTML = [['all', 'All'], ['critical', 'Critical'], ['important', 'Important'], ['info', 'Info']].map(([k, n]) => `<button class="chip ${f === k ? 'on' : ''}" data-af="${k}">${n} ${k === 'all' ? st.alerts.length : st.alerts.filter(a => a.lvl === k).length}</button>`).join('');
    const ws = st.alerts.filter(a => a.type === 'reversalWarn' && a.result), wk = ws.filter(a => a.result === 'worked').length;
    $('alertList').innerHTML = (ws.length ? `<div class="hzcap" style="padding:0 14px 8px">Reversal warnings today: ${wk} of ${ws.length} worked (moved 0.25%+ the warned way).</div>` : '') + (list.length ? list.map(a => `<div class="alert lv-${a.lvl || 'info'} ${a.tone || ''}"><div class="ic">${icon[a.type] || '🔔'}</div><div style="min-width:0;flex:1">
        <div class="t"><b>${C.istTime(a.ts)}</b> · ${a.index} · ${esc(a.kind)}${a.lvl ? ` · <span class="lvl ${a.lvl}">${a.lvl}</span>` : ''}</div>
        ${a.title ? `<div class="at">${esc(a.title)}</div>` : ''}<div class="msg">${esc(a.msg)}</div>${planHtmlBox(a.plan)}
        <button class="askw" data-ask="${esc(`Explain this alert from ${C.istTime(a.ts)}: ${a.title || a.kind}. ${a.plan ? 'Should I take the suggested trade?' : 'What should I do?'}`)}">💬 Why? Ask EV</button>
        ${a.result ? `<div class="after"><b class="${a.result === 'worked' ? 'up' : 'dn'}">${a.result === 'worked' ? `✓ Reversal came: +${a.best.toFixed(2)}% within ${Math.round((a.resTs - a.ts) / 60000)} min` : '✗ No reversal followed'}</b></div>` : ''}
        ${isFinite(a.spot0) ? `<div class="after">Spot then ${f2(a.spot0)} · after 15 min ${mv(a.s15)} · after 30 min ${mv(a.s30)}</div>` : ''}</div></div>`).join('')
      : `<div class="empty">No alerts yet today.<br>Alerts run during market hours. Choose which alerts you want in Settings.</div>`);
  }

  // ---------- Settings: per-alert switches
  function alertCfgHtml() {
    return ALERTS.map(a => { const c = acfg(a.id); return `<div class="acfg" data-aid="${a.id}">
      <div class="acf1"><div style="min-width:0"><div class="t">${a.name}</div><div class="s">${a.desc}</div></div><input type="checkbox" data-k="on" ${c.on ? 'checked' : ''}></div>
      <div class="acf2"><div class="seg3">${['critical', 'important', 'info'].map(l => `<button class="${c.lvl === l ? 'on ' + l : ''}" data-l="${l}">${l[0].toUpperCase() + l.slice(1)}</button>`).join('')}</div>
        <label class="exp"><input type="checkbox" data-k="exp" ${c.exp ? 'checked' : ''}> Expiry day only</label></div></div>`; }).join('');
  }
  function setAcfg(id, patch) {
    const all = st.settings.alertCfg = st.settings.alertCfg || {};
    all[id] = Object.assign(acfg(id), all[id] || {}, patch); saveSettings();
  }

  let settingsFilled = false;
  const TH_SW = { kblgold: ['#120B18', '#853A93', '#E8B04B'], kblnight: ['#110A16', '#853A93', '#B57CC2'], kblday: ['#F6F2F8', '#853A93', '#FFFFFF'], navy: ['#0E1116', '#161B22', '#4C7DFF'],
    amoled: ['#000000', '#141418', '#4C7DFF'], gold: ['#0A0A0A', '#1C1A16', '#F5A524'], teal: ['#06171B', '#123039', '#22C3B5'], purple: ['#100D1C', '#221C3A', '#8B6CFF'], day: ['#F3F5F9', '#FFFFFF', '#2F5BEA'] };
  function themeGrid() {
    const g = $('thGrid'); if (!g || !window.EV_THEMES) return;
    const cur = st.settings.theme || 'kblgold';
    g.innerHTML = Object.keys(window.EV_THEMES).map(k => `<button class="thb ${k === cur ? 'on' : ''}" data-theme="${k}"><span class="sw">${(TH_SW[k] || []).map(c => `<i style="background:${c}"></i>`).join('')}</span>${esc(window.EV_THEMES[k].name)}${k === 'kblgold' ? ' ★' : ''}</button>`).join('');
  }
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-theme]'); if (!b || !b.classList.contains('thb')) return;
    st.settings.theme = window.applyTheme(b.dataset.theme); saveSettings(); themeGrid(); toast('Theme: ' + window.EV_THEMES[st.settings.theme].name); });
  function renderSettings() {
    themeGrid(); tradeSettings();
    const line = (src, idx) => {
      const dg = st.diag[src], err = st.errors[idx];
      const state = err ? `<span class="dn">✗ ${esc(err)}</span>` : dg ? (dg.ok ? '<span class="up">✓ Working</span>' : '<span class="dn">✗ No data</span>') : 'Not checked yet';
      return `<div><b>${src}</b> (${idx}) · ${state}${dg ? `<br><span class="dim">Last call ${C.istTime(dg.at, true)} · HTTP ${dg.status}</span>` : ''}</div>`;
    };
    $('connStatus').innerHTML = line('NSE', 'NIFTY') + '<div style="height:6px"></div>' + line('BSE', 'SENSEX');
    const diagEl = $('diagOut');
    if (diagEl.dataset.open === '1') {
      diagEl.innerHTML = ['NSE', 'BSE'].map(src => { const dg = st.diag[src]; return dg ? `<b>${src}</b> ${esc(dg.url)}<br>HTTP ${dg.status}<pre>${esc(dg.snippet || '(empty)')}</pre>` : `<b>${src}</b>: no call yet`; }).join('<hr>');
    }
    $('ftStatus').innerHTML = `<b>${FT.status()}</b>` + (st.ftErr ? `<br><span class="dn">${esc(st.ftErr)}</span>` : '');
    $('srcFt').classList.toggle('on', st.settings.source === 'ft'); $('srcHs').classList.toggle('on', st.settings.source === 'hs'); $('srcEx').classList.toggle('on', !wantFT());
    $('hsStatus').innerHTML = `<b>${HS.status()}</b>` + (HS.err ? `<br><span class="dn">${esc(HS.err)}</span>` : '') + (st.hsErr ? `<br><span class="dn">${esc(st.hsErr)}</span>` : '')
      + (HS.ready() && HS.master ? `<br><span class="dim">Contracts loaded: NIFTY ${HS.master.NIFTY.opts.length}, SENSEX ${HS.master.SENSEX.opts.length}</span>` : '');
    $('hsLoginBtn').textContent = HS.ready() ? 'Logged in for today ✓ (log in again)' : 'Log in to HDFC Sky (today)';
    const hd = $('hsDiagOut');
    if (hd.dataset.open === '1') hd.innerHTML = HS.diag.length ? HS.diag.map(x => `<b>${C.istTime(x.at, true)} ${esc(x.what)}</b><pre>${esc(x.detail)}</pre>`).join('') : 'No HDFC Sky calls yet.';
    $('ftLoginBtn').textContent = FT.ready() ? 'Logged in for today ✓ (log in again)' : 'Log in to Flattrade (today)';
    const fd = $('ftDiagOut');
    if (fd.dataset.open === '1') fd.innerHTML = FT.diag.length ? FT.diag.map(x => `<b>${C.istTime(x.at, true)} ${esc(x.what)}</b><pre>${esc(x.detail)}</pre>`).join('') : 'No Flattrade calls yet.';
    $('auditSet').innerHTML = auditCard(Object.keys(EXPORTS));
    if (settingsFilled) return;
    settingsFilled = true;
    $('ftUid').value = FT.cfg.uid; $('ftKey').value = FT.cfg.key;
    $('ftSecret').value = ''; $('ftSecret').placeholder = FT.cfg.secret ? 'Saved ✓ (paste to replace)' : 'API secret';
    $('ftRedirect').textContent = FT.REDIRECT;
    $('hsKey').value = HS.cfg.key; $('hsSecret').value = ''; $('hsSecret').placeholder = HS.cfg.secret ? 'Saved ✓ (paste to replace)' : 'API secret';
    $('hsRedirect').value = HS.cfg.redirect || HS.DEF_REDIRECT; $('hsRedirDef').textContent = HS.cfg.redirect || HS.DEF_REDIRECT;
    const S = st.settings;
    $('strikes').value = S.strikes; $('strikesVal').textContent = S.strikes;
    $('sNotify').checked = S.notify; $('sAlarm').checked = S.alarm !== false; $('sRev').value = S.revPct || 0.3;
    $('alertCfg').innerHTML = alertCfgHtml();
    $('fsState').textContent = !Bridge || !Bridge.canFullScreen ? 'Available in the Android app.' : Bridge.canFullScreen() ? '✓ Full-screen alerts allowed' : '✗ Not allowed yet: tap the button and turn it on';
    $('sPcrHigh').value = S.pcrHigh; $('sPcrLow').value = S.pcrLow; $('sSpikePct').value = S.spikePct;
    $('sSpikeWin').value = String(S.spikeWin); $('sSpikeShare').value = S.spikeShare; $('sCool').value = S.cooldown;
    $('hMin').value = S.heroMin; $('hMax').value = S.heroMax; $('hDrop').value = S.heroDrop; $('hEarly').value = S.heroEarly || 50; $('hMove').value = S.hzMove || 30;
    $('sfOn').checked = S.safe !== false; $('sfChance').value = S.safeChance; $('sfRR').value = S.safeRR; $('sfStop').value = S.safeStop; $('sfBE').value = S.safeBE; $('sfLoss').value = S.safeLosses;
    $('hzOn').checked = S.hzSafe !== false; $('hzBudget').value = S.hzBudget; $('hzTries').value = S.hzTries;
    $('hStart').value = `${String(Math.floor(S.heroStart / 60)).padStart(2, '0')}:${String(S.heroStart % 60).padStart(2, '0')}`;
    $('bgOn').checked = !!st.ui.bg;
  }

  // ------------------------------------------------------------------- events
  function saveUi() { store.set('oi.ui', st.ui); }
  function go(view) {
    st.ui.view = view; saveUi();
    for (const b of $('nav').children) b.classList.toggle('on', b.dataset.v === view);
    for (const v of document.querySelectorAll('.view')) v.classList.toggle('on', v.id === 'v-' + view);
    if (view === 'settings') settingsFilled = false;
    if (view === 'daily') NEWS.refresh(false).then(render).catch(() => { });
    if (view === 'penny') { try { pennyPaint(); } catch (e) { } }
    if (view === 'hz') fetchHzx(false).then(() => { if (st.ui.view === 'hz') hzPaint(); }).catch(() => { });
    window.scrollTo(0, 0); st.scrolledFor = null;
    render();
  }

  function bind() {
    $('winChips').insertAdjacentHTML('beforeend', WINDOWS.map(w => `<button class="chip" data-w="${w[0]}">${w[1]}</button>`).join(''));
    $('winChips').addEventListener('click', e => { const b = e.target.closest('.chip'); if (!b) return; st.ui.win = b.dataset.w; saveUi(); render(); });
    $('idxSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; st.ui.index = b.dataset.i; st.openRow = null; st.scrolledFor = null; saveUi(); render(); });
    $('expSel').addEventListener('change', e => {
      st.sel[st.ui.index] = e.target.value; st.scrolledFor = null; st.openRow = null; render();
      if (!(st.snaps[curKey()] || []).length) cycle(true);
    });
    $('refresh').addEventListener('click', () => cycle(true));
    document.querySelector('.brand').addEventListener('click', () => go('settings'));
    $('nav').addEventListener('click', e => { const b = e.target.closest('button'); if (b) go(b.dataset.v); });
    document.body.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) go(b.dataset.go); });
    $('pickBox').addEventListener('click', e => {
      const b = e.target.closest('[data-goto]'); if (!b) return;
      const k = +b.dataset.goto; st.openRow = k; render();
      const tr = document.querySelector(`#chainTbl tr[data-k="${k}"]`); if (tr) tr.scrollIntoView({ block: 'center', behavior: 'smooth' });
    });
    $('chainTbl').addEventListener('click', e => {
      const tr = e.target.closest('tr[data-k]'); if (!tr) return;
      const k = +tr.dataset.k; st.openRow = st.openRow === k ? null : k; render();
    });
    $('oiToggle').addEventListener('click', e => { const b = e.target.closest('.chip'); if (!b) return; st.ui.oiMode = b.dataset.m; saveUi(); render(); });
    $('clearAlerts').addEventListener('click', () => { st.alerts = []; saveDay(); render(); });
    $('diagBtn').addEventListener('click', () => { const el = $('diagOut'); el.dataset.open = el.dataset.open === '1' ? '0' : '1'; if (el.dataset.open !== '1') el.innerHTML = ''; renderSettings(); });
    const ftLogin = () => {
      FT.login().then(() => { toast('Flattrade connected ✓'); st.settings.source = 'ft'; saveSettings(); settingsFilled = false; cycle(true); })
        .catch(async e => {
          const msg = (e && e.msg) || 'Login failed';
          toast(msg); st.ftErr = msg;
          if (/INVALID_IP/i.test(msg)) {          // show the phone's current public IPv4 so it can be compared with the one registered at Flattrade
            const r = await http('GET', 'https://api.ipify.org?format=json', { 'Accept': 'application/json' }), j = parseJson(r.text);
            st.ftErr = `Flattrade rejected this phone's IP address. Your phone's IP right now: ${j && j.ip ? j.ip : 'unknown'}. ` +
              'It must match the IP registered with your API key. Mobile data IPs change; use the registered network, or update the IP at Flattrade. Meanwhile NSE/BSE data is used.';
          }
          settingsFilled = false; render();
        });
    };
    document.body.addEventListener('click', e => { if (e.target.closest('[data-ftlogin]')) ftLogin(); });
    $('ftSave').addEventListener('click', () => {
      const uid = $('ftUid').value.trim().toUpperCase(), key = $('ftKey').value.trim(), sec = $('ftSecret').value.trim() || FT.cfg.secret;
      if (!uid || !key || !sec) { toast('Enter client ID, API key and API secret'); return; }
      FT.saveCfg({ uid, key, secret: sec }); settingsFilled = false; toast('Saved. Now tap "Log in to Flattrade".'); render();
    });
    $('ftLoginBtn').addEventListener('click', ftLogin);
    const hsLogin = () => {
      st.hsErr = null;
      HS.login().then(() => { toast('HDFC Sky connected ✓'); st.settings.source = 'hs'; saveSettings(); settingsFilled = false; HS.loadMaster().catch(e => { st.hsErr = e && e.msg; }); cycle(true); })
        .catch(e => { const msg = (e && e.msg) || 'Login failed'; toast(msg); st.hsErr = msg; settingsFilled = false; render(); });
    };
    document.body.addEventListener('click', e => { if (e.target.closest('[data-hslogin]')) hsLogin(); });
    $('hsSave').addEventListener('click', () => {
      const key = $('hsKey').value.trim(), sec = $('hsSecret').value.trim() || HS.cfg.secret, red = $('hsRedirect').value.trim() || HS.DEF_REDIRECT;
      if (!key || !sec) { toast('Enter the API key and API secret'); return; }
      if (!/^https?:\/\//i.test(red)) { toast('Redirect URL must start with https://'); return; }
      HS.saveCfg({ key, secret: sec, redirect: red }); settingsFilled = false; toast('Saved. Now tap "Log in to HDFC Sky".'); render();
    });
    $('hsLoginBtn').addEventListener('click', hsLogin);
    $('srcHs').addEventListener('click', () => { st.settings.source = 'hs'; saveSettings(); st.live = {}; render(); if (HS.ready()) cycle(true); else toast('Save your HDFC Sky details and log in'); });
    $('hsCopy').addEventListener('click', () => { const r = HS.cfg.redirect || HS.DEF_REDIRECT; try { navigator.clipboard.writeText(r); toast('Redirect URL copied'); } catch (e) { toast(r); } });
    $('hsDiagBtn').addEventListener('click', () => { const el = $('hsDiagOut'); el.dataset.open = el.dataset.open === '1' ? '0' : '1'; if (el.dataset.open !== '1') el.innerHTML = ''; renderSettings(); });
    $('srcFt').addEventListener('click', () => { st.settings.source = 'ft'; saveSettings(); st.live = {}; render(); if (FT.ready()) cycle(true); else toast('Save your Flattrade details and log in'); });
    $('srcEx').addEventListener('click', () => { st.settings.source = 'exchange'; saveSettings(); st.live = {}; st.fut.liveCur = null; render(); cycle(true); });
    $('ftCopy').addEventListener('click', () => { try { navigator.clipboard.writeText(FT.REDIRECT); toast('Redirect URL copied'); } catch (e) { toast(FT.REDIRECT); } });
    $('ftDiagBtn').addEventListener('click', () => { const el = $('ftDiagOut'); el.dataset.open = el.dataset.open === '1' ? '0' : '1'; if (el.dataset.open !== '1') el.innerHTML = ''; renderSettings(); });
    journalBind($('daily')); checkerBind();
    $('daily').addEventListener('click', e => {
      const dt = e.target.closest('[data-dt]');
      const as_ = e.target.closest('[data-as]'); if (as_) { st.ui.accSafe = as_.dataset.as; saveUi(); render(); return; }
      const ap = e.target.closest('[data-ap]'); if (ap) { st.ui.accPer = ap.dataset.ap; saveUi(); render(); return; }
      if (dt) { st.ui.dtab = dt.dataset.dt; saveUi(); if (dt.dataset.dt === 'call') fetchGlobal(false).then(render).catch(() => { }); render(); window.scrollTo(0, 0); return; }
      if (e.target.closest('#globRefresh')) { toast('Loading overseas markets…'); fetchGlobal(true).then(() => { render(); if (st.globErr) toast(st.globErr); }); return; }
      if (e.target.closest('#lockCall')) { const d = lockCall(true); toast(d.NIFTY ? `Locked: NIFTY ${d.NIFTY.label}` : 'Not enough data to make a call yet'); render(); return; }
      if (e.target.closest('#giftRefresh')) { toast('Fetching GIFT Nifty…'); fetchGift(true).then(render); return; }
      if (e.target.closest('#giftSave')) {
        const v = parseFloat($('giftIn').value);
        if (!(v > 1000)) { toast('Enter the GIFT Nifty value, e.g. 25120'); return; }
        store.set('oi.gift', { v, ts: Date.now() }); toast('GIFT Nifty saved'); render(); return;
      }
      const t = e.target.closest('[data-nt]'); if (t) { st.ui.newsTab = t.dataset.nt; saveUi(); render(); return; }
      if (e.target.closest('#newsRefresh')) { toast('Loading news…'); NEWS.refresh(true).then(render); return; }
      const ni = e.target.closest('[data-ni]');
      if (ni) { const x = NEWS.items[+ni.dataset.ni]; if (x && x.link) { if (Bridge && Bridge.openUrl) Bridge.openUrl(x.link); else window.open(x.link, '_blank'); } }
    });
    $('retryNow').addEventListener('click', () => { st.nseWarmAt = 0; st.bseWarmAt = 0; st.expFetchedAt = {}; toast('Fetching from NSE & BSE…'); cycle(true); });

    $('strikes').addEventListener('input', e => { st.settings.strikes = +e.target.value; $('strikesVal').textContent = e.target.value; saveSettings(); });
    const bindCk = (id, k) => $(id).addEventListener('change', e => { st.settings[k] = e.target.checked; saveSettings(); });
    bindCk('sNotify', 'notify'); bindCk('sAlarm', 'alarm');
    $('alertCfg').addEventListener('click', e => {
      const row = e.target.closest('[data-aid]'); if (!row) return;
      const l = e.target.closest('[data-l]');
      if (l) { setAcfg(row.dataset.aid, { lvl: l.dataset.l }); $('alertCfg').innerHTML = alertCfgHtml(); }
    });
    $('alertCfg').addEventListener('change', e => {
      const row = e.target.closest('[data-aid]'), k = e.target.dataset.k; if (!row || !k) return;
      setAcfg(row.dataset.aid, { [k]: e.target.checked });
    });
    $('fsBtn').addEventListener('click', () => { if (Bridge && Bridge.openAlertSettings) Bridge.openAlertSettings(); else toast('Available in the Android app'); });
    const testA = (lvl, tone) => { const a = { ts: Date.now(), index: 'NIFTY', type: 'reversal', kind: 'Test', lvl, tone, title: lvl === 'critical' ? '🔄 TEST · Critical alert' : `TEST · ${lvl} alert`, msg: 'This is how a ' + lvl + ' alert looks and sounds.', spot0: NaN };
      attachPlan(a); deliver(a); };
    $('testCrit').addEventListener('click', () => testA('critical', 'bull'));
    $('testImp').addEventListener('click', () => testA('important', 'bear'));
    $('ovDismiss').addEventListener('click', () => closeOverlay(false));
    $('ovSnooze').addEventListener('click', () => closeOverlay(true));
    $('ovOpen').addEventListener('click', () => { closeOverlay(false); go('alerts'); });
    $('abanner').addEventListener('click', () => { $('abanner').className = 'abanner'; go('alerts'); });
    $('alertFilt').addEventListener('click', e => { const b = e.target.closest('[data-af]'); if (b) { st.ui.afilt = b.dataset.af; saveUi(); render(); } });
    const bindNum = (id, k, lo, hi) => $(id).addEventListener('change', e => {
      let v = parseFloat(e.target.value); if (!isFinite(v)) v = C.DEFAULT_SETTINGS[k];
      v = Math.min(hi, Math.max(lo, v)); e.target.value = v; st.settings[k] = v; saveSettings();
    });
    bindNum('sPcrHigh', 'pcrHigh', 0.3, 5); bindNum('sPcrLow', 'pcrLow', 0.05, 3); bindNum('sSpikePct', 'spikePct', 2, 500);
    bindNum('sSpikeShare', 'spikeShare', 0, 100); bindNum('sCool', 'cooldown', 1, 240); bindNum('sSpikeWin', 'spikeWin', 1, 60);
    bindNum('sfChance', 'safeChance', 30, 95); bindNum('sfRR', 'safeRR', 1, 5); bindNum('sfStop', 'safeStop', 5, 50); bindNum('sfBE', 'safeBE', 5, 50); bindNum('sfLoss', 'safeLosses', 1, 10);
    bindNum('hzBudget', 'hzBudget', 100, 1000000); bindNum('hzTries', 'hzTries', 1, 10);
    $('sfOn').addEventListener('change', e => { st.settings.safe = e.target.checked; saveSettings(); render(); });
    $('hzOn').addEventListener('change', e => { st.settings.hzSafe = e.target.checked; saveSettings(); render(); });
    bindNum('sRev', 'revPct', 0.1, 3); bindNum('hMin', 'heroMin', 0.05, 500); bindNum('hMax', 'heroMax', 0.1, 1000); bindNum('hDrop', 'heroDrop', 10, 100); bindNum('hEarly', 'heroEarly', 20, 95); bindNum('hMove', 'hzMove', 10, 200);
    $('hStart').addEventListener('change', e => {
      const m = /^(\d{1,2}):(\d{2})$/.exec(e.target.value);
      if (m) { st.settings.heroStart = +m[1] * 60 + +m[2]; saveSettings(); }
    });
    $('testNotif').addEventListener('click', () => { notify("EV Pulse", 'Test alert ✓ Notifications are working.'); toast('Test notification sent'); });
    $('bgOn').addEventListener('change', e => {
      st.ui.bg = e.target.checked; saveUi();
      if (Bridge && Bridge.setBackground) Bridge.setBackground(st.ui.bg);
      toast(st.ui.bg ? 'Background tracking on' : 'Background tracking off');
    });
    $('battery').addEventListener('click', () => { if (Bridge && Bridge.openBatterySettings) Bridge.openBatterySettings(); else toast('Available in the Android app'); });

    document.body.addEventListener('click', e => {
      if (e.target.id === 'autoSave') { st.settings.autoSave = e.target.checked; saveSettings(); toast(e.target.checked ? 'Daily auto-save on' : 'Daily auto-save off'); return; }
      const d = e.target.closest('[data-dl]');
      if (d) { if (d.dataset.dl === 'all') downloadAll(); else download(d.dataset.dl); return; }
      if (e.target.closest('[data-dlopen]') && Bridge && Bridge.openSaved) { Bridge.openSaved(); return; }
      const b = e.target.closest('[data-setup]'); if (!b || !Bridge) return;
      const k = b.dataset.setup;
      if (k === 'notif' && Bridge.requestNotif) Bridge.requestNotif();
      if (k === 'fs' && Bridge.openAlertSettings) Bridge.openAlertSettings();
      if (k === 'bat' && Bridge.requestBattery) Bridge.requestBattery();
      if (k === 'ovl' && Bridge.requestOverlay) Bridge.requestOverlay();
    });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        render();
        if (!st.busy && (!st.lastOk || Date.now() - st.lastOk > 70000)) cycle(false);
      }
    });
    setInterval(() => { if (document.visibilityState === 'visible' && !st.busy) { renderTop(); if (st.ui.view === 'chain') { const d = current(); if (d) $('chainSub').innerHTML = subLine(d); } } }, 10000);
  }
  function saveSettings() { store.set('oi.settings', st.settings); }

  // live refresh: every 2 s rebuild the visible chain + futures from Flattrade ticks
  setInterval(() => {
    if (!useFT() || st.busy || document.visibilityState !== 'visible') return;
    const L = LD(), index = st.ui.index, iso = st.sel[index];
    if (!iso || !L.hasChain(index, iso)) return;
    const p = L.chain(index, iso, lastSpot(index));
    if (p.rows.length && p.spot) {
      if (noOi(p) && !applyOi(index, iso, p) && Date.now() - (st.oiTry[index] || 0) > 60000) { st.oiTry[index] = Date.now(); fixOi(index, iso, p).catch(() => { }); }
      else if (!noOi(p) && p.oiSrc) st.oiSrc[index] = p.oiSrc;
      st.live[index + '|' + iso] = C.makeSnap(Date.now(), p.spot, p.rows); st.srcUsed[index] = L.name || 'Flattrade'; tickPush(index, p.spot);
      if (C.marketOpen(Date.now()) && iso === (st.expiries[index] || [])[0]) { try { recordPath(index + '|' + iso, st.live[index + '|' + iso]); } catch (e) { } } }
    const q = L.futQuote();
    if (q) st.fut.liveCur = { ltp: q.ltp, oi: q.oi, spot: q.underlying || lastSpot('NIFTY'), ts: Date.now() };
    if (C.marketOpen(Date.now()) && (st.liveTick || 0) % 5 === 4) { try { adviseAll(true); } catch (e) { } }
    if (C.marketOpen(Date.now()) && (st.liveTick = (st.liveTick || 0) + 1) % 5 === 0) {
      try { const k = index + '|' + iso, lv = st.live[k]; if (iso === (st.expiries[index] || [])[0] && lv) { if (minsOf(lv.ts) < 15 * 60 + 15) earlyReversal(index, iso, lv.spot); casTick(index, lv); } } catch (e) { }
    }
    if (['home', 'chain', 'oi', 'pos', 'hz', 'penny'].includes(st.ui.view)) render();
  }, 2000);

  // -------------------------------------------------------------------- start
  if (!store.get('oi.def39', false)) {
    st.ui.bg = true; st.settings.notify = true; st.settings.alarm = true;
    store.set('oi.ui', st.ui); store.set('oi.settings', st.settings); store.set('oi.def39', true);
    setTimeout(() => { if (Bridge && Bridge.batteryOk && !Bridge.batteryOk() && Bridge.requestBattery) Bridge.requestBattery(); }, 2500);
  }
  loadDay();
  bind();
  go(st.ui.view);
  if (Bridge && Bridge.setBackground && st.ui.bg) Bridge.setBackground(true);
  setTimeout(() => { const sp = $('splash'); if (sp) { sp.classList.add('hide'); setTimeout(() => sp.remove(), 500); } }, 4500);   // signal lock 1.9 s + name scramble ≈1.1 s + tagline ≈1.1 s
  cycle(true);
})();
