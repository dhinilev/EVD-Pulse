package com.oitracker.app;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.Dns;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity {

    static final String CH_ALERTS = "alerts";
    static final String CH_TRACKING = "tracking";
    static final String CH_CRIT = "alert_critical";
    static final String CH_IMP = "alert_important";
    static final String CH_INFO = "alert_info";

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final AtomicInteger notifId = new AtomicInteger(100);
    private volatile Uri lastSaved = null;
    private volatile String lastMime = "text/csv";
    private final java.util.List<Integer> critIds = java.util.Collections.synchronizedList(new java.util.ArrayList<>());

    /** IPv4-only DNS: Flattrade checks the caller's IP against the one IPv4 address registered with the API key. */
    private static final Dns IPV4_ONLY = hostname -> {
        List<InetAddress> all = Dns.SYSTEM.lookup(hostname);
        List<InetAddress> v4 = new ArrayList<>();
        for (InetAddress a : all) if (a instanceof Inet4Address) v4.add(a);
        return v4.isEmpty() ? all : v4;
    };
    private final OkHttpClient ok4 = new OkHttpClient.Builder()
            .dns(IPV4_ONLY)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build();
    private final Map<String, WebSocket> sockets = new ConcurrentHashMap<>();

    private static boolean ipv4Host(String url) {
        try { String h = Uri.parse(url).getHost(); return h != null && (h.endsWith("flattrade.in") || h.endsWith("hdfcsky.com")); } catch (Exception e) { return false; }
    }

    private void jsCall(final String js) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    static final int REQ_VOICE = 4711;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_VOICE) return;
        String said = "";
        if (resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) said = r.get(0);
        }
        final String js = "window.__voice && window.__voice(" + jsString(said) + ")";
        if (web != null) web.evaluateJavascript(js, null);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        alive = true;
        createChannels(this);
        WakeReceiver.schedule(this);
        // NSE/BSE need session cookies: keep them across requests (in memory).
        if (!(CookieHandler.getDefault() instanceof CookieManager)) {
            CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));
        }

        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#0E1116"));
        w.setNavigationBarColor(Color.parseColor("#161B22"));

        handleAlertIntent(getIntent());
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0E1116"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        // started by the 8:50 / 3:43 wake-up: run quietly in the background
        if (getIntent() != null && getIntent().getBooleanExtra("auto", false)) {
            web.postDelayed(() -> { try { moveTaskToBack(true); } catch (Exception ignored) { } }, 1500);
        }
    }

    static volatile boolean alive = false;

    private volatile boolean inForeground = false;
    private View overlayView = null;

    @Override
    protected void onResume() { super.onResume(); inForeground = true; runOnUiThread(this::hideOverlay); }

    @Override
    protected void onPause() { super.onPause(); inForeground = false; }

    /** Blinking critical-alert card drawn over other apps (needs "Display over other apps"). */
    private void showOverlay(String title, String text, String tone) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
        hideOverlay();
        final android.view.WindowManager wm = (android.view.WindowManager) getApplicationContext().getSystemService(WINDOW_SERVICE);
        if (wm == null) return;
        final float dp = getResources().getDisplayMetrics().density;
        final int accent = "bull".equals(tone) ? Color.parseColor("#2FB37A") : "bear".equals(tone) ? Color.parseColor("#F2555A") : Color.parseColor("#F5A524");
        android.widget.LinearLayout box = new android.widget.LinearLayout(getApplicationContext());
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = (int) (16 * dp); box.setPadding(pad, pad, pad, (int) (12 * dp));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.parseColor("#161B22")); bg.setCornerRadius(18 * dp); bg.setStroke((int) (3 * dp), accent);
        box.setBackground(bg);
        android.widget.TextView k = new android.widget.TextView(getApplicationContext());
        k.setText("⚠ CRITICAL ALERT · EV PULSE"); k.setTextColor(accent); k.setTextSize(12); k.setTypeface(null, android.graphics.Typeface.BOLD);
        android.widget.TextView t = new android.widget.TextView(getApplicationContext());
        t.setText(title); t.setTextColor(Color.WHITE); t.setTextSize(19); t.setTypeface(null, android.graphics.Typeface.BOLD); t.setPadding(0, (int) (6 * dp), 0, 0);
        android.widget.TextView m = new android.widget.TextView(getApplicationContext());
        m.setText(text); m.setTextColor(Color.parseColor("#E6EAF0")); m.setTextSize(14); m.setPadding(0, (int) (6 * dp), 0, 0); m.setMaxLines(9);
        android.widget.LinearLayout row = new android.widget.LinearLayout(getApplicationContext());
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL); row.setPadding(0, (int) (12 * dp), 0, 0);
        android.widget.Button dismiss = new android.widget.Button(getApplicationContext());
        dismiss.setText("Dismiss"); dismiss.setAllCaps(false);
        android.widget.Button open = new android.widget.Button(getApplicationContext());
        open.setText("Open EV Pulse"); open.setAllCaps(false); open.setTextColor(Color.WHITE);
        android.graphics.drawable.GradientDrawable ob = new android.graphics.drawable.GradientDrawable(); ob.setColor(accent); ob.setCornerRadius(12 * dp); open.setBackground(ob);
        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(0, (int) (46 * dp), 1f);
        lp.setMargins((int) (4 * dp), 0, (int) (4 * dp), 0);
        row.addView(dismiss, lp); row.addView(open, new android.widget.LinearLayout.LayoutParams(lp));
        box.addView(k); box.addView(t); box.addView(m); box.addView(row);
        dismiss.setOnClickListener(v -> { hideOverlay(); clearCritical(); });
        open.setOnClickListener(v -> {
            hideOverlay();
            Intent i = new Intent(MainActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            i.putExtra("critical", true);
            startActivity(i);
        });
        int type = Build.VERSION.SDK_INT >= 26 ? android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : android.view.WindowManager.LayoutParams.TYPE_PHONE;
        android.view.WindowManager.LayoutParams p = new android.view.WindowManager.LayoutParams(
                android.view.WindowManager.LayoutParams.MATCH_PARENT, android.view.WindowManager.LayoutParams.WRAP_CONTENT, type,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = android.view.Gravity.TOP; p.x = 0; p.y = (int) (40 * dp);
        p.horizontalMargin = 0.03f;
        try { wm.addView(box, p); overlayView = box; } catch (Exception e) { overlayView = null; return; }
        // blink the border until dismissed
        android.animation.ValueAnimator va = android.animation.ValueAnimator.ofInt(255, 70);
        va.setDuration(600); va.setRepeatMode(android.animation.ValueAnimator.REVERSE); va.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        va.addUpdateListener(an -> bg.setStroke((int) (3 * dp), Color.argb((int) an.getAnimatedValue(), Color.red(accent), Color.green(accent), Color.blue(accent))));
        va.start();
        box.setTag(va);
    }

    private void hideOverlay() {
        if (overlayView == null) return;
        try {
            Object tag = overlayView.getTag(); if (tag instanceof android.animation.ValueAnimator) ((android.animation.ValueAnimator) tag).cancel();
            ((android.view.WindowManager) getApplicationContext().getSystemService(WINDOW_SERVICE)).removeView(overlayView);
        } catch (Exception ignored) { }
        overlayView = null;
    }

    private void clearCritical() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        synchronized (critIds) { for (Integer i : critIds) nm.cancel(i); critIds.clear(); }
    }

    private void handleAlertIntent(Intent i) {
        if (i != null && i.getBooleanExtra("critical", false) && Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleAlertIntent(intent);
        if (web != null) web.evaluateJavascript("window.__alertOpened && window.__alertOpened()", null);
    }

    // Keep running when the user presses Back, so tracking continues in the background.
    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        alive = false;
        // The tracking runs inside this screen's WebView, so stop the background service with it.
        if (isFinishing()) stopService(new Intent(this, TrackService.class));
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        pool.shutdownNow();
        super.onDestroy();
    }

    static void createChannels(Context ctx) {
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        NotificationChannel a = new NotificationChannel(CH_ALERTS, "OI alerts", NotificationManager.IMPORTANCE_HIGH);
        a.setDescription("PCR, OI spike and support/resistance alerts");
        a.enableVibration(true);
        nm.createNotificationChannel(a);
        NotificationChannel crit = new NotificationChannel(CH_CRIT, "Critical alerts (alarm)", NotificationManager.IMPORTANCE_HIGH);
        crit.setDescription("Hero-zero signals, reversals, range breaks, support/resistance shifts");
        crit.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        crit.enableVibration(true);
        crit.setVibrationPattern(new long[]{0, 800, 300, 800, 300, 800});
        crit.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(crit);
        NotificationChannel imp = new NotificationChannel(CH_IMP, "Important alerts", NotificationManager.IMPORTANCE_HIGH);
        imp.setDescription("OI reduction, shift forecasts, strike dumps, premium jumps");
        imp.enableVibration(true);
        imp.setVibrationPattern(new long[]{0, 400, 200, 400});
        nm.createNotificationChannel(imp);
        NotificationChannel inf = new NotificationChannel(CH_INFO, "Info alerts", NotificationManager.IMPORTANCE_DEFAULT);
        inf.setDescription("PCR, zero-OI flips, reminders");
        nm.createNotificationChannel(inf);
        NotificationChannel t = new NotificationChannel(CH_TRACKING, "Background tracking", NotificationManager.IMPORTANCE_LOW);
        t.setDescription("Shown while the app tracks the option chain in the background");
        nm.createNotificationChannel(t);
    }

    private PendingIntent openAppIntent() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static String jsString(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    /** Methods callable from JavaScript as window.Android.* */
    class Bridge {

        /** HTTP request done natively (no browser CORS limits). Result goes to window.__httpCb(id, status, base64Body). */
        @JavascriptInterface
        public void http(final String id, final String method, final String url, final String headersJson, final String body) {
            if (ipv4Host(url)) { httpV4(id, method, url, headersJson, body); return; }
            pool.execute(() -> {
                int status = 0;
                String b64;
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setRequestMethod(method);
                    c.setInstanceFollowRedirects(true);
                    c.setUseCaches(false);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(url.contains("api.anthropic.com") ? 90000 : 20000);   // AI answers can take longer
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> keys = h.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                    if (body != null && !body.isEmpty() && !"GET".equals(method)) {
                        c.setDoOutput(true);
                        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                        c.setFixedLengthStreamingMode(bytes.length);
                        try (OutputStream os = c.getOutputStream()) {
                            os.write(bytes);
                        }
                    }
                    status = c.getResponseCode();
                    InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    byte[] data = in == null ? new byte[0] : readAll(in);
                    b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                } catch (Exception e) {
                    status = 0;
                    String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
                    b64 = Base64.encodeToString(msg.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.__httpCb && window.__httpCb(" + jsString(id) + "," + status + "," + jsString(b64) + ")";
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript(js, null);
                });
            });
        }

        /** WebSocket over IPv4 (Flattrade live feed). Events go to window.__wsEvt(id, type, data). */
        @JavascriptInterface
        public void wsOpen(final String id, final String url) {
            Request req = new Request.Builder().url(url).build();
            WebSocket ws = ok4.newWebSocket(req, new WebSocketListener() {
                @Override public void onOpen(WebSocket w, Response r) { jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'open','')"); }
                @Override public void onMessage(WebSocket w, String text) { jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'message'," + jsString(text) + ")"); }
                @Override public void onClosed(WebSocket w, int code, String reason) { sockets.remove(id); jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'close'," + jsString(reason) + ")"); }
                @Override public void onFailure(WebSocket w, Throwable t, Response r) { sockets.remove(id); jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'error'," + jsString(String.valueOf(t.getMessage())) + ")"); }
            });
            sockets.put(id, ws);
        }

        /** WebSocket with request headers and binary frames (HDFC Sky feed). Binary frames arrive as type 'bin' with base64 data. */
        @JavascriptInterface
        public void wsOpen2(final String id, final String url, final String headersJson) {
            Request.Builder rb = new Request.Builder().url(url);
            try {
                JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                Iterator<String> keys = h.keys();
                while (keys.hasNext()) { String k = keys.next(); rb.header(k, h.getString(k)); }
            } catch (Exception ignored) { }
            WebSocket ws = ok4.newWebSocket(rb.build(), new WebSocketListener() {
                @Override public void onOpen(WebSocket w, Response r) { jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'open','')"); }
                @Override public void onMessage(WebSocket w, String text) { jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'message'," + jsString(text) + ")"); }
                @Override public void onMessage(WebSocket w, okio.ByteString bytes) {
                    jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'bin'," + jsString(bytes.base64()) + ")");
                }
                @Override public void onClosed(WebSocket w, int code, String reason) { sockets.remove(id); jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'close'," + jsString(reason) + ")"); }
                @Override public void onFailure(WebSocket w, Throwable t, Response r) {
                    sockets.remove(id);
                    String why = String.valueOf(t.getMessage()) + (r != null ? " (HTTP " + r.code() + ")" : "");
                    jsCall("window.__wsEvt && window.__wsEvt(" + jsString(id) + ",'error'," + jsString(why) + ")");
                }
            });
            sockets.put(id, ws);
        }

        /**
         * Downloads a ZIP, reads its first .csv and returns only the header plus the lines matching regex
         * (the broker's 17 MB contract list is cut down to the few thousand rows the app needs).
         * Result goes to window.__httpCb(id, status, base64Text).
         */
        @JavascriptInterface
        public void httpZipCsv(final String id, final String url, final String headersJson, final String regex) {
            pool.execute(() -> {
                int status = 0;
                String text;
                try {
                    Request.Builder rb = new Request.Builder().url(url);
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> keys = h.keys();
                    while (keys.hasNext()) { String k = keys.next(); rb.header(k, h.getString(k)); }
                    OkHttpClient slow = ok4.newBuilder().readTimeout(180, TimeUnit.SECONDS).build();
                    try (Response r = slow.newCall(rb.build()).execute()) {
                        status = r.code();
                        if (!r.isSuccessful() || r.body() == null) { text = r.body() != null ? r.body().string() : ""; }
                        else {
                            java.util.regex.Pattern p = java.util.regex.Pattern.compile(regex);
                            StringBuilder sb = new StringBuilder();
                            try (java.util.zip.ZipInputStream z = new java.util.zip.ZipInputStream(r.body().byteStream())) {
                                java.util.zip.ZipEntry e;
                                while ((e = z.getNextEntry()) != null) {
                                    if (!e.getName().toLowerCase().endsWith(".csv")) continue;
                                    java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(z, StandardCharsets.UTF_8));
                                    String line; boolean first = true;
                                    while ((line = br.readLine()) != null) {
                                        if (first || p.matcher(line).find()) sb.append(line).append('\n');
                                        first = false;
                                    }
                                    break;
                                }
                            }
                            text = sb.toString();
                        }
                    }
                } catch (Exception e) {
                    status = 0;
                    text = e.getClass().getSimpleName() + ": " + e.getMessage();
                }
                String b64 = Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                jsCall("window.__httpCb && window.__httpCb(" + jsString(id) + "," + status + "," + jsString(b64) + ")");
            });
        }

        /**
         * Broker login in a full-screen dialog (HDFC Sky). When the page goes to redirectPrefix, or to any
         * non-broker page carrying a request_token, the full URL is handed to window[cb](url).
         */
        @JavascriptInterface
        public void brokerLogin(final String url, final String redirectPrefix, final String cb) {
            final String fn = cb == null || !cb.matches("[A-Za-z_$][A-Za-z0-9_$]*") ? "__brokerUrl" : cb;
            runOnUiThread(() -> {
                final Dialog d = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                final WebView w = new WebView(MainActivity.this);
                final boolean[] done = {false};
                WebSettings ws = w.getSettings();
                ws.setJavaScriptEnabled(true);
                ws.setDomStorageEnabled(true);
                w.setWebViewClient(new WebViewClient() {
                    private boolean handle(String u) {
                        if (u == null) return false;
                        String host = "";
                        try { host = String.valueOf(Uri.parse(u).getHost()); } catch (Exception ignored) { }
                        boolean hit = (redirectPrefix != null && !redirectPrefix.isEmpty() && u.startsWith(redirectPrefix))
                                || ((u.contains("request_token=") || u.contains("requestToken=")) && !host.endsWith("hdfcsky.com") && !host.endsWith("hdfcsec.com"));
                        if (!hit) return false;
                        if (!done[0]) {
                            done[0] = true;
                            if (web != null) web.evaluateJavascript("window." + fn + " && window." + fn + "(" + jsString(u) + ")", null);
                            d.dismiss();
                        }
                        return true;
                    }
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                        return handle(req.getUrl().toString());
                    }
                    @Override
                    public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                        if (handle(u)) v.stopLoading();
                    }
                });
                d.setContentView(w);
                d.setOnDismissListener(x -> {
                    if (!done[0] && web != null) web.evaluateJavascript("window." + fn + " && window." + fn + "('')", null);
                    w.destroy();
                });
                d.show();
                w.loadUrl(url);
            });
        }

        /** Voice question: opens the phone's speech recogniser (Indian English); the text goes to window.__voice(text). */
        @JavascriptInterface
        public void voice() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Ask EV: e.g. will 25100 CE go up?");
                    startActivityForResult(i, REQ_VOICE);
                } catch (Exception e) {
                    if (web != null) web.evaluateJavascript("window.__voice && window.__voice('', 'Voice input is not available on this phone')", null);
                }
            });
        }

        @JavascriptInterface
        public void wsSend(String id, String text) { WebSocket w = sockets.get(id); if (w != null) w.send(text); }

        @JavascriptInterface
        public void wsClose(String id) { WebSocket w = sockets.remove(id); if (w != null) w.close(1000, "bye"); }

        /** SHA-256 hex of a UTF-8 string (Flattrade token exchange). */
        @JavascriptInterface
        public String sha256(String s) {
            try {
                byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b));
                return sb.toString();
            } catch (Exception e) {
                return "";
            }
        }

        /**
         * Opens the broker login page in a full-screen dialog. When the page redirects to
         * redirectPrefix, the "code" and "client" query values are handed to window.__ftCode(code, client).
         */
        @JavascriptInterface
        public void ftLogin(final String url, final String redirectPrefix) {
            runOnUiThread(() -> {
                final Dialog d = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                final WebView w = new WebView(MainActivity.this);
                final boolean[] done = {false};
                WebSettings ws = w.getSettings();
                ws.setJavaScriptEnabled(true);
                ws.setDomStorageEnabled(true);
                w.setWebViewClient(new WebViewClient() {
                    private boolean handle(String u) {
                        if (u == null || !u.startsWith(redirectPrefix)) return false;
                        if (!done[0]) {
                            done[0] = true;
                            Uri uri = Uri.parse(u);
                            final String js = "window.__ftCode && window.__ftCode(" + jsString(uri.getQueryParameter("code"))
                                    + "," + jsString(uri.getQueryParameter("client")) + ")";
                            if (web != null) web.evaluateJavascript(js, null);
                            d.dismiss();
                        }
                        return true;
                    }
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                        return handle(req.getUrl().toString());
                    }
                    @Override
                    public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) {
                        if (handle(u)) v.stopLoading();
                    }
                });
                d.setContentView(w);
                d.setOnDismissListener(x -> {
                    if (!done[0] && web != null) web.evaluateJavascript("window.__ftCode && window.__ftCode('', '')", null);
                    w.destroy();
                });
                d.show();
                w.loadUrl(url);
            });
        }

        /** level: critical | important | info. Critical = alarm sound (repeats until opened) + full-screen pop-up. */
        @JavascriptInterface
        public void alert(String levelTone, String title, String text) {
            String level = levelTone, tone = "";
            int ci = levelTone == null ? -1 : levelTone.indexOf(':');
            if (ci >= 0) { level = levelTone.substring(0, ci); tone = levelTone.substring(ci + 1); }
            if (("critical".equals(level) || "critical_quiet".equals(level)) && !inForeground) {
                final String t1 = title, t2 = text, tn = tone;
                runOnUiThread(() -> showOverlay(t1, t2, tn));      // pop-up over other apps when EV Pulse is minimized
            }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
            boolean quiet = "critical_quiet".equals(level);
            boolean crit = "critical".equals(level) || quiet;
            String ch = crit && !quiet ? CH_CRIT : crit || "important".equals(level) ? CH_IMP : CH_INFO;
            Intent open = new Intent(MainActivity.this, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            open.putExtra("critical", crit);
            PendingIntent pi = PendingIntent.getActivity(MainActivity.this, crit ? 7 : 6, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder b = new Notification.Builder(MainActivity.this, ch)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            if (crit) {
                b.setCategory(Notification.CATEGORY_ALARM).setFullScreenIntent(pi, true).setTimeoutAfter(3 * 60 * 1000);
            }
            Notification n = b.build();
            if (crit && !quiet) n.flags |= Notification.FLAG_INSISTENT;   // keep ringing until the user opens/clears it
            int id = notifId.incrementAndGet();
            if (crit) critIds.add(id);
            getSystemService(NotificationManager.class).notify(id, n);
        }

        @JavascriptInterface
        public boolean overlayOk() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(MainActivity.this); }

        /** Opens "Display over other apps" for this app. */
        @JavascriptInterface
        public void requestOverlay() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { } }
            });
        }

        /** Stops the ringing critical alerts (called when the user dismisses the in-app pop-up). */
        @JavascriptInterface
        public void clearAlerts() {
            NotificationManager nm = getSystemService(NotificationManager.class);
            synchronized (critIds) { for (Integer i : critIds) nm.cancel(i); critIds.clear(); }
        }

        /** Opens the system page that allows full-screen alerts (Android 14+) or the app's notification settings. */
        @JavascriptInterface
        public void openAlertSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i;
                    if (Build.VERSION.SDK_INT >= 34) {
                        i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName()));
                    } else {
                        i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    }
                    startActivity(i);
                } catch (Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public boolean canFullScreen() {
            if (Build.VERSION.SDK_INT < 34) return true;
            return getSystemService(NotificationManager.class).canUseFullScreenIntent();
        }

        /** Share text (CSV export) through any app: WhatsApp, Gmail, Drive... */
        /**
         * Saves a text file (CSV) to Downloads/EV Pulse. Returns "ok|<where>" or "err|<reason>".
         * A UTF-8 byte-order mark is added so Excel shows ₹ and other symbols correctly.
         */
        @JavascriptInterface
        public String saveFile(String path, String mime, String text) {
            try {
                String sub = "", name = path;
                int sl = path.lastIndexOf('/');
                if (sl > 0) { sub = "/" + path.substring(0, sl).replaceAll("[^A-Za-z0-9 _-]", ""); name = path.substring(sl + 1); }
                byte[] body = text.getBytes(StandardCharsets.UTF_8);
                byte[] bom = new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EV Pulse" + sub);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "err|Could not create the file";
                    try (OutputStream o = getContentResolver().openOutputStream(uri)) { o.write(bom); o.write(body); }
                    lastSaved = uri; lastMime = mime;
                    return "ok|Downloads/EV Pulse" + sub + "/" + name;
                }
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2));
                    return "err|Allow storage access, then tap Download again";
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EV Pulse" + sub);
                if (!dir.exists() && !dir.mkdirs()) return "err|Could not create the Downloads folder";
                File f = new File(dir, name);
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(bom); o.write(body); }
                lastSaved = null;
                return "ok|Downloads/EV Pulse" + sub + "/" + name;
            } catch (Exception e) {
                return "err|" + e.getMessage();
            }
        }

        // ---------------- per-second recorder: files in the app's private folder ----------------
        private File recDir() { File d = new File(getFilesDir(), "rec"); if (!d.exists()) d.mkdirs(); return d; }
        private boolean safeName(String n) { return n != null && n.matches("[A-Za-z0-9_.-]{3,80}"); }

        /** Append text to a recorder file. Names ending .gz get a new gzip member per call (gzip readers join them). */
        @JavascriptInterface
        public String recAppend(String name, String text) {
            if (!safeName(name)) return "err|bad name";
            try {
                File f = new File(recDir(), name);
                byte[] b = text.getBytes(StandardCharsets.UTF_8);
                try (FileOutputStream fo = new FileOutputStream(f, true)) {
                    if (name.endsWith(".gz")) { java.util.zip.GZIPOutputStream g = new java.util.zip.GZIPOutputStream(fo); g.write(b); g.finish(); }
                    else fo.write(b);
                }
                return "ok|" + f.length();
            } catch (Exception e) { return "err|" + e.getMessage(); }
        }

        /** JSON list of recorder files: [{n, size, t}] */
        @JavascriptInterface
        public String recList() {
            try {
                org.json.JSONArray a = new org.json.JSONArray();
                File[] fs = recDir().listFiles();
                if (fs != null) for (File f : fs) { JSONObject o = new JSONObject(); o.put("n", f.getName()); o.put("size", f.length()); o.put("t", f.lastModified()); a.put(o); }
                return a.toString();
            } catch (Exception e) { return "[]"; }
        }

        /** Read a small recorder file (plain text; .gz is unpacked). Capped at maxBytes. */
        @JavascriptInterface
        public String recRead(String name, int maxBytes) {
            if (!safeName(name)) return "";
            try {
                File f = new File(recDir(), name); if (!f.exists()) return "";
                InputStream in = new java.io.FileInputStream(f);
                if (name.endsWith(".gz")) in = new java.util.zip.GZIPInputStream(in);
                ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n, tot = 0;
                while ((n = in.read(buf)) != -1) { int k = Math.min(n, Math.max(0, maxBytes - tot)); out.write(buf, 0, k); tot += k; if (tot >= maxBytes) break; }
                in.close();
                return new String(out.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception e) { return ""; }
        }

        /**
         * Check a tick file's hash chain: every "#BLOCK,<label>,<rows>,<hash>" line must equal
         * sha256(previous hash + the lines since the previous marker, each ending in newline). Returns JSON.
         */
        @JavascriptInterface
        public String recVerify(String name) {
            JSONObject r = new JSONObject();
            try {
                File f = new File(recDir(), name);
                if (!safeName(name) || !f.exists()) { r.put("ok", false); r.put("why", "file not found"); return r.toString(); }
                InputStream in = new java.io.FileInputStream(f);
                if (name.endsWith(".gz")) in = new java.util.zip.GZIPInputStream(in);
                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(in, StandardCharsets.UTF_8));
                String line, prev = ""; StringBuilder blk = new StringBuilder(); int blocks = 0, rows = 0; boolean ok = true; String bad = "";
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("#BLOCK,")) {
                        String[] p = line.split(",");
                        String want = p.length >= 4 ? p[3].trim() : "";
                        byte[] d = md.digest((prev + blk.toString()).getBytes(StandardCharsets.UTF_8));
                        StringBuilder hx = new StringBuilder(); for (byte b : d) hx.append(String.format("%02x", b));
                        if (!hx.toString().equals(want)) { ok = false; bad = p.length > 1 ? p[1] : "?"; break; }
                        prev = want; blk.setLength(0); blocks++;
                    } else if (!line.startsWith("#GAP") && !line.startsWith("time,")) { blk.append(line).append('\n'); rows++; }
                }
                br.close();
                r.put("ok", ok); r.put("blocks", blocks); r.put("rows", rows); r.put("badAt", bad); r.put("tail", blk.length() > 0 ? "last block not sealed yet" : "");
                byte[] fd = MessageDigest.getInstance("SHA-256").digest(readAll(new java.io.FileInputStream(f)));
                StringBuilder fx = new StringBuilder(); for (byte b : fd) fx.append(String.format("%02x", b)); r.put("fileHash", fx.toString());
            } catch (Exception e) { try { r.put("ok", false); r.put("why", e.getMessage()); } catch (Exception ignored) { } }
            return r.toString();
        }

        /** Copy a recorder file to Downloads/EV Pulse/Recorder. Returns ok|path or err|why. */
        @JavascriptInterface
        public String recExport(String name) {
            if (!safeName(name)) return "err|bad name";
            try {
                File f = new File(recDir(), name); if (!f.exists()) return "err|file not found";
                String mime = name.endsWith(".gz") ? "application/gzip" : "text/csv";
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EV Pulse/Recorder");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (uri == null) return "err|Could not create the file";
                    try (OutputStream o = getContentResolver().openOutputStream(uri); InputStream in = new java.io.FileInputStream(f)) {
                        byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) != -1) o.write(buf, 0, n);
                    }
                    lastSaved = uri; lastMime = mime;
                    return "ok|Downloads/EV Pulse/Recorder/" + name;
                }
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2));
                    return "err|Allow storage access, then tap Download again";
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EV Pulse/Recorder");
                if (!dir.exists() && !dir.mkdirs()) return "err|Could not create the folder";
                File out = new File(dir, name);
                try (FileOutputStream o = new FileOutputStream(out); InputStream in = new java.io.FileInputStream(f)) {
                    byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) != -1) o.write(buf, 0, n);
                }
                lastSaved = null;
                return "ok|Downloads/EV Pulse/Recorder/" + name;
            } catch (Exception e) { return "err|" + e.getMessage(); }
        }

        /** Delete recorder files whose name carries a date (yyyy-mm-dd) older than keepFrom. Returns count. */
        @JavascriptInterface
        public int recPrune(String keepFrom) {
            int n = 0; File[] fs = recDir().listFiles(); if (fs == null) return 0;
            java.util.regex.Pattern p = java.util.regex.Pattern.compile("(\\d{4}-\\d{2}-\\d{2})");
            for (File f : fs) { java.util.regex.Matcher m = p.matcher(f.getName()); if (m.find() && m.group(1).compareTo(keepFrom) < 0 && f.delete()) n++; }
            return n;
        }

        /** Opens the last saved file in Excel / Sheets / a text app (Android 10+). */
        @JavascriptInterface
        public void openSaved() {
            final Uri u = lastSaved; if (u == null) return;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, lastMime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, "Open with"));
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void shareText(final String subject, final String text) {
            runOnUiThread(() -> {
                Intent s = new Intent(Intent.ACTION_SEND);
                s.setType("text/plain");
                s.putExtra(Intent.EXTRA_SUBJECT, subject);
                s.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(s, subject));
            });
        }

        @JavascriptInterface
        public void notify(String title, String text) {
            Notification n = new Notification.Builder(MainActivity.this, CH_ALERTS)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setAutoCancel(true)
                    .setContentIntent(openAppIntent())
                    .build();
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            nm.notify(notifId.incrementAndGet(), n);
        }

        @JavascriptInterface
        public void setBackground(boolean on) {
            getSharedPreferences("evd", MODE_PRIVATE).edit().putBoolean("bg", on).apply();
            Intent i = new Intent(MainActivity.this, TrackService.class);
            if (on) {
                startForegroundService(i);
            } else {
                stopService(i);
            }
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
            });
        }

        /** true when Android will not put the app to sleep (battery optimisation off for this app) */
        @JavascriptInterface
        public boolean batteryOk() {
            try {
                android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
            } catch (Exception e) { return false; }
        }

        /** Shows the system "Allow app to run in background?" dialog (one tap). */
        @JavascriptInterface
        public void requestBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception ignored) { }
                }
            });
        }

        /** true when the app may post notifications */
        @JavascriptInterface
        public boolean notifOk() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
            return getSystemService(NotificationManager.class).areNotificationsEnabled();
        }

        /** Asks for the notification permission again, or opens the app's notification settings. */
        @JavascriptInterface
        public void requestNotif() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        && shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else {
                    try { startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())); } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void openBatterySettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception ignored) { }
                }
            });
        }
    }

    private void httpV4(final String id, final String method, final String url, final String headersJson, final String body) {
        pool.execute(() -> {
            int status = 0;
            String text;
            try {
                Request.Builder rb = new Request.Builder().url(url);
                JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                String ctype = "application/octet-stream";
                Iterator<String> keys = h.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    if (k.equalsIgnoreCase("Content-Type")) ctype = h.getString(k);
                    rb.header(k, h.getString(k));
                }
                if ("GET".equals(method) || body == null || body.isEmpty()) rb.method(method, "GET".equals(method) ? null : RequestBody.create(new byte[0], (MediaType) null));
                else rb.method(method, RequestBody.create(body.getBytes(StandardCharsets.UTF_8), MediaType.parse(ctype)));
                try (Response r = ok4.newCall(rb.build()).execute()) {
                    status = r.code();
                    text = r.body() != null ? r.body().string() : "";
                }
            } catch (Exception e) {
                status = 0;
                text = e.getClass().getSimpleName() + ": " + e.getMessage();
            }
            String b64 = Base64.encodeToString(text.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            jsCall("window.__httpCb && window.__httpCb(" + jsString(id) + "," + status + "," + jsString(b64) + ")");
        });
    }

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close();
        return out.toByteArray();
    }
}
