package com.oitracker.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Wakes EV Pulse on trading days at 8:50 AM (GIFT Nifty + morning call lock at 9:00)
 * and 3:43 PM (grading, closing-auction record and the automatic end-of-day save),
 * so the records are made without anyone opening the app. Also re-arms itself after a reboot.
 */
public class WakeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent intent) {
        String act = intent == null ? null : intent.getAction();
        boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(act) || "android.intent.action.MY_PACKAGE_REPLACED".equals(act);
        boolean bg = c.getSharedPreferences("evd", Context.MODE_PRIVATE).getBoolean("bg", true);
        if (!boot && bg) {
            try {
                Intent s = new Intent(c, TrackService.class);
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
            } catch (Exception ignored) { }
            if (!MainActivity.alive) {
                try {
                    Intent a = new Intent(c, MainActivity.class);
                    a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    a.putExtra("auto", true);
                    c.startActivity(a);
                } catch (Exception ignored) { }
            }
        }
        schedule(c);
    }

    /** next weekday 08:50 or 15:43 IST */
    static void schedule(Context c) {
        try {
            Calendar now = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"));
            Calendar best = null;
            for (int d = 0; d < 8 && best == null; d++) {
                for (int[] hm : new int[][]{{8, 50}, {15, 43}}) {
                    Calendar t = (Calendar) now.clone();
                    t.add(Calendar.DAY_OF_YEAR, d);
                    t.set(Calendar.HOUR_OF_DAY, hm[0]); t.set(Calendar.MINUTE, hm[1]); t.set(Calendar.SECOND, 0); t.set(Calendar.MILLISECOND, 0);
                    int wd = t.get(Calendar.DAY_OF_WEEK);
                    if (wd == Calendar.SATURDAY || wd == Calendar.SUNDAY) continue;
                    if (t.getTimeInMillis() <= now.getTimeInMillis() + 30000) continue;
                    best = t; break;
                }
            }
            if (best == null) return;
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = PendingIntent.getBroadcast(c, 9, new Intent(c, WakeReceiver.class).setAction("com.oitracker.app.WAKE"),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best.getTimeInMillis(), pi);
        } catch (Exception ignored) { }
    }
}
